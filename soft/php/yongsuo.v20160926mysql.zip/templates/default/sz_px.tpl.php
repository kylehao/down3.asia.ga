<table cellpadding="0" border="0" style="border-collapse: collapse"><tbody><tr valign="top"><td>
<div id="ysleft">
<h2>空间后台操作菜单</h2>
<strong>主要操作</strong>
<ul class="yslb3">
<li><a href="/user.php">空间状态</a></li>
<li><a href="/user.php?act=sj">空间升级</a></li>
<!--        <li><a href="/user.php?act=yq">空间延期</a></li>
-->        </ul>
<strong>账户管理</strong>
<ul class="yslb3">
<li><a href="/zh.php">账户充值</a></li>
<li><a href="/zh.php?act=cz">充值记录</a></li>
<li><a href="/zh.php?act=xf">消费记录</a></li>
</ul>
<strong>空间设置</strong>
<ul class="yslb3">
<li><a href="/sz.php">常规设置</a></li>
<li><a href="/sz.php?act=qx">访客权限</a></li>
<li><a href="/sz.php?act=lj">首页链接</a></li>
<li><a href="/sz.php?act=px" id="xz">目录排序方式</a></li>
<li><a href="/sz.php?act=fg">空间风格</a></li>
<li><a href="/sz.php?act=zl">设置个人资料</a></li>
</ul>
<strong>空间安全</strong>
<ul class="yslb3">
<li><a href="/aq.php">设置登录密码</a></li>
<li><a href="/aq.php?act=glmm">修改管理密码</a></li>
<!--<li><a href="/aq.php?act=xgyx">修改邮箱</a></li>-->
<li><a href="/aq.php?act=szmb">设置密保</a></li>
<li><a href="/aq.php?act=xgmb">修改密保</a></li>
<!--<li><a href="/aq.php?act=wjmm">忘记密码</a></li>-->
</ul>
<strong>其它</strong>
<ul class="yslb3">
<li><a href="/mmcx.php">加密目录密码查询</a></li>
<li><a href="/ly.php">留言管理</a></li>
</ul></div>
</td><td>
<div id="ysright">
<h1><label class="dl1">用户名：<a><font color="green"><?=$pd_username?></font></a>  账户余额：<?=$userinfo['wealth']?>元  <a href="/zh.php">账户充值</a> <a href="/account.php?action=logout">退出</a></label><img width="32" height="32" border="0" alt="" src="/images/tools.gif">设置目录排序方式</h1>
<div class="ysdb2">
<form id="ctl00" action="sz.php?act=pxe" method="post" name="ctl00">
<table width="100%" border="1">
<tbody><tr>
<td width="95" class="tdbt">1.按时间排序</td>
<td>
<span class="cc"><input type="radio" <?php  if($userinfo['mlpx']==1){echo ' checked="checked"';}  ?> value="1" name="aa" id="1"><label for="p1">升序</label></span>
&nbsp;&nbsp;&nbsp;&nbsp;
<span class="cc"><input type="radio" <?php  if($userinfo['mlpx']==2){echo ' checked="checked"';}  ?> value="2" name="aa" id="p2"><label for="p2">降序</label></span>
</td>
</tr>
<tr>
<td width="95" class="tdbt">2.按标题排序</td>
<td>
<span class="cc"><input type="radio" <?php  if($userinfo['mlpx']==3){echo ' checked="checked"';}  ?> value="3" name="aa" id="p3"><label for="p3">升序</label></span>
&nbsp;&nbsp;&nbsp;&nbsp;
<span class="cc"><input type="radio" <?php  if($userinfo['mlpx']==4){echo ' checked="checked"';}  ?> value="4" name="aa" id="p4"><label for="p4">降序</label></span>
</td>
</tr>
<tr>
<td width="95" class="tdbt">3.按署名排序</td>
<td>
<span class="cc"><input type="radio" <?php  if($userinfo['mlpx']==5){echo ' checked="checked"';}  ?> value="5" name="aa" id="p5"><label for="p5">升序</label></span>
&nbsp;&nbsp;&nbsp;&nbsp;
<span class="cc"><input type="radio" <?php  if($userinfo['mlpx']==6){echo ' checked="checked"';}  ?> value="6" name="aa" id="p6"><label for="p6">降序</label></span>
</td>
</tr>
</tbody></table>
<p><input type="submit" id="bu1" onclick="return confirm('请确认是否提交设置');" value="提交设置" name="bu1"></p>
</form>
</div>
<ul class="yslb2">
<li>正确设置"目录排序方式"能有效的组织您的目录布局,。"升序"是指由小到大，"降序"则相反</li>
<li>如果您的空间用于给客户传送文件，您可以设置成"按时间降序"，则新建的目录会出现在上面，易于客户接收</li>
<li>如果您的空间用于自己收藏文件，则可以设置成按标题或按署名排序。这样相同或相似的标题的目录会排在一起。例如您可以把标题写成：歌曲专集1、歌曲专集2、常用软件1、常用软件2...您也可以把目录署名当作类别来整理您的目录</li>
</ul>
</div>
</td>
</tr>
</tbody>
</table>