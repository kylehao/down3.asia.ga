<table cellpadding="0" border="0" style="border-collapse: collapse"><tbody><tr valign="top"><td>
<div id="ysleft">
<h2>空间后台操作菜单</h2>
<strong>主要操作</strong>
<ul class="yslb3">
<li><a href="/user.php">空间状态</a></li>
<li><a href="/user.php?act=sj" id="xz">空间升级</a></li>
<!--        <li><a href="/user.php?act=yq">空间延期</a></li>
-->        </ul>
<strong>账户管理</strong>
<ul class="yslb3">
<li><a href="/zh.php">账户充值</a></li>
<li><a href="/zh.php?act=cz">充值记录</a></li>
<li><a href="/zh.php?act=xf">消费记录</a></li>
</ul>
<strong>空间设置</strong>
<ul class="yslb3">
<li><a href="/sz.php">常规设置</a></li>
<li><a href="/sz.php?act=qx">访客权限</a></li>
<li><a href="/sz.php?act=lj">首页链接</a></li>
<li><a href="/sz.php?act=px">目录排序方式</a></li>
<li><a href="/sz.php?act=fg">空间风格</a></li>
<li><a href="/sz.php?act=zl">设置个人资料</a></li>
</ul>
<strong>空间安全</strong>
<ul class="yslb3">
<li><a href="/aq.php">设置登录密码</a></li>
<li><a href="/aq.php?act=glmm">修改管理密码</a></li>
<!--<li><a href="/aq.php?act=xgyx">修改邮箱</a></li>-->
<li><a href="/aq.php?act=szmb">设置密保</a></li>
<li><a href="/aq.php?act=xgmb">修改密保</a></li>
<!--<li><a href="/aq.php?act=wjmm">忘记密码</a></li>-->
</ul>
<strong>其它</strong>
<ul class="yslb3">
<li><a href="/mmcx.php">加密目录密码查询</a></li>
<li><a href="/ly.php">留言管理</a></li>
</ul></div>
</td><td>
<script type="text/javascript">
function __doPostBack(eventTarget, eventArgument) {
//$('#ctl00').submit();
$('#status').val(eventTarget);
}
$(document).ready(function(){
$("input[type='radio']").click(function(){
$("#bu1").attr("disabled",'');
});
});
</script>
<form name="ctl00" method="post" action="/user.php?act=sjs" id="ctl00">
<input type="hidden" name="status" id="status" value="" />
<div id="ysright">
<h1><label class="dl1">用户名：<a><font color="green"><?=$pd_username?></font></a>  账户余额：<?=$userinfo['wealth']?>元  <a href="/zh.php">账户充值</a> <a href="/account.php?action=logout">退出</a></label><img width="32" height="32" border="0" alt="" src="/images/sj.gif">空间升级</h1>
<p><b>当前空间类型：</b><br><br>
<span style="color:Blue; padding-left:30px;"><span id="la_kj"><?=$pd_group_name?>[<?=$diskinfo['max_storage']?>]</span></span>
<span id="la_ts"></span>
<br><br><b>请选择所需类型的期限：</b>
</p>
<div style="margin-left:30px;">
<table style="border:1px solid #335374;border-collapse:collapse;background-color:#EFEFEF;">
<tbody><tr bgcolor="#ffffff">
<td class="bg" style="width:140px;">空间类型</td>
<td class="bg">一月付</td>
<td class="bg">半年付</td>
<td class="bg">一年付</td>
<td class="bg">两年付</td>
</tr>
<?php 
foreach($result as $k => $v){
$color = ($k%2 ==0) ? '' :'#ffffff';
?>
<tr bgcolor="<?=$color?>">
<td class="bg"><?=$v['group_name']?>(<?=$v['max_storage']?>)</td>
<td class="bg">
<?php 
if($v['jg_yy']==0){
?>
/
<?php 
}else{
?>
<span class="cc"><input type="radio" value="<?=$v['gid']?>-1" name="kjstatus"><label for="a1"><?=$v['jg_yy']?>元</label></span>
<?php 
}
?>
</td>
<td class="bg">
<?php 
if($v['jg_bn']==0){
?>
/
<?php 
}else{
?>
<span class="cc"><input type="radio" value="<?=$v['gid']?>-2" name="kjstatus"><label for="a1"><?=$v['jg_bn']?>元</label></span>
<?php 
}
?>
</td>
<td class="bg">
<?php 
if($v['jg_yn']==0){
?>
/
<?php 
}else{
?>
<span class="cc"><input type="radio" value="<?=$v['gid']?>-3" name="kjstatus"><label for="a1"><?=$v['jg_yn']?>元</label></span>
<?php 
}
?>
</td>
<td class="bg">
<?php 
if($v['jg_ln']==0){
?>
/
<?php 
}else{
?>
<span class="cc"><input type="radio" value="<?=$v['gid']?>-4" name="kjstatus"><label for="a1"><?=$v['jg_ln']?>元</label></span>
<?php 
}
?>
</td>
</tr>
<?php 
}
unset($result11);
?>
</tbody></table>
</div>
<p><span id="sm"></span></p>
<p>
<span id="ysts"><font color="green">请选择您要升级的空间</font></span>
<input type="submit" onclick="return confirm('升级所需费用将从您的账户余额中扣除，请确认是否进行空间升级！');" disabled="disabled" id="bu1" value="确认升级" name="bu1">
</p>
<ul class="yslb2">
<li>您的账户余额为:<b><?=$userinfo['wealth']?></b>元 <a href="/zh.php">账户充值</a></li>
<li>升级前请先查看<a href="/list_cp.php">Ｅ盘产品介绍</a></li>
</ul>
</div>
</form>
</td>
</tr>
</tbody>
</table>