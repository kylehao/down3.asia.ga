<hr /><td height="50" align="center"><?=$footer?></td>
<!--<hr /><td height="50" align="center"><br/>Copyright© 2015-2016 海诚Ｅ盘（pan.haic.cc）_网络存储系统 海诚Ｅ盘工作室版权所有，并保留所有权利<br><br></td>