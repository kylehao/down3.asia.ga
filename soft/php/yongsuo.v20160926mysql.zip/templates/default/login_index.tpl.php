<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title><?=$userinfo['t1']?>Ｅ盘登录</title>
</head>
<script language="javascript">
function initIt() {
document.forms[0].teqtbz.focus();
}
onload = initIt;
function tx() { 
alert("请打开空间登录管理区 在设置个人资料里面设置:联系QQ或者MSN");
}
</script>
<script language="javascript">
function initIt(){document.forms[0].teqtbz.focus();}
onload = initIt;
</script>
<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0">
<form name="ctl00" method="post" action="l.php?name=<?=$name?>&act=display" id="ctl00">
<table border="0" width="100%" cellspacing="0" cellpadding="0" height="100%">
<tr>
<td height="30" bgcolor="#0066B3">
<p align="right"><span style="font-size: 9pt">
</span>&nbsp;</td>
</tr>
<tr>
<td valign="top">
<h2 align="center" style="margin-top:40px;"><font color="#000080"><span id="l_dwmc"><?=$userinfo['t1']?></span></font></h2>
<div align="center">
<div style="border:1px solid green;width:307px;">
<table border="0" width="100%" cellspacing="0" cellpadding="3" bgcolor="#E6E7E8" bordercolor="#800080">
<tr>
<td width="124" bordercolor="#E6E7E8">
</td>
<td bordercolor="#E6E7E8" width="160">
</td>
</tr>
<tr>
<td width="124" bordercolor="#E6E7E8">
<p align="right"><font color="#000080">用户名:</font></td>
<td bordercolor="#E6E7E8" width="160">
<font color="#0000FF"><span id="L_dlmc"><?=$name?></span></font></td>
</tr>
<tr>
<td width="124" bordercolor="#E6E7E8">
<p align="right"><font color="#000080">
<span style="font-size: 12pt">登录密码:</span></font></td>
<td bordercolor="#E6E7E8" width="160">
<input name="teqtbz" type="password" id="teqtbz" style="width:100px;" />
</td>
</tr>
<tr>
<td colspan="2" bordercolor="#E6E7E8" height="50">
<p align="center">
<span id="l_czts"><font color="red"><?=$error?></font></span>
<input type="submit" name="b_dl" value="登录Ｅ盘" id="b_dl" />
</tr>
</table>
</div>
</br>
<div align="center"><span style="font-size: 13px">客服QQ：<?=$userinfo['zl_teqq']?></span></div>
</div>
</td>
</tr>
<tr><td height="10"></td></tr>
<tr><td height="10" bgcolor="#0066B3"></td></tr>
<!--<tr><td height="10" bgcolor="#43B6D3"></td></tr> -->
<!--<tr><td height="50" bgcolor="#E6E7E8"></td></tr> -->
<tr><td height="50" align="center">Copyright© 2015-2016 海诚Ｅ盘（pan.haic.cc）_网络存储系统 海诚Ｅ盘工作室版权所有，并保留所有权利 <script src="https://s4.cnzz.com/z_stat.php?id=1256185585&web_id=1256185585" language="JavaScript"></script></td></tr>
</table>
</form>
</body>
</html>