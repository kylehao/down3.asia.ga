<div id="container">
<div class="tit"><?=$space_title?></div>
<div class="layout_box">
<div class="l">
<script language="javascript">
$(document).ready(function(){
$("#f_tab tr").mouseover(function(){
$(this).addClass("alt_bg");
}).mouseout(function(){
$(this).removeClass("alt_bg");
});
});
</script>
<br />
<table align="center" width="98%" cellpadding="0" cellspacing="0" border="0" id="f_tab" class="td_line">
<?php 
if(count($files_array)){
?>
<tr>
<td width="50%" class="bold"><?=__('file_name')?></td>
<td align="center" class="bold"><?=__('file_size')?></td>
<td align="center" width="150" class="bold"><?=__('file_upload_time')?></td>
</tr>
<?php 
foreach($files_array as $k => $v){
$color = ($k%2 ==0) ? 'color1' :'color4';
?>
<tr class="<?=$color?>">
<td>&nbsp;<?=file_icon($v['file_extension'])?>&nbsp;
<?php if($v['is_locked']){ ?>
<span class="txtgray" title="<?=__('file_locked')?>"><?=$v['file_name']?> <?=$v['file_description']?></span>
<?php }elseif($v['is_image']){ ?>
<a href="<?=$v['a_viewfile']?>" id="p_<?=$k?>" target="_blank" ><?=$v['file_name']?></a>&nbsp;<span class="txtgray"><?=$v['file_description']?></span><br />
<div id="c_<?=$k?>" class="menu_thumb"><img src="<?=$v['file_thumb']?>" /></div>
<script type="text/javascript">on_menu('p_<?=$k?>','c_<?=$k?>','x','');</script>
<?php }else{ ?>
<a href="<?=$v['a_viewfile']?>" target="_blank" ><?=$v['file_name']?></a> <span class="txtgray"><?=$v['file_description']?></span>
<?php } ?>
</td>
<td align="center"><?=$v['file_size']?></td>
<td align="center" width="150"  class="txtgray"><?=$v['file_time']?></td>
</tr>
<?php 		
}
unset($files_array);
}else{	
?>
<tr>
<td colspan="6"><?=__('file_not_found')?></td>
</tr>
<?php 
}
?>
</table>
</div>
<div class="r">
<?php if($settings['show_hot_file_right']){ ?>
<br />
<div class="common_box">
<div class="tit2"><?=__('hot_file')?></div>
<ul>
<?php 
if(count($hot_file)){
foreach($hot_file as $v){
?>
<li><?=file_icon($v['file_extension'])?> <a href="<?=$v['a_viewfile']?>" target="_blank"><?=$v['file_name']?></a> <?=$v['file_views']?></li>
<?php 
}
unset($hot_file);
}
?>
</ul>
</div>
</div>
<div class="clear"></div>
<?php } ?>
<br />
<?php show_adv_data('adv_right'); ?>
</div>
</div>
