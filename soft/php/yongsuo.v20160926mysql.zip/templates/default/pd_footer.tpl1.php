<table width="100%" border="0" cellspacing="0" cellpadding="0" class="mt25 border2">
<tbody><tr>
<td ><table width="1050" border="0" align="center" cellpadding="0" cellspacing="0">
<tbody><tr>
<td height="50" align="center"><?=$footer?></td>
</tr>
<!--<tr>
<td><table width="1050" border="0" cellspacing="0" cellpadding="0">
<tbody><tr>
<td height="100" align="center"><a href="http://www.anquan.org/authenticate/cert/?site=www.ziyuane.cn&amp;at=business" target="_blank"><img src="images\index_r18_c8.jpg" width="124" height="47"></a>
</td>
<td align="center"><a href="http://webscan.360.cn/index/checkwebsite/url/www.ziyuane.cn" target="_blank"><img src="images\index_r18_c14.jpg" width="124" height="47"></a>
</td>
<td align="center"><a href="http://zhanzhang.anquan.org/physical/report/?domain=ziyuane.cn" target="_blank"><img src="http://zhanzhang.anquan.org/static/common/images/zhanzhang.ad19ee934b6f.png"></a>
</td>
<td align="center"><a href="http://www.qcloud.com" target="_blank"><img src="images\index_r18_c26.jpg" width="124" height="48"></a></td>
<td align="center"><a href="http://c.trustutn.org/s/ziyuane.cn" target="_blank"><img src="images\index_r19_c22.jpg" width="123" height="46"></a>
</td>
</tr>
</tbody></table></td>
</tr>
</tbody></table></td>
</tr> -->
</tbody></table>