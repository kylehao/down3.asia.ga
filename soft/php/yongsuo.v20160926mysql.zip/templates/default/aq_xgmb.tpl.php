<table cellpadding="0" border="0" style="border-collapse: collapse"><tbody><tr valign="top"><td>
<div id="ysleft">
<h2>空间后台操作菜单</h2>
<strong>主要操作</strong>
<ul class="yslb3">
<li><a href="/user.php">空间状态</a></li>
<li><a href="/user.php?act=sj">空间升级</a></li>
</ul>
<strong>账户管理</strong>
<ul class="yslb3">
<li><a href="/zh.php">账户充值</a></li>
<li><a href="/zh.php?act=cz">充值记录</a></li>
<li><a href="/zh.php?act=xf">消费记录</a></li>
</ul>
<strong>空间设置</strong>
<ul class="yslb3">
<li><a href="/sz.php">常规设置</a></li>
<li><a href="/sz.php?act=qx">访客权限</a></li>
<li><a href="/sz.php?act=lj">首页链接</a></li>
<li><a href="/sz.php?act=px">目录排序方式</a></li>
<li><a href="/sz.php?act=fg">空间风格</a></li>
<li><a href="/sz.php?act=zl">设置个人资料</a></li>
</ul>
<strong>空间安全</strong>
<ul class="yslb3">
<li><a href="/aq.php">设置登录密码</a></li>
<li><a href="/aq.php?act=glmm">修改管理密码</a></li>
<!--<li><a href="/aq.php?act=xgyx">修改邮箱</a></li>-->
<li><a href="/aq.php?act=szmb">设置密保</a></li>
<li><a href="/aq.php?act=xgmb" id="xz">修改密保</a></li>
<!--<li><a href="/aq.php?act=wjmm">忘记密码</a></li>-->
</ul>
<strong>其它</strong>
<ul class="yslb3">
<li><a href="/mmcx.php">加密目录密码查询</a></li>
<li><a href="/ly.php">留言管理</a></li>
</ul></div>
</td><td>
<style type="text/css">
.ta{border:2px solid #335374;width:400px;border-collapse:collapse;background-color:#EFEFEF;}
.ta td{padding:3px;border:1px solid #9C9C9C;}
</style>
<script language="javascript" type="text/javascript">
window.onload = function() { var ts = ""; if (ts != "") alert(ts); }
var ja_zs= 19;
function check() {
if (!confirm('请确认是否进行提交')) return false;
var ys = document.forms[0];
//原答案判断
if (ys.y_da1.value == '') { alert('原答案1不能为空！'); ys.y_da1.focus(); return false; }
if (ys.y_da1.value.length > 50) { alert('原答案1最多50个字符！'); ys.y_da1.focus(); return false; }
if (ys.y_da2.value == '') { alert('原答案2不能为空！'); ys.y_da2.focus(); return false; }
if (ys.y_da2.value.length > 50) { alert('原答案2最多50个字符！'); ys.y_da2.focus(); return false; }
if (checkzf(ys.y_da1.value) == 'F') { alert('原答案1不支持特殊字符的输入！'); ys.y_da1.focus(); return false; }
if (checkzf(ys.y_da2.value) == 'F') { alert('原答案2不支持特殊字符的输入！'); ys.y_da2.focus(); return false; }
//新问题和答案判断
if (ys.x_wt1.selectedIndex == ja_zs) {
if (ys.x_wenti1.value == '') { alert('自定义问题1不能为空。'); ys.x_wenti1.focus(); return false; }
if (ys.x_wenti1.value.length > 50) { alert('自定义区问题1至少3个字符，最多50个字符。'); ys.x_wenti1.focus(); return false; }
if (ys.x_wenti1.value.length < 3) { alert('自定义区问题1至少3个字符，最多50个字符。'); ys.x_wenti1.focus(); return false; }
if (checkzf(ys.x_wenti1.value) == 'F') { alert('自定义区问题1不支持特殊字符的输入。'); ys.x_wenti1.focus(); return false; }
}
if (ys.x_wt2.selectedIndex == ja_zs) {
if (ys.x_wenti2.value == '') { alert('自定义问题2不能为空。'); ys.x_wenti2.focus(); return false; }
if (ys.x_wenti2.value.length > 50) { alert('自定义区问题2至少3个字符，最多50个字符。'); ys.x_wenti2.focus(); return false; }
if (ys.x_wenti2.value.length < 3) { alert('自定义区问题2至少3个字符，最多50个字符。'); ys.x_wenti2.focus(); return false; }
if (checkzf(ys.x_wenti2.value) == 'F') { alert('自定义区问题2不支持特殊字符的输入。'); ys.x_wenti2.focus(); return false; }
}
if (ys.x_wt1.selectedIndex == ja_zs && ys.x_wt2.selectedIndex == ja_zs) { if (ys.x_wenti1.value == ys.x_wenti2.value) { alert('抱歉，不能设置2个相同的问题。'); return false; } }
if (ys.x_wt1.selectedIndex == 0) { alert('请选择新问题1。');  return false; }
if (ys.x_da1.value == '') { alert('新答案1不能为空。'); ys.x_da1.focus(); return false; }
if (ys.x_da1.value.length > 50) { alert('新答案1最多50个字符。'); ys.x_da1.focus(); return false; }
if (checkzf(ys.x_da1.value) == 'F') { alert('新答案1不支持特殊字符的输入。'); ys.x_da1.focus(); return false; }
if (ys.x_wt2.selectedIndex == 0) { alert('请选择新问题2。');  return false; }
if (ys.x_da2.value == '') { alert('新答案2不能为空。'); ys.x_da2.focus(); return false; }
if (ys.x_da2.value.length > 50) { alert('新答案2最多50个字符。'); ys.x_da2.focus(); return false; }
if (checkzf(ys.x_da2.value) == 'F') { alert('新答案2不支持特殊字符的输入。'); ys.x_da2.focus(); return false; }
if (ys.x_da2.value == ys.x_da1.value) { alert('2个新答案不能相同。'); ys.x_da1.focus(); return false; }
}
function dk() {
if (document.forms[0].x_wt1.selectedIndex == ja_zs) { document.getElementById("z_wt1").style.display = 'block'; document.getElementById("x_wenti1").focus(); }
else {
document.getElementById("z_wt1").style.display = 'none'; 
if (document.forms[0].x_wt1.selectedIndex != 0) {
if (document.forms[0].x_wt1.selectedIndex == document.forms[0].x_wt2.selectedIndex) {
alert('抱歉，不能选择2个相同的问题。');
document.forms[0].x_wt1.selectedIndex = 0;
}
}
}
}
function dk2() {
if (document.forms[0].x_wt2.selectedIndex == ja_zs) { document.getElementById("z_wt2").style.display = 'block'; document.getElementById("x_wenti2").focus(); }
else {
document.getElementById("z_wt2").style.display = 'none'; 
if (document.forms[0].x_wt2.selectedIndex != 0) {
if (document.forms[0].x_wt1.selectedIndex == document.forms[0].x_wt2.selectedIndex) {
alert('抱歉，不能选择2个相同的问题。');
document.forms[0].x_wt2.selectedIndex = 0;
}
}
}
}
function checkzf(nr) {
var zf = "/\\,'<>\"&"
for (i = 0; i <= zf.length - 1; i++) {
if (nr.indexOf(zf.substr(i, 1)) >= 0) { return "F" }
}
return "T"
}
</script>
<div id="ysright">
<h1><label class="dl1">用户名：<a><font color="green"><?=$pd_username?></font></a>  账户余额：<?=$userinfo['wealth']?>元  <a href="/zh.php">账户充值</a> <a href="/account.php?action=logout">退出</a></label><img width="32" height="32" border="0" alt="" src="/images/xg.gif">修改密码保护</h1>
<form id="ctl00" action="aq.php?act=xgmbe" method="post" name="ctl00">
<div>
<h3>请正确输入原问题答案。</h3>
<div style=" padding-left:50px;">
<table class="ta">
<tbody><tr>
<td width="50" class="tdbt">问题1：</td>
<td width="350"><span id="y_wt1"><?=$userinfo['wen1']?></span></td>
</tr>
<tr>
<td width="50" class="tdbt">答案：</td>
<td width="350"><input type="text" style="width:300px;" id="y_da1" name="y_da1"></td>
</tr>
<tr>
<td width="50" class="tdbt">问题2：</td>
<td width="350"><span id="y_wt2"><?=$userinfo['wen2']?></span></td>
</tr>
<tr>
<td width="50" class="tdbt">答案：</td>
<td width="350"><input type="text" style="width:300px;" id="y_da2" name="y_da2"></td>
</tr>
</tbody></table>
</div>
<h3>请设置新的密保问题。</h3>
<div style=" padding-left:50px;">
<table class="ta">
<tbody><tr>
<td width="50" class="tdbt">问题1：</td>
<td>
<select style="width:300px;" onchange="dk()" id="x_wt1" name="x_wt1">
<option value="请选择密保问题">请选择密保问题</option>
<option value="您母亲的姓名是？">您母亲的姓名是？</option>
<option value="您父亲的职业是？">您父亲的职业是？</option>
<option value="您配偶的生日是？">您配偶的生日是？</option>
<option value="您的学号（或工号）是？">您的学号（或工号）是？</option>
<option value="您母亲的生日是？">您母亲的生日是？</option>
<option value="您高中班主任的名字是？">您高中班主任的名字是？</option>
<option value="您父亲的姓名是？">您父亲的姓名是？</option>
<option value="您的出生地是？">您的出生地是？</option>
<option value="您小学班主任的名字是？">您小学班主任的名字是？</option>
<option value="您小学的校名是？">您小学的校名是？</option>
<option value="您父亲的生日是？">您父亲的生日是？</option>
<option value="您配偶的姓名是？">您配偶的姓名是？</option>
<option value="您母亲的职业是？">您母亲的职业是？</option>
<option value="您初中班主任的名字是？">您初中班主任的名字是？</option>
<option value="您配偶的职业是？">您配偶的职业是？</option>
<option value="您最熟悉的童年好友的名字是？">您最熟悉的童年好友的名字是？</option>
<option value="您最熟悉的学校宿舍好友的名字是？">您最熟悉的学校宿舍好友的名字是？</option>
<option value="对您影响最大的人的名字是？">对您影响最大的人的名字是？</option>
</select>
</td>
</tr>
<tr>
<td width="50" class="tdbt">答案：</td>
<td><input type="text" style="width:300px;" id="x_da1" name="x_da1"></td>
</tr>
<tr>
<td width="50" class="tdbt">问题2：</td>
<td>
<select style="width:300px;" onchange="dk2()" id="x_wt2" name="x_wt2">
<option value="请选择密保问题">请选择密保问题</option>
<option value="您母亲的姓名是？">您母亲的姓名是？</option>
<option value="您父亲的职业是？">您父亲的职业是？</option>
<option value="您配偶的生日是？">您配偶的生日是？</option>
<option value="您的学号（或工号）是？">您的学号（或工号）是？</option>
<option value="您母亲的生日是？">您母亲的生日是？</option>
<option value="您高中班主任的名字是？">您高中班主任的名字是？</option>
<option value="您父亲的姓名是？">您父亲的姓名是？</option>
<option value="您的出生地是？">您的出生地是？</option>
<option value="您小学班主任的名字是？">您小学班主任的名字是？</option>
<option value="您小学的校名是？">您小学的校名是？</option>
<option value="您父亲的生日是？">您父亲的生日是？</option>
<option value="您配偶的姓名是？">您配偶的姓名是？</option>
<option value="您母亲的职业是？">您母亲的职业是？</option>
<option value="您初中班主任的名字是？">您初中班主任的名字是？</option>
<option value="您配偶的职业是？">您配偶的职业是？</option>
<option value="您最熟悉的童年好友的名字是？">您最熟悉的童年好友的名字是？</option>
<option value="您最熟悉的学校宿舍好友的名字是？">您最熟悉的学校宿舍好友的名字是？</option>
<option value="对您影响最大的人的名字是？">对您影响最大的人的名字是？</option>
</select>
</td>
</tr>
<tr>
<td width="50" class="tdbt">答案：</td>
<td><input type="text" style="width:300px;" id="x_da2" name="x_da2"></td>
</tr>                    
</tbody></table>	                
</div>
<br>
<input type="submit" id="butj" onclick="return check();" value=" 确认修改 " name="butj">
<br><br>
<ul class="yslb2">
<li>请认真选择或填写问题、答案，此将成为您找回密码的凭据。</li>
<li>请牢记密保答案，如果遗失，将无法找回或重置。</li>
<li>问题和答案不支持字符（' &lt; &gt; / \ " &amp;）</li>
<li>密保答案不区分大小写</li>
</ul>
</div>
</form>
</div>
</td>
</tr>
</tbody>
</table>