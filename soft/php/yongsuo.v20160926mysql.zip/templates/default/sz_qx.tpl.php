<table cellpadding="0" border="0" style="border-collapse: collapse"><tbody><tr valign="top"><td>
<div id="ysleft">
<h2>空间后台操作菜单</h2>
<strong>主要操作</strong>
<ul class="yslb3">
<li><a href="/user.php">空间状态</a></li>
<li><a href="/user.php?act=sj">空间升级</a></li>
<!--        <li><a href="/user.php?act=yq">空间延期</a></li>
-->        </ul>
<strong>账户管理</strong>
<ul class="yslb3">
<li><a href="/zh.php">账户充值</a></li>
<li><a href="/zh.php?act=cz">充值记录</a></li>
<li><a href="/zh.php?act=xf">消费记录</a></li>
</ul>
<strong>空间设置</strong>
<ul class="yslb3">
<li><a href="/sz.php">常规设置</a></li>
<li><a href="/sz.php?act=qx" id="xz">访客权限</a></li>
<li><a href="/sz.php?act=lj">首页链接</a></li>
<li><a href="/sz.php?act=px">目录排序方式</a></li>
<li><a href="/sz.php?act=fg">空间风格</a></li>
<li><a href="/sz.php?act=zl">设置个人资料</a></li>
</ul>
<strong>空间安全</strong>
<ul class="yslb3">
<li><a href="/aq.php">设置登录密码</a></li>
<li><a href="/aq.php?act=glmm">修改管理密码</a></li>
<!--<li><a href="/aq.php?act=xgyx">修改邮箱</a></li>-->
<li><a href="/aq.php?act=szmb">设置密保</a></li>
<li><a href="/aq.php?act=xgmb">修改密保</a></li>
<!--<li><a href="/aq.php?act=wjmm">忘记密码</a></li>-->
</ul>
<strong>其它</strong>
<ul class="yslb3">
<li><a href="/mmcx.php">加密目录密码查询</a></li>
<li><a href="/ly.php">留言管理</a></li>
</ul></div>
</td><td>
<div id="ysright">
<h1><span id="yhztxs"><label class="dl1">用户名：<a><font color="green"><?=$pd_username?></font></a>  账户余额：<?=$userinfo['wealth']?>元  <a href="/zh.php">账户充值</a> <a href="/account.php?action=logout">退出</a></label></span><img width="32" height="32" border="0" alt="" src="/images/Tools.gif">常规设置</h1>
<div class="ysdb2">
<form id="ctl00" action="sz.php?act=qxs" method="post" name="ctl00">
<table width="100%" border="1" id="table1">
<tbody><tr>
<td width="179" class="tdbt">访客留言权限：</td>
<td>
<div onclick="document.forms[0].d1.checked=true;" style="cursor:hand;margin-top:5px;"><input type="radio" 
<?php 
if($userinfo['ly']==0){echo 'checked="checked"';}
?>
id="d1" name="ly" value="0"><span class="zt">禁止访客留言</span></div>
<div onclick="document.forms[0].d2.checked=true;" style="cursor:hand;"><input type="radio" id="d2" name="ly" 
<?php 
if($userinfo['ly']==1){echo 'checked="checked"';}
?>
value="1"><span class="zt">允许访客留言</span></div>
</td>
</tr>
<tr>
<td width="179" class="tdbt">访客查看下载记录权限：</td>
<td>
<div onclick="document.forms[0].d4.checked=true;" style="cursor:hand;margin-top:5px;"><input type="radio" 
<?php 
if($userinfo['xz']==0){echo 'checked="checked"';}
?>
id="d4" name="xz" value="0"><span class="zt">禁止访客查看下载记录</span></div>
<div onclick="document.forms[0].d5.checked=true;" style="cursor:hand;margin-bottom:5px;"><input type="radio" id="d5"
<?php 
if($userinfo['xz']==1){echo 'checked="checked"';}
?>                        
name="xz" value="1"><span class="zt">允许访客查看下载记录</span></div>
</td>
</tr>
<tr>
<td width="179" class="tdbt">访客增加目录权限：</td>
<td>
<div onclick="document.forms[0].d6.checked=true;" style="cursor:hand;margin-top:5px;"><input type="radio" 
<?php 
if($userinfo['ml']==0){echo 'checked="checked"';}
?>
id="d6" name="ml" value="0"><span class="zt">禁止访客增加目录</span></div>
<div onclick="document.forms[0].d7.checked=true;" style="cursor:hand;margin-bottom:5px;"><input type="radio" id="d7"
<?php 
if($userinfo['ml']==1){echo 'checked="checked"';}
?>
name="ml" value="1"><span class="zt">允许访客增加目录</span></div>
</td>
</tr>
<tr>
<td width="179" class="tdbt">访客上传文件权限：</td>
<td>
<div onclick="document.forms[0].d8.checked=true;" style="cursor:hand;margin-top:5px;"><input type="radio" 
<?php 
if($userinfo['sc']==0){echo 'checked="checked"';}
?>
id="d8" name="sc" value="0"><span class="zt">禁止访客上传文件</span></div>
<div onclick="document.forms[0].d9.checked=true;" style="cursor:hand;margin-bottom:5px;"><input type="radio" id="d9"
<?php 
if($userinfo['sc']==1){echo 'checked="checked"';}
?>
name="sc" value="1"><span class="zt">允许访客上传文件</span></div>
</td>
</tr>
</tbody></table>
<p><input type="submit" id="bu1" onclick="return confirm('请确认是否提交设置');" value="提交设置" name="bu1"></p>
</form>
</div>
<ul class="yslb2">
<li>此处主要是设定访客的权限。管理员在空间管理区登录后则不受这些限制影响。</li>
<li>如果目录加密，则此目录的上传权限不受此处设定限制。</li>
</ul>            
</div>
</td>
</tr>
</tbody>
</table>