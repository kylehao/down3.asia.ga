<table cellpadding="0" border="0" style="border-collapse: collapse"><tbody><tr valign="top"><td>
<div id="ysleft">
<h2>空间后台操作菜单</h2>
<strong>主要操作</strong>
<ul class="yslb3">
<li><a href="/user.php">空间状态</a></li>
<li><a href="/user.php?act=sj">空间升级</a></li>
<!--        <li><a href="/user.php?act=yq">空间延期</a></li>
-->        </ul>
<strong>账户管理</strong>
<ul class="yslb3">
<li><a href="/zh.php">账户充值</a></li>
<li><a href="/zh.php?act=cz">充值记录</a></li>
<li><a href="/zh.php?act=xf" id="xz">消费记录</a></li>
</ul>
<strong>空间设置</strong>
<ul class="yslb3">
<li><a href="/sz.php">常规设置</a></li>
<li><a href="/sz.php?act=qx">访客权限</a></li>
<li><a href="/sz.php?act=lj">首页链接</a></li>
<li><a href="/sz.php?act=px">目录排序方式</a></li>
<li><a href="/sz.php?act=fg">空间风格</a></li>
<li><a href="/sz.php?act=zl">设置个人资料</a></li>
</ul>
<strong>空间安全</strong>
<ul class="yslb3">
<li><a href="/aq.php">设置登录密码</a></li>
<li><a href="/aq.php?act=glmm">修改管理密码</a></li>
<!--<li><a href="/aq.php?act=xgyx">修改邮箱</a></li>-->
<li><a href="/aq.php?act=szmb">设置密保</a></li>
<li><a href="/aq.php?act=xgmb">修改密保</a></li>
<!--<li><a href="/aq.php?act=wjmm">忘记密码</a></li>-->
</ul>
<strong>其它</strong>
<ul class="yslb3">
<li><a href="/mmcx.php" >加密目录密码查询</a></li>
<li><a href="/ly.php">留言管理</a></li>
</ul></div>
</td><td>
<style type="text/css">
ul.mllb			{margin:0;width:100%;}
ul.mllb li		{float:left;list-style-type:none;margin:3px 6px 0 0;font-size:9pt;line-height:120%;}
ul.mllb a		{font-weight:bold;font-size:9pt;color:#000;padding:5px 3px 3px 3px;height:20px;background-color:#E1E1FF;border:1px solid #000;text-align:center;TEXT-DECORATION: none;}
ul.mllb a:hover	{color:#490685;background-color:#FFEEE1;border:1px solid #1706FF;}
ul.mllb a:visited {color:#000;}
</style>
<div id="ysright">
<h1><span id="yhztxs"><label class="dl1">用户名：<a><font color="green"><?=$pd_username?></font></a>  账户余额：<?=$userinfo['wealth']?>元  <a href="/zh.php">账户充值</a> <a href="/account.php?action=logout">退出</a></label></span><img width="32" height="32" border="0" alt="" src="/images/money.gif">消费记录</h1>
<div class="ysdb">
<table>
<tbody><tr class="trbt">
<td>编号</td>
<td>时间</td>
<td>金额</td>
<td>购买产品</td>
<td>服务到期</td>
</tr>
<?=$result?>
</tbody></table>
</div>
</div>
</td>
</tr>
</tbody>
</table>
