<div style="text-align:justify;width:100%;padding:5px;">
<h3>产品列表</h3>
<div class="ysdb2">
<table>
<tbody><tr>
<td style="text-align: center;" class="tdbt">产品类型</td>
<td style="text-align: center;" class="tdbt">空间大小</td>
<td style="text-align: center;" class="tdbt">单个文件最大</td>
<td style="text-align: center;" class="tdbt">两小时最大下载量</td>
<td style="text-align: center;" class="tdbt">月付</td>
<td style="text-align: center;" class="tdbt">半年付</td>
<td style="text-align: center;" class="tdbt">年付</td>
<td style="text-align: center;" class="tdbt">两年付</td>
</tr>
<tr bgcolor="#ffffff">
<td align="center"><font color="#003399"><b>免费型空间</b></font></td>
<td align="center"><font size="3" color="#000080"><b>400</b>MB</font></td>
<td align="center">8MB</td>
<td align="center">80MB</td>
<td align="center">0</td>
<td align="center">0</td>
<td align="center">0</td>
<td align="center">0</td>
</tr>
<tr>
<td align="center"><font color="#003399"><b>个人型</b></font></td>
<td align="center"><font size="3" color="#000080"><b>600</b>MB</font></td>
<td align="center">60MB</td>
<td align="center">240MB</td>
<td align="center">8元</td>
<td align="center">30元</td>
<td align="center">48元</td>
<td align="center">88元</td>
</tr>
<tr>
<td bgcolor="#FFFFFF" align="center"><font color="#003399"><b>标准型</b></font></td>
<td bgcolor="#FFFFFF" align="center"><font size="3" color="#000080"><b>1000</b>MB</font></td>
<td bgcolor="#FFFFFF" align="center">100MB</td>
<td bgcolor="#FFFFFF" align="center">450MB</td>
<td bgcolor="#FFFFFF" align="center">12元</td>
<td bgcolor="#FFFFFF" align="center">60元</td>
<td bgcolor="#FFFFFF" align="center">96元</td>
<td bgcolor="#FFFFFF" align="center">180元</td>
</tr>
<tr>
<td align="center"><font color="#003399"><b>增强型</b></font></td>
<td align="center"><font size="3" color="#000080"><b>2000</b>MB</font></td>
<td align="center">150MB</td>
<td align="center">800MB</td>
<td align="center">/</td>
<td align="center">120元</td>
<td align="center">200元</td>
<td align="center">380元</td>
</tr>
<tr bgcolor="#FFFFFF">
<td align="center"><font color="#003399"><b>企业I型</b></font></td>
<td align="center"><font size="3" color="#000080"><b>6000</b>MB</font></td>
<td align="center">400MB</td>
<td align="center">1600MB</td>
<td align="center">/</td>
<td align="center">260元</td>
<td align="center">468元</td>
<td align="center">888元</td>
</tr>
<tr>
<td align="center"><font color="#003399"><b>企业II型</b></font></td>
<td align="center"><font size="3" color="#000080"><b>12000</b>MB</font></td>
<td align="center">700MB</td>
<td align="center">3000MB</td>
<td align="center">/</td>
<td align="center">500元</td>
<td align="center">900元</td>
<td align="center">1600元</td>
</tr>
</tbody></table>
</div>
<p>
<b>注：</b>
<br>
0.<u>本站网盘空间登录地址是</u>：<a>http://pan.haic.cc/用户名</a>
<br>
1.<u>单个文件最大</u>:是指上传时单个文件的大小不能超过此大小限制。
<br>
2.<u>两个小时最大下载量</u>:即两个小时最多从空间内下载文件的数据量，当超过这个容量限制时，用户将不能再从空间内下载文件。用户提交下载请求时，系统会计算从用户提交时到2小时前的下载量。如果没有超过流量限制就可以下载。
</p>
<h3>付费、免费的区别</h3>
<div style="float:right;width: 409px;" class="ysdb2">
<table>
<tbody><tr>
<td align="right" class="tdbt">&#12288;</td>
<td align="center"><b><font color="#003399">免费空间</font></b></td>
<td width="150" align="center"><b><font color="#003399">付费空间</font></b></td>
</tr>
<tr>
<td align="right" class="tdbt">目录总数限定</td>
<td align="center">30个</td>
<td width="150" align="center">60个<br>（企业型用户限制200个）</td>
</tr>
<tr>
<td align="right" class="tdbt">单目录中记录数限定</td>
<td align="center">60个</td>
<td width="150" align="center">300个</td>
</tr>
<tr>
<td align="right" class="tdbt">留言本记录总数限定</td>
<td align="center">1000条</td>
<td width="150" align="center">5000条<br>（企业型用户限制30000条）</td>
</tr>
<tr>
<td align="right" class="tdbt">文件备份</td>
<td align="center">不备份</td>
<td width="150" align="center">每日备份</td>
</tr>
<tr>
<td align="right" class="tdbt">是否显示广告</td>
<td align="center">显示广告</td>
<td width="150" align="center">不显示</td>
</tr>
</tbody></table>
</div>
<p>
右表列出了免费空间和付费空间的主要区别。
<br> 
另外付费空间和免费空间的服务器完全分离，付费空间用户使用的是独享带宽，免费用户使用的是共享带宽，在网络高峰期时付费用户的网速更有保障。
<br>
空间升级、续费皆可全程自助完成。
<br>
<br>
<a class="go" href="/account.php?action=register">注册空间</a>
<a class="go" href="/account.php">登录空间</a>
<a class="go" href="/user.php?act=sj">立即升级空间</a>
</p>
</div>
<div style="clear:both;"></div>