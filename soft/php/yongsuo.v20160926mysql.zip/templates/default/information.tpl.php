<div class="info_box">
<div class="info_box_tit"><img src="images/light.gif" align="absmiddle" border="0" /> <?=__('tips_message')?></div>
<div class="info_box_msg">
<?=$msg?>
<div align="center"><a href="<?=$url?>"><?=__('click_to_back')?></a></div><br>
</div>
<br />
</div>