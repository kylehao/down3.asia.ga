<?php
#	$Id: template_info.php 40 2012-06-01 06:04:01Z along $
#

//	Template Name: Disk
//	Template URL: 
//	Description: Disk Copyright 2011-2012 (C)。
//	Author: Disk
//	Author Site: 
//	Version: v1.1
//	Template Type: user
//  PHPDISK Core: v6.5+

?> 
