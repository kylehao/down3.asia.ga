<center>
<table border="0" cellpadding="0" style="border-collapse: collapse"><tr valign="top"><td>
<div id="ysright">
<a onfocus='javascript:this.blur()' href="/kf.php"><img class="tp" src="images/ys_welcome.gif" width="240" height="268" style="float:right;" alt="海诚Ｅ盘" /></a>
<img class="tp" src="images/welcome.gif" width="264" height="14" style="margin-top:15px;" alt="海诚Ｅ盘" />
<p style="font-size:10pt;">
<b>海诚Ｅ盘--专业数据存储、交流平台</b>
<br />
<label class="kt">可</label>以保存您的文件、网址、记事等。以便随时随地调用或与朋友、同事分享。
</p>
<p>
<b>适用于：</b>个人文件存储、公司内部或公司之间文件传递以及小团体情感交流等。
</p>
<div>
<b>系统特点：</b>
<ul class="yslb2" style="margin-left:10px;">
<li>以二级目录域名的形式直接进入您的Ｅ盘空间，<br />地址形为：<span style="color: red">http://pan.haic.cc/用户名</span></li>
<li>系统稳定，反应迅速</li>
<li>界面简洁，易操作</li>
<li>支持各种类型文件</li>
<li>400M免费，可随时自助升级扩容</li>
<li>可查看当日下载记录</li>
<li>多人在线时，数据实时刷新显示</li>
<li>提供空间自定义功能</li>
<li>支持目录加密，并能设置多种访客权限</li>
</ul>
</div>
<a onfocus='javascript:this.blur()' href="account.php?action=register" style="float:right;margin-right:30px;margin-top:-30px;"><img class="tp" src="images/zc1.gif" width="180" height="60"  alt="免费注册"></a>
<p>
<a class="go" href='account.php?action=register'>注册免费空间</a>
<a class="go" href='list_cp.php'>Ｅ盘产品介绍</a>
<a class="go" href='demo' target ="_blank">查看示例空间</a>
</p>
</div>
</td>
</tr>
</table>
</center>