<table cellpadding="0" border="0" style="border-collapse: collapse"><tbody><tr valign="top"><td>
<div id="ysleft">
<h2>帮助菜单</h2>
<ul style="height:80px; width:170px; overflow:hidden;" class="yslb3">
<li><a href="/help.php" id="xz">Ｅ盘使用说明</a></li>
<li><a href="/diy.php">如何设置自定义区</a></li>
<li><a href="/bigfile.php">采用分压缩方式上传大文件</a></li>
</ul>
</div>
</td><td>
<div id="ysright">
<h1><img width="30" height="27" border="0" alt="" src="/images/js1.gif">海诚Ｅ盘使用说明</h1>
<h3>用户如何访问</h3>
<ul class="yslb2">
<li><a>地址：http://pan.haic.cc/用户名</a><li>
</ul>
<h3>如何进入空间</h3>
<ul class="yslb2">
<li>用户注册Ｅ盘成功后即可通过页面提示的空间地址登录，在浏览器地址栏内输入此地址即可。</li>
<li>请输入您的用户名：
<input type="text" onkeydown="writedlmc();" style="width:150px;" id="tedlmc" />
<a href="/user.php?act=index">查询空间地址</a></li>
<!--<input type="button" value="查询空间地址" onclick="cxdlmc();"> -->
<li>如果您要限制别人访问您的空间，您可以在<a href="/aq.php?act=index">设置登录密码</a>页面设置登录密码。</li>
</ul>
<h3>如何添加内容</h3>
<ul class="yslb2">
<li><img width="260" height="154" border="0" style=" float:right;" alt="增加目录" src="images/h1.gif"><span class="xbt">建立目录</span>&nbsp;初次使用Ｅ盘的时候，目录列表是空的，需要在左上角的功能区内点"增加目录"来建立您的目录。如右图<br><br><br><br><br><br><br><br></li>
<li><img width="260" height="154" border="0" style=" float:right;" alt="增加目录" src="images/h1_2.gif"><span class="xbt">上传文件</span>&nbsp;点击目录名打开目录，功能区会转到"上传文件"栏。点"浏览"选择您需要上传的文件,，按"开始上传"按钮即可进行上传。此栏目内容比较多，除了上传文件外，还集成了添加网址链接、增加子目录等。如右图</li>
</ul>
<br><br><br>
<h3>如何编辑、删除数据</h3>
<ul class="yslb2">
<li>点击数据项前面的<font color="blue">小图标</font>即可在弹出小窗口内进行相关的编辑、删除操作。小图标的位置如下图所示。<br>
<img width="462" height="326" border="0" alt="" src="images/h2.gif">                </li>
<li>如果您没有在空间管理区登录，系统会提示您先在空间管理区登录后再进行编辑。</li>
<li>点击图标后，就可以在弹出的窗口内进行编辑、删除操作</li>
<li>访客新增的数据（目录、文件、留言等），将会在数项后面显示（编辑）字样，以便进行即时修改，当其再次进入空间时，将不再显示（编辑）字样，请点击小图标进行编辑。</li>
</ul>
<h3>如何进行空间升级</h3>
<ul class="yslb2">
<li>空间升级所需费用从账户余额中扣除。首先到<a href="/user.php?act=sj">空间升级</a>处计算所需费用</li>
<li>然后把所需费用充值到账户余额</li>
<li>充值完成后再到<a href="/user.php?act=sj">空间升级</a>处完成空间升级操作。</li>
<li>付费空间未到期也可以进行升级操作，升级时空间剩余的期限按照天数比例换算成金额，增加在您的空间账户内。</li>
</ul>
<h3>账户充值</h3>
<ul class="yslb2">
<li><a href="/zh.php?act=index">账户充值</a>支持
<a href="/zh.php?act=zfb">支付宝支付</a>                </li>
</ul>
<h3>其它</h3>
<ul class="yslb2">
<li>Ｅ盘空间支持自定义功能，详情见<a href="/diy.php">如何设置自定义区</a></li>
<li>海诚Ｅ盘有严格的下载流量限制，具体请查看<a href="/list_cp.php">海诚产品介绍</a>。</li>
<li>免费空间两个月内至少要管理（在管理区或者在空间后台登录）一次，否则空间会被系统自动锁定，如果超过半年没有进行管理，系统会删除此空间。</li>
<li>免费空间的数据无备份服务，并不对免费空间的数据安全负责，请免费用户不要在空间上传重要的数据。</li>
<li>如果您对我们的产品满意，建议<a href="/user.php?act=sj">升级</a>您的Ｅ盘以获得更好的服务。</li>
<li>请不要使用海诚Ｅ盘传播违法的内容，否则我们会配合国家执法部门追究违规人员的责任。</li>
<li>为了避免您的空间被不法份子利用，建议限制访客的<a href="/sz.php?act=qx">上传权限</a>，或给空间<a href="/aq.php?act=index">设置登录密码</a></li>
<li>如果还有其它问题，请到<a href="/kf.php">客服中心</a>提问或和我们联系</li>
</ul>
</div>
</td>
</tr>
</tbody>
</table>
