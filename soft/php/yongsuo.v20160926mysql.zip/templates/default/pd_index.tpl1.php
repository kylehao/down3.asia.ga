<table border="0" cellpadding="0" style="border-collapse: collapse"><tr valign="top"><td>
<div id="ysleft">
<h2>首页快捷导航</h2>
<ul class="yslb">
<li><a href="demo">查看演示空间</a></li>
<li><a href="user.php">登录空间后台</a></li>
<li><a href="aq.php">设置Ｅ盘登录密码</a></li>
<li><a href="user.php?act=sj">空间升级</a></li>
<li><a href="user.php?act=sj">空间延期</a></li>
<li><a href="sz.php?act=qx">设置访客权限</a></li>
<li><a href="zh.php">账户充值</a></li>
<li><a href="help.php">如何设置Ｅ盘自定义区</a></li>
</ul>
<h2>部分客户列表</h2>
<marquee scrollamount='2' scrolldelay='30' direction= 'UP' id='haic.cc' height='130' onmouseover='haic.cc.stop()' onmouseout='haic.cc.start()' Author:redriver='redriver'; For more,visit:www.haic.cc>
<ul class='yslb'>
<li>上海致逸建筑设计有限公司</li>
<li>上海日清景观设计有限公司</li>
<li>武汉市建筑设计院建筑空间</li>
<li>荆州市晴川建筑设计院有限公司</li>
<li>上海新建设建筑设计有限公司</li>
<li>上海印象空间数码科技有限公司</li>
<li>浙江绿城东方建筑设计有限公司</li>
<li>南京水晶石数字科技有限公司</li>
<li>上海广亩景观设计咨询有限公司</li>
<li>上海现代设计集团</li>
<li>浙江昌盛电气有限公司</li>
<li>大化县财政局</li>
<li>河池市财政局</li>
<li>云和县安监局</li>
<li>邮储银行上海浦东新区南汇支行</li>
<li>上海邮政速递物流公司</li>
<li>奉贤区邮政局</li>
<li>上海市清洁生产中心</li>
<li>湟中县教育局</li>
<li>广州市番禺区象贤中学</li>
<li>广西武宣县中学</li>
<li>广州市花都区教育局花山教育指导中心</li>
<li>妮梦衣服饰</li>
<li>上海沐海服饰有限公司</li>
<li>我衣我秀中国服饰代理分销总站</li>
<li>广州市纤婷服饰有限公司</li>
<li>风尚服饰批发</li>
<li>南方服装网</li>
<li>杭州恩娴服饰有限公司</li>
<li>千鸿网络鞋店</li>
<li>万辉服装</li>
<li>轩氏邦服饰</li>
<li>酷依家男装网</li>
<li>《素质教育》杂志社</li>
<li>北京华夏顺泽投资集团</li>
<li>盐城中南世纪城房地产投资有限公司</li>
<li>华润置地工程管理部</li>
<li>乐品品牌策划（北京）有限公司</li>
<li>广州搏智广告有限公司</li>
<li>长春君地房地产开发有限公司</li>
<li>广东奥马电器股份有限公司</li>
<li>雅善贸易（上海）有限公司</li>
<li>上海今尚数码科技有限公司</li>
<li>中信建投证券</li>
<li>光大证券</li>
<li>南通中南新世界中心开发有限公司</li>
<li>南京艺景数字科技有限公司</li>
<li>上海鼎为软件技术有限公司</li>
</ul>
</marquee> 
<h2>首页链接</h2>
<ul class="yslb">
<li>
<a href='http://www.baidu.com'>百度</a>
<a href='http://www.sohu.com'>搜狐</a>
<a href='http://www.sina.com.cn'>新浪</a>
<a href='http://www.qq.com/'>腾讯</a>
<a href='http://www.youku.com'>优酷</a>
</li>
<li>
<a href='http://www.haic.cc'>海诚</a>
<a href='http://blog.haic.cc'>博客</a>
<a href='http://www.hufen.co'>互粉</a>
<a href='http://mz.haic.cc'>秒赞</a>
<a href='http://www.ezs.ys168.com'>网盘</a>
</li>
</ul>
</div>
</td><td>
<div id="ysright">
<a onfocus='javascript:this.blur()' href="/kf.php"><img class="tp" src="images/ys_welcome.gif" width="241" height="268" style="float:right;" alt="" /></a>
<img class="tp" src="images/welcome.gif" width="264" height="14" style="margin-top:15px;" alt="" />
<p style="font-size:10pt;">
<b>海诚Ｅ盘--专业数据存储、交流平台</b>
<br />
<label class="kt">可</label>以保存您的文件、网址、记事等。以便随时随地调用或与朋友、同事分享。
</p>
<p>
<b>适用于：</b>个人文件存储、公司内部或公司之间文件传递以及小团体情感交流等。
</p>
<div>
<b>系统特点：</b>
<ul class="yslb2" style="margin-left:10px;">
<li>以二级域名的形式直接进入</li>
<li>系统稳定，反应迅速</li>
<li>界面简洁，易操作</li>
<li>支持各种类型文件</li>
<li>400M免费，可随时自助升级扩容</li>
<li>可查看当日下载记录</li>
<li>多人在线时，数据实时刷新显示</li>
<li>提供空间自定义功能</li>
<li>支持目录加密，并能设置多种访客权限</li>
</ul>
</div>
<a onfocus='javascript:this.blur()' href="account.php?action=register" style="float:right;margin-right:30px;margin-top:-30px;"><img class="tp" src="images/zc1.gif" width="180" height="60" alt="" /></a>
<p>
<a class="go" href='account.php?action=register'>注册免费空间</a>
<a class="go" href='list_cp.php'>Ｅ盘产品介绍</a>
<a class="go" href='demo' target ="_blank">查看示例空间</a>
</p>
</div>
</td>
</tr>
</table>