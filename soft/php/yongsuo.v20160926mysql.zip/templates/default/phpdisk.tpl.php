<table border="0" cellpadding="0" style="border-collapse: collapse"><tr valign="top"><td>
<div id="ysleft">
<h2>首页快捷导航</h2>
<ul class="yslb">
<li><a href="/account.php?action=login">登录空间后台</a></li>
<li><a href="/aq.php?act=index">设置Ｅ盘登录密码</a></li>
<li><a href="/user.php?act=sj">空间升级</a></li>
<li><a href="/zh.php?act=index">账户充值</a></li>
<li><a href="/sz.php?act=qx">设置访客权限</a></li>
<li><a href="/sz.php?act=index">常规设置</a></li>
<li><a href="/help.php">使用说明</a></li>
</ul>
<h2>部分客户列表</h2><marquee scrollamount='2' scrolldelay='30' direction= 'UP' id='haic.cc' height='130' onmouseover='haic.cc.stop()' onmouseout='haic.cc.start()' Author:redriver='redriver'; For more,visit:haic.cc>
{$khlb}
</marquee> 
<h2>首页链接</h2>
<ul class="yslb">
<li>
<!--#
$iii=1;
foreach($C[links_arr] as $k => $v){
if($iii%4==0){
#-->
</li>
<li>
<!--#
}else{
#-->
<a href="{$v['url']}" target="_blank">{$v['title']}</a>&nbsp;
<!--#
}
$iii=$iii+1;
}
#-->
</li>
</ul>
</div>
</td><td>
<div id="ysright">
{$syxx}
</div>
</td>
</tr>
</tbody>
</table>