<div class="user_box">
<b class="ctop">
<b class="cb1"></b><b class="cb2"></b><b class="cb3"></b><b class="cb4"></b>
</b>