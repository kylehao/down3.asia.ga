<table cellpadding="0" border="0" style="border-collapse: collapse"><tbody><tr valign="top"><td>
<div id="ysleft">
<h2>帮助菜单</h2>
<ul style="height:80px; width:170px; overflow:hidden;" class="yslb3">
<li><a href="/help.php">Ｅ盘使用说明</a></li>
<li><a href="/diy.php" id="xz">如何设置自定义区</a></li>
<li><a href="/bigfile.php">采用分压缩方式上传大文件</a></li>
</ul>
</div>
</td><td>
<div id="ysright">
<h1><img width="30" height="27" border="0" alt="" src="/images/js1.gif">如何设置空间自定义区</h1>
<font size="2"><label class="kt">空</label>间自定义区放置于空间目录列表的右边。用于显示图片、音频、视频、链接、文字等，会使空间更加非富。</font>
<h3>开启自定义区</h3>
<div class="zdy">
开启自定义区很简单，只要<span class="zd">空间里有一个署名为&nbsp;<font color="#0000FF">*</font>&nbsp;的目录</span>即可，可以通过编辑现有目录或新建一个目录实现(以下称此目录为自定义目录)。如下图：
<br>
<img alt="增加自定义目录" style="border-width: 0px;width:268px; height:156px;" src="images/zdy01.gif">
<br>
<ul class="yslb2">
<li>签写署名里填写的&nbsp;*&nbsp;前后都不要增加空格等其他字符。</li>
<li>如果空间内有多个署名为&nbsp;*&nbsp;的目录，那么系统会默认符合条件中最上面的目录为自定义目录。</li>
</ul>
</div>
<h3>设置栏目</h3>
<div class="zdy">
自定义区的栏目和自定义目录的子目录一一对应，设置栏目只需要<span class="zd">在自定义目录内增加子目录</span>即可，显示的栏目名称和与其对应的子目录名一致。自定义区内最多支持10个栏目。
<br>建立子目录如下图：
<br>
<img alt="建立子目录" style="width:268px; height:156px;border-width: 0px;" src="images/zdy02.gif">
</div>
<h3>添加内容</h3>
<div class="zdy">
<span class="zd">在上一步建立的子目录内增加内容</span>即可完成自定义区的设置。<font color="green">设置完毕后点此目录内的[刷新]按钮即可看到效果。</font><br>
栏目显示的内容取决于此子目录内的第一项。例如：子目录内的第一项是图片文件，那么对应的栏目内就会显示此图片。
</div>
<h3>栏目分类</h3>
<div class="zdy">
<ul class="yslb2">
<li><span class="fl">图片</span>设置方法：子目录中的第一项是图片文件。
<br>
如果子目录中有多张图片，则与其对应的栏目会对这些图片进行轮流播放。
<br>
自定义区显示的图片大小宽度固定为162像素，高度按照第一张图片的高宽比确定。大于800KB的图片文件不予显示。
</li>
<li><span class="fl">视频、音频</span>设置方法：子目录中的第一项是视频、音频文件。
<br>
视频、音频文件支持：mid、rm、swf、mpg、mp3、wma、asf、wmv等格式，如果要在播放窗口中显示视频，则需修改此文件的备注为 <font size="4" color="#0000FF">*</font>，否则，将只播放音频。如下图
<br>
<img alt="显示视频文件" style="width:268px; height:156px;border-width: 0px;" src="images/zdy04.gif">
</li>
<li><span class="fl">链接、文字</span>设置方法：子目录中的第一项是链接、文字。
<br>
链接和文字是在上传文件的窗口内选择“链接网址”设置的，如果链接网址一栏内不是“http”开头的，就会按照文字显示。如下图
<br>
<div style=" float:right;"><img alt="增加文字项" style="width:190px; height:156px;border-width: 0px;" src="images/zdy06.gif"></div>
<img alt="增加文字项" style="width:268px; height:156px;border-width: 0px;" src="images/zdy03.gif">
</li>
</ul>
</div>
<h3>注意事项</h3>
<div class="zdy">
<ul class="yslb2">
<li>自定义区内只显示一个图片轮播栏目。其他类型栏目不限。</li>
<li>如果视频、音频栏目内有多个文件，那么只播放第一项的文件。</li>
<li>子目录的排列顺序是按照子目录名正排，您可以在子目录名前增加数字方便子目录的排列。</li>
<li>如果您的空间流量超过限制，则自定义区内有关文件的内容将不能显示。</li>
<li>自定义区内的文件显示或播放将占用空间下载流量，请尽量把图片缩小后上传，宽度为162像素为最佳。视频、音频文件推荐使用rm、swf格式。</li>
<li>图片轮播窗口内的图片，请尽量选用高宽比相近的。</li>
</ul>
</div>
<!--<h3>在空间目录列表下显示自已制作的网页</h3>
<div class="zdy">
首先自己制作一个网页文件，文件名需为"home.htm",然后把其上传至自定义目录下，注意，不要把其放置于任何一个子目录中。
<br>
上传好后刷新空间，即可在目录列表下看到您的文件内容。显示尺寸默认大小为300*200。您也可以自定义显示尺寸。方法是修改home.htm文件的备注为&#12288;宽度*高度(最大限制800*1000)，如下图所示。
<br>
<img width="232" height="189" border="0" alt="" style="border-width: 0px" src="images/zdy05.gif">
</div> -->
</div>
</td>
</tr>
</tbody>
</table>