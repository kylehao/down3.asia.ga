<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>抱歉，找不到此Ｅ盘页面了</title>
<style type="text/css">
body {margin: 0px; padding:0px; font-family:"微软雅黑", Arial, "Trebuchet MS", Verdana, Georgia,Baskerville,Palatino,Times; font-size:16px;text-align:center;}div{margin-left:auto; margin-right:auto;color:#555;}a {text-decoration: none; color: #555;}a:hover {color: #0078D2;}img { border:none;}h1,h2,h3,h4 {margin:0;font-weight:normal; font-family: "微软雅黑", Arial, "Trebuchet MS", Helvetica, Verdana ; }h1{font-size:44px; color:#0188DE; padding:20px 0px 10px 0px;}h2{color:#0188DE; font-size:16px; padding:10px 0px 40px 0px;}#page{width:910px; padding:40px 20px 60px 20px; margin-top:80px;}.button{width:380px; height:55px;line-height:55px; margin-left:0px; margin-top:10px;margin:0 auto; background:#0394F0; text-align:center;border-radius:8px;}.button a{width:380px; height:55px; line-height:55px;display:block; font-size:18px;letter-spacing:1px; color:#fff;border-radius:8px;}.button a:hover{ background:#0176CB;}.footer{font-size:14px;margin-top:15px;}
</style>
</head>
<body>
<div id="page" style="border-style:dashed;border-color:#e4e4e4;line-height:30px;background:url(sorry.png) no-repeat right;">
<h1>抱歉，找不到此Ｅ盘页面了</h1>
<h2>Sorry, the site now can not be accessed. </h2>
<font color="#666666">你请求访问的Ｅ盘页面，暂时找不到，我们建议你返回Ｅ盘首页官网进行浏览，谢谢！</font><br /><br />
<div class="button">
<a href="http://pan.haic.cc" title="点击返回Ｅ盘首页">点击返回Ｅ盘首页</a>
</div>
</div>
</body>
</html>