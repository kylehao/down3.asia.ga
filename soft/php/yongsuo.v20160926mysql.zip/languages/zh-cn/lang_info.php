<?php
#	$Id: lang_info.php 2 2011-05-27 03:00:17Z along $
#
#	Copyright (C) 2008-2011 PHPDisk Team. All Rights Reserved.
#
*/

//	Language Name: 简体中文语言包  
//	Language URL: http://www.phpdisk.com/
//	Description: PHPDISK中文简体语言包。
//	Author: PHPDISK TEAM
//	Author Site: http://www.phpdisk.com/ 
//	Version: v1.3
//  PHPDISK Core: v6.5

?> 
