<?php
#	$Id: phpdisk_version.inc.php 42 2012-06-08 08:26:21Z along $
#

if(!defined('IN_PHPDISK')) {
	exit('[PHPDisk] Access Denied');
}

define('PHPDISK_EDITION','V-Core File Edition');
define('PHPDISK_VERSION','6.5.0');
define('PHPDISK_RELEASE','20120717');

?>