<?php
#	$Id: front_msg.inc.php 26 2012-03-29 10:33:52Z along $
#
if(!defined('IN_PHPDISK')) {
	exit('[PHPDisk] Access Denied');
}

require_once template_echo('front_msg',$user_tpl_dir);
?>