<?php
$_CACHE['apps'] = array (
  1 => 
  array (
    'appid' => '1',
    'type' => 'DISCUZ',
    'name' => 'Discuz! Board',
    'url' => 'http://localhost/dz7_u',
    'ip' => '127.0.0.1',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => 'utf-8',
    'synlogin' => '1',
    'extra' => '',
    'recvnote' => '1',
  ),
  6 => 
  array (
    'appid' => '6',
    'type' => 'OTHER',
    'name' => 'phpdisk',
    'url' => 'http://localhost/pd_xp',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => '',
    ),
    'recvnote' => '1',
  ),
  'UC_API' => 'http://localhost/dz7_u/uc_server',
);
