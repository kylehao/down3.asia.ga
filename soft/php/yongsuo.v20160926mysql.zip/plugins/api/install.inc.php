<?php 
##
#	Project: PHPDISK File Storage Solution
#	This is NOT a freeware, use is subject to license terms.
#
#	Site: http://www.phpdisk.com
#
#	$Id: install.inc.php 9 2012-02-04 02:17:20Z along $
#
#	Copyright (C) 2008-2012 PHPDisk Team. All Rights Reserved.
#
##
if(!defined('IN_PHPDISK')) {
	exit('[PHPDisk] Access Denied');
}
function install_plugin(){
	return true;
}
function uninstall_plugin(){
	return true;
}
?>