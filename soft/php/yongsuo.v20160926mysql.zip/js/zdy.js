var Yimg = null;
var zml = new Array();
var Qtplb = new Array();
var Qtpbh = 0;
var Qtpob = null;
var Qtpma = 166;
var elady_tp = new Array();
var adNumvii = 0;
var Qti = 0;
var Qtpzt = 0;
var Qhome = 0;
var iicjpd = false;
//总控室
//onload = function() { zdqdq(); }


function $p(rid) {
    return document.getElementById(rid)
}

function zdqdq() {

    Yimg = null;
    zml = new Array();
    Qtplb = new Array();
    Qtpbh = 0;
    Qtpob = null;
    elady_tp = new Array();
    adNumvii = 0;
    Qhome = 0;
    var P_sp = 0, P_tp = 0;

    var mlbh = Qzdqbh;
    var menu = $p("ZMm_" + mlbh);


    var js = 0;
    $p("idzdy").innerHTML = "";

    for (var z = 0; z < menu.childNodes.length - 1; z++) {
        dfml = menu.childNodes[z];

        var y = dfml.lastChild.childNodes.length;
        if (y == 0)
            continue;
        js += 1;
        //if (js > 10) return;
        xmmc = dfml.childNodes[1].innerHTML;

        if (xmmc == undefined) {
            return false;
        }
        var opd = dfml.lastChild.childNodes[0];
        if(opd.childNodes[0]==null)  continue;

        Fcr(xmmc, js);
        xob = $p("zdyBo_" + js);
      

        if (opd.childNodes[0].id.substr(0, 1) == "w") {
            var _fx = fxwj(opd.childNodes[0]);
            if (_fx.kqzf == "播放" || _fx.kqzf == "Play") {
                var gdz = 120;
                if (_fx.bz == "*") {
                    gdz = 140
                }
                if (_fx.kzm == "mp3") {
                    gdz = 30
                }
                if (_fx.kzm == "swf" || _fx.kzm == "mp4")
                    gdz = 120;
                xob.innerHTML = "<Iframe name='fff' src='" + Qzydz + "/play.php?filename=" + _fx.fn + "' width='100%' height='" + gdz + "' scrolling='no' frameborder='0'></iframe>"
                continue;
            }

            if (_fx.kqzf == "查看" || _fx.kqzf == "View") {

                dimtp = new Array();
                dimjs = 0;

                for (var i = 0; i < dfml.lastChild.childNodes.length; i++) {
                    if (dfml.lastChild.childNodes[i].childNodes[0].id.substr(0, 1) == "w") {
                        var fx2 = fxwj(dfml.lastChild.childNodes[i].childNodes[0]);
                        var fx3 = dfml.lastChild.childNodes[i].childNodes[2].href;
                        // console.info(fx3);
                        if (fx2.kqzf == "查看" || fx2.kqzf == "View") {
                            dimjs += 1;
                            dimtp[dimjs - 1] = fx3;
                        }
                    }
                }


                if (dimtp.length == 1 || P_tp == 1) {
                    xob.innerHTML = "<img border='0' src='" + dimtp[0] + "' width='" + Qtpma + "'>";

                } else {
                    if (P_tp == 1)
                        continue;
                    P_tp = 1;
                    elady_tp = dimtp;
                    xob.innerHTML = "<img title='单击暂停' style='cursor:hand;' onclick='tpkz();' style='FILTER: revealTrans(duration=2,transition=20)' src='" + elady_tp[0] + "' border=0 name='elady_tprotator1' id='elady_tprotator1' width='" + Qtpma + "' style='display:none;height:60'>";
                    tp_cc();
                }
                continue;
            }
        }
        dnr = "<ul>";

        for (var u = 0; u < dfml.lastChild.childNodes.length; u++) {
            dxx = dfml.lastChild.childNodes[u];
            if (dxx.childNodes[0].id.split("_")[0] == "t") {
                if(dxx.childNodes[2].innerHTML!='打开'){
                    dnr += "<li><img border=0 src='" + Qzydz + "/tp/wjlx2/wj.gif' width=16 height=16>";
                    dnr += "<font color=blue>" + dxx.childNodes[1].innerHTML + "</font>";
                    dnr += dxx.childNodes[2].innerHTML + "</li>";
                }
            } else if (dxx.childNodes[0].id.split("_")[0] == "u") {
                dnr += "<li><img border=0 src='" + Qzydz + "/tp/wjlx2/url.gif' width=16 height=16>";
                dnr += "<a href='" + dxx.childNodes[1].href + "' target='_blank'>" + dxx.childNodes[1].innerHTML + "</a></li>";
            }

        }
        dnr += "</ul>";
        xob.innerHTML = dnr;
    }


    if (js == 0) {
        $p("idzdy").innerHTML = "<div style='color:blue;padding:3px 3px 3px 3px;'>请在自定义目录下增加子目录，并在子目录中增加数据，每个子目录对应一个栏目。</div>";
    }
    return;
}

function Fcr(x1, x2) {
    $p("idzdy").innerHTML += "<div class='z_bt'>" + x1 + "</div>";
    $p("idzdy").innerHTML += "<div class='z_bo' id='zdyBo_" + x2 + "'></div>";
}
function dqq() {
    if (document.all) {
        if (Yimg.readyState != "complete")
            return false;
    }
    ;
    h1 = parseInt(Yimg.height);
    w1 = parseInt(Yimg.width);
    x = (Qtpma * h1) / w1;
    $p("elady_tprotator1").style.height = Math.round(x);
    $p("elady_tprotator1").style.display = "block";
    if (Qti != 1) {
        Qti = 1;
        next_elady1();
    }

}

function tp_cc() {
    Yimg = document.createElement("img");
    Yimg.style.display = "none";
    if (document.all) {
        myAttachEvent(Yimg, "readystatechange", dqq);
    } else {
        Yimg.onload = function () {
            if (Yimg.complete == true) {
                dqq();
            }
        }
    }
    Yimg.src = elady_tp[0];
    Yimg.onload = function () {
        if (Yimg.complete == true) {
            dqq();
        }
    };
}
function tpkz() {
    if (Qtpzt == 0) {
        Qtpzt = 1;
        $p("elady_tprotator1").title = '单击继续';
    } else {
        Qtpzt = 0;
        $p("elady_tprotator1").title = '单击暂停';
    }
}
function next_elady1() {
    if (Qtpzt == 0) {
        if (adNumvii < elady_tp.length - 1)
            adNumvii++;
        else
            adNumvii = 0;
        if (document.all) {
            $p("elady_tprotator1").filters.revealTrans.Transition = Math.floor(Math.random() * 23);
            $p("elady_tprotator1").filters.revealTrans.apply();
            $p("elady_tprotator1").src = elady_tp[adNumvii];
            $p("elady_tprotator1").filters.revealTrans.play();

        } else {
            $p("elady_tprotator1").src = elady_tp[adNumvii];
        }

    }
    theTimer = setTimeout("next_elady1()", 5000);

}
var myAttachEvent = function (obj, evt, fn) {
    if (obj.addEventListener) {
        obj.addEventListener(evt, fn, false);
    }
    else if (obj.attachEvent) {
        obj.attachEvent("on" + evt, fn);

    }
}

zdqdq();