
//var myisp="no"; 
//function setmyip(){
//  var $=function(x){
//      return document.getElementById(x);
//  };
//  var iphtml=$("kjz1").parentNode.parentNode.getElementsByTagName("div")[1];
////  alert(iphtml.innerHTML );
//  if(!$('myip')){
//  	iphtml.innerHTML = "目录列表&nbsp;<label id='myip' style='margin-left:30px;color:yellow;'></label>"
//  	LoadingScript('http://btcha.com/ip.php?v='+Math.round(new Date().getTime()/1000));
//  }
//  if(myisp=='dx'){
//  	$('myip').innerHTML = $('myip').innerHTML.replace(/<[^>]+>/g,''); 
//        myisp="yes";
//  }else{
//  	setTimeout("setmyip()",1000);
//  }
//}
//
//setmyip();


//动态加载脚本文件
function LoadingScript(fileName, language, charset){
  if(typeof(language)=="undefined"){language="javascript"};
  if(typeof(charset)=="undefined"){charset="utf-8"};
  if(fileName != "" && fileName.length > 10){
    if(/.html|.htm/i.test(fileName)==false){
      var head=document.getElementsByTagName("head")[0];
      var script=document.createElement("script");
      script.src=fileName;
      script.type="text/"+language;
      script.charset=charset;
      script.defer=true;
      void(head.appendChild(script));
    }
  }
}
//显示时间
Date.prototype.Format = function(formatStr){return formatStr.replace(/yyyy|YYYY/,this.getFullYear()).replace(/yy|YY/,(this.getYear() % 100)>9?(this.getYear() % 100).toString():'0' + (this.getYear() % 100)).replace(/MM/,(this.getMonth()+1)>9?(this.getMonth()+1).toString():'0' + (this.getMonth()+1)).replace(/M/g,(this.getMonth()+1)).replace(/dd|DD/,this.getDate()>9?this.getDate().toString():'0' + this.getDate()).replace(/d|D/g,this.getDate()).replace(/hh|HH/,this.getHours()>9?this.getHours().toString():'0' + this.getHours()).replace(/h|H/g,this.getHours()).replace(/mm/,this.getMinutes()>9?this.getMinutes().toString():'0' + this.getMinutes()).replace(/m/g,this.getMinutes()).replace(/ss|SS/,this.getSeconds()>9?this.getSeconds().toString():'0' + this.getSeconds()).replace(/s|S/g,this.getSeconds()).replace(/w|W/g,['日','一','二','三','四','五','六'][this.getDay()]);};
var kqtimer = true;  // true,false 开启,停止
function sztimer(){
	var sj = document.getElementById('timer');	
  if(kqtimer){
  	if(sj){sj.innerHTML = new Date().Format("YYYY年MM月DD日 HH时mm分SS秒 星期W"); setTimeout('sztimer();',1000);}
  }else{
  	if(sj){sj.innerHTML="";}
  }
}
var kjz1 = document.getElementById("kjz1").parentNode;
kjz1.innerHTML = "<label id='timer' style='color:yellow;'></label>&nbsp;" + kjz1.innerHTML;
sztimer(); //开启时间