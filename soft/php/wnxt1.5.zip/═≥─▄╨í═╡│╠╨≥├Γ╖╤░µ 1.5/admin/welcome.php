<?php
/*--------------------------
ɵ��С͵ϵͳ
mail: kylehao#163.com
---------------------------*/
require_once('data.php');
require_once('checkAdmin.php');
require_once('../inc/common.inc.php');
?>
<div class="right_top"><marquee behavior=slide width=600 scrollamount=10 onmouseover=this.stop() onmouseout=this.start()><?php echo $welcome;?></marquee></div>