<?php
/*--------------------------
ɵ��С͵ϵͳ
mail: kylehao#163.com
---------------------------*/
require_once('data.php');
require_once('checkAdmin.php');
?>

<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
		<link rel="stylesheet" type="text/css" href="../public/css/admin.css">
		<link href="../public/css/jquery.css" rel="stylesheet" type="text/css">
		<link href="../public/css/base.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="../public/js/jquery-1.3.2.min.js">
			</script>
			<script type="text/javascript" src="../public/js/jquery-ui.min.js">
				</script>
				<script type="text/javascript" src="../inc/common.inc.php?action=dejs&file=vivi.js&key=9604&_t=1416985294">
					</script>
					<style type="text/css">.error_msg{	color:red;}.success_msg{	color:green;}</style>
	</head>
	
	<body background="../public/img/top10.gif"><div style="width:170px">	
		<img src="../public/img/top11.gif">	
		<div class="expand" onclick="expandIt(1)" id="main1">		
			<div class="expand_title">ϵͳ����</div>	</div>	
				<div class="expand_sub" id="sub1">		<ul>		
						<li><a target="content" href="admin_index.php">��վ״̬</a></li>			
						<li><a target="content" href="admin_main.php">��������</a></li>			
						<li><a target="content" href="admin_admin.php">�޸�����</a></li>				
						</ul>	</div>	
				<div class="expand" onclick="expandIt(2)" id="main2">		
				<div class="expand_title">�ɼ�����</div>	</div>	
					<div class="expand_sub" id="sub2">		<ul>			
						<li><a target="content" href="caiji_config.php">�ɼ��ڵ�</a></li>			
					</ul>	
				</div>	

				<div class="expand" onclick="expandIt(4)" id="main4">		
				<div class="expand_title">��������</div>	</div>	
					<div class="expand_sub" id="sub4">		<ul>			
					<li><a target="content" href="flink.php">��������</a></li>
					<li><a target="content" href="admin_ad.php">������</a></li>			
					<li><a target="content" href="admin_ip.php">IP ����</a></li>			
					<li><a target="content" href="zhizhu.php">֩����ʼ�¼</a></li>		
				</ul>	
				</div>	
				<div class="expand" onclick="expandIt(5)" id="main5">		
					<div class="expand_title">����֧��</div>	</div>	
						<div class="expand_sub" id="sub5">		<ul>			
							<li>�ͷ�EMAIL��<font color="#FF6600">kylehao#163.com</font></a></li>			
							<li>������<a target="_blank" href="http://www.x286.com">
								<font color="#FF6600">X286.Com</font></a></li>		
						</ul>	
					</div>
				</div>
	</body>
</html>