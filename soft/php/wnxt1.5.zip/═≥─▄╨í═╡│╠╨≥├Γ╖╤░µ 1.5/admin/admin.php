<?php
/*--------------------------
ɵ��С͵ϵͳ
mail: kylehao#163.com
---------------------------*/
require_once('data.php');
require_once('checkAdmin.php');
?>

<head>
<META content="MSHTML 6.00.2600.0" name=GENERATOR>
<title>��վ��̨����ϵͳ</title>
<LINK href="admin.css" type=text/css rel=stylesheet>
</head>
<frameset rows="90,*" frameborder="NO" border="0" framespacing="0" cols="*">
  <frame name="head" scrolling="NO" noresize src="top.php" >
  <frameset cols="172,*" frameborder="NO" border="0" framespacing="0" rows="*">
    <frame name="toc" scrolling="NO" noresize src="left.php">
    <frame name="content" src="admin_index.php" title="mainFrame">
  </frameset>
</frameset>
<noframes>
<body >
��֧�ֿ��!
</body>
</noframes>
</html>