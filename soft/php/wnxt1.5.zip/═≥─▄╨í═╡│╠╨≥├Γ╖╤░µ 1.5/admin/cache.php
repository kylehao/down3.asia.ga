<?php
/*--------------------------
ɵ��С͵ϵͳ
mail: kylehao#163.com
---------------------------*/
require_once('data.php');
require_once('checkAdmin.php');
$v_config=require_once('../data/config.php');
require_once('../inc/common.inc.php');
$id=isset($_GET ['id'])?$_GET ['id']:'';
if ($id=='') {
echo ADMIN_HEAD;
?>
<body>
<div class="right">
 <?php include "welcome.php";?>
  <div class="right_main">
<table width="98%" cellspacing="1" cellpadding="4" border="0" class="tableoutline">
	<tbody>
		<tr class="tb_head">
			<td><h2>�������ã�</h2></td>
		</tr>
	</tbody>
</table>
<table width="98%" border="0" cellpadding="4" cellspacing="1" class="tableoutline">
	<form action="?id=save" method="post">
	<tbody id="config1">
		<tr nowrap class="firstalt">
			<td width="260"><b>��ҳ���汣��ʱ��</b><br>
			<font color="#666666"><font color='red'>Сʱ</font>Ϊ��λ,1Ϊ1Сʱ</font></td>
			<td><input type="text" name="con[indexcache]" size="25" maxlength="50" value="<?php echo $v_config['indexcache'];?>"onFocus="this.style.borderColor='#00CC00'" onBlur="this.style.borderColor='#dcdcdc'" ></td>
		</tr>
		<tr nowrap class="firstalt">
			<td width="260"><b>����ҳ���汣��ʱ��</b><br>
			<font color="#666666"><font color='red'>Сʱ</font>Ϊ��λ,1Ϊ1Сʱ</font></td>
			<td><input type="text" name="con[othercache]" size="25" maxlength="50" value="<?php echo $v_config['othercache'];?>"onFocus="this.style.borderColor='#00CC00'" onBlur="this.style.borderColor='#dcdcdc'" ></td>
		</tr>
		<tr nowrap class="firstalt">
			<td width="260"><b>css���濪��</b><br>
			<font color="#666666">����css���棬�ӿ��ٶ�</font></td>
			<td><select name="con[csscache]">
				<option value="1" <?php if($v_config['csscache']) echo "selected";?>>����</option>
				<option value="0" <?php if(!$v_config['csscache']) echo "selected";?>>�ر�</option>
			</select></td>
		</tr>
		<tr nowrap class="firstalt">
			<td width="260"><b>ҳ�滺�濪��</b><br>
			<font color="#666666">����ҳ�滺�棬��ʡ������CPU��Դ</font></td>
			<td><select name="con[cacheon]">
				<option value="1" <?php if ($v_config['cacheon']) echo "selected";?>>����</option>
				<option value="0" <?php if (!$v_config['cacheon']) echo "selected";?>>�ر�</option>
			</select></td>
		</tr>
		<tr class="firstalt"><td align="center" colspan="2"><input type="submit" value=" �ύ " name="submit" class="bginput">&nbsp;&nbsp;<input type="reset" value=" ���� " name="Input" class="bginput"></td></tr>
	</tbody>
	</form>
</table>
</div>
</div>
<?php include "footer.php";?>
</body>
</html>
<?php
}elseif($id == 'save') {
}
?>