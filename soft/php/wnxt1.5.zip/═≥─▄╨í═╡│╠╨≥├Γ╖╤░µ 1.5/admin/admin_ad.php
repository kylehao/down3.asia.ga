<?php
/*--------------------------
ɵ��С͵ϵͳ
qq: 996948519
---------------------------*/
require_once('data.php');
require_once('checkAdmin.php');
$v_config=require_once('../data/config.php');
require_once('../inc/common.inc.php');
$id=isset($_GET ['id'])?$_GET ['id']:'';
if ($id=='') {
echo ADMIN_HEAD;
?>
<body>
<div class="right">
 <?php include "welcome.php";?>
  <div class="right_main">
    <table width="98%" border="0" cellpadding="4" cellspacing="1" class="tableoutline">
	<form action="?id=save" method="post">
      <tbody id="config1">
		<tr nowrap  class="tb_head">
          <td colspan="2"><h2><font color="red">������ΪHTML��ʽ</font></h2></td>
        </tr>
		<tr nowrap class="firstalt">
          <td width="200"><b>ȫվ���</b><br><font color="#666666">�ɷ�ͨ��ͼƬ����</font></td>
          <td ><textarea name="js_top" cols="80" style="height:120px" onFocus="this.style.borderColor='#00CC00'" onBlur="this.style.borderColor='#dcdcdc'" ><?php echo @file_get_contents(VV_DATA.'/adjs/top.js');?></textarea>
          </td>
        </tr>
		 <tr nowrap class="firstalt">
          <td width="200"><b>ȫվ��ײ�</b><br><font color="#666666">�ɷ�Ư������������</font></td>
          <td ><textarea name="js_bottom" cols="80" style="height:120px" onFocus="this.style.borderColor='#00CC00'" onBlur="this.style.borderColor='#dcdcdc'" ><?php echo @file_get_contents(VV_DATA.'/adjs/bottom.js');?></textarea>
          </td>
        </tr>
		</tbody>
		<tr class="firstalt">
          <td colspan="2" align="center"><input type="hidden" name="action" value="setting">
            <input class="bginput" type="submit" name="submit" value=" �ύ " >
            <input class="bginput" type="reset" name="Input" value=" ���� " >
          </td>
        </tr>
      </form>
    </table>

  </div>
</div>
<?php include "footer.php"; ?>
</body>
</html>
<?php
}elseif($id == 'save') {
	write(VV_DATA.'/adjs/top.js',get_magic(@$_POST['js_top']));
	write(VV_DATA.'/adjs/bottom.js',get_magic(@$_POST['js_bottom']));
	ShowMsg("��ϲ��,�޸ĳɹ���",'admin_ad.php',2000);
}
?>