<?php
/*--------------------------
ɵ��С͵ϵͳ
mail: kylehao#163.com
---------------------------*/
require_once('data.php');
require_once('checkAdmin.php');
$v_config=require_once('../data/config.php');
require_once('../inc/common.inc.php');
$id=isset($_GET ['id'])?$_GET ['id']:'';
if ($id=='') {
echo ADMIN_HEAD;
?>
<body>
<div class="right">
 <?php include "welcome.php";?>
  <div class="right_main">
<table width="98%" cellspacing="1" cellpadding="4" border="0" class="tableoutline">
	<tbody>
		<tr class="tb_head">
			<td><h2>���������</h2></td>
		</tr>
	</tbody>
</table>
<table width="98%" border="0" cellpadding="4" cellspacing="1" class="tableoutline">
	<tbody id="config2">
		<tr align=center class="firstalt">
          <td width="30%">����˵��</td>
          <td width="30%">����Ŀ¼</td>
		  <td width="20%">�����С</td>
          <td width="20%">����</td>
        </tr>
		<tr align=center class="firstalt">
          <td>��ҳ����</td>
          <td>../cache/index.html</td>
		  <td style="color: #FF0000;"><?php echo @round(@filesize(VV_CACHE."/index.html")/1024,2)?> KB</td>
          <td style="text-align:center"><input type="button" class="bginput" style="height:19px; font-size:12px" value="���" onClick="javascript:location.href='?id=del&del=index';" name="Input"></td>
        </tr>
        <tr align=center class="firstalt">
          <td>����ҳ����</td>
          <td >../cache/html</td>
		  <td style="color: #FF0000;" id="getdirsize"><a href="javascript:" onclick='getdirsize();'>�����ȡ</a></td>
          <td style="text-align:center"><input type="button" class="bginput" style="height:19px; font-size:12px" value="���" onClick="javascript:location.href='?id=del&del=other';" name="Input"></td>
        </tr>
		<tr align=center class="firstalt">
          <td>css����</td>
          <td >../cache/css</td>
		  <td style="color: #FF0000;" id="getcsssize"><a href="javascript:" onclick='getcsssize();'>�����ȡ</a></td>
          <td style="text-align:center"><input type="button" class="bginput" style="height:19px; font-size:12px" value="���" onClick="javascript:location.href='?id=del&del=css';" name="Input"></td>
        </tr>
		<tr align=center class="firstalt">
          <td>֩�����м�¼</td>
          <td >../zhizhu.txt</td>
		  <td style="color: #FF0000;"><?php echo @round(@filesize(VV_DATA."/zhizhu.txt")/1024,2)?> KB</td>
          <td style="text-align:center"><input type="button" class="bginput" style="height:19px; font-size:12px" value="���" onClick="javascript:location.href='?id=del&del=zhizhu';" name="Input"></td>
        </tr>
		<tr align=center class="firstalt">
          <td >һ�����ȫ������</td>
          <td >&nbsp;</td>
		  <td>&nbsp;</td>
          <td style="text-align:center"><input type="button" class="bginput" style="height:19px; font-size:12px" value="���" onClick="javascript:location.href='?id=del&del=all';" name="Input"></td>
        </tr>
	</tbody>
</table>
</div>
</div>
<script type="text/javascript">
function getdirsize(){
	$('#getdirsize').html('<img src="../public/img/load.gif"> ������...');
	$.get("?id=getdirsize&_t="+Math.random()*10,function(data){
	  $('#getdirsize').html(data);
	});
}
function getcsssize(){
	$('#getcsssize').html('<img src="../public/img/load.gif"> ������...');
	$.get("?id=getcsssize&_t="+Math.random()*10,function(data){
	  $('#getcsssize').html(data);
	});
}
</script>
<?php include "footer.php";?>
</body>
</html>
<?php
}elseif($id == 'getdirsize') {
	echo 0;
}elseif($id == 'getcsssize') {
	echo 0;
}elseif($id == 'del') {
	echo 0;
}
?>