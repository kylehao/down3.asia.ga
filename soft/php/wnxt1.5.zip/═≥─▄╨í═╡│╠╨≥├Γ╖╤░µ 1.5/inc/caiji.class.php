<?php
/*--------------------------
ɵ��С͵ϵͳ
mail: kylehao#163.com
---------------------------*/
class caiji {
	public $keyfile;
	public $jsfile;
	function replace($str){
		if( is_file($this->keyfile) ){
			$arr=file($this->keyfile);
			$arr=str_replace(array("\r\n","\n","\r"),'',$arr);
			foreach( $arr as $k => $v ){
				if( trim($v)=='' ) break;
				list($l,$r)=explode(',',$v);
				if( function_exists('mb_string') ){
					mb_regex_encoding("gb2312");
					$str=mb_ereg_replace($l,$r,$str);
				}else{
					$str=str_replace($l,$r,$str);
				}
			}
		}
		return $str;
	}
	function strcut($start,$end,$str,$lt=false,$gt=false){
		if( $str=='' ) return '$false$';
		$strarr=explode($start,$str);
		if( $strarr[1] ){
			$strarr2=explode($end,$strarr[1]);
			$return=$strarr2[0];
			if( $lt ) $return=$start.$return;
			if( $gt ) $return=$return.$end;
		}else{
			return '$false$';
		}
		return $return;
	}
	function geturl($url){
		$user_agent = "Mozilla/5.0 (Windows NT 5.1; rv:17.0) Gecko/20100101 www.x286.com/17.0";
		$cookie='_lang=zh_CN:GBK; t=ba6a2a7ea0ebd4f0dbef8d54d73b7a7b;';
		$timeout=25;
		$data=array();
		if(function_exists('curl_init') && function_exists('curl_exec')){
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			@curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_AUTOREFERER,1);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_COOKIE,$cookie);
			curl_setopt($ch, CURLOPT_REFERER, $url);
			curl_setopt($ch, CURLOPT_TIMEOUT, 15);
			curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
			$data = curl_exec($ch);
			$ContentType=curl_getinfo($ch,CURLINFO_CONTENT_TYPE);
			$httpCode=curl_getinfo($ch,CURLINFO_HTTP_CODE);
			$lasturl=curl_getinfo($ch,CURLINFO_EFFECTIVE_URL);
			if(preg_match('~^(application|image|video)~i',$ContentType)){
				header('HTTP/1.1 301 Moved Permanently');
				header("Location:$lasturl");
				exit;
			}
			curl_close($ch);
		}else if ( function_exists('fsockopen') || function_exists('pfsockopen') ){
			$arr = parse_url($url);
			$path=$arr['path']?$arr['path']:"/";
			$host=$arr['host'];
			$port=isset($arr['port'])?$arr['port']:80;
			if ( $arr['query'] ){
				$path .= "?".$arr['query'];
			}
			if(function_exists('fsockopen')){
				$fp = fsockopen( $host,$port,$errno,$errstr,$timeout=25 );
			}else{
				$fp = pfsockopen( $host,$port,$errno,$errstr,$timeout=25 );
			}
			if (!$fp) {
				die("$errstr ($errno)");
			}
			stream_set_timeout( $fp, $timeout );
			$out = "GET {$path} HTTP/1.0\r\n";
			$out .= "Host: {$host}\r\n";
			$out .= "User-Agent: {$user_agent}\r\n";
			$out .= "Accept: */*\r\n";
			$out .= "Accept-Language: zh-cn\r\n";
			$out .= "Accept-Encoding: identity\r\n";
			$out .= "Referer: {$url}\r\n";
			$out .= "Cookie: {$cookie}\r\n";
			$out .= "Connection: Close\r\n\r\n";
			fputs( $fp, $out );
			$data = "";
			$httpCode = substr(fgets($fp, 13),9,3);
			while ($line=@fgets( $fp, 2048 ))
			{
				$data.=$line;
			}
			fclose( $fp );
			preg_match("/Content-Length:.?(\d+)/",$data, $matches);
			$data=substr($data,strlen($data)-$matches[1]);
		}else{
			if (ini_get('allow_url_fopen')) {
				for($i=0;$i<3;$i++){
					if(function_exists('stream_context_create')){
						$opt=array('http'=>array('timeout'=>$timeout,'header'=>"User-Agent: {$user_agent}\r\nCookie: {$cookie}\r\nReferer: {$url}"));
						$context=stream_context_create($opt);
						$data = file_get_contents($url,false,$context) or die('��������֧�ֲɼ�');
					}else{
						$data = file_get_contents($url) or die('��������֧�ֲɼ�');
					}
					if($data){
						$httpCode=substr($http_response_header[0],9,3);
						break;
					}
				}
			}else{
				die('������δ����php�ɼ�����');
			}
		}
		if($httpCode>=400){
			header("HTTP/1.1 404 Not Found");
			exit;
		}
		return $data;
	}
	function __construct(){
		$this->keyfile=VV_DATA."/keyword.php";
	}
}
$caiji=new caiji;