<?php
/*--------------------------
kylehaoԭ��Դ�� kylehao@163.com
---------------------------*/
require(dirname(__FILE__)."/inc/common.inc.php");
require(dirname(__FILE__)."/inc/caiji.class.php");
require(dirname(__FILE__)."/inc/robot.php");
require(VV_DATA."/rules.php");
?>