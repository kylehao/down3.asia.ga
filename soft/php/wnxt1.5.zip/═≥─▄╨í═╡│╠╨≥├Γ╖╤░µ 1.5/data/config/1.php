<?php
return array (
  'name' => '66Ӱ��',
  'from_url' => 'http://www.66e.cc/',
  'other_url' => '',
  'charset' => 'gbk',
  'replacerules' => 'src="?images/logo.gif"{vivicut}src="../logo.gif"

{vivicutline}

66Ӱ��{vivicut}���ɸ�

{vivicutline}

6v��Ӱ{vivicut}���ɸ�

{vivicutline}

6vhao.com{vivicut}free163.com

{vivicutline}

6vhao.nett{vivicut}free163.com

{vivicutline}

66ys.cc{vivicut}free163.com

{vivicutline}

66e.cc{vivicut}free163.com

{vivicutline}

/e/search/index.php{vivicut}?e/search/index.php

{vivicutline}

?pic/logo.png{vivicut}./logo.jpg

{vivicutline}

��ICP��12002782�� | ����Ա���䣺(my66ecc#gmail.com){vivicut}����Ա���䣺(kylehao#gmail.com)',
  'siftrules' => '',
  'licence' => '',
  'siftags' => 
  array (
    0 => 'iframe',
    1 => 'object',
    2 => 'script',
    3 => 'outjs',
  ),
  'time' => 1426086039,
);
?>