<?php
return array (
  'web_name' => '���ɸ��Ӱ�� FREE163.COM',
  'web_url' => 'http://free163.com/',
  'web_keywords' => '���ɸ󣬹ŵ�ʫ�ʣ�ɵ��С͵ϵͳ�����µ�Ӱ',
  'web_description' => '���ɸ󣬹ŵ�ʫ�ʣ�ɵ��С͵ϵͳ�����µ�Ӱ',
  'web_tongji' => '<center><script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id=\'cnzz_stat_icon_27189\'%3E%3C/span%3E%3Cscript src=\'" + cnzz_protocol + "s19.cnzz.com/stat.php%3Fid%3D27189%26show%3Dpic\' type=\'text/javascript\'%3E%3C/script%3E"));</script><center>',
  'collectid' => '1',
  'sifton' => '1',
  'sifturl' => '',
  'indexcache' => '',
  'othercache' => '',
  'csscache' => '0',
  'cacheon' => '0',
);
?>