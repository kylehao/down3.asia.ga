<?php if (!defined('VV_INC')) exit(header("HTTP/1.1 403 Forbidden"));banip();$v_config=require(VV_DATA."/config.php");$ac=isset($_GET['ac']) ? $_GET['ac'] : '';$collectid=$v_config['collectid'];if($ac=='yulan'){	$collectid=intval(@$_GET['collectid']);}$caiji_config=require(VV_DATA."/config/{$collectid}.php");if($caiji_config['charset']!='gbk' && $caiji_config['charset']!='gb2132' && !empty($_SERVER['QUERY_STRING']) ){$_SERVER['QUERY_STRING']=urldecode($_SERVER['QUERY_STRING']);if(PATH_SEPARATOR==':'){$_SERVER['QUERY_STRING']=mb_convert_encoding($_SERVER['QUERY_STRING'],$caiji_config['charset'],"gbk");}else{$_SERVER['QUERY_STRING']=iconv("gbk",$caiji_config['charset'],$_SERVER['QUERY_STRING']);}}if($ac=='yulan'){	if(isset($_GET['url'])){$caiji_config['from_url']=$_GET['url'];}}$parse_url=parse_url($caiji_config['from_url']);$server_url='http://'.$parse_url['host'];$str='';$sign='?';$temp_url=parse_url($v_config['web_url']);define('WEB_ROOT',substr($temp_url['path'],0,-1));if(empty($_SERVER['QUERY_STRING'])){	$cachefile=VV_CACHE.'/index.html';	$cachetime=$v_config['indexcache'];	$geturl=$caiji_config['from_url'];}else{	if(substr($_SERVER['QUERY_STRING'],0,1)=='/') $_SERVER['QUERY_STRING']=substr($_SERVER['QUERY_STRING'],1);	$geturl=$server_url.'/'.$_SERVER['QUERY_STRING'];	$cacheid=md5($geturl);	$cachefile=getcachefile($cacheid);	$cachetime=$v_config['othercache'];}$extarr=array('php','html','shtml','htm','jsp','xhtml','asp','aspx','action','xml','css');foreach($extarr as $vo){	$geturl=str_replace('.'.$vo.'&','.'.$vo.'?',$geturl);}if($ac=='yulan'){	$geturl=$caiji_config['from_url'];}unset($parse_url);$parse_url=parse_url($geturl);$urlpath=$parse_url['path'];$urlpathext=pathinfo($parse_url['path'],PATHINFO_EXTENSION);if(empty($urlpathext)){	if(substr($urlpath,-1)!='/') $urlpath.='/';}else{	$urlpathinfo=pathinfo($parse_url['path']);	$urldirname=$urlpathinfo['dirname'];	$urlbasename=$urlpathinfo['basename'];	$urlpath=str_replace($urlbasename,'',$parse_url['path']);	if($urldirname!='\\') $urlpath=$urldirname.'/';}if(substr($urlpath,0,1)=='/'){	$urlpath=substr($urlpath,1);}$urlext=pathinfo($parse_url['path'],PATHINFO_EXTENSION);if($urlext=='css'){	header("Content-type: text/css; charset=gbk");	$cachefile=getcsscachefile($cacheid);}if($urlext<>'' && !in_array($urlext,$extarr)){	header('HTTP/1.1 301 Moved Permanently');	header("Location:$geturl");	exit;}include(VV_DATA.'/rules_get.php');if($ac=='yulan'){$str=htmlspecialchars($str);$str=<<<STR
	<script type="text/javascript" src="../public/js/syntaxhighlighter/scripts/shCore.js"></script>
	<script type="text/javascript" src="../public/js/syntaxhighlighter/scripts/shBrushXml.js"></script>
	<link type="text/css" rel="stylesheet" href="../public/js/syntaxhighlighter/styles/shCore.css"/>
	<link type="text/css" rel="stylesheet" href="../public/js/syntaxhighlighter/styles/shThemeEditplus.css"/>
	<script type="text/javascript">
		SyntaxHighlighter.config.clipboardSwf = '../public/js/syntaxhighlighter/scripts/clipboard.swf';
		SyntaxHighlighter.config.tagName = 'textarea';
		SyntaxHighlighter.all();
	</script>
	<table width="99%" border="0" cellpadding="4" cellspacing="1" class="tableoutline">
	<tbody>
		<tr nowrap class="tb_head">
			<td><h2>Դ����鿴</h2></td>
		</tr>
	</tbody>
	<tr nowrap class="firstalt">
		<td><b>����Ϊ�ɼ����� [{$caiji_config['name']}] ��Դ���룬����Ը��������д���˹���:</b></td>
	</tr>
	<tr nowrap class="firstalt">
		<form method="get" action="caiji_config.php">
		<input type="hidden" name="ac" value="{$ac}" />
		<input type="hidden" name="collectid" value="{$collectid}" />
		<td><input type="text" name="url" size="80" value="{$caiji_config['from_url']}" onFocus="this.style.borderColor='#00CC00'" onBlur="this.style.borderColor='#999999'" > <input type="submit" value="�鿴Դ����" /></td>
		</form>
	</tr>
	<tr nowrap class="firstalt">
		<td><textarea style="height:500px" class="brush: html;auto-links:false;">{$str}</textarea></td>
	</tr>
</table>
</body>
</html>
STR;
$str=ADMIN_HEAD.$str;
}
echo $str;