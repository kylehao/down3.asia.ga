<?
session_start();
  if($_SESSION['adminname']=='')
  {
echo "<script>alert('Please Login First');location.href='admin.php';</script>";
  }

require_once('config.php');
require_once('function.php');
if($newpassword == $newpassword2)
{
   if($oldpassword== $pas )
  {
$data ="config.php";
$id ="pas[^\n;]*";
$tihuan="pas = '".$newpassword."'";
sqlwork($data,$id,$tihuan);
echo "<script>alert('�޸ĳɹ�');location.href='admin.php';</script>";
  }
  else
  {
  echo "<script>alert('����ľ��������');location.href='admin.php';</script>";
  }
}
else
{
 echo "<script>alert('����������벻һ��');location.href='admin.php';</script>";
}


?>
