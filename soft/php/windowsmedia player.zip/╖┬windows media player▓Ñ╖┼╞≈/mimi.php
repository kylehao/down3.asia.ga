<?php

$dl=@$HTTP_GET_VARS["vid"];
$tv= "data/tv.sql";
$buffer = file($tv);
	
	for($i=0;$i<sizeof($buffer);$i++)
{
//print_r($buffer[$i]);
$pieces=explode("|", $buffer[$i]);

if($pieces[0]==$dl)
{

echo $pieces[3];
}
}

?>
