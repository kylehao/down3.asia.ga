<?php
$dl=@$HTTP_GET_VARS["id"];
?>

<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>���ŵ��� </title>

</SCRIPT>
</head>
<body topmargin="0" leftmargin="0" bgcolor="#000000">
<div align="center">
  <center>
  <table border="0" width="100%" cellspacing="0" cellpadding="0" height="100%">
    <tr>
      <td width="100%" height="100%" valign="top">

<p align="center">
<object classid="CLSID:22d6f312-b0f6-11d0-94ab-0080c74c7e95" codebase="http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=6,4,5,715" type="application/x-oleobject" width="100%" height="100%" hspace="0" standby="Loading Microsoft Windows Media Player components..." id="NSPlay" align="center">
    <param name=ShowStatusBar value=-1>
    <param name="FileName" value="mimi.php?vid=<?=$dl?>">
    <param name="ShowControls" value="-1">
    <param name="ShowPositionControls" value="0">
    <param name="ShowAudioControls" value="-1">
    <param name="ShowTracker" value="-1">
    <param name="ShowDisplay" value="0">
    <param name="AutoSize" value="0">
    <param name="ShowGotoBar" value="0">
    <param name="ShowCaptioning" value="0">
    <param name="AutoStart" value="-1">
    <param name="PlayCount" value="0">
    <param name="AnimationAtStart" value="0">
    <param name="TransparentAtStart" value="0">
    <param name="AllowScan" value="0">
    <param name="EnableContextMenu" value="-1">
    <param name="ClickToPlay" value="0">
    <param name="InvokeURLs" value="-1">
    <param name="DefaultFrame" value="datawindow">
    <param name="AudioStream" value="-1">
	<param name="AllowChangeDisplaySize" value="-1">
	<param name="AutoRewind" value="0">
	<param name="Balance" value="0">
	<param name="BaseURL" value>
	<param name="BufferingTime" value="5">
	<param name="CaptioningID" value>
	<param name="CursorType" value="0">
	<param name="CurrentPosition" value="-1">
	<param name="CurrentMarker" value="0">
	<param name="DisplayBackColor" value="0">
	<param name="DisplayForeColor" value="16777215">
	<param name="DisplayMode" value="0">
	<param name="DisplaySize" value="4">
	<param name="Enabled" value="-1">
	<param name="EnablePositionControls" value="-1">
	<param name="EnableFullScreenControls" value="0">
	<param name="EnableTracker" value="-1">
	<param name="Language" value="-1">
	<param name="Mute" value="0">
	<param name="PreviewMode" value="0">
	<param name="Rate" value="1">
	<param name="SAMILang" value>
	<param name="SAMIStyle" value>
	<param name="SAMIFileName" value>
	<param name="SelectionStart" value="-1">
	<param name="SelectionEnd" value="-1">
	<param name="SendOpenStateChangeEvents" value="-1">
	<param name="SendWarningEvents" value="-1">
	<param name="SendErrorEvents" value="-1">
	<param name="SendKeyboardEvents" value="0">
	<param name="SendMouseClickEvents" value="0">
	<param name="SendMouseMoveEvents" value="0">
	<param name="SendPlayStateChangeEvents" value="-1">
	<param name="VideoBorderWidth" value="0">
	<param name="VideoBorderColor" value="0">
	<param name="VideoBorder3D" value="0">
	<param name="Volume" value="-600">
	<param name="WindowlessVideo" value="0">
      </object>
      </p>
      
      </td>
    </tr>
    <tr>
      <td width="100%" height="100%" valign="middle">
<p align="center">
      </td>
    </tr>
  </table>
  </center>
</div>
</body>

</html>