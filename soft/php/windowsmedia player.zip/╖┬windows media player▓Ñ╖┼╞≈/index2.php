<?php

$dl=@$HTTP_GET_VARS["tid"];
$tv= "data/tv.sql";
$buffer = file($tv);
	

			
			
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<STYLE type=text/css></STYLE>
<LINK href="images/css.css" type=text/css rel=stylesheet>
<SCRIPT language=javascript>
function click()
{if(event.button==2)
{
alert('ϵͳ�����Ҽ��������������   ')}
}
document.onmousedown=click;
</SCRIPT>
<title>�������</title>
<style type="text/css">
<!-- 
td           { font-size: 12px; line-height: 17px }
body         { font-size: 12px; line-height: 17px }
p            { margin-top: 1px; margin-bottom: 1px }
a:link       { text-decoration: none; color: white }
a:visited    { text-decoration: none; color: white }
a:active     { text-decoration: none }
a:hover      { text-decoration: underline; color: red }
-->
</style>
<script language= "javascript">
function newpage(htmlurl) {
var newwin=window.open(htmlurl,"newWin","toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,top=20,left=200,width=305,height=288");
newwin.focus();
return false;
}
</script>

<base target="I1">
</head>

<body leftmargin="0" topmargin="0" text="#FFFFFF">


<div align="center">
  <center>

  </center>   
  <table border="0" width="100%" cellspacing="0" cellpadding="0" bordercolorlight="#F1F1F1" bordercolordark="#FFFFFF">
    <center>                  
                           
           
<?php

	for($i=0;$i<sizeof($buffer);$i++)
{
//print_r($buffer[$i]);
$pieces=explode("|", $buffer[$i]);

if($pieces[1]==$dl)
{

?>		                   
    <tr>                    
      <td width="97%" height="15" align=rleft>&nbsp;&nbsp;<?=$pieces[2]?>&nbsp;&nbsp;</td>                
      <td width="3%" height="15" align=right>   
        <p align="right"><a style="text-decoration: underline" );" href="play2.php?id=<?=$pieces[0]?>">[GO]</a></td>                
    </tr>                
<?php		
}
}
?>            
          
                     
  </center>                 
    </table>                    
</div>                                                                                   
</body>                                                                                          
</html>
<head>
<meta http-equiv="Content-Language" content="zh-cn">
<META http-equiv=Content-Type content="text/html; charset=gb2312">
<meta name="description" content="">
</HEAD>

<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
</head>

</head>

<title></title>


<base target="I1">



<body bgcolor="#004E98">
