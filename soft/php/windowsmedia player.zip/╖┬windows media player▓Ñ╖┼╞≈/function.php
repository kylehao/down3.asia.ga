<?
function sqlwork($data,$id,$tihuan)
{
$filename = "$data";
$handle   = fopen($filename, "r");
$contents = fread($handle, filesize ($filename));
$putlei   = ereg_replace( $id,$tihuan,$contents);
//echo $putlei;
$handle2  = fopen($filename, 'wb');
fwrite($handle2, $putlei);
fclose($handle); 
fclose($handle2); 
}
?>