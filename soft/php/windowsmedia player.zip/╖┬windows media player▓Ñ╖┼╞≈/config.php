<?php
$us   = 'admin';
$pas = 'admin';
?>