<?
session_start();
  if($_SESSION['adminname']=='')
  {

?>  
  <table width="100%" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
  <form action="admin.php" method="post"><td align="center" valign="middle"><table width="400" border="0" cellpadding="5" cellspacing="1" class="tablebg">
  <tr class="tdbg">
  <td colspan="2"><div align="center"> ������½ </div></td>
  </tr>
  <tr class="tdbg">
  <td><div align="center">�û�����</div></td>
  <td><div align="center">
  <input name="username" type="text" id="username">
  </div></td>
  </tr>
  <tr class="tdbg">
  <td><div align="center">�� �룺</div></td>
  <td><div align="center">
  <input name="password" type="password" id="password">
  </div></td>
  </tr>
  <tr class="tdbg">
  <td colspan="2"><div align="center">
  <input type="submit" name="Submit" value="Submit" >
  <input type="reset" name="Submit2" value="Clear">
  </div></td>
  </tr>
  </table></td></form>
  </tr>
  </table>

<?  


require('config.php');

  $username=$_POST['username'];
  $password=$_POST['password'];
  
if (!empty($username)) 
 {
    if($pas==$password and $us==$username )
    {
      $_SESSION['adminname']=$username;
 
      echo "<script>location.href='admin.php';</script>";
      
    }
    else
    {
      echo "������û�������";
    }
  
 }
    //print_r($rs);

}

else
{
	switch ($put) {
case "gai":
require_once('admin/gai.php');
    break;
    case "gai1":
require_once('admin/gai1.php');
    break;
    case "gai2":
require_once('admin/gai2.php');
    break;
case "input":
require_once('admin/input.php');
    break;
    case "input2":
require_once('admin/input2.php');
    break;
case "del":
require_once('admin/del.php');
    break;
    case "apple":
    echo "i is apple";
    break;

case "":
?>	

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>��̨����</title>
<style>
<!--
table			{ font: 12px Tahoma, Verdana; color: #004080 }
.tableborder		{ background: #000000; border: 1px solid #FFFFFF } 
.altbg1			{ background: #DFDFDF }
.altbg2			{ background: #F1F1F1 }
-->
</style>
</head>
<body bgcolor="#DFDFDF">
<table border="0" width="780" cellspacing="0" cellpadding="0" id="table1"  height="586">
		<tr>
			<td width="4">��</td>
			<td width="211" valign="top">
			<p align="center"><font size="3"><a href="admin.php?put=gai" target="window">�޸Ľ�Ŀ</a></font></p>
			<p align="center"><a  href="admin.php?put=input"target="window"><font size="3">���ӽ�Ŀ</font></a></p>
			<p align="center"><a  href="admin.php?put=del"target="window"><font size="3">ɾ����Ŀ</font></a></p>
<form action="xiugai.php" method="post">
                <p dir="ltr">�޸Ĺ������룺</p>
<table class="tableborder" cellSpacing="1" cellPadding="4" width="96%" >
	<tr>
		<td class="altbg1" width="98">ԭ����:</td>
		<td class="altbg2">
		<input type="password" size="25" value name="oldpassword" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 12px; font-family: Tahoma, Verdana; color: #004080; background-color: #DFDFDF"> 
		</td>
	</tr>
	<tr>
		<td class="altbg1">������:</td>
		<td class="altbg2">
		<input type="password" size="25" value name="newpassword" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 12px; font-family: Tahoma, Verdana; color: #004080; background-color: #DFDFDF"> 
		</td>
	</tr>
	<tr>
		<td class="altbg1">ȷ��������:</td>
		<td class="altbg2">
		<input type="password" size="25" value name="newpassword2" style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 12px; font-family: Tahoma, Verdana; color: #004080; background-color: #DFDFDF"> 
		</td>
	</tr>

	</table>
	 <input type="submit" name="Submit" value="�޸�" >
</form>

			<p><b>
			<a href="admin.php?logout=logout"><font size="3" color="#660033">�˳�</font></a></b></td>
			<td width="565" valign="top">
		
	<p>
			<iframe  height="100%" width="100%" src="admin.php?put=gai" name="window" target="_blank" >
			�������֧��Ƕ��ʽ��ܣ�������Ϊ����ʾǶ��ʽ��ܡ�</iframe></p>

</td>
		</tr>
		<tr>
			<td width="4" height="14"></td>
			<td width="211" height="14"></td>
			<td width="565" height="14"></td>
		</tr>
	</table>
</body>

</html>
<?
}
}



if($logout=="logout")
{
session_destroy();
echo "<script>location.href='admin.php';</script>";
}



?>