</html>
<head>
<meta http-equiv="Content-Language" content="zh-cn">
<META http-equiv=Content-Type content="text/html; charset=gb2312">
<meta name="description" content="���ı�Է - ����̨">
<STYLE type=text/css></STYLE>
<LINK href="images/css.css" type=text/css rel=stylesheet>
<SCRIPT language=javascript>
function click()
{if(event.button==2)
{
alert('ϵͳ�����Ҽ��������������   ')}
}
document.onmousedown=click;
</SCRIPT>
<!--
-->

</HEAD>

<meta http-equiv="Content-Type" content="text/html; charset=gb2312">

</head>

</head>

<title>���ı�Է - ����̨</title>


<base target="_blank">





<body bgcolor="#004E98" text="#FFFFFF">





<div align="center">
<table border="0" width="780" cellspacing="0" cellpadding="0" id="table1" height="586" background="bofangqi.gif">
		<tr>
			<td width="780" colspan="3" height="85" align="right" valign="bottom">

		    <form name="tablesForm" method="get" action="index2.php" target="window">
		    <p dir="ltr">
		    <select dir="ltr" onchange="this.form.submit();" name="tid">
<?

$lei= "data/lei.txt";
$buffer = file($lei);
	for($i=0;$i<sizeof($buffer);$i++)
 {
//print_r($buffer[$i]);
$row=explode("|", $buffer[$i]);

?>	

  <option value="<?=$row[0]?>" selected><?=$row[1]?></option>

<?  
 $index2 = $row[0];
 }
?>      
  
  </select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>
			</form>
			</td>
		</tr>
		<tr>
			<td width="4" rowspan="2">��</td>
			<td width="605" rowspan="2">
			<iframe name="I1" height="100%" width="100%" src="index-z.htm" target="_blank" >
			�������֧��Ƕ��ʽ��ܣ�������Ϊ����ʾǶ��ʽ��ܡ�</iframe></td>
			<td width="188" valign="top">
			<iframe  height="66%" width="100%" src="index2.php?tid=<?=$index2?>"  name="window" target="I1" >
			�������֧��Ƕ��ʽ��ܣ�������Ϊ����ʾǶ��ʽ��ܡ�</iframe></td>
		</tr>
		<tr>
			<td width="188" height="1"></td>
		</tr>
		<tr>
			<td width="4" height="57">��</td>
			<td width="605" height="57">��</td>
			<td width="188" height="57">��</td>
		</tr>
	</table>
	</div>
	<style type="text/css">
<!-- 
td           { font-size: 12px; line-height: 17px }
body         { font-size: 12px; line-height: 17px }
p            { margin-top: 1px; margin-bottom: 1px }
a:link       { text-decoration: none; color: white }
a:visited    { text-decoration: none; color: white }
a:active     { text-decoration: none }
a:hover      { text-decoration: underline; color: red }
-->
</style>

<head>
<meta http-equiv="Content-Language" content="zh-cn">
</head>
<TABLE WIDTH="100%" BORDER="0" CELLPADDING="0" CELLSPACING="0" ALIGN="CENTER">
  <TR>
    <TD ALIGN="center">Copyright 2005 &copy; <a href='http://www.htsky.com' target="_blank">���ı�Է</a> All Rights Reserved   <a href='http://www.miibeian.gov.cn' target="_blank">��ICP��05075041��</a><br>
<script language="javascript" type="text/javascript" src="http://js.d.s32.51.la/514.js"></script>
<script src='http://s11.cnzz.com/stat.php?id=1547&web_id=28195&show=pic' language='JavaScript' charset='gb2312'></script>
</TD>
</TR>
</TABLE>
</body>
