<?
if (file_exists("data/config.php"))	
{
$sys_info=explode("|",readfrom("data/config.php"));
static $down_name;
static $down_url;
static $site_url;
$down_name=$sys_info[2];
$down_url=$sys_info[3];
$site_url=$sys_info[1];

}
?>
<html>
<head>
<title><? echo $down_name; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="images/css.css" type="text/css">
<noscript></head></noscript>

<body topmargin="0" leftmargin="0" bgcolor="#ffffff">
	
<table width="1350" height=24 border=0 align=left cellpadding=0 cellspacing=0 bordercolor="#5FB0D8" 
bgcolor=#ffffff>
  <tr> 
    <td width="125" height="43" align=left bgcolor="#FFFFFF" background="images/topbg.jpg" class="font">
    </td>
    <td width="718" align=left bgcolor="#FFFFFF" background="images/topbg.jpg" class="font"><div align="left"> <a href="index.php"><font color="#000000">首&nbsp;&nbsp;页</font> </a>|<a href="sort.php" ><font color="#000000">软件分类</font></a> |<a href="news.php"> <font color="#000000">最近更新</font> </a>| <a href="hot.php"><font color="#000000">软件排行</font></a> | <a href="commends.php"><font color="#000000">精品推荐</font> </a>|</div></td>
    <td width="377" align=center bgcolor="#FFFFFF" background="images/topbg.jpg"><span class="style5">&nbsp;<a href="../"><span class="style8"><font color="#000000">听松阁下载站：安全、高速、放心的专业下载站！</font></a></span></td>
    <td width="130" align=center bgcolor="#FFFFFF" background="images/topbg.jpg">&nbsp;</td>
  </tr>
</table>

<table width="1350" height="110" border=0 align=center cellpadding=0 cellspacing=0 bordercolor="#5FB0D8" 
bgcolor=#ffffff>
  <tr align="left" bgcolor="#FFFFFF" > 
  	<td width="125"></td>
  	<td  colspan="1" width="300" height="110">
  		<a href="../../"><img src="images/logo.jpg" width="229" height="88"></a>
    </td>
  	<td width="100"></td>
  		
    <td colspan="1" width="750" height="110">
    	<table width="100%" border="0" cellspacing="0" cellpadding="0">
        <form method="post" action="search.php" name="Searchsoft">
          <tr> 
            <td width="4%" height="30" bgcolor="#FFFFFF">&nbsp; <b></b></td>
            <td width="84%" height="30" bgcolor="#FFFFFF"><span class="style8"><b>软件搜索：</b></span>
              <select name="action" size="1" style="width:70px;height:30px;border: 2px solid #47B751;">
                <option value="title">名称</option>
                <option value="content">简介</option>
              </select>
              <input maxlength=40 size=16 name=keyword style="width:300px;height:30px;border: 2px solid #47B751;">
              <select name="sclass" size="1" style="width:70px;height:30px;border: 2px solid #47B751;">
                <option value="all" >全部类别</option>
                <?
$list=file("data/class.php");
$count=count($list);
for ($i=0; $i<$count; $i++) {
$list_info=explode("|",$list[$i]);
echo"<option value=$list_info[0]>$list_info[1]</option>";
}?>
              </select>
&nbsp;
<input type=submit value=查找 name=Submit style="width:80px;height:30px;background:#47B751 no-repeat left top; color:#FFF;"></td>
            <td width="12%" height="20" bgcolor="#FFFFFF">&nbsp;<a href="<?=$site_url?>" target="_blank" class="style8"><span class="style8"> </span></a></td>
          </tr>
        </form>
      </table>   
    </td>
    
    
  </tr>
</table>



<table width="1350" height="45" border="0" align="left" cellpadding="3" cellspacing="0" bgcolor="#FFFFFF">
  <tbody> 
  <tr align="left"> 
    <td width="120" height="45" background="images/bannerbg.jpg" align="left">&nbsp;</td>
    <td width="1110" height="45" background="images/bannerbg.jpg" class="font" align="left"><a href="index.php"><font color="#FFFFFF">返回首页 </a><?
$list=file("data/class.php");
$count=count($list)-1;
for ($i=0; $i<=$count; $i++) {
	$list_info=explode("|",$list[$i]);
	echo" | <a href=\"list.php?classid=$list_info[0]\"><font color=#FFFFFF>$list_info[1]</font></a>";
}
?>
      |</font> </td>
    <td width="120" height="45" background="images/bannerbg.jpg" align="left">&nbsp;</td>
    </tr>
  </tbody>
</table>


