<?
require("fun.php");
get_classid();

if ($ckeckid==0){ echo"没有此分类";exit;}
if (!$nclassid) {$nclass_name='本类软件'; }else {get_nclassid();if ($nckeckid==0){ echo"没有此子分类";exit;}}

if (empty($page)) $page=1;
if ($page <1)  $page=1;
settype($page, integer);
$perpage=20;

$softgs=@file("data/list.php");

require "header.php";
?>
<link href="images/css.css" rel=stylesheet>
<table width="1100" border="0" cellspacing="4" cellpadding="0" align="center" height="20">
  <tr> 
    <td bgcolor="#E4E4E4"><font color="#000000">您的位置：</font><a href=index.php><font color="#000000">首页</font></a> <font color="#00000">-></font> <a href="sort.php"><font color="#000000">软件分类</font></a> <font color="#000000">-></font> <a href=list.php?classid=<?=$classid?>><font color="#000000"><?=$class_name?></font></a> <font color="#000000">-> <?echo $nclass_name?></font></td>
  </tr>
</table>


<table width="1100" height="60" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFF7">
  <tr> 
    <td width="350" bgcolor="#FFFFFF" valign="top">
      <table width="350" border="0" cellspacing="0" cellpadding="2">
        <tr> 
          <td height="40" width="350" align="center" background="images/bannerbg2.jpg"><a href=list.php?classid=<?=$classid?>><font color="#000000"><b><?=$class_name?></b></font></a></td>
        </tr>
        <tr>
          <td height="20" bgcolor="#FFFFFF" align="left"><table width=98% border="0" cellspacing="0" cellpadding="1" align="left">
          
<?
$list=@file("data/nclass.php");
$count=count($list)-1;
$bclass="";
for ($i=0; $i<=$count; $i++) 
{
	$list_info=explode("|",$list[$i]);
	if ($list_info[0]==$classid) echo "<tr><td align=center><a href=\"list.php?classid=$list_info[0]&nclassid=$list_info[1]\"><font color=#330000>$list_info[2]</font></a></td></tr>";	
}
?>
          </table></td>
        </tr>
      </table>
	  <table width="350" border="0" cellspacing="0" cellpadding="2">
        <tr> 
          <td height="40" width="350" align="center" background="images/bannerbg2.jpg"><div align="left"><font color="#FFFFFF"><b> <font color="#000000"><b>全部</b>下载TOP10</font></b></font></div></td>
        </tr>
        <tr>
          <td height="20" bgcolor="#FFFFFF">
		  <table width=98% border="0" cellspacing="0" cellpadding="1">
		  <tr><td bgcolor="#FFFFFF">
<?
$top10=@file("data/downhot.php");

$c=min(count($top10),10); 
 for ($i=0; $i<$c; $i++){

 $detail=explode("|",$top10[$i]);      

 $file_name=chop($detail[2]);     

//if (strlen($detail[3])>=25) $detail[3]=substr($detail[3],0,22)."...";
 echo "<LI><a href=\"show.php?id=$detail[2]\">$detail[3]</a>";			
         

   }
 ?></LI></td>
		  </tr>
		  </table></td>
        </tr>
      </table>
      <table width="350" border="0" cellspacing="0" cellpadding="2">
        <tr>
          <td height="40" width="350" align="center" background="images/bannerbg2.jpg"><div align="left"><font color="#330000"><b> <font color="#000000">今日下载TOP10</font></b></font><font color="#FFFFFF"></font></div></td>
        </tr>
        <tr>
          <td height="20" bgcolor="#FFFFFF">
            <table width=98% border="0" cellspacing="0" cellpadding="1">
              <tr>
                <td bgcolor="#FFFFFF">
                  <?
$top10=@file("data/downhotday.php");

$c=min(count($top10),10); 
 for ($i=0; $i<$c; $i++){

 $detail=explode("|",$top10[$i]);      

 $file_name=chop($detail[2]);     

//if (strlen($detail[3])>=25) $detail[3]=substr($detail[3],0,22)."...";
 echo "<LI><a href=\"show.php?id=$detail[2]\">$detail[3]</a>";			
         

   }
 ?></td>
              </tr>
          </table></td>
        </tr>
    </table></td>
    <td width="20" bgcolor="#FFFFFF">&nbsp;</td>
    <td valign=top> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td bgcolor="#FFFFF7" height="20">
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="40" background="images/bannerbg2.jpg">
          <tr bgcolor="#FFF7E7">
          	<td bgcolor="#E4E4E4">&nbsp;<font color="#000000">软件名称</font></td>
          	<td width="14%" align=center bgcolor="#E4E4E4"><font color="#000000">日期</font></td>
          	<td width="10%" align=center bgcolor="#E4E4E4"><font color="#000000">人气</font></td>
          	<td width="10%" align=right bgcolor="#E4E4E4"><font color="#000000">大小&nbsp;</font></td>
          </tr>
          </table></td>
        </tr>
		<tr><td height=5 bgcolor="#FFFFFF"></td>
		</tr>
        <tr>
          <td height="50" bgcolor="#FFFFFF" class="font">
<?
$count=count($softgs);
 for ($i=0; $i<$count; $i++){

 $detail=explode("|",$softgs[$i]);
 $file_name=chop($detail[2]);
 if (file_exists("data/data/$file_name.php")){
 if(!$nclassid) {
	 if ($classid==$detail[0]) $softg_list[]=$softgs[$i];
 }else {
	 if ($classid==$detail[0] && $nclassid==$detail[1]) $softg_list[]=$softgs[$i];
	 }
 }

 }
$countnum=count($softg_list);
$list_soft='';
$count=$countnum;
if($count!=0){
 if ($count%$perpage==0) $maxpageno=$count/$perpage;
		else $maxpageno=floor($count/$perpage)+1;
	if ($page>$maxpageno) $page=$maxpageno;
	$pagemin=min( ($page-1)*$perpage , $count-1);
	$pagemax=min( $pagemin+$perpage-1, $count-1);
	for ($i=$pagemin; $i<=$pagemax; $i++) {
	 $detail=explode("|",$softg_list[$i]);
$file_name=chop($detail[2]);
  $a_info=@file("data/data/$file_name.php");  list($txt_category_id,$txt_class_id,$txtshowname,$txtfilename,$txtshow,$txtfilename1,$txtshow1,$txtfilename2,$txtshow2,$txtfilename3,$txtshow3,$fromurl,$adddate,$size,$order,$hot,$hots,$hide,$usrtool,$runsystem,$txtnote,$times,$imgurl)=explode("|",$a_info[1]);
$txtnote=str_replace("<br>","　",$txtnote);
  if (strlen($txtnote)>=50) $txtnote=substr($txtnote,0,48)."...";
list($viewnum,$downnum,$tviewnum,$tdownnum,$pinfeng,$viewtimes)=explode("|",$a_info[2]);
if($downnum=="") $downnum=0;
if($size=="KB") $size="未知";
$times=get_date($times);  
?>
<table width="99%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="20" bgcolor="#FFFFFF" class="font"><a href="show.php?id=<?echo $file_name;?>"><b><?echo $txtshowname?></b></a></td>
  </tr>
  <tr> 
    <td height="40" align="right" bgcolor="#FFFFFF"> 
      <table width="98%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td height="20">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td bgcolor="#FFFFFF"><?echo $txtnote;?> </td>
                <td width="14%" align=center bgcolor="#FFFFFF" class="font"><?echo $adddate;?></td>
                <td width="10%" align=center bgcolor="#FFFFFF" class="font"><?=$viewnum?></td>
                <td width="10%" align=right bgcolor="#FFFFFF" class="font"><?echo $size;?>&nbsp;</td>
              </tr>
            </table>
          </td>
        </tr>
        <tr>
          <td height="20">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td width="100%" bgcolor="#FFFFFF" class="font"><b>操作系统</b>：<?echo $runsystem;?> &nbsp;&nbsp;<b>授权方式</b>：<?echo $order;?></td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="1" bgcolor="#FFCC99"></td>
  </tr>
</table>
<?

}
}else {echo "本类别暂时无软件";}
?></td>
        </tr>
		<form method=post action=list.php?classid=<?=$classid?>&nclassid=<?=$nclassid?>>
        <tr>
          <td bgcolor="#E4E4E4" height="22">&nbsp;<?=$nclass_name?> | 
<?
if ($maxpageno<=1) echo " 软件合计{$countnum}个 | 只有一页";
else { 
      $nextpage=$page+1;
      $previouspage=$page-1;
	  echo " 软件合计{$countnum}个 | ";
	  if ($page<=1) echo " 首页　上一页　<a href=list.php?classid=$classid&nclassid=$nclassid&page=$nextpage>下一页</a>　<a href=list.php?classid=$classid&nclassid=$nclassid&page=$maxpageno>尾页</a> ";
	  elseif($page>=$maxpageno) echo " <a href=list.php?classid=$classid&nclassid=$nclassid&page=1>首页</a>　<a href=list.php?classid=$classid&nclassid=$nclassid&page= $previouspage>上一页</a>　下一页　尾页 ";
	 
	  else echo " <a href=list.php?classid=$classid&nclassid=$nclassid&page=1>首页</a>　<a href=list.php?classid=$classid&nclassid=$nclassid&page= $previouspage>上一页</a>　<a href=list.php?classid=$classid&nclassid=$nclassid&page=$nextpage>下一页</a>　<a href=list.php?classid=$classid&nclassid=$nclassid&page=$maxpageno>尾页</a> ";
	  echo " | $page/$maxpageno  20个/页 | 转到 <select name='page' size='1' style=\"border: 1px solid #429234; background-color: #FAFDF9\" onChange='javascript:submit()'>";
	for ($j=1; $j<=$maxpageno; $j++) {echo "<option value='".$j."'>第".$j."页</option>";
	}
	echo "</select>";
}
?></td>
        </tr></form>
      </table>
    </td>
  </tr>
</table>
<?
require "footer.php";
?>
