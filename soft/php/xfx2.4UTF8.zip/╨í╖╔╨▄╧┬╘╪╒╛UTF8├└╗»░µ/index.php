<?
require("fun.php");

if (file_exists("data/config.php"))	
{
$sys_info=explode("|",readfrom("data/config.php"));
static $notice;
$notice=$sys_info[4];
}

$softgs=@file("data/list.php");
$numober=count($softgs);

$listv=@file("data/nclass.php");	

$c=min(count($softgs),20); 
$softgss='';
 for ($i=0; $i<$c; $i++){

 $detail=explode("|",$softgs[$i]);      

 $file_name=chop($detail[2]);
 $countv=count($listv);
	for ($ii=0; $ii<$countv; $ii++) {
		$detailv=explode("|", trim($listv[$ii]));
		if ($detailv[1]==$detail[1] && $detailv[0]==$detail[0]){$nclass_name=$detailv[2];break;}
		
	}


// if (strlen($detail[3])>=29) $detail[3]=substr($detail[3],0,27)."...";
 $softgss.="[<a href=list.php?classid=$detail[0]&nclassid=$detail[1]>".$nclass_name."</a>]&nbsp;<a href=\"show.php?id=$detail[2]\">$detail[3]</a><br>";			
       

   }
require "header.php";
?>
<body bgcolor="#FFFFFF">
<table width="1100" height="70" align="center" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF">
  <tr> 
    <td width="350" bgcolor="#FFFFFF" valign="top"> 
      <table width="100%" border="0" cellpadding="2" cellspacing="0" bordercolor="#FFFFFF">
        <tr> 
          <td height="40" align="center" background="images/bannerbg2.jpg">
          	<div align="left"><b><font color="#000000"> 推荐软件</font></b></div></td>
        </tr>
        <tr> 
          <td height="5" bgcolor="#FFFFFF"></td>
        </tr>
        <tr> 
          <td height="20" bgcolor="#FFFFFF"> 
            <?
$top10=@file("data/hots.php");

$c=min(count($top10),10); 
 for ($i=0; $i<$c; $i++){

 $detail=explode("|",$top10[$i]);      

 $file_name=chop($detail[2]);     

////if (strlen($detail[3])>=25) $detail[3]=substr($detail[3],0,22)."...";
 echo "<LI><a href=\"show.php?id=$detail[2]\">$detail[3]</a>";			
         

   }
 ?></LI>
          </td>
        </tr>
      </table>


      <table width="100%" border="0" cellspacing="0" cellpadding="2">
        <tr> 
          <td height="40" align="center" background="images/bannerbg2.jpg"><div align="left"><b><font color="#000000"> 软件下载TOP10</font></b></div></td>
        </tr>
        <tr> 
          <td height="20" bgcolor="#FFFFFF"> 
            <?
$top10=@file("data/downhot.php");

$c=min(count($top10),10); 
 for ($i=0; $i<$c; $i++){

 $detail=explode("|",$top10[$i]);      

 $file_name=chop($detail[2]);     

 //if (strlen($detail[3])>=25) $detail[3]=substr($detail[3],0,22)."...";
 echo "<LI><a href=\"show.php?id=$detail[2]\">$detail[3]</a>";			
         

   }
 ?></LI>
          </td>
        </tr>
      </table>
    </td>
    
  <td width="30"></td>  
    
    
    <td width="500" valign="top" align="center"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td height="40" align="center" background="images/bannerbg2.jpg">&nbsp;&nbsp; <font color="#000000"><b>近期更新</b></font></td>
        </tr>
        <tr> 
          <td height="70" bordercolor="#5FB0D8" bgcolor="#FFFFFF"><? echo $softgss; ?><br><br><br><br><br><br>
          </td>
        </tr>
      </table>
    </td>
    
    
  <td width="30"></td> 
  
  
    <td  width="190" valign="top" bgcolor="#FFFFFF"> 
      <table height="40" cellspacing=0 cellpadding=0 width=100% border=0>
        <tbody> 
        <tr align=middle> 
          <td height=40 align=center valign=middle background="images/bannerbg2.jpg" class=bt><b><font color="#370000"><b><font color="#370000"><font color="#000000">&#29305;&#21035;&#20844;&#21578;</font></font></b> </font></b></td>
          </tr>
        </tbody> 
      </table>
      <div align="center" height="200"><marquee onMouseOver=this.stop() onMouseOut=this.start() scrollamount=2 direction=up border="0"> <div align="center"><? echo $notice;?>
        </marquee> 
    </div></td>
  </tr>
</table>
<div align="center">
  <?
require "footer.php";
?>
</div>
