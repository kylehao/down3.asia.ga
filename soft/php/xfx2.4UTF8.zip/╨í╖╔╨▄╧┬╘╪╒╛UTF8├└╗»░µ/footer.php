<?
if (file_exists("data/config.php"))	
{
$sys_info=explode("|",readfrom("data/config.php"));
static $site_name;
static $site_url;
$site_name=$sys_info[0];
$site_url=$sys_info[1];
}
?>
<style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
</style>

<table width="1100" height="119" align="center" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF">
	<tr>
		<td background="images/yqlj.jpg" width="1100" height="49"><font color="#370000"><b>友情链接</b></font></td>
	</tr>
  <tr> 
    <td width="1100" height="70" bgcolor="#FFFFFF" valign="top"> 
     <a href="http://www.free163.com">听松阁</a>
     
    </td>
  </tr>
</table>
        
        
<table cellspacing=0 cellpadding=0 width="1350" align=center border=0>
  <tbody> 
  <tr> 
    <td background="images/footerbg.png" width="1350" height="44">
  </td>
  </tr>
  <tr> 
    <td height=22 align=center bgcolor="#FFFFFF" class=top style1>Copyright @ 2005-2019 <a href=http://www.free163.com>听松阁</a> All Rights Reserved.  
  </td> 
  </tr>
  </tbody> 
</table>
<TABLE WIDTH="680" BORDER="0" CELLPADDING="0" CELLSPACING="0" ALIGN="CENTER" bgcolor="#FFFFFF">
  <TR>
    <TD ALIGN="center">
<script language="javascript" type="text/javascript" src="http://js.d.s32.51.la/514.js"></script>
<script src='http://s11.cnzz.com/stat.php?id=1547&web_id=28195&show=pic' language='JavaScript' charset='gb2312'></script>
</TD>
  </TR>
</TABLE>
</body>
</html>
<center><script type="text/javascript"><!--
google_ad_client = "pub-8742386847853865";
google_ad_width = 680;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text_image";
google_ad_channel ="";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script></center>
