<?

require("fun.php");

if (empty($keyword)) {echo '没有输入关键字,请您重新输入!  <a href=javascript:history.go(-1)>返回前页</a>' ;exit;}


$listtosearch=file("data/list.php");
	$count=count($listtosearch);
	for ($j=0; $j<$count; $j++) {
list($a,$b,$c,$d,$e,$f)=explode("|",$listtosearch[$j]);
if($action=='title'){
if($sclass=='all') 	{
	if (strpos($d,$keyword) !== false ) {
					$result[] = $listtosearch[$j];
					$resultcount++;
					
				}
				}else{
if ($a==$sclass && strpos($d,$keyword) !== false ) {
					$result[] = $listtosearch[$j];
					$resultcount++;
					
				}
				}
	
}elseif($action=='content'){

$file_name=chop($c);
  $a_info=@file("data/data/$file_name.php");  list($txt_category_id,$txt_class_id,$txtshowname,$txtfilename,$txtshow,$txtfilename1,$txtshow1,$txtfilename2,$txtshow2,$txtfilename3,$txtshow3,$fromurl,$size,$order,$hot,$hots,$hide,$usrtool,$runsystem,$txtnote,$times,$imgurl)=explode("|",$a_info[1]);

 if($sclass=='all') 	{
	if (strpos($txtnote,$keyword) !== false ) {
					$result[] = $listtosearch[$j];
					$resultcount++;
					
				}
				}else{
if ($a==$sclass && strpos($txtnote,$keyword) !== false ) {
					$result[] = $listtosearch[$j];
					$resultcount++;
					
				}
				}
	}

}
$class_name="搜索软件";
if (empty($page)) $page=1;
if ($page <1)  $page=1;
settype($page, integer);
$perpage=20;

require "header.php";
?>
<link href="images/css.css" rel=stylesheet>
<table width="1100" border="0" cellspacing="4" cellpadding="0" align="center" height="20">
  <tr> 
    <td bgcolor="#E4E4E4"><font color="#000000">您的位置：</font><a href=index.php><font color="#000000">首页</font></a> <font color="#000000F">-></font> <a href="sort.php"><font color="#000000">软件分类</font></a> <font color="#000000">-></font>      <?=$class_name?></td>
  </tr>
</table>
<table width="1100" border="0" cellspacing="0" cellpadding="0" align="center" height="60">
  <tr> 
    <td width="350" bgcolor="#FFFFFF" valign="top">
	  <table width="350" border="0" cellspacing="0" cellpadding="2">
        <tr> 
          <td height="40" align="center" background="images/bannerbg2.jpg"><div align="left"><font color="#FFFFFF"><b> <font color="#000000"><b>全部</b>下载TOP10</font></b></font></div></td>
        </tr>
        <tr>
          <td height="20" bgcolor="#FFFFFF">
		  <table width=98% border="0" cellspacing="0" cellpadding="1">
		  <tr><td bgcolor="#FFFFFF">
<?
$top10=@file("data/downhot.php");

$c=min(count($top10),10); 
 for ($i=0; $i<$c; $i++){

 $detail=explode("|",$top10[$i]);      

 $file_name=chop($detail[2]);     

//if (strlen($detail[3])>=25) $detail[3]=substr($detail[3],0,22)."...";
 echo "<LI><a href=\"show.php?id=$detail[2]\">$detail[3]</a>";			
         

   }
 ?></LI></td>
		  </tr>
		  </table></td>
        </tr>
      </table>
      
      

	  <table width="350" border="0" cellspacing="0" cellpadding="2">
        <tr> 
          <td height="40" align="center" background="images/bannerbg2.jpg"><div align="left"><font color="#330000"><b> <font color="#000000">今日下载TOP10</font></b></font><font color="#FFFFFF"></font></div></td>
        </tr>
        <tr>
          <td height="20" bgcolor="#FFFFFF">
		  <table width=98% border="0" cellspacing="0" cellpadding="1">
		  <tr><td bgcolor="#FFFFFF">
<?
$top10=@file("data/downhotday.php");

$c=min(count($top10),10); 
 for ($i=0; $i<$c; $i++){

 $detail=explode("|",$top10[$i]);      

 $file_name=chop($detail[2]);     

//if (strlen($detail[3])>=25) $detail[3]=substr($detail[3],0,22)."...";
 echo "<LI><a href=\"show.php?id=$detail[2]\">$detail[3]</a>";			
         

   }
 ?></LI></td>
		  </tr>
		  </table></td>
        </tr>
      </table>
    </td>
    
    
    
    <td width="30">&nbsp;</td>
    
    
    
    <td valign=top class="font"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td bgcolor="#FFFFF7" height="20">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr bgcolor="#FFF7E7">
          	<td height="40" background="images/bannerbg2.jpg">&nbsp;软件名称</td>
          	<td width="14%" align=center bgcolor="#E4E4E4"><font color="#000000">日期</font></td>
          	<td width="10%" align=center bgcolor="#E4E4E4"><font color="#000000">人气</font></td>
          	<td width="10%" align=right bgcolor="#E4E4E4"><font color="#000000">大小&nbsp;</font></td>
          </tr>
          </table></td>
        </tr>
		<tr><td height=5 bgcolor="#FFFFFF"></td>
		</tr>
        <tr>
          <td height="50" bgcolor="#FFFFFF" class="font">
<?
$countnum=count($result);
$list_soft='';
$count=$countnum;
if($count!=0){
 if ($count%$perpage==0) $maxpageno=$count/$perpage;
		else $maxpageno=floor($count/$perpage)+1;
	if ($page>$maxpageno) $page=$maxpageno;
	$pagemin=min( ($page-1)*$perpage , $count-1);
	$pagemax=min( $pagemin+$perpage-1, $count-1);
	for ($i=$pagemin; $i<=$pagemax; $i++) {
	 $detail=explode("|",$result[$i]);
$file_name=chop($detail[2]);
  $a_info=@file("data/data/$file_name.php");  list($txt_category_id,$txt_class_id,$txtshowname,$txtfilename,$txtshow,$txtfilename1,$txtshow1,$txtfilename2,$txtshow2,$txtfilename3,$txtshow3,$fromurl,$size,$order,$hot,$hots,$hide,$usrtool,$runsystem,$txtnote,$times,$imgurl)=explode("|",$a_info[1]);
  $txtnote=str_replace("<br>","　",$txtnote);
  if (strlen($txtnote)>=50) $txtnote=substr($txtnote,0,47)." ...";
  $txtshowname = str_replace($keyword,"<font color=red>$keyword</font>",$txtshowname);
  $txtnote = str_replace($keyword,"<font color=red>$keyword</font>",$txtnote);
list($viewnum,$downnum,$tviewnum,$tdownnum,$pinfeng,$viewtimes)=explode("|",$a_info[2]);

?>
<table width="99%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="20" bgcolor="#FFFFFF" class="font"><a href="show.php?id=<?echo $file_name;?>"><b><?echo $txtshowname?></b></a></td>
  </tr>
  <tr> 
    <td height="40" align="right"> 
      <table width="98%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td height="20">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr class="font"> 
            <td width="66%" align=left><?echo $nouse;?> </td>
                <td width="14%" align=center class="font"><?echo $size;?></td>
                <td width="10%" align=center class="font"><?=$viewnum?></td>
                <td width="10%" align=right class="font"><?echo $order;?>&nbsp;</td>
              </tr>
            </table>
          </td>
        </tr>
        <tr>
          <td height="20">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td width="100%"><span class="font"><b>操作系统</b>：<?echo $txtnote;?>&nbsp;&nbsp;<b>授权方式:</b>
                    <?=$hot?>
                    &nbsp;</span>&nbsp;</td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="1" bgcolor="#FFCC99"></td>
  </tr>
</table>
<?

}
}else {echo "对不起，没有搜索到相关的软件";}
?></td>
        </tr>
		<form method=post action=list.php?classid=<?=$classid?>&nclassid=<?=$nclassid?>>
        <tr>
          <td bgcolor="#E4E4E4" height="22">&nbsp;<font color="#000000">搜索软件 |</font><?
if ($maxpageno<=1) echo " 搜到合计{$countnum}个 | 只有一页";
else { 
      $nextpage=$page+1;
      $previouspage=$page-1;
	  echo " 搜到合计{$countnum}个 | ";
	  if ($page<=1) echo " 首页　上一页　<a href=list.php?classid=$classid&nclassid=$nclassid&page=$nextpage>下一页</a>　<a href=list.php?classid=$classid&nclassid=$nclassid&page=$maxpageno>尾页</a> ";
	  elseif($page>=$maxpageno) echo " <a href=list.php?classid=$classid&nclassid=$nclassid&page=1>首页</a>　<a href=list.php?classid=$classid&nclassid=$nclassid&page= $previouspage>上一页</a>　下一页　尾页 ";
	 
	  else echo " <a href=list.php?classid=$classid&nclassid=$nclassid&page=1>首页</a>　<a href=list.php?classid=$classid&nclassid=$nclassid&page= $previouspage>上一页</a>　<a href=list.php?classid=$classid&nclassid=$nclassid&page=$nextpage>下一页</a>　<a href=list.php?classid=$classid&nclassid=$nclassid&page=$maxpageno>尾页</a> ";
	  echo " | $page/$maxpageno  20个/页 | 转到 <select name='page' size='1' style=\"border: 1px solid #429234; background-color: #FAFDF9\" onChange='javascript:submit()'>";
	for ($j=1; $j<=$maxpageno; $j++) {echo "<option value='".$j."'>第".$j."页</option>";
	}
	echo "</select>";
}
?></td>
        </tr>
		</form>
      </table>
    </td>
  </tr>
</table>
<?
require "footer.php";
?>
