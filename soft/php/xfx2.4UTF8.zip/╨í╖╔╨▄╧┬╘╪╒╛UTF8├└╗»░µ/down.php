<?
require("fun.php");
if(empty($id)) { echo"对不起，此软件不存在，可能已被删除，有问题请联系站长";exit;}
if(empty($downid)) $downid=1;
if (!file_exists("data/data/$id.php")) { echo"此软件不存在，可能已被删除，有问题请联系站长";exit;}
$a_info=@file("data/data/$id.php");  list($txt_category_id,$txt_class_id,$txtshowname,$txtfilename,$txtshow,$txtfilename1,$txtshow1,$txtfilename2,$txtshow2,$txtfilename3,$txtshow3,$fromurl,$size,$order,$hot,$hots,$hide,$usrtool,$runsystem,$txtnote,$times,$imgurl)=explode("|",$a_info[1]);
list($viewnum,$downnum,$tviewnum,$tdownnum,$pinfeng,$viewtimes,$viewtimes1)=explode("|",$a_info[2]);
if($downid==1) $downurl=$txtfilename;
elseif($downid==2) $downurl=$txtfilename1;
elseif($downid==3) $downurl=$txtfilename2;
$t=getdate($viewtimes);	
$d=getdate($timestamp);

if($t['mday']==$d['mday']) {
	$tdownnum++;
}else{
$tdownnum=1;
$viewtimes=$timestamp;

}
$downnum++;
$a_infoa=trim($a_info[0]);
$a_infob=trim($a_info[1]);
unset($a_info[0]);
unset($a_info[1]);
unset($a_info[2]);
$a_infoc="$viewnum|$downnum|$tviewnum|$tdownnum|$pinfeng|$viewtimes|$viewtimes1|";
$line_ff= $a_infoa."\n".$a_infob."\n".$a_infoc."\n".implode("",$a_info);
writeto("data/data/$id.php",$line_ff);


$down_hot=file("data/downhot.php");
$down_hot_count=count($down_hot)-1;
$down_hot_info=explode("|",$down_hot[29]);
$ab_info=@file("data/data/$down_hot_info[2].php"); 
list($viewnumd,$downnumd,$tviewnumd,$tdownnumd,$pinfengd,$viewtimesd,$viewtimesd1)=explode("|",$ab_info[2]);
if ($downnum>=$downnumd) {
for ($i=0;$i<=$down_hot_count;$i++){
    $down_hot_info=explode("|",$down_hot[$i]);
	$ab_info=@file("data/data/$down_hot_info[2].php"); 
list($viewnumd,$downnumd,$tviewnumd,$tdownnumd,$pinfengd,$viewtimesd,$viewtimesd1)=explode("|",$ab_info[2]);
       	
    if ($down_hot_info[2]!=$id )   $rank_typearray[$down_hot[$i]]=$downnumd;
}
$down_hot_show=$txt_category_id."|".$txt_class_id."|".$id."|".$txtshowname."|".$times."|\n";
$rank_typearray[$down_hot_show]=$downnum;
arsort($rank_typearray);
reset($rank_typearray);
$fp=fopen("data/downhot.php","w");
flock($fp,3);
for ($counter=1; $counter<=30; $counter++) {
    $keytype=key($rank_typearray);
    fwrite($fp,$keytype);
    if (!(next($rank_typearray))) break;
}
fclose($fp);
}
$day_hot=file("data/downhotday.php");
$day_hot_count=count($day_hot)-1;
$day_hot_info=explode("|",$day_hot[9]);
$ab_info=@file("data/data/$day_hot_info[2].php"); 
list($viewnumd,$downnumd,$tviewnumd,$tdownnumd,$pinfengd,$viewtimesd,$viewtimesd1)=explode("|",$ab_info[2]);
if ($tdownnum>=$tdownnumd) {
for ($i=0;$i<=$day_hot_count;$i++){
    $day_hot_info=explode("|",$day_hot[$i]);
	$ab_info=@file("data/data/$day_hot_info[2].php"); 
$day_hots=explode("|",$ab_info[2]);
    $c=getdate($day_hots[5]);
    if ($day_hot_info[2]!=$id && $c['mday']==$d['mday'])   $rank_hots[$day_hot[$i]]=$day_hots[3];

}
$day_hot_show=$txt_category_id."|".$txt_class_id."|".$id."|".$txtshowname."|".$times."|\n";
$rank_hots[$day_hot_show]=$tdownnum;
arsort($rank_hots);
reset($rank_hots);
$fp=fopen("data/downhotday.php","w");
flock($fp,3);
for ($counter=1; $counter<=10; $counter++) {
    $keytype=key($rank_hots);
    fwrite($fp,$keytype);
    if (!(next($rank_hots))) break;
}
fclose($fp);
}

header ("Location:".$downurl);
exit;

 
?>
