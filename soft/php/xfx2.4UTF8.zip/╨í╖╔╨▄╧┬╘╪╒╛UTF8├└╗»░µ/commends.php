<?
require("fun.php");
get_classid();

$class_name="精品推荐";
if (empty($page)) $page=1;
if ($page <1)  $page=1;
settype($page, integer);
$perpage=20;
$softg_list=@file("data/hots.php");
$numober=count($softg_list);
require "header.php";
?>
<link href="images/css.css" rel=stylesheet>
<table width="1100" border="0" cellspacing="4" cellpadding="0" align="center" height="20">
  <tr> 
    <td bgcolor="#E4E4E4"><font color="#000000">您的位置：</font><a href=index.php><font color="#000000">首页</font></a> <font color="#000000">-> </font><a href="sort.php"><font color="#000000">软件分类</font></a><font color="#000000"> -></font>      <?=$class_name?></td>
  </tr>
</table>
<table width="1100" border="0" cellspacing="0" cellpadding="0" align="center" height="60">
  <tr> 
    <td width="350" bgcolor="#FFFFFF" valign="top">
	  <table width="350" border="0" cellspacing="0" cellpadding="2">
        <tr> 
          <td height="40" align="center" background="images/bannerbg2.jpg"><div align="left"><font color="#FFFFFF"><b><font color="#370000"> </font><font color="#000000"><b><font color="#330000">全部</font></b></font><font color="#330000">下载TOP10</font></b></font></div></td>
        </tr>
        <tr>
          <td height="20">
		  <table width=98% border="0" cellspacing="0" cellpadding="1">
		  <tr><td bgcolor="#FFFFFF">
<?
$top10=@file("data/downhot.php");$c=min(count($top10),10); 
 for ($i=0; $i<$c; $i++){ $detail=explode("|",$top10[$i]);       $file_name=chop($detail[2]);     //if (strlen($detail[3])>=25) $detail[3]=substr($detail[3],0,22)."...";
 echo "<LI><a href=\"show.php?id=$detail[2]\">$detail[3]</a>";			
            }
 ?></LI></td>
		  </tr>
		  </table></td>
        </tr>
      </table>
      

<table width="350" border="0" cellspacing="0" cellpadding="2">
        <tr> 
          <td height="40" align="center" background="images/bannerbg2.jpg"><div align="left"><font color="#000000"><b> 今日下载TOP10</b></font></div></td>
        </tr>
        <tr>
          <td height="20">
		  <table width=98% border="0" cellspacing="0" cellpadding="1">
		  <tr><td bgcolor="#FFFFFF">
<?
$top10=@file("data/downhotday.php");$c=min(count($top10),10); 
 for ($i=0; $i<$c; $i++){ $detail=explode("|",$top10[$i]);       $file_name=chop($detail[2]);     //if (strlen($detail[3])>=25) $detail[3]=substr($detail[3],0,22)."...";
 echo "<LI><a href=\"show.php?id=$detail[2]\">$detail[3]</a>";			
            }
 ?></LI></td>
		  </tr>
		  </table></td>
        </tr>
      </table>
    </td>
    
    <td width="30">&nbsp;</td>
    
    <td valign=top> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td bgcolor="#FFFFF7" height="20">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr bgcolor="#FFF7E7">
          	<td height="40" background="images/bannerbg2.jpg">&nbsp;<font color="#000000">软件名称</font></td>
          	<td width="14%" align=center bgcolor="#E4E4E4"><font color="#000000">日期</font></td>
          	<td width="10%" align=center bgcolor="#E4E4E4"><font color="#000000">人气</font></td>
          	<td width="10%" align=right bgcolor="#E4E4E4"><font color="#000000">大小&nbsp;</font></td>
          </tr>
          </table></td>
        </tr>
		<tr><td height=5 bgcolor="#FFFFF7"></td>
		</tr>
        <tr>
          <td height="50" bgcolor="#FFFFFF" class="font">
<?
$countnum=count($softg_list);
$list_soft='';
$count=$countnum;
if($count!=0){
 if ($count%$perpage==0) $maxpageno=$count/$perpage;
		else $maxpageno=floor($count/$perpage)+1;
	if ($page>$maxpageno) $page=$maxpageno;
	$pagemin=min( ($page-1)*$perpage , $count-1);
	$pagemax=min( $pagemin+$perpage-1, $count-1);
	for ($i=$pagemin; $i<=$pagemax; $i++) {
	 $detail=explode("|",$softg_list[$i]);
$file_name=chop($detail[2]);
  $a_info=@file("data/data/$file_name.php");  list($txt_category_id,$txt_class_id,$txtshowname,$txtfilename,$txtshow,$txtfilename1,$txtshow1,$txtfilename2,$txtshow2,$txtfilename3,$txtshow3,$fromurl,$size,$order,$hot,$hots,$hide,$usrtool,$runsystem,$txtnote,$times,$imgurl)=explode("|",$a_info[1]);
  $txtnote=str_replace("<br>","　",$txtnote);
  if (strlen($txtnote)>=50) $txtnote=substr($txtnote,0,49)."...";
list($viewnum,$downnum,$tviewnum,$tdownnum,$pinfeng,$viewtimes)=explode("|",$a_info[2]);
$times=get_date($times); 
?>
<table width="99%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="20" bgcolor="#FFFFFF"><a href="show.php?id=<?echo $file_name;?>"><b><?echo $txtshowname?></b></a></td>
  </tr>
  <tr> 
    <td height="40" align="right"> 
      <table width="98%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
                 <td height="20">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr> 
            <td width="66%" align=left bgcolor="#FFFFFF"><?echo $nouse;?> </td>
                <td width="14%" align=center><?echo $size;?></td>
                <td width="10%" align=center><?=$viewnum?></td>
                <td width="10%" align=right><?echo $order;?>&nbsp;</td>
              </tr>
            </table>
          </td>
        </tr>
        <tr>
          <td height="20">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td width="100%"><b>操作系统</b>：<?echo $txtnote;?>&nbsp;&nbsp;<b>授权方式:</b><?=$hot?>&nbsp;&nbsp;</td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="1" bgcolor="#FFCC99"></td>
  </tr>
</table>
<?}
}else {echo "本类别暂时无软件";}
?></td>
        </tr>
		<form method=post action=commends.php>
        <tr>
          <td bgcolor="#E4E4E4" height="22">&nbsp;<?
if ($maxpageno<=1) echo " 软件合计{$countnum}个 | 只有一页";
else { 
      $nextpage=$page+1;
      $previouspage=$page-1;
	  echo " 软件合计{$countnum}个 | ";
	  if ($page<=1) echo " 首页　上一页　<a href=commends.php?page=$nextpage>下一页</a>　<a href=commends.php?page=$maxpageno>尾页</a> ";
	  elseif($page>=$maxpageno) echo " <a href=commends.php?page=1>首页</a>　<a href=commends.php?page= $previouspage>上一页</a>　下一页　尾页 ";
	 
	  else echo " <a href=commends.php?page=1>首页</a>　<a href=commends.php?page= $previouspage>上一页</a>　<a href=commends.php?page=$nextpage>下一页</a>　<a href=commends.php?page=$maxpageno>尾页</a> ";
	  echo " | $page/$maxpageno  20个/页 | 转到 <select name='page' size='1' style=\"border: 1px solid #429234; background-color: #FAFDF9\" onChange='javascript:submit()'>";
	for ($j=1; $j<=$maxpageno; $j++) {echo "<option value='".$j."'>第".$j."页</option>";
	}
	echo "</select>";
}
?></td>
        </tr></form>
      </table>
    </td>
  </tr>
</table>
<?
require "footer.php";
?>
