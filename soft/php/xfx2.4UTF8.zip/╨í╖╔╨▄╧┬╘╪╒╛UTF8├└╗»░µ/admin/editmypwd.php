<?
session_start();
$thisprog="editmypwd.php";
require("global.php");
if ($_SESSION["login_status"]=="yes"){
print "<tr><td bgcolor=#ADADAD colspan=3><font color=#ffffff>
    <b>欢迎来到管理程式 /修改自己密码</b>
    </td></tr>
";


if (empty($action)) {
	
	
	print <<<EOT
    <tr><td bgcolor=#ffffff colspan=3>
    <b>修改自己的密码：</b>[密码已被MD5加密]
    <form action="$thisprog" method=POST><input type=hidden name="action" value="editmypwd">
    $tab_top
    你的旧密码：<input type=text name="oldpwd" size=25>　<br>你的新密码：<input type=password name="newpwd" size=25> <br>确认新密码：<input type=password name="newpwd1" size=25><br><br>
    　　　<input type=submit value="修　改">
    $tab_bottom</form>
	 
   
    </td></tr></td></tr></table></body></html>
EOT;
exit;
}elseif ($action=="editmypwd") {
print "<tr><td bgcolor=#ADADAD valign=middle align=center colspan=2><b>修改密码</b></td></tr>
	<tr><td bgcolor=ffffff colspan=2>";
	
	if (file_exists("../data/user/$username.php"))	$useri=explode("|",readfrom("../data/user/$username.php"));

if ($useri[2]==md5($oldpwd)){

	if($newpwd && $newpwd==$newpwd1){

$addpwd=md5($newpwd);
$user_info="$useri[0]|$useri[1]|$addpwd|$useri[3]|$useri[4]|";

writeto("../data/user/".$username.".php",$user_info);
echo "<br><br>修改密码完成，请用新密码重新登录<b></b><br>";

	}else{
echo "<br><br>二次输入的新密码不一至<b></b><br>";
}
}else{
//setcookie("userid","");
//setcookie("userpwd","");
echo"<br><br>旧密码错误<b></b><br>";

}
}
print "<br><b>&nbsp;操作完成</b><br><br>&nbsp;&gt;&gt; <a href=$thisprog>返回执行其他动作</a></td></tr></table></body></html>";
exit;
}
elseif ($_SESSION["login_status"]=="ok"){
print <<<EOT
<tr>
  <td bgcolor=#ADADAD><font color=#ffffff>
<b>欢迎来到 小飞熊下载系统2.4 后台管理系统</b>&nbsp;&nbsp;&nbsp;&nbsp;[<font color=red>对不起，只用超级管理员才能管理这部分。</font>]</td>
EOT;
exit;
}
else
{
print <<<EOT
<tr>
  <td bgcolor=#ADADAD><font color=#ffffff>
<b>欢迎来到 小飞熊下载系统2.4 后台管理系统</b>&nbsp;&nbsp;&nbsp;&nbsp;[您没有登陆，请您点击<a href='login.php'>这里</a>进行登陆！]</td>

EOT;
exit;
}
?>
