<?
session_start();
$thisprog="adduser.php";
require("global.php");
if ($_SESSION["login_status"]=="yes"){
print "<tr><td bgcolor=#ADADAD colspan=3><font color=#ffffff>
    <b>欢迎来到管理程式 / 用户管理</b>
    </td></tr>
";


if (empty($action)) {
	$user_info='';
	$dh=opendir("../data/user/");

	while ($userfile=readdir($dh)) {

		if (($userfile!=".") && ($userfile!="..") && ($userfile!="") && strpos($userfile,".php")) {

			$useri=explode("|",readfrom("../data/user/$userfile"));
	unset($powe);unset($powe1);
	if($useri[3]==1) $powe='selected'; else $powe1='selected';
	$user_info.="
<tr> 
<form action=$thisprog method=POST><input type=hidden name=action value='edit'>
		<input type=hidden name=oldname value=\"$useri[1]\">
<td height=26 width=25% align=center>
<input type=text name=\"name\" size=12 value=\"$useri[1]\"></td>
<td height=26 width=25% align=center>
<input type=text name=\"usrpwds\" size=12 ></td>
<td height=26 width=25%  align=center>
<select name=\"usrpower\"><option value=0 $powe1>普通管理员</option><option value=1 $powe>超级管理员</option></select></td>
<td height=26 width=25%  align=center>
<b><input type=\"submit\" name=\"Submit\" value=\"修改\"> <input type=button value=\"删除\" onClick=\"location.href='$thisprog?action=del&name=$useri[1]'\" ></b></td></form>
</tr>
";

		}

	}

	closedir($dh);
	
	print <<<EOT
    <tr><td bgcolor=#ffffff colspan=3>
    <b>1.新增管理员：</b>
    <form action="$thisprog" method=POST><input type=hidden name="action" value="addnew">
    $tab_top
    新管理员：   
    <input type=text name="name" size=12>　密码：<input type=text name="usrpwd" size=12> 权限：<select name="usrpower"><option value=0>普通管理员</option><option value=1>超级管理员</option></select>
    <input type=submit value="提 交">
    $tab_bottom</form>
	 
    <b>2.用户修改：</b>[密码是MD5加密过的，所以不会显示；如不修改密码，请不要填写]
   
    $tab_top
	<div align="center">
  <center>
<table width=100% border="0" cellspacing="0" cellpadding="0" >
<tr> 

<td height="26" width="25%"align="center">
<b>用户名</b></td>
<td height="26" width="25%" align="center">
<b>密码</b></td>
<td height="26" width="25%"  align="center">
<b>权限</b></td>
<td height="26" width="25%"  align="center">
<b>操作</b></td>
</tr>

$user_info
	</table>
  </center>
</div>
   $tab_bottom
    <b>3.注意</b>
    $tab_top
    超级用户可以进行所有功能的操作，
普通用户只有添加修改删除程序的权限。
   
    $tab_bottom
    </td></tr></td></tr></table></body></html>
EOT;
exit;
}elseif ($action=="edit") {
print "<tr><td bgcolor=#ADADAD valign=middle align=center colspan=2><b>修改用户</b></td></tr>
	<tr><td bgcolor=ffffff colspan=2>";

if(file_exists("../data/user/".$oldname.".php")){$useri=explode("|",readfrom("../data/user/$oldname.php"));


if($usrpwds) $addpwd=md5($usrpwds); else $addpwd=$useri[2];
if ($name==$oldname) {

$user_info="$useri[0]|$useri[1]|$addpwd|$usrpower|$useri[4]|";

writeto("../data/user/".$name.".php",$user_info);}
else{
$user_info="$useri[0]|$name|$addpwd|$usrpower|$useri[4]|";

writeto("../data/user/".$name.".php",$user_info);
if(file_exists("../data/user/".$oldname.".php")) unlink("../data/user/".$oldname.".php");
}

echo "<br><br>成功修改<b></b><br>";
}else{echo"有错误发生";}
}elseif ($action=="addnew") {
print "<tr><td bgcolor=#ADADAD valign=middle align=center colspan=2><b>新用户</b></td></tr>
	<tr><td bgcolor=ffffff colspan=2>";	        
$name=str_replace("\t","",$name);
$name=str_replace("\r","",$name);
$name=str_replace("\n","",$name);
$name=kick_out($name);
$date_reg=$timestamp;
$addpwd=md5($usrpwd);

$user_info="<?echo\"终止，您进行的操作非法！\";exit;?>|$name|$addpwd|$usrpower|$date_reg|";

writeto("../data/user/".$name.".php",$user_info);
echo "<br><br>成功加入新成员<b></b><br>";
}elseif ($action=="del") {
print "<tr><td bgcolor=#ADADAD valign=middle align=center colspan=2><b>删除用户</b></td></tr>
	<tr><td bgcolor=ffffff colspan=2>";	        
if(file_exists("../data/user/$name.php")) unlink("../data/user/$name.php");
echo "<br><br>成功删除<b></b><br>";


}
print "<br><b>&nbsp;操作完成</b><br><br>&nbsp;&gt;&gt; <a href=$thisprog>返回执行其他动作</a></td></tr></table></body></html>";
exit;
}
elseif ($_SESSION["login_status"]=="ok"){
print <<<EOT
<tr>
  <td bgcolor=#ADADAD><font color=#ffffff>
<b>欢迎来到 小飞熊下载系统2.4 后台管理系统</b>&nbsp;&nbsp;&nbsp;&nbsp;[<font color=red>对不起，只用超级管理员才能管理这部分。</font>]</td>
EOT;
exit;
}
else
{
print <<<EOT
<tr>
  <td bgcolor=#ADADAD><font color=#ffffff>
<b>欢迎来到 小飞熊下载系统2.4 后台管理系统</b>&nbsp;&nbsp;&nbsp;&nbsp;[您没有登陆，请您点击<a href='login.php'>这里</a>进行登陆！]</td>

EOT;
exit;
}
?>
