<?
session_start();
$thisprog="admin.php";
require("global.php");

$current_time = date("Y-m-d   g:i:s a");
$phpver=PHP_VERSION;
$phpos=PHP_OS;
{
if (isset($_COOKIE)) $testcookie="<font color=000066>通 过</font>";
else $testcookie="<font color=990000>失 败</font>";
}
if ($_SESSION["login_status"]=="yes" || $_SESSION["login_status"]=="ok"){
print <<<EOT
<tr>
  <td bgcolor=#ADADAD><font color=#ffffff>
<b>欢迎来到 小飞熊下载系统2.4 后台管理系统</b>
</td>
</tr>
<tr>
<td bgcolor=#FFFFFF valign=middle align=center>
<font color="#FF6600" face=verdana><b>欢迎您登陆管理程序</b></font>
</td>
</tr>
<tr><td bgcolor=#ffffff>
</td>
</tr>
                
<tr>
<td bgcolor=#ffffff valign=middle align=left>
<center><br>
服务器当前时间：<b><font face=verdana>$current_time</font></b><br>
</center>
$warning
<hr><br>
<font color="#000000"><b>管理员可进行操作说明：</b><br>
<br>
$tab_top<br>
1、已经上传文件至服务器，请选择添加软件进行添加。<font color="blue"> 操可作用户：所有管理员</font><br>
2、对已经添加软件修改或删除，请选择修改删除进行操作。<font color="blue"> 可操作用户：所有管理员</font><br>
3、对软件栏目进行添加、修改、删除，请选择栏目管理进行操作。<font color="blue"> 可操作用户：超级管理员</font><br>
4、对管理员的增加、修改、删除，请选择用户管理进行操作。<font color="blue"> 可操作用户：超级管理员</font><br>
5、为了系统的安全性，<font color="red">离开管理页面时请点击退出系统</font> 。<br>
$tab_bottom
<br>
<br>
<br>
<b>程式环境数据</b><br>
<br>
$tab_top
当前运行程式：&nbsp; &nbsp;$PHP_SELF</font>
<font color="#000000"><br>
PHP程式版本：&nbsp; &nbsp;$phpver</font>
<font color="#000000"><br>
服务端操作系统： $phpos</font>
<font color="#000000"><br>
Cookie 测试：&nbsp; &nbsp; $testcookie
$tab_bottom <br>
<br>
</font>
<font color=#000000>
<hr>
<center>程序制作/版权所有：小飞熊工作室 | Powered By：LFBear Studio [<a href="http://www.lfbear.cn" target="_blank">Url=http://www.lfbear.cn</a>]</font></center><br>
</td></tr></table></td></tr></table></td></tr></table></body></html>
EOT;
exit;
}
else
{
print <<<EOT
<tr>
  <td bgcolor=#ADADAD><font color=#ffffff>
<b>欢迎来到 小飞熊下载系统2.4 后台管理系统</b>&nbsp;&nbsp;&nbsp;&nbsp;[您没有登陆，请您点击<a href='login.php'>这里</a>进行登陆！]</td>

EOT;
exit;
}
?>
