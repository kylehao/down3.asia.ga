// I18N constants

// LANG: "cn", ENCODING: UTF-8 | ISO-8859-1
// Author: LFBear|http://www.lfbear.cn|email:lfbear@yeah.net

// FOR TRANSLATORS:
//
//   1. PLEASE PUT YOUR CONTACT INFO IN THE ABOVE LINE
//      (at least a valid email address)
//
//   2. PLEASE TRY TO USE UTF-8 FOR ENCODING;
//      (if this is not possible, please include a comment
//       that states what encoding is necessary.)

HTMLArea.I18N = {

	// the following should be the filename without .js extension
	// it will be used for automatically load plugin language.
	lang: "cn",

	tooltips: {
		bold:           "粗体",
		italic:         "斜体",
		underline:      "下划线",
		strikethrough:  "删除线",
		subscript:      "下标",
		superscript:    "上标",
		justifyleft:    "左对齐",
		justifycenter:  "居中",
		justifyright:   "右对齐",
		justifyfull:    "两端对齐",
		insertorderedlist:    "顺序清单",
		insertunorderedlist:  "无序清单",
		outdent:        "左缩进",
		indent:         "右缩进",
		forecolor:      "字体颜色",
		hilitecolor:    "背景颜色",
		inserthorizontalrule: "水平线",
		createlink:     "插入链接",
		insertimage:    "插入/更改图像",
		inserttable:    "插入表格",
		htmlmode:       "切换到HTML模式",
		popupeditor:    "编辑器最大化",
		about:          "关于",
		showhelp:       "帮助",
		textindicator:  "通用格式",
		undo:           "撤销",
		redo:           "重做",
		cut:            "剪切",
		copy:           "复制",
		paste:          "粘贴",
		lefttoright:    "从左到右",
		righttoleft:    "从右到左"
	},

	buttons: {
		"ok":           "确定",
		"cancel":       "取消"
	},

	msg: {
		"Path":         "位置",
		"TEXT_MODE":    "您现在出于HTML模式，使用“<>”按钮返回到文本编辑模式。",

		"IE-sucks-full-screen" :
		// translate here
		"The full screen mode is known to cause problems with Internet Explorer, " +
		"due to browser bugs that we weren't able to workaround.  You might experience garbage " +
		"display, lack of editor functions and/or random browser crashes.  If your system is Windows 9x " +
		"it's very likely that you'll get a 'General Protection Fault' and need to reboot.\n\n" +
		"You have been warned.  Please press OK if you still want to try the full screen editor."
	},

	dialogs: {
		"Cancel"                                            : "取消",
		"Insert/Modify Link"                                : "插入/更改链接",
		"New window (_blank)"                               : "弹出新窗口(_blank)",
		"None (use implicit)"                               : "不弹出新窗口",
		"OK"                                                : "确定",
		"Other"                                             : "其它",
		"Same frame (_self)"                                : "同一框架(_self)",
		"Target:"                                           : "目标:",
		"Title (tooltip):"                                  : "窗口标题:",
		"Top frame (_top)"                                  : "顶部框架(_top)",
		"URL:"                                              : "URL:",
		"You must enter the URL where this link points to"  : "您必须输入要指向的网络地址！"
	}
};
