<?
session_start();
function showclass() {
	$downlist=file("../data/nclass.php");
	$fcount=count($downlist);
	for ($i=0; $i<$fcount; $i++) {
$detail=explode("|",$downlist[$i]);
		echo "subcat[$i] = new Array(\"$detail[2]\",\"$detail[0]\",\"$detail[1]\");\n\n";
	}
	echo "onecount=$fcount;\n";
}
function showcategory() {	
$downlist=file("../data/class.php");
	$fcount=count($downlist);
	for ($i=0; $i<$fcount; $i++) {
	$detail=explode("|",$downlist[$i]);
		echo "				<OPTION VALUE=\"$detail[0]\">$detail[1]</OPTION>\n";
}
}
?>

<script language="JavaScript1.2">
function validate(theform) {
	if (theform.txtshowname.value=="" ) {
		alert("请填写软件名称.");
		return false; }
		if (theform.txt_category_id.value=="" || theform.txt_class_id.value=="") {
		alert("请填写软件分类栏目.");
		return false; }
		if (theform.txtfilename.value=="") {
		alert("请填写软件下载地址一.");
		return false; }
	if (theform.txtnote.value=="") {
		alert("请填写软件简介.");
		return false; }}//-->
</script>
<script language = "JavaScript">
var onecount;
onecount=0;
subcat = new Array();
<?=showclass()?>

function changelocation(locationid){
    document.FORM.txt_class_id.length = 0; 
    var locationid=locationid;
    var i;
    for (i=0;i < onecount; i++)
        {if (subcat[i][1] == locationid)
            { document.FORM.txt_class_id.options[document.FORM.txt_class_id.length] = new Option(subcat[i][0], subcat[i][2]);
            }
			if (document.FORM.txt_category_id.options[document.FORM.txt_category_id.selectedIndex].value == "" ) 
			{
			document.FORM.txt_class_id.options[document.FORM.txt_class_id.length] = new Option("[请选择子分类]", "");
			}}} 
</script>


<?
$nowdate=date("Y-m-d");
$thisprog="soft.php";
require("global.php");
if ($_SESSION["login_status"]=="yes" || $_SESSION["login_status"]=="ok"){
$info=explode("|",readfrom("../data/config.php"));
if (empty($actions)) {
print <<<EOT
<head>
<script type="text/javascript">
  _editor_url = 'htmlarea/';
  _editor_lang = 'en';
</script>
<script type="text/javascript" src="htmlarea/htmlarea.js"></script>
<script type="text/javascript" src="htmlarea/dialog.js"></script>
<script tyle="text/javascript" src="htmlarea/lang/en.js"></script>
<noscript></head></noscript>
<noframes><body onload="HTMLArea.replace('TA')"></noframes>
  <tr><td bgcolor=#ADADAD colspan=2><font color=#ffffff>
  <b>欢迎来到管理程式 / 添加软件</b>
  </td></tr>
  <tr>
  <td bgcolor=#eeeeee valign=middle align=center colspan=2>
  <font color=#333333><b>添加软件</b>
  </td></tr>
  <tr bgcolor=ffffff colspan=2><td height=5></td></tr>
  <form action="$thisprog" method="post" name="FORM"  >
  <input type=hidden name="actions" value="process">
  <tr>
  <td bgcolor=ffffff align=center colspan=2>
<table cellspacing="0" width="80%" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse">
<tr align="center"><td width="100%">
<table border="1" cellspacing="0" width="100%" cellpadding="0" style="border-collapse: collapse" bordercolor="#ADADAD" bgcolor="#ffffff">

<TR>
<TD align="right" width="20%" nowrap height="30">
<font color="#FF0000">软件归属：</font></TD>
<TD width="80%" height="30">&nbsp;<select name="txt_category_id" onChange="changelocation(document.FORM.txt_category_id.options[document.FORM.txt_category_id.selectedIndex].value)">
 				<option selected value="">[请选择主分类]</option>
<!------------------ Show Category ------------------------>
EOT;
showcategory();
print <<<EOT
<!--------------------------- END ----------------------------->
		  </select>
        
        &nbsp;<font color="red">---</font>&nbsp; <select name="txt_class_id">
 				<option selected value="">[请选择子分类]</option>
          </select>
　</TD>
</TR>
<tr><td width="20%" align="right" height="30">
<font color="#FF0000">软件名称：</font></td>
<td width="80%" height="30">
&nbsp;<input type="text" name="txtshowname" size="48" class="smallinput" maxlength="40"></td></tr>
<tr><td width="20%" align="right" height="30">
<font color="#FF0000">下载地一：</font></td>
<td width="80%" height="30">
&nbsp;<input type="text" name="txtfilename" size="48" class="smallinput" maxlength="160" value="$info[3]/">
<select size="1" name="txtshow">
<option value="下载地址一">下载地址一</option>
<option selected value="本地下载">本地下载</option>
<option value="下载页面">下载页面</option>
</select></td></tr>
<tr><td width="20%" align="right" height="30"><font color="#FF0000">图片地址：</font></td>
<td width="80%" height="30">
&nbsp;<input type="text" name="txtfilename3" size="48" class="smallinput" maxlength="160" value="http://">
<select size="1" name="txtshow3">
<option value="预览图片" selected>预览图片&nbsp;&nbsp;</option>
<option value="演示地址">演示地址&nbsp;&nbsp;</option>
</select></td></tr>

<tr><td width="20%" align="right" height="30">
<td width="80%" height="30">
<input name="txtfilename3" type="checkbox" id="txtfilename3" value="images/nopic.gif" checked>
                      <font color="#0000FF">无预览图片或者演示地址</font></td>

<tr><td width="20%" align="right" height="30">下载地二：</td>
<td width="80%" height="30">
&nbsp;<input type="text" name="txtfilename1" size="48" class="smallinput" maxlength="160" value="">
<select size="1" name="txtshow1">
<option value="下载地址二" selected>下载地址二</option>
<option value="汉化补丁">汉化补丁</option>
<option value="破解文件">破解文件</option>
<option value="注册文件">注册文件</option>
</select></td></tr>
<tr><td width="20%" align="right" height="30">下载地三：</td>
<td width="80%" height="30">
&nbsp;<input type="text" name="txtfilename2" size="48" class="smallinput" maxlength="160" value="">
<select size="1" name="txtshow2">
<option value="下载地址三" selected>下载地址三</option>
<option value="汉化补丁">汉化补丁</option>
<option value="破解文件">破解文件</option>
<option value="注册文件">注册文件</option>
</select></td></tr>

<tr><td width="20%" align="right" height="30">软件来源：</td>
<td width="80%" height="30">
&nbsp;<input type="text" name="fromurl" size="48" class="smallinput" maxlength="100" value="http://">&nbsp;&nbsp;<font color="blue">填入来源网址</font></td></tr>
<tr><td width="20%" align="right" height="30">
<td width="80%" height="30"><font color="#FF0000"><input name="fromurl" type="checkbox" id="fromurl" value="无" checked>
                      <font color="#0000FF">无软件来源</font></td>
<tr><td width="20%" align="right" height="30">加入时间：</td>
<td width="80%" height="30">
&nbsp;<input type="text" name="adddate" size="12" class="smallinput" maxlength="20" value="$nowdate"></font></td></tr>
<tr><td width="20%" align="right" height="30">软件大小：</td>
<td width="80%" height="30">
&nbsp;<input type="text" name="size" size="12" class="smallinput" maxlength="20" value=""></font>
<select name="sizetype"><option value="KB">KB</option>
<option value="MB" selected>MB</option> <option value="GB">GB</option>
</select></td></tr>
<tr><td width="20%" align="right" height="30">授权形式：</td>
<td width="80%" height="30">
&nbsp;<select name="order" size="1">
<option value="免费软件" name="order" selected>免费软件</option>
<option value="正版软件" name="order">正版软件</option><
option value="破解注册" name="order">破解注册</option>
<option value="共享软件" name="order">共享软件</option>
<option value="商业软件" name="order">商业软件</option>
<option value="试用软件" name="order">试用软件</option>

</select></td></tr>
<tr><td width="20%" align="right" height="30">
推荐力度：</td>
<td width="80%" height="30">
&nbsp;<select name="hot" size="1">
<option value="1" name="hot">低等『一级』</option>
<option value="2" name="hot" >较低『二级』</option>
<option value="3" name="hot">中等『三级』</option>
<option value="4" name="hot" selected>较高『四级』</option>
<option value="5" name="hot">最高『五级』</option>
</select>　<input type="checkbox" name="hots" value="on" id=x><label for=x>加入精品推荐</label>　<input type="checkbox" name="hide" value="on" id=y><label for=y>设为隐藏</label>　<input type="checkbox" name="usrtool" value="on" id=z><label for=z>加入常用工具</label></td></tr>
<tr><td width="20%" align="right" height="30">
运行环境：</td>
<td width="80%" height="30">
&nbsp;<select name="runsystem">
              <option value="Win9x/ME/NT/2000/XP" selected>Win9x/ME/NT/2000/XP</option>
               <option value="Win9x/ME">Win9x/ME</option>
              <option value="WinNT/2000">WinNT/2000</option>
              <option value="Win9x/NT/2000/UNIX/Lunix">Win9x/NT/2000/XP/UNIX/Lunix</option>
              <option value="UNIX/Lunix">UNIX/Lunix</option>
              <option value="UNIX">UNIX</option>
              <option value="DOS">DOS</option>
              <option value="Mac">Mac</option>
          </select>
</td></tr>
<tr><td width="20%" align="right" height="30">
<font color="#FF0000">软件简介：</font></td>
<td width="80%" height="30">
&nbsp;<textarea name=txtnote1 id="TA" style="width: 100%; height: 20em;"></textarea></td></tr>

 </td>
  </tr>

  <tr bgcolor=eeeeee>
   <td colspan=2 align=center ><input type=submit onclick="return validate(this.form)" value="提 交"> <input type=reset value="重 置">
  </tr>
</form>
  </td></tr></table></body></html>
EOT;
exit;
}
elseif ($actions=="process") {
		$size=$size.$sizetype;
		$txtnote2=str_replace("|","·",$txtnote1);
		$txtnote=stripslashes($txtnote2);
		$txtshowname=stripslashes($txtshowname); 
		$imgurl=stripslashes($imgurl);
        $fromurl=stripslashes($fromurl);
        $adddate=stripslashes($adddate);
		$txtfilename=stripslashes($txtfilename);
		$txtfilename2=stripslashes($txtfilename2);
		$txtfilename3=stripslashes($txtfilename3);
		$txtfilename1=stripslashes($txtfilename1);
		$txtfilename1=kick_out($txtfilename1);
		$txtfilename2=kick_out($txtfilename2);
		$txtfilename3=kick_out($txtfilename3);
		$txtfilename=kick_out($txtfilename);
		$txtshowname=kick_out($txtshowname); 
		$imgurl=kick_out($imgurl);
		$fromurl=kick_out($fromurl);
		if (file_exists("../data/list.php")) {
			$filecc=readfrom("../data/list.php");			
			$filename=get_next_filename($filecc);
		}
		else $filename="1";
		$newlist="$txt_category_id|$txt_class_id|$filename|$txtshowname|$timestamp|\n";
		$hotslist="$txt_category_id|$txt_class_id|$filename|$txtshowname|$timestamp|\n";
		$toollist="$txt_category_id|$txt_class_id|$filename|$txtshowname|$timestamp|\n";
		if (isset($filecc)) $newlist.=$filecc;
		writeto("../data/list.php",$newlist); 
		if($hots=='on') {
			if (file_exists("../data/hots.php")) $filehots=readfrom("../data/hots.php");	
			if (isset($filehots)) $hotslist.=$filehots;
			writeto("../data/hots.php",$hotslist); 
		}
		if($usrtool=='on') {
			if (file_exists("../data/usrtool.php")) $filetool=readfrom("../data/usrtool.php");	
			if (isset($filetool)) $toollist.=$filetool;
			writeto("../data/usrtool.php",$toollist); 
		}
		$file_line=array(
			$txt_category_id,
			$txt_class_id,
			$txtshowname,
			$txtfilename,
			$txtshow,
			$txtfilename1,
			$txtshow1,
			$txtfilename2,
			$txtshow2,
			$txtfilename3,
			$txtshow3,
			$fromurl,
			$adddate,
            $size,
			$order,
			$hot,
			$hots,
			$hide,
			$usrtool,
			$runsystem,			
			$txtnote,
			$timestamp,
			$imgurl,
			);
		$line_cc=implode("|",$file_line)."|\n";
        $line_cc="<? exit;?>\n".$line_cc;
		writeto("../data/data/$filename.php",$line_cc);
		
  	print <<<EOT
  	<tr><td bgcolor=#ADADAD colspan=2><font color=#333333>
		<b>欢迎来到管理程式</b>
		</td></tr>
		<tr>
		<td bgcolor=#eeeeee valign=middle colspan=2>
		<center><b>成功</b></center><br><br>&nbsp;&gt;&gt; <a href=$thisprog>返回执行其他动作</a>
		</td></tr></table></body></html>
EOT;
	exit;
}


}else{
print <<<EOT
<tr>
  <td bgcolor=#ADADAD><font color=#ffffff>
<b>欢迎来到 小飞熊下载系统2.4 后台管理系统</b>&nbsp;&nbsp;&nbsp;&nbsp;[您没有登陆，请您点击<a href='login.php'>这里</a>进行登陆！]</td>

EOT;
exit;
}

?>
