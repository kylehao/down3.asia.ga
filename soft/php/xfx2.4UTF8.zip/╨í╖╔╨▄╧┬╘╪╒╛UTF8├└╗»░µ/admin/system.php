<?
session_start();
$thisprog="system.php";
require("global.php");
if ($_SESSION["login_status"]=="yes"){
print "<tr><td bgcolor=#ADADAD colspan=3><font color=#ffffff>
    <b>欢迎来到管理程式 / 设置系统参数</b>
    </td></tr>
";


if (empty($action)) 
{

if (file_exists("../data/config.php"))	
{
$new_info=explode("|",readfrom("../data/config.php"));
}

	print <<<EOT
    <tr><td bgcolor=#ffffff colspan=3>
    <b>设定下载系统必要参数：</b>
    <form action="$thisprog" method=POST>
      
      <div align="left">
        <p>
          <input type=hidden name="action" value="system">
        $tab_top
        <br>
        您的网站名称：
        <input type=text name="site_name1" size=25 value=$new_info[0]>  
        （如：小飞熊工作室）
	    <br>
	    您的网站地址：
	    <input type=text name="site_url1" size=25 value=$new_info[1]>
	    （以"http://"开头，最后不要以"/"收尾） <br>
	    您的电子邮件：
          <input type=text name="email1" size=25 value=$new_info[6]>
<br>（如：lfbear@yeah.net 此邮件地址将用于访客与您联系）<br>
下载系统名称：
<input type=text name="down_name1" size=25 value=$new_info[2]>
          （如：小飞熊工作室的下载中心） <br>
          下载系统网址：
          <input type=text name="down_url1" size=25 value=$new_info[3]>
        （以"http://"开头，最后不要以"/"收尾） </p>
        <p>
          主页公告内容：[不支持html语言，请不要使用"<"或">"，回车用"[br]"表示]
          <textarea name="notice1" cols="70" rows="5">$new_info[4]</textarea>
          <br>
          下载注意事项：[不支持html语言，请不要使用"<"或">",回车用"[br]"表示]
          <textarea name="atten1" cols="70" rows="5">$new_info[5]</textarea>
	      <br>
	      <br>
          <input type=submit value="确认修改">
          $tab_bottom</p>
      </div>
    </form>
	 
   
    </td></tr></td></tr></table></body></html>
EOT;
exit;
}elseif ($action=="system") {
print "<tr><td bgcolor=#ADADAD valign=middle align=center colspan=2><b>修改系统资料</b></td></tr>
	<tr><td bgcolor=ffffff colspan=2>";
	
$site_name=$site_name1;
$site_url=$site_url1;
$down_name=$down_name1;
$down_url=$down_url1;
$notice=str_replace("<","[",$notice1);
$notice=str_replace(">","]",$notice);
$notice=str_replace("[br]","<br>",$notice);
$atten=str_replace("<","[",$atten1);
$atten=str_replace(">","]",$atten);
$atten=str_replace("[br]","<br>",$atten);

$emali=$email1;

$new_info="$site_name|$site_url|$down_name|$down_url|$notice|$atten|$emali";

writeto("../data/config.php",$new_info);
exit;
echo "<br><br>恭喜您，成功的修改了系统资料！<b></b><br><a href=$thisprog>返回执行其他动作</a>";

}
}
elseif ($_SESSION["login_status"]=="ok"){
print <<<EOT
<tr>
  <td bgcolor=#ADADAD><font color=#ffffff>
<b>欢迎来到 小飞熊下载系统2.4 后台管理系统</b>&nbsp;&nbsp;&nbsp;&nbsp;[<font color=red>对不起，只用超级管理员才能管理这部分。</font>]</td>
EOT;
exit;
}
else
{
print <<<EOT
<tr>
  <td bgcolor=#ADADAD><font color=#ffffff>
<b>欢迎来到 小飞熊下载系统2.4 后台管理系统</b>&nbsp;&nbsp;&nbsp;&nbsp;[您没有登陆，请您点击<a href='login.php'>这里</a>进行登陆！]</td>

EOT;
exit;
}
?>



