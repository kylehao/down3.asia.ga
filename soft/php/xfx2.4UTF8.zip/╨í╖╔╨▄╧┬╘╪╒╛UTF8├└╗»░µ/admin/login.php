<?
session_start();
require("global.php");
switch ($action){
case login:
$data=explode("|",readfrom("../data/user/$login_name.php"));
$name=$data[1];
$pass=$data[2];
$level=$data[3];
$psw=md5($_POST["login_pass"]);
if ($_POST["login_name"]==$name && $psw==$pass && $level==1)
{
$_SESSION["login_status"] ="yes";
@header("Location: admin.php");
print <<<EOT
<br><br><br>
<div align="center">等待自动转入……<br><br>
如果浏览器不支持自动转入请点击<a href='admin.php'>这里</a></div>
EOT;
}
elseif ($_POST["login_name"]==$name && $psw==$pass && $level==0)
{
$_SESSION["login_status"] ="ok";
@header("Location: admin.php");
print <<<EOT
<br><br><br>
<div align="center">等待自动转入……<br><br>
如果浏览器不支持自动转入请点击<a href='admin.php'>这里</a></div>
EOT;
}
else
{
print <<<EOT
<tr>
<td bgcolor=#ADADAD><font color=#ffffff>
<b>欢迎来到 小飞熊下载系统2.4 后台管理系统</b>&nbsp;&nbsp;&nbsp;&nbsp;[<font color="red">警告：用户名/错误。</font>重新登陆点击<a href='login.php'>这里</a>。]</td>
</tr>
EOT;
exit;
}
break;
case loginout:
$_SESSION["login_status"] ="";
	print <<<EOT
<tr>
<td bgcolor=#ADADAD><font color=#ffffff>
<b>欢迎来到 小飞熊下载系统2.4 后台管理系统</b>&nbsp;&nbsp;&nbsp;&nbsp;[<font color=red size='2'>系统信息：成功退出！</font>]</td>
</tr>
EOT;
exit;
break;
default:
if ($_SESSION["login_status"]=="yes" || $_SESSION["login_status"]=="ok")
{
	print <<<EOT
<tr>
<td bgcolor=#ADADAD><font color=#ffffff>
<b>欢迎来到 小飞熊下载系统2.4 后台管理系统</b>&nbsp;&nbsp;&nbsp;&nbsp;[您已经登陆成功，请从左边菜单上选择您想要进行的操作！]</td>
</tr>
EOT;
exit;
}
else{
	print <<< eot
<font color="#FFFFFF"><div align="center"><b><br>欢迎来到『小飞熊下载系统2.4』后台管理系统</b></div></font>
<br>
  <form action="login.php?action=login" method="post">
  <table cellpadding=0 cellspacing=0 align=center width='44%' >
    <tr><br>
      <td><table cellpadding=5 cellspacing=1 width='99%' heoght=400>
          <tr bgcolor='#FFFFFF'>
            <td height="20"><div align="left">用户名：</span>
      <input name=login_name type="text" size="25">
            </div></td>
          </tr>
          <tr bgcolor='#FFFFFF'>
            <td height="9"><div align="left">密&nbsp;&nbsp;码：</span>
                <input name=login_pass type="password"  size="25">
            </div></td>
          </tr>
          <tr bgcolor='#FFFFFF'>
            <td height="10">
              <div>
                <div align="left">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" name="Submit" value="登  陆">
&nbsp;&nbsp;&nbsp;&nbsp;
    <input type="reset" name="Submit" value="重  填">
                </div>
              </div></td>
          </tr>
      </table></td>
    </tr>
  </table>
  </form>
  	  
        <blockquote><b>请注意</b><p>在进入管理时，请确定你的浏览器打开了 Cookie 选项。否则您将无法登陆<br><font color=blue>请您在尽快将登陆信息填写并提交，验证码将会在一分钟后失效。<b>如失效请刷新</b></font><br><font color="red">当您想退出管理时请从左侧菜单栏的退出系统处退出</font><p><p>
	<hr><br><br><center>程序制作/版权所有：小飞熊工作室 | Powered By：LFBear Studio [<a href="http://www.lfbear.cn" target="_blank">Url=http://www.lfbear.cn</a>]</center>

    </blockquote>
    </table></body></html>
eot;
}}
?>
