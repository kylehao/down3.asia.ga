<?echo"终止，您进行的操作非法！";exit;?>|admin|e10adc3949ba59abbe56e057f20f883e|1|1118409045|
