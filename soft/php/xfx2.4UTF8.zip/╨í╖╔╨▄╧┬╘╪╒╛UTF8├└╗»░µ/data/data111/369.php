<? exit;?>
2|20|IP查询程序|http://www.geocities.jp/kylehys2007/code/down/ip.zip|本地下载|http://freett.com/upload3/code/down/ip.zip|下载地址二|http://down.atw.hu/soft/code/down/ip.zip|下载地址三|images/nopic.gif|界面预览|无|2005-10-15|MB|免费软件|4||||Win9x/ME/NT/2000/XP||||
15|9|1|9|||1139384746|
