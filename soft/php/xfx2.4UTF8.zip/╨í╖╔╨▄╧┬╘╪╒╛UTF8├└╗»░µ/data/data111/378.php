<? exit;?>
8|8|迅雷50280高速下载软件|http://www.geocities.jp/kylehao2010/soft/Thunder50280.zip|本地下载|http://freett.com/upload9/soft/Thunder50280.zip|下载地址二|http://up.atw.hu/soft/Thunder50280.zip|下载地址三|images/nopic.gif|预览图片|无|2005-10-15|MB|免费软件|4||||Win9x/ME/NT/2000/XP||1129391474||
91|42|1|42|||1139705957|
