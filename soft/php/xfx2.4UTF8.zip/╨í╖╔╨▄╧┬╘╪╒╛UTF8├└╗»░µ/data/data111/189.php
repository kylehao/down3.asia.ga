<? exit;?>
3|17|D-Show-酷银|http://www.geocities.jp/kylehys2009/down/D_Show_cool_aoto.zip|本地下载|http://freett.com/inets/down/D_Show_cool_aoto.zip|下载地址二|http://phpwind.atw.hu/down/D_Show_cool_aoto.zip|下载地址三|images/nopic.gif|预览图片|无|2005-09-17|MB|免费软件|4||||Win9x/ME/NT/2000/XP||1126956277||
3|6|1|6|||1138750262|
