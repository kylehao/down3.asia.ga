<? exit;?>
2|14|中国搜HTML整站|http://www.geocities.jp/kylehys2008/code/down/ChinaSo-HTML.zip|本地下载|http://freett.com/upload3/code/down/ChinaSo-HTML.zip|下载地址二|http://down.atw.hu/soft/code/down/ChinaSo-HTML.zip|下载地址三|images/nopic.gif|预览图片|无|2005-12-06|MB|免费软件|4||||Win9x/ME/NT/2000/XP||1133857330||
117|42|1|42|||1139783852|
