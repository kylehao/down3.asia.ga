<? exit;?>
3|17|桀骜不驯风格|http://www.geocities.jp/kylehys2009/down/jieaobuxun.zip|本地下载|http://freett.com/inets/down/jieaobuxun.zip|下载地址二|http://phpwind.atw.hu/down/jieaobuxun.zip|下载地址三|images/nopic.gif|预览图片|无|2005-09-15|MB|免费软件|4||||Win9x/ME/NT/2000/XP|桀骜不驯风格|1126777030||
2|7|1|7|||1138789074|
