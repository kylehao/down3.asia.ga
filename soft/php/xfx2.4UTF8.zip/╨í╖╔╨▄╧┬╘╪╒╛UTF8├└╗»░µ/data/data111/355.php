<? exit;?>
3|18|遗忘日记风格|http://www.geocities.jp/kylehao2011/down/yiwang_riji.zip|本地下载|http://freett.com/upload4/down/yiwang_riji.zip|下载地址二|http://phpwind.atw.hu/down/phpwind/yiwang_riji.zip|下载地址三|images/nopic.gif|预览图片|无|2005-09-25|MB|免费软件|4||||Win9x/ME/NT/2000/XP||1127673037||
30|21|1|21|||1139492134|
