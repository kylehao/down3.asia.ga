<? exit;?>
2|11|小飞熊下载系统2.4|http://www.geocities.jp/kylehys2007/code/down/soft_2_4.zip|本地下载|http://freett.com/upload9/code/down/soft_2_4.rar|下载地址二|http://down.atw.hu/code/down/soft_2_4.zip|下载地址三|http://cndown.com.ru|界面预览|无|2005-09-12|136KB|免费软件|4|on||on|Win9x/ME/NT/2000/XP|无须数据库支持，速度快，使用简单 |||
75|30|1|30|||1139780273|
