<? exit;?>
3|18|APN_V2.0.0_ACGAME风格|http://www.geocities.jp/kylehao2011/down/APN_V2.0.0_ACGAME.zip|本地下载|http://freett.com/upload4/down/APN_V2.0.0_ACGAME.zip|下载地址二|http://phpwind.atw.hu/down/phpwind/APN_V2.0.0_ACGAME.zip|下载地址三|images/nopic.gif|预览图片|无|2005-09-18|MB|免费软件|4||||Win9x/ME/NT/2000/XP||1127054555||
2|6|1|6|||1139384897|
