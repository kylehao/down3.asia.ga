<? exit;?>
8|8|肉鸡猎手1.0|http://www.geocities.jp/kylehao2010/soft/rouji.zip|本地下载|http://freett.com/upload9/soft/rouji.zip|下载地址二|http://up.atw.hu/soft/rouji.zip|下载地址三|images/nopic.gif|界面预览|无|2005-09-13|269KB|免费软件|4|on||on|Win9x/ME/NT/2000/XP|肉鸡猎手1.0|||
55|23|1|23|||1139582110|
