<? exit;?>
8|16|暗杀西特勒第二版|http://www.geocities.jp/kylehao20011/game/spear.zip|本地下载|http://freett.com/yesite/game/spear.zip|下载地址二|http://kylehao.atw.hu/game/spear.zip|下载地址三|images/nopic.gif|预览图片|无|2005-09-15|659KB|免费软件|4|on||on|Win9x/ME/NT/2000/XP|第一人称的仿CS射击游戏，小巧的程序却能完成这样完美的游戏，让人叹服|1126773948||
61|30|1|30|||1139761521|
