<? exit;?>
2|20|phpMyAdmin|http://www.geocities.jp/kylehys2007/code/down/phpMyAdmin.zip|本地下载|http://freett.com/upload3/code/down/phpMyAdmin.zip|下载地址二|http://down.atw.hu/soft/code/down/phpMyAdmin.zip|下载地址三|images/nopic.gif|预览图片|无|2005-10-15|MB|免费软件|4||||Win9x/ME/NT/2000/XP||1129390164||
27|12|1|12|||1139749143|
