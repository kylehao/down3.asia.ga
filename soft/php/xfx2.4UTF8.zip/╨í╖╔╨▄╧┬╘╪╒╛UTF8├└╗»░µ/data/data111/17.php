<? exit;?>
8|8|强行打开摄像头的软件04.08|http://www.geocities.jp/kylehao2010/soft/shext04.08.zip|本地下载|http://freett.com/upload9/soft/shext04.08.zip|下载地址二|http://up.atw.hu/soft/shext04.08.zip|下载地址三|images/nopic.gif|界面预览|无|2005-09-13|26KB|免费软件|4|on||on|Win9x/ME/NT/2000/XP|强行打开摄像头的软件04.08|||
435|657|3|657|3||1139780231|
3|他妈的，是病毒|
