<? exit;?>
3|17|反恐精英风格|http://www.geocities.jp/kylehys2009/down/cs.zip|本地下载|http://page.freett.com/inets/down/cs.rar|下载地址二|http://phpwind.atw.hu/down/cs.zip|下载地址三|images/nopic.gif|预览图片|无|2005-09-17|MB|免费软件|4||||Win9x/ME/NT/2000/XP||1126957336||
3|7|1|7|||1138117567|
