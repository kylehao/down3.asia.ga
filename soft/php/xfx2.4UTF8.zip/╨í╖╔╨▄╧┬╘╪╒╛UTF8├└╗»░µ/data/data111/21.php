<? exit;?>
8|16|暗杀西特勒第三版|http://www.geocities.jp/kylehao20011/game/bwolf2se.zip|本地下载|http://freett.com/yesite/game/bwolf2se.zip|下载地址二|http://kylehao.atw.hu/game/bwolf2se.zip|下载地址三|images/nopic.gif|预览图片|无|2005-09-15|1.87MB|免费软件|4|on||on|Win9x/ME/NT/2000/XP|第一人称的仿CS射击游戏，小巧的程序却能完成这样完美的游戏，让人叹服|1126774006||
122|66|1|66|||1139783722|
