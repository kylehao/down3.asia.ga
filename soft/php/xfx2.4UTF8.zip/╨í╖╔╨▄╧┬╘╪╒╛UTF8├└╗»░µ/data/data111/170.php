<? exit;?>
3|17|魔兽-女生版|http://www.geocities.jp/kylehys2009/down/muoshou.zip|本地下载|http://freett.com/inets/down/muoshou.zip|下载地址二|http://phpwind.atw.hu/down/muoshou.zip|下载地址三|images/nopic.gif|预览图片|无|2005-09-17|MB|免费软件|4||||Win9x/ME/NT/2000/XP||1126955476||
2|4|1|4|||1139049050|
