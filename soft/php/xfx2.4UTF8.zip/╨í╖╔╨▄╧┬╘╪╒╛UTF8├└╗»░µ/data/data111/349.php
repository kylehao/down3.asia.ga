<? exit;?>
3|18|幸福守望风格|http://www.geocities.jp/kylehao2011/down/xf_shouwang.zip|本地下载|http://freett.com/upload4/down/xf_shouwang.zip|下载地址二|http://phpwind.atw.hu/down/phpwind/xf_shouwang.zip|下载地址三|images/nopic.gif|预览图片|无|2005-09-25|MB|免费软件|4||||Win9x/ME/NT/2000/XP||1127672805||
25|21|1|21|||1139510006|
