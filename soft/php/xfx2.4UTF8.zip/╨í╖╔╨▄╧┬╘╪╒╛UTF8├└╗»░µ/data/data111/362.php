<? exit;?>
3|18|逝去的年代V21情陷上海滩|http://www.geocities.jp/kylehao2011/down/time_go_21.zip|本地下载|http://freett.com/upload4/down/time_go_21.zip|下载地址二|http://phpwind.atw.hu/down/phpwind/time_go_21.zip|下载地址三|images/nopic.gif|界面预览|无|2005-10-10|MB|免费软件|4||||Win9x/ME/NT/2000/XP||||
66|30|1|30|||1139552656|
