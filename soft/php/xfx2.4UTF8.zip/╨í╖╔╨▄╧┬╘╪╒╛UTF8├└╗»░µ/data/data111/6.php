<? exit;?>
8|8|flashftp3.0|http://www.geocities.jp/kylehao2010/soft/flashftp3.zip|本地下载|http://freett.com/upload9/soft/flashftp3.rar|下载地址二|http://up.atw.hu/soft/flashftp3.zip|下载地址三|images/nopic.gif|界面预览|无|2005-09-12|660KB|免费软件|5|on||on|Win9x/ME/NT/2000/XP|<p>FTP下载利器，内附注册码</p>|||
219|149|4|149|||1139783738|
