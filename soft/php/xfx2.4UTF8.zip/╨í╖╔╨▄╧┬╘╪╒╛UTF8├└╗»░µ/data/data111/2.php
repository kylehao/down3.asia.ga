<? exit;?>
8|8|日文语言包|http://www.geocities.jp/kylehao2010/soft/japan.zip|本地下载|http://freett.com/upload9/soft/japan.rar|下载地址二|http://up.atw.hu/soft/japan.zip|下载地址三|images/nopic.gif|界面预览|无|2005-09-12|2.45MB|免费软件|5|on||on|Win9x/ME/NT/2000/XP|日文语言包 |||
31|18|1|18|||1139804775|
