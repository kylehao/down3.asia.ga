<? exit;?>
6|27|新扬州电子相册|http://www.geocities.jp/kylehys2007/code/asp/new-yz_asp.zip|本地下载|http://freett.com/upload3/code/asp/new-yz_asp.zip|下载地址二|http://down.atw.hu/soft/code/asp/new-yz_asp.zip|下载地址三|images/nopic.gif|界面预览|无|2005-09-17|483KB|免费软件|4||||Win9x/ME/NT/2000/XP||||
13|14|1|14|||1139264007|
