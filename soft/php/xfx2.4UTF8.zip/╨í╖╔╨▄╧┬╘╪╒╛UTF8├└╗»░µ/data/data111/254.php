<? exit;?>
6|27|yuseskyphoto_asp相册|http://www.geocities.jp/kylehys2007/code/asp/yuseskyphoto_asp.zip|本地下载|http://freett.com/upload3/code/asp/yuseskyphoto_asp.zip|下载地址二|http://down.atw.hu/soft/code/asp/yuseskyphoto_asp.zip|下载地址三|images/nopic.gif|界面预览|无|2005-09-17|MB|免费软件|4||||Win9x/ME/NT/2000/XP||||
17|17|2|17|||1139380092|
