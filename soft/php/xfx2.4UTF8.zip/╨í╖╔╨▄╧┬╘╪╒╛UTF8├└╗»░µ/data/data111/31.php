<? exit;?>
3|17|D3标准版|http://www.geocities.jp/kylehys2009/down/D3.zip|本地下载|http://freett.com/inets/down/D3.zip|下载地址二|http://phpwind.atw.hu/down/D3.zip|下载地址三|images/nopic.gif|界面预览|无|2005-09-15|MB|免费软件|4|||on|Win9x/ME/NT/2000/XP|D3标准版|||
38|11|1|11|||1139561939|
