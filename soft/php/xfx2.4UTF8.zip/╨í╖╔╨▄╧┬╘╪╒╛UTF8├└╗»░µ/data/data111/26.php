<? exit;?>
8|8|浏览器MyIE34|http://www.geocities.jp/kylehao2010/soft/MyIE34.zip|本地下载|http://freett.com/upload9/soft/MyIE34.zip|下载地址二|http://up.atw.hu/soft/MyIE34.zip|下载地址三|images/nopic.gif|界面预览|无|2005-09-15|420AKB|免费软件|4|on||on|Win9x/ME/NT/2000/XP|浏览器MyIE34|||
97|36|1|36|||1139783693|
