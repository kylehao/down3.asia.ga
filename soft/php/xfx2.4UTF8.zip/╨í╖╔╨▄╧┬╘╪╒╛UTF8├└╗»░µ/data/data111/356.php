<? exit;?>
3|18|音乐风风格|http://www.geocities.jp/kylehao2011/down/music_wind.zip|本地下载|http://freett.com/upload4/down/music_wind.zip|下载地址二|http://phpwind.atw.hu/down/phpwind/music_wind.zip|下载地址三|images/nopic.gif|预览图片|无|2005-09-25|MB|免费软件|4||||Win9x/ME/NT/2000/XP||1127673076||
26|14|1|14|||1139264015|
