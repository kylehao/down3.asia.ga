<? exit;?>
8|8|dnapro玉米查询工具|http://www.geocities.jp/kylehao2010/soft/dnapro4_setup.zip|本地下载|http://freett.com/upload9/soft/dnapro4_setup.zip|下载地址二|http://up.atw.hu/soft/dnapro4_setup.zip|下载地址三|images/nopic.gif|预览图片|无|2005-12-06|MB|免费软件|4||||Win9x/ME/NT/2000/XP||1133849609||
11|10|1|10|||1139264060|
