<? exit;?>
2|20|404错误界面设置程序|http://www.geocities.jp/kylehys2007/code/down/404.zip|本地下载|http://freett.com/upload3/code/down/404.zip|下载地址二|http://down.atw.hu/soft/code/down/404.zip|下载地址三|images/nopic.gif|预览图片|无|2005-10-15|MB|免费软件|4||||Win9x/ME/NT/2000/XP||1129389594||
57|17|3|17|||1139504877|
