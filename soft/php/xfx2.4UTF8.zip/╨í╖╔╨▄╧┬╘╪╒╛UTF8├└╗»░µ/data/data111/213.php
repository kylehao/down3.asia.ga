<? exit;?>
3|17|亲亲家园中秋风格|http://www.geocities.jp/kylehys2009/down/kll_zq.zip|本地下载|http://freett.com/inets/down/kll_zq.rar|下载地址二|http://phpwind.atw.hu/down/kll_zq.zip|下载地址三|images/nopic.gif|预览图片|无|2005-09-17|MB|免费软件|4||||Win9x/ME/NT/2000/XP||1126957112||
2|9|1|9|||1138437665|
