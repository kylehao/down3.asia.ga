<? exit;?>
8|16|暗杀西特勒第一版|http://www.geocities.jp/kylehao20011/game/ansha.zip|本地下载|http://freett.com/yesite/game/ansha.zip|下载地址二|http://kylehao.atw.hu/game/ansha.zip|下载地址三|images/nopic.gif|预览图片|无|2005-09-15|694KB|免费软件|4|on||on|Win9x/ME/NT/2000/XP|暗杀西特勒第一版，第一人称的仿CS射击游戏，小巧的程序却能完成这样完美的游戏，让人叹服|1126773889||
55|20|1|20|||1139519524|
