<? exit;?>
3|18|暗夜星辰风格|http://www.geocities.jp/kylehao2011/down/anyexch.zip|本地下载|http://freett.com/upload4/down/anyexch.zip|下载地址二|http://phpwind.atw.hu/down/phpwind/anyexch.zip|下载地址三|images/nopic.gif|预览图片|无|2005-09-25|MB|免费软件|4||||Win9x/ME/NT/2000/XP||1127666316||
2|3|1|3|||1139733921|
