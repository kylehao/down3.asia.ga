<? exit;?>
3|17|童话设计之游戏篇|http://www.geocities.jp/kylehys2009/down/game_aoto.zip|本地下载|http://freett.com/inets/down/game_aoto.zip|下载地址二|http://phpwind.atw.hu/down/game_aoto.zip|下载地址三|images/nopic.gif|预览图片|无|2005-09-15|MB|免费软件|4||||Win9x/ME/NT/2000/XP|童话设计之游戏篇|1126777435||
2|3|1|3|||1139121548|
