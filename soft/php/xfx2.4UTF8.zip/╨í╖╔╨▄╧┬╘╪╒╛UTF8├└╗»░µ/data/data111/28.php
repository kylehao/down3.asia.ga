<? exit;?>
8|8|QQ自动申请器|http://www.geocities.jp/kylehao2010/soft/qq2.zip|本地下载|http://freett.com/upload9/soft/qq2.zip|下载地址二|http://up.atw.hu/soft/qq2.zip|下载地址三|images/nopic.gif|预览图片|无|2005-09-15|523KB|免费软件|4|on||on|Win9x/ME/NT/2000/XP|QQ自动申请器，可以批量申请免费QQ|1126775411||
193|120|2|120|||1139783679|
