<? exit;?>
3|17|True改进版|http://www.geocities.jp/kylehys2009/down/true.zip|本地下载|http://freett.com/inets/down/true.zip|下载地址二|http://phpwind.atw.hu/down/true.zip|下载地址三|images/nopic.gif|预览图片|无|2005-09-15|MB|免费软件|4||||Win9x/ME/NT/2000/XP|True改进版|1126777151||
2|4|1|4|||1139422749|
