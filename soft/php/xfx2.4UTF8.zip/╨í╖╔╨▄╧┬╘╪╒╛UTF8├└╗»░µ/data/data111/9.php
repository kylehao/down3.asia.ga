<? exit;?>
8|8|photoshop7.0简体中文版|http://upload.sitesled.com/soft/photoshop7.rar|本地下载|ftp://1028537041:520yoyo@ftp.52boa.com/软件/photoshop7.rar|下载地址二|ftp://finets:kyle1982@769.cc/软件/photoshop7.exe|下载地址三|images/nopic.gif|界面预览|无|2005-09-13|21MB|免费软件|5|on||on|Win9x/ME/NT/2000/XP|<span class="tpc_title"><font size="2">压缩密码: </font><a href="http://www.photoshopit.com/" target="_blank"><font size="2">www.photoshopit.com</font></a>&nbsp;&nbsp; photoshop7.0简体中文精简版,适用于网吧用户</span> |||
61|20|1|20|||1139784683|
