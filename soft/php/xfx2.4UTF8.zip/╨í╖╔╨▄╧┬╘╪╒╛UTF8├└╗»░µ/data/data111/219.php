<? exit;?>
3|17|銀白簡單风格|http://www.geocities.jp/kylehys2009/down/yinbai.zip|本地下载|http://freett.com/inets/down/yinbai.rar|下载地址二|http://phpwind.atw.hu/down/yinbai.zip|下载地址三|images/nopic.gif|预览图片|无|2005-09-17|MB|免费软件|4||||Win9x/ME/NT/2000/XP||1126957306||
2|3|1|3|||1138521143|
