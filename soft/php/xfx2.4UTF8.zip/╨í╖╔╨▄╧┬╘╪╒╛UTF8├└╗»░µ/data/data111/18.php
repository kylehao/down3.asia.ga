<? exit;?>
2|12|批量查询域名程序PHP版|http://www.geocities.jp/kylehys2007/code/down/whois.zip|本地下载|http://freett.com/upload3/code/down/whois.zip|下载地址二|http://down.atw.hu/soft/code/down/whois.zip|下载地址三|images/nopic.gif|界面预览|无|2005-09-15|110KB|免费软件|5|on||on|Win9x/ME/NT/2000/XP|批量查询域名程序PHP版|||
66|32|2|32|||1139681889|
