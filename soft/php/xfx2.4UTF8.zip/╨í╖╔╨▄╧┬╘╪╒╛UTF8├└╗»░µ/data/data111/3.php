<? exit;?>
8|8|俄文语言包|http://www.geocities.jp/kylehao2010/soft/russia.zip|本地下载|http://freett.com/upload9/soft/russia.rar|下载地址二|http://up.atw.hu/soft/russia.zip|下载地址三|images/nopic.gif|界面预览|网络|2005-09-12|1.3MB|免费软件|5|on||on|Win9x/ME/NT/2000/XP|俄文语言包 |||
42|25|2|25|||1139598548|
