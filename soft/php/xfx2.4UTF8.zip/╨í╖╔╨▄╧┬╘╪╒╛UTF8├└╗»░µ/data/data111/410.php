<? exit;?>
2|20|yoyo域名查询系统|http://www.geocities.jp/kylehys2007/code/down/yoyonetworkcenter.zip|本地下载|http://freett.com/upload3/code/down/yoyonetworkcenter.zip|下载地址二|http://down.atw.hu/soft/code/down/yoyonetworkcenter.zip|下载地址三|images/nopic.gif|预览图片|无|2005-12-06|MB|免费软件|4||||Win9x/ME/NT/2000/XP||1133854872||
50|23|1|23|||1139810155|
