<? exit;?>
8|8|韩文显示/输入程序|http://www.geocities.jp/kylehao2010/soft/komondo.zip|本地下载|http://freett.com/upload9/soft/komondo.zip|下载地址二|http://up.atw.hu/soft/komondo.zip|下载地址三|images/nopic.gif|预览图片|无|2005-09-15|1.96MB|免费软件|5|on||on|Win9x/ME/NT/2000/XP|韩文显示/输入程序,使你的浏览器支持韩文|1126775140||
115|38|1|38|||1139783698|
