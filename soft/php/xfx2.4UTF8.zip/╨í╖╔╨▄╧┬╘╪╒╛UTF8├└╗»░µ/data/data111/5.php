<? exit;?>
8|8|信用卡号码生成器|http://www.geocities.jp/kylehao2010/soft/xinyk.zip|本地下载|http://freett.com/upload9/soft/xinyk.zip|下载地址二|http://up.atw.hu/soft/xinyk.zip|下载地址三|images/nopic.gif|界面预览|无|2005-09-12|0.3MB|免费软件|4|on||on|Win9x/ME/NT/2000/XP|信用卡号码生成器|||
48|26|1|26|||1139784317|
