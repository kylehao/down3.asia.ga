<? exit;?>
8|8|移动联通可互发的免费短信软件|http://www.geocities.jp/kylehao2010/soft/yl-short.zip|本地下载|http://freett.com/upload9/soft/yl-short.zip|下载地址二|http://up.atw.hu/soft/yl-short.zip|下载地址三|images/nopic.gif|界面预览|无|2005-09-13|0.2MB|免费软件|4|on||on|Win9x/ME/NT/2000/XP|移动联通可互发的免费短信软件|||
53|22|1|22|||1139701537|
