<? exit;?>
8|8|批量米查询工具|http://www.geocities.jp/kylehao2010/soft/mi.zip|本地下载|http://freett.com/upload9/soft/mi.zip|下载地址二|http://up.atw.hu/soft/mi.zip|下载地址三|images/nopic.gif|预览图片|无|2005-12-06|MB|免费软件|4||||Win9x/ME/NT/2000/XP||1133849688||
124|57|2|57|||1139783749|
