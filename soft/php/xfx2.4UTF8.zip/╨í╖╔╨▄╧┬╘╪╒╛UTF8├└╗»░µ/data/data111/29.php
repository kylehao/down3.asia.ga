<? exit;?>
8|8|方便更换代理服务器的浏览器|http://www.geocities.jp/kylehao2010/soft/proxy-llq.zip|本地下载|http://freett.com/upload9/soft/proxy-llq.zip|下载地址二|http://up.atw.hu/soft/proxy-llq.zip|下载地址三|images/nopic.gif|预览图片|无|2005-09-15|1.2MB|免费软件|4|on||on|Win9x/ME/NT/2000/XP|方便更换代理服务器，可以添加代理列表，自动搜索最快的代理|1126775521||
111|33|1|33|||1139783675|
