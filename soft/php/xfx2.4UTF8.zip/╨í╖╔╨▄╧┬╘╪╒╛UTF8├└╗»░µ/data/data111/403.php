<? exit;?>
2|21|168相册系统 v3.0 Beta|http://www.geocities.jp/kylehys2007/code/down/168photo-v3.0Beta.zip|本地下载|http://freett.com/upload3/code/down/168photo-v3.0Beta.zip|下载地址二|http://down.atw.hu/soft/code/down/168photo-v3.0Beta.zip|下载地址三|images/nopic.gif|预览图片|无|2005-12-06|MB|免费软件|4||||Win9x/ME/NT/2000/XP||1133854150||
7|7|1|7|||1139598522|
