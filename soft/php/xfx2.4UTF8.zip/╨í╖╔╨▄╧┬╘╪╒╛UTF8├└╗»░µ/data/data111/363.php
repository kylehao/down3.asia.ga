<? exit;?>
2|20|探针包|http://www.geocities.jp/kylehys2007/code/down/tz.php|本地下载|http://freett.com/upload3/code/down/tz.php|下载地址二|http://down.atw.hu/soft/code/down/tz.php|下载地址三|images/nopic.gif|预览图片|无|2005-10-15|MB|免费软件|4||||Win9x/ME/NT/2000/XP||1129387986||
25|24|1|24|||1139786749|
