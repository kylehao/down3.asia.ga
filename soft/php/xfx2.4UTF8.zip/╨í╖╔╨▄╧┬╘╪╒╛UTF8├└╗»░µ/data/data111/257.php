<? exit;?>
3|18|APN_V1.0.1_海的遐想|http://www.geocities.jp/kylehao2011/down/APN_V1.0.1_sea_xiax.zip|本地下载|http://freett.com/upload4/down/APN_V1.0.1_sea_xiax.zip|下载地址二|http://phpwind.atw.hu/down/phpwind/APN_V1.0.1_sea_xiax.zip|下载地址三|images/nopic.gif|预览图片|无|2005-09-18|MB|免费软件|4||||Win9x/ME/NT/2000/XP||1127054385||
2|5|1|5|||1139349505|
