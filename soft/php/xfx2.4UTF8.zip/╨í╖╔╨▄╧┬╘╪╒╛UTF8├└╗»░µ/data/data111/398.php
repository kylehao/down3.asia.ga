<? exit;?>
2|20|cybersyndrome.net匿名代理小偷|http://www.geocities.jp/kylehys2007/code/down/cybersyndrome.net.zip|本地下载|http://freett.com/upload3/code/down/cybersyndrome.net.zip|下载地址二|http://down.atw.hu/soft/code/down/cybersyndrome.net.zip|下载地址三|images/nopic.gif|预览图片|无|2005-12-06|MB|免费软件|4||||Win9x/ME/NT/2000/XP||1133852915||
12|5|1|5|||1139796227|
