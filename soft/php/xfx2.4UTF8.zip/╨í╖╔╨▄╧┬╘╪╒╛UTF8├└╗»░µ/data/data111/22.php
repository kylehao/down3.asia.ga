<? exit;?>
8|8|微软Java虚拟机|http://www.geocities.jp/kylehao20011/soft/Java.zip|本地下载|http://52down.sitesled.com/soft/Java.zip|下载地址二|http://kylehao.atw.hu/soft/Java.zip|下载地址三|images/nopic.gif|预览图片|无|2005-09-15|4.93MB|免费软件|4|on||on|Win9x/ME/NT/2000/XP|微软Java虚拟机|1126774505||
127|41|1|41|||1139783718|
