﻿<?php 
//我的第二个PHP学习实例
//yd631_php_user
//D.JOY www.yd631.com 
//实例只展示功能，供学习用，美工就差了点，不好意思
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>yd631_php_user会员管理实例</title>
<noscript></head></noscript>

<body><center>
  <table width="51%" height="186"  border="0" cellpadding="0" cellspacing="1">
    <tr>
      <td align="center" >您的邮箱已经申请成功，请等候管理员审核，谢谢！</td>
    </tr>

  </table>
</center>

</body>
</html>
