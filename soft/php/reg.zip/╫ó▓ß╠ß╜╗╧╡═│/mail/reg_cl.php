﻿<?php 
//注册处理页面
//www.yd631.com
//技术D.JOY
function checkmail($nmail){   /// 验证电子邮件地址
	if(ereg("^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+",$nmail))
		return true;
	else
		return false;
}

include("config.php"); //参数页面提取过来

if(empty($_POST["yd631_name"])){
echo ("<script type='text/javascript'> alert('用户名不能是空的');history.go(-1);</script>");
exit;
}
//if(empty($_POST["yd631_pws"])){
//echo ("<script type='text/javascript'> alert('密码为空了吧');history.go(-1);</script>");
//exit;
//}
//if(empty($_POST["yd631_sex"])){
//echo ("<script type='text/javascript'> alert('性别呢');history.go(-1);</script>");
//exit;
//}
//if(empty($_POST["yd631_age"])){
//echo ("<script type='text/javascript'> alert('年龄不能为空');history.go(-1);</script>");
//exit;
//}
//if(!is_numeric($_POST["yd631_age"])){
//echo ("<script type='text/javascript'> alert('年龄要是数字的');history.go(-1);</script>");
//exit;
//}
//if(empty($_POST["yd631_call"])){
//echo ("<script type='text/javascript'> alert('电话不能为空');history.go(-1);</script>");
//exit;
//}
//if(!is_numeric($_POST["yd631_call"])){
//echo ("<script type='text/javascript'> alert('电话要是数字的');history.go(-1);</script>");
//exit;
//}
if(empty($_POST["yd631_email"])){
echo ("<script type='text/javascript'> alert('邮箱不能为空');history.go(-1);</script>");
exit;
}
if($_POST["yd631_email"]!=""){

		if(!checkmail($_POST["yd631_email"])) {
	echo ("<script type='text/javascript'> alert('不对了，邮箱格式');history.go(-1);</script>");
	exit;
		}
}

//if(empty($_POST["yd631_address"])){
//echo ("<script type='text/javascript'> alert('地址不能为空');history.go(-1);</script>");
//exit;
//}

$yd631_name=$_POST["yd631_name"];
$yd631_pws=$_POST["yd631_pws"];
$yd631_sex=$_POST["yd631_sex"];
$yd631_age=$_POST["yd631_age"];
$yd631_call=$_POST["yd631_call"];
$yd631_email=$_POST["yd631_email"];
$yd631_address=$_POST["yd631_address"];
$yd631_time=date("Y-m-d");
$yd631_pass="no";

$db=mysql_connect($servername,$sqlservername,$sqlserverpws);
mysql_select_db($sqlname,$db) ;
$sql="select * from $sqltable where yd631_name='$yd631_name'";
$result=mysql_fetch_row(mysql_query($sql));

if($result){
echo ("<script type='text/javascript'> alert('用户名在，你就不能注册这个名字');history.go(-1);</script>");

}
else{
$sql="insert into $sqltable(yd631_name,yd631_pws,yd631_sex,yd631_age,yd631_call,yd631_email,yd631_address,yd631_time,yd631_pass) values('$yd631_name','$yd631_pws','$yd631_sex','$yd631_age','$yd631_call','$yd631_email','$yd631_address','$yd631_time','$yd631_pass') ";
mysql_query($sql);

echo ("<script type='text/javascript'> alert('添加成功');location.href='success.php';</script>");
}
?>