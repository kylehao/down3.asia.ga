﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?
include('geturl.php');    
?>
<head>
<title>听松阁免费PHP空间 - Power By Free163.Com</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="免费PHP空间|听松阁">
<meta name="keywords" content="10G免费PHP空间，100G月流量|听松阁">
<meta name="author" content="free163.com">
<link rel="stylesheet" href="images/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="images/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="images/style.css" type="text/css" media="all">
<!--[if lt IE 7]>
<script type="text/javascript" src="images/ie6_script_other.js"></script>
<![endif]-->
<!--[if lt IE 9]>
<script type="text/javascript" src="images/html5.js"></script>
<![endif]-->
<noscript></head>
</noscript><body id="page1" onLoad="new ElementMaxHeight();">


<div class="tail-top">
<!-- header -->
	<header>
		<div class="container">
		
<!-- 	
					<div>
						<span class="top-info">

    <div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare">
        <a class="bds_qzone"></a>
        <a class="bds_tsina"></a>
        <a class="bds_tqq"></a>
        <a class="bds_renren"></a>
        <span class="bds_more">更多</span>
		<a class="shareCount"></a>
    </div>

</span>

		</div>	
		-->

		



					
		
		
			<div class="header-box">
				<div class="left">
					<div class="right">
						<nav>
							<ul>
								<li class="current"><a href="../index.htm">主页</a></li>

										<li><a href="../mail/login.htm">邮箱管理</a></li>
								<li><a href="../mail/admin.htm">邮箱后台</a></li>								<li><a href="http://cpanel.idc.free163.com" target="_blank">控制面板</a></li>
							</ul>
						</nav>
						<h1><a href="../index.htm"><span><font color="#F8B81D">听松阁</font></span></a></h1>
					</div>
				</div>
			</div>

		</div>
	</header>
	<!-- content -->


						<section id="content"><div class="ic">听松阁</div>
		<div class="container">
			<div class="inside">
				<div class="wrapper row-1">
					<div class="box col-6 maxheight">
						<div class="border-right maxheight">
							<div class="border-bot maxheight">
								<div class="border-left maxheight">
									<div class="left-top-corner maxheight">
										<div class="right-top-corner maxheight">
											<div class="right-bot-corner maxheight">
												<div class="left-bot-corner maxheight">
													<div class="inner">
														<h3>后台管理</h3>
<iframe  src="yd631.php" frameborder="0" scrolling="auto" width="900" height="325" marginwidth="0" marginheight="0" ></iframe>

											</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>									
				</div>	
			</div>									
	  </div>													
	</section>

	

<!-- aside -->
<aside>
	<div class="container">
		<div class="inside">
			<div class="line-ver1">
				<div class="line-ver2">
					<div class="line-ver3">
						<div class="wrapper line-ver4">
							<ul class="list col-1">
								<li>账户管理</li>
								<li><a href="http://cpanel.free163.com" 

target="_blank">免费空间控制面板</a></li>
								<li><a 

href="http://bbs.free163.com/home.php" target="_blank">会员中心</a></li>
								<li><a 

href="http://bbs.free163.com/group.php" target="_blank">用户贴吧</a></li>
								<li><a href="http://idc.free163.com/domain-

registration/index.php" target="_blank">域名注册</a></li>
								<li><a 

href="http://www.free163.com/ShiPinJiaoCheng/" target="_blank">视频教程</a></li>
								<li><a 

href="http://www.free163.com/XiaZaiZhongXin" target="_blank">下载中心</a></li>
							</ul>
							<ul class="list col-2">
								<li>新闻中心</li>
								<li><a 

href="http://www.free163.com/XinWenZhongXin/ZhanZhangXinWenl" target="_blank">站长新闻</a></li>
								<li><a 

href="http://www.free163.com/XinWenZhongXin/DianZiShangWu/" target="_blank">电子商务</a></li>
								<li><a 

href="http://www.free163.com/XinWenZhongXin/YeJieDongTai/" target="_blank">业界动态</a></li>
								<li><a 

href="http://www.free163.com/XinWenZhongXin/MenHuDongTai" target="_blank">门户动态</a></li>
								<li><a 

href="http://www.free163.com/XinWenZhongXin/SouSuoYinQing" target="_blank">搜索引擎</a></li>
								<li><a href="http://wap.free163.com" 

target="_blank">手机客户端</a></li>
							</ul>
							<ul class="list col-3">
								<li>建站资源</li>
								<li><a 

href="http://www.free163.com/WangZhanYunYing/CeHuaYingLi/" target="_blank">网站运营</a></li>
								<li><a 

href="http://www.free163.com/WangZhanYunYing/TuiGuangCeHua/" target="_blank">网站推广</a></li>
								<li><a href="http://bbs.free163.com/forum-7

-1.html" target="_blank">网站交易</a></li>
								<li><a href="http://bbs.free163.com/forum-6

-1.html" target="_blank">域名交易</a></li>
								<li><a 

href="http://www.free163.com/WangZhanYunYing/SouSuo&SEO/" target="_blank">SEO交流</a></li>
								<li><a href="http://tool.free163.com" 

target="_blank">站长工具</a></li>
							</ul>
							<ul class="list col-4">
								<li>帮助和支持</li>
								<li><a href="http://bbs.free163.com/forum-

28-1.html" target="_blank">客户支持</a></li>
								<li><a href="solutions.html" 

target="_blank">建站方案</a></li>
								<li><a 

href="http://bbs.free163.com/forum.php?gid=16" target="_blank">广告联盟</a></li>
								<li><a href="http://bbs.free163.com/forum-

11-1.html" target="_blank">程序与代码</a></li>
								<li><a href="http://bbs.free163.com/forum-

12-1.html" target="_blank">建站技术交流</a></li>
								<li><a href="http://bbs.free163.com/forum-

21-1.html" target="_blank">友情链接交换</a></li>
							</ul>
							<ul class="list col-5">
								<li>关于我们</li>
								<li><a>工作机会</a></li>
								<li><a 

href="http://www.free163.com/about.htm" target="_blank" rel="nofollow">关于听松阁</a></li>
								<li><a  href="contacts.html">联系方式

</a></li>
								<li><a href="terms.html">服务条款</a></li>
								<li><a href="services.html">服务内容

</a></li>
								<li><a href="http://t.free163.com" 

target="_blank">站长微博</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</aside>
<!-- footer -->
<footer>
	<div class="container">
		<div class="inside">
			Powered By <a href="http://www.free163.com" target="_blank" >听松阁</a> & <a 

href="http://www.byethost.com" target="_blank" rel="nofollow">Byet Host</a> & <a href="http://boyhost.cn" 

target="_blank">免费资源网</a><br>


		</div>
	</div>
</footer>

</body>
</html>
