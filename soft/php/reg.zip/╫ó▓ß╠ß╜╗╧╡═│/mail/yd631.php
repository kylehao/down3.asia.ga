﻿<?php 
//我的第二个PHP学习实例
//yd631_php_user
//D.JOY www.yd631.com 
//实例只展示功能，供学习用，美工就差了点，不好意思
session_start(); //一定要的
if($_SESSION["name"]==""){
echo "<script>location.href='index.php';</script>";
exit;
}
//上面的要验证过滤的
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>yd631_php_user会员管理实例</title>
<style type="text/css">
<!--
.style1 {color: #009900}
-->
</style>
<noscript></head></noscript>

<body><center>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>

  <table width="58%" height="186"  border="0" cellpadding="0" cellspacing="2">
    <tr>
      <td align="center" ><strong>会员管理中心</strong> | <a href="login_out.php">退出</a> </td>
    </tr>
    <tr>
      <td align="center" ><?php echo $_SESSION["name"]?><span class="style1">欢迎您的到来</span>！</td>
    </tr>
    <tr>
      <td align="center" ><a href="user_edi.php?name=<?php echo $_SESSION["name"]?>">编辑个人资料</a></td>
    </tr>
  </table>
</center>

</body>
</html>
