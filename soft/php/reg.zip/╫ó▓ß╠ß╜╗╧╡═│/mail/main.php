﻿<?php 
//我的第二个PHP学习实例
//yd631_php_user
//D.JOY www.yd631.com 
//实例只展示功能，供学习用，美工就差了点，不好意思
session_start(); //要验证SESSION，看是不是管理员
if($_SESSION["admin"]!="kylehao"){
	echo "<script>location.href='index.php';</script>";
    exit;
}
include("config.php"); //包含文件
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>yd631_php_user会员管理实例</title>
<noscript></head></noscript>

<body><center>
 
  <table width="100%"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="39" align="center" bgcolor="#FFFFFF">后台管理| <a href="login_out.php">退出</a></td>
    </tr>
  </table>
  <?php 
 $db=mysql_connect($servername,$sqlservername,$sqlserverpws);
 mysql_select_db($sqlname,$db);
 $sql="select * from $sqltable order by yd631_id desc";
 $conn=mysql_query($sql);
 
 ?>
  <table width="100%" height="51"  border="0" cellpadding="0" cellspacing="1" bgcolor="#000000">
    <tr align="center" bgcolor="#FFFFFF">
      <td width="4%">ID</td>
      <td width="9%">名字</td>
      <td width="11%">密码</td>
      <td width="6%">性别</td>
<!--      <td width="4%">年龄</td> 
      <td width="11%">电话</td> -->
      <td width="12%">邮件</td>
      <td width="10%">时间</td>
<!--      <td width="24%">地址</td> -->
      <td width="4%">审核</td>
      <td width="5%">管理</td>
    </tr>
	<?php
	while($rs=mysql_fetch_array($conn)){	
	
	?>
    <tr bgcolor="#FFFFFF">
      <td><?=$rs["yd631_id"]?></td>
      <td><?=$rs["yd631_name"]?></td>
      <td><?=$rs["yd631_pws"]?></td>
      <td><?=$rs["yd631_sex"]?></td>
 <!--     <td><?=$rs["yd631_age"]?></td>
      <td><?=$rs["yd631_call"]?></td> -->
      <td><?=$rs["yd631_email"]?></td>
      <td><?=$rs["yd631_time"]?></td>
<!--       <td><?=$rs["yd631_address"]?></td> -->
      <td><a href="admin_pass.php?id=<?=$rs["yd631_id"]?>&pass=<?=$rs["yd631_pass"]?>"><?=$rs["yd631_pass"]?></a></td>
      <td><a href="admin_del.php?id=<?=$rs["yd631_id"]?>">删除</a></td>
    </tr>
	<?php 
		}
    mysql_close();
	exit;
 ?>
  </table>

  </center>

</body>
</html>
