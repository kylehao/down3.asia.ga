﻿<?php 
//我的第二个PHP学习实例
//yd631_php_user
//D.JOY www.yd631.com 
//实例只展示功能，供学习用，美工就差了点，不好意思
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>yd631_php_user会员管理实例</title>
<noscript></head></noscript>

<body><center>
  <p>&nbsp;</p>
  [yd631_php_user会员程序]
此程序供PHP初学者学习使用  
  <p>&nbsp;</p>
  <table width="51%" height="186"  border="0" cellpadding="0" cellspacing="1" bgcolor="#FFFFFF">
    <tr>
      <td align="center" bgcolor="#CCCCCC"><strong>会员中心</strong>(index.php)</td>
    </tr>
    <tr>
      <td align="center" bgcolor="#CCCCCC"><a href="login.php">登陆请进</a>(login.php)</td>
    </tr>
    <tr>
      <td align="center" bgcolor="#CCCCCC"><a href="reg.php">我要注册</a> (reg.php)</td>
    </tr>
    <tr>
      <td align="center" bgcolor="#CCCCCC"><a href="admin.php">管理员</a>(admin.php)</td>
    </tr>
  </table>
  <table width="100%" height="29"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td align="center">www.yd631.com 技术：<a href="http://www.yd631.com/blog" target="_blank">D.JOY</a></td>
    </tr>
  </table>
</center>

</body>
</html>
