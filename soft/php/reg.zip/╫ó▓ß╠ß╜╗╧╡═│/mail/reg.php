﻿<?php 
//我的第二个PHP学习实例
//yd631_php_user
//D.JOY www.yd631.com 
//实例只展示功能，供学习用，美工就差了点，不好意思
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>yd631_php_user会员管理实例</title>
<noscript></head></noscript>

<body><center>
  <form name="form1" method="post" action="reg_cl.php"><table width="68%" height="304"  border="0" cellpadding="0" cellspacing="1">
<!--    <tr align="center" >
      <td colspan="2">注册(reg.php)||<a href="index.php">返回</a></td>
    </tr>
-->
    <tr >
      <td align="right">用户名：</td>
      <td align="left"><input name="yd631_name" type="text" id="yd631_name">@FreeMail.Ltd</td>
    </tr>
<!-- 
    <tr >
      <td align="right">密码：</td>
      <td align="left"><input name="yd631_pws" type="password" id="yd631_pws"></td>
    </tr>
    <tr >
      <td align="right">性别：</td>
      <td align="left"><input name="yd631_sex" type="radio" value="男" checked>男
          <input type="radio" name="yd631_sex" value="女">女</td>
    </tr>
    <tr >
      <td align="right">年龄：</td>
      <td align="left"><input name="yd631_age" type="text" id="yd631_age" size="10" maxlength="4"></td>
    </tr>
    <tr >
      <td align="right">电话：</td>
      <td align="left"><input name="yd631_call" type="text" id="yd631_call"></td>
    </tr>
-->
    <tr >
      <td align="right">目标邮件：</td>
      <td align="left"><input name="yd631_email" type="text" id="yd631_email"></td>
    </tr>
<!-- 
    <tr >
      <td align="right">地址：</td>
      <td align="left"><input name="yd631_address" type="text" id="yd631_address" size="４０"></td>
    </tr>
-->
    <tr align="center" >
      <td colspan="2"><input type="submit" name="Submit" value="提交">　　
        <input type="reset" name="Submit" value="重置"></td>
    </tr>
  </table>
  </form>
</center>

</body>
</html>
