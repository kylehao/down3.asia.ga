<?
require("fun.php");

if (file_exists("data/config.php"))	
{
$sys_info=explode("|",readfrom("data/config.php"));
static $notice;
$notice=$sys_info[4];
}

$softgs=@file("data/list.php");
$numober=count($softgs);

$listv=@file("data/nclass.php");	

$c=min(count($softgs),20); 
$softgss='';
 for ($i=0; $i<$c; $i++){

 $detail=explode("|",$softgs[$i]);      

 $file_name=chop($detail[2]);
 $countv=count($listv);
	for ($ii=0; $ii<$countv; $ii++) {
		$detailv=explode("|", trim($listv[$ii]));
		if ($detailv[1]==$detail[1] && $detailv[0]==$detail[0]){$nclass_name=$detailv[2];break;}
		
	}


// if (strlen($detail[3])>=29) $detail[3]=substr($detail[3],0,27)."...";
 $softgss.="[<a href=list.php?classid=$detail[0]&nclassid=$detail[1]>".$nclass_name."</a>]&nbsp;<a href=\"show.php?id=$detail[2]\">$detail[3]</a><br>";			
       

   }
require "header.php";
?>
<body bgcolor="#FFFFFF">
<table width="680" height="70" align="center" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF">
  <tr> 
    <td width="160" bgcolor="#FFFFFF" valign="top"> 
      <table width="100%" border="0" cellpadding="2" cellspacing="0" bordercolor="#FFFFFF">
        <tr> 
          <td height="20" align="center" bgcolor="#E4E4E4"><div align="left"><b><font color="#000000"> �Ƽ�����</font></b></div></td>
        </tr>
        <tr> 
          <td height="5" bgcolor="#FFFFFF"></td>
        </tr>
        <tr> 
          <td height="20" bgcolor="#FFFFFF"> 
            <?
$top10=@file("data/hots.php");

$c=min(count($top10),10); 
 for ($i=0; $i<$c; $i++){

 $detail=explode("|",$top10[$i]);      

 $file_name=chop($detail[2]);     

////if (strlen($detail[3])>=25) $detail[3]=substr($detail[3],0,22)."...";
 echo "<LI><a href=\"show.php?id=$detail[2]\">$detail[3]</a>";			
         

   }
 ?></LI>
          </td>
        </tr>
      </table>


      <table width="100%" border="0" cellspacing="0" cellpadding="2">
        <tr> 
          <td height="20" align="center" bgcolor="#E4E4E4"><div align="left"><b><font color="#000000"> ��������TOP10</font></b></div></td>
        </tr>
        <tr> 
          <td height="20" bgcolor="#FFFFFF"> 
            <?
$top10=@file("data/downhot.php");

$c=min(count($top10),10); 
 for ($i=0; $i<$c; $i++){

 $detail=explode("|",$top10[$i]);      

 $file_name=chop($detail[2]);     

 //if (strlen($detail[3])>=25) $detail[3]=substr($detail[3],0,22)."...";
 echo "<LI><a href=\"show.php?id=$detail[2]\">$detail[3]</a>";			
         

   }
 ?></LI>
          </td>
        </tr>
      </table>
    </td>
    <td width="400" valign="top" align="center"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td height="20" align="center" bgcolor="#E4E4E4">&nbsp;&nbsp; <font color="#000000">���ڸ���</font></td>
        </tr>
        <tr> 
          <td height="70" bordercolor="#5FB0D8" bgcolor="#FFFFFF"><? echo $softgss; ?><br><br><br><br><br><br>
          </td>
        </tr>
      </table>
    </td>
    <td valign="top" bgcolor="#FFFFFF"> 
      <table height=20 cellspacing=0 cellpadding=0 width=100% border=0>
        <tbody> 
        <tr align=middle> 
          <td height=20 align=center valign=top bgcolor="#E4E4E4" class=bt><b><font color="#370000"><b><font color="#370000"><font color="#000000">&#29305;&#21035;&#20844;&#21578;</font></font></b> </font></b></td>
          </tr>
        </tbody> 
      </table>
      <div align="center"><marquee onMouseOver=this.stop() onMouseOut=this.start() scrollamount=2 direction=up border="0"> <div align="center"><? echo $notice;?>
        </marquee> 
    </div></td>
  </tr>
</table>
<div align="center">
  <?
require "footer.php";
?>
</div>
