<?

require("fun.php");
get_classid();

$class_name="��������";
if (empty($page)) $page=1;
if ($page <1)  $page=1;
settype($page, integer);
$perpage=20;
$softg_list=@file("data/list.php");
$numober=count($softg_list);

require "header.php";
?>
<link href="images/css.css" rel=stylesheet>
<table width="680" border="0" cellspacing="4" cellpadding="0" align="center" height="20">
  <tr> 
    <td bgcolor="#E4E4E4"><font color="#000000">����λ�ã�<a href=index.php><font color="#000000">��ҳ</a></font> <font color="#000000">-> </font><a href="sort.php"><font color="#000000">��������</a><font color="#000000"> -></font>      <?=$class_name?></td>
  </tr>
</table>
<table width="680" border="0" cellspacing="0" cellpadding="0" align="center" height="60">
  <tr> 
    <td width="200" bgcolor="#FFFFFF" valign="top">
	  <table width="190" border="0" cellspacing="0" cellpadding="2">
        <tr> 
          <td height="20" align="center" bgcolor="#E4E4E4"><div align="left"><font color="#FFFFFF"><b><font color="#370000"> </font><font color="#000000"><b>ȫ��</b>����TOP10</font></b></font></div></td>
        </tr>
        <tr>
          <td height="20" bgcolor="#FFFFFF">
		  <table width=98% border="0" cellspacing="0" cellpadding="1">
		  <tr><td bgcolor="#FFFFFF">
<?
$top10=@file("data/downhot.php");

$c=min(count($top10),10); 
 for ($i=0; $i<$c; $i++){

 $detail=explode("|",$top10[$i]);      

 $file_name=chop($detail[2]);     

//if (strlen($detail[3])>=25) $detail[3]=substr($detail[3],0,22)."...";
 echo "<LI><a href=\"show.php?id=$detail[2]\">$detail[3]</a>";			
         

   }
 ?></LI></td>
		  </tr>
		  </table></td>
        </tr>
      </table>
	  <table width="190" border="0" cellspacing="0" cellpadding="2">
        <tr> 
          <td height="20" align="center" bgcolor="#E4E4E4"><div align="left"><font color="#330000"><b> <font color="#000000">��������TOP10</font></b></font></div></td>
        </tr>
        <tr>
          <td height="20" bgcolor="#FFFFFF">
		  <table width=98% border="0" cellspacing="0" cellpadding="1">
		  <tr><td bgcolor="#FFFFFF">
<?
$top10=@file("data/downhotday.php");

$c=min(count($top10),10); 
 for ($i=0; $i<$c; $i++){

 $detail=explode("|",$top10[$i]);      

 $file_name=chop($detail[2]);     

//if (strlen($detail[3])>=25) $detail[3]=substr($detail[3],0,22)."...";
 echo "<LI><a href=\"show.php?id=$detail[2]\">$detail[3]</a>";			
         

   }
 ?></LI></td>
		  </tr>
		  </table></td>
        </tr>
      </table>
    </td>
    <td valign=top> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td bgcolor="#FFFFF7" height="20">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr bgcolor="#FFF7E7">
          	<td bgcolor="#E4E4E4"><font color="#000000">&nbsp;��������</font></td>
          	<td width="14%" align=center bgcolor="#E4E4E4"><font color="#000000">����</font></td>
          	<td width="10%" align=center bgcolor="#E4E4E4"><font color="#000000">����</font></td>
          	<td width="10%" align=right bgcolor="#E4E4E4"><font color="#000000">��С</font>&nbsp;</td>
          </tr>
          </table></td>
        </tr>
		<tr><td height=5 bgcolor="#FFFFFF"></td>
		</tr>
        <tr>
          <td height="50" bgcolor="#FFFFFF" class="font">
<?
$countnum=count($softg_list);
$list_soft='';
$count=$countnum;
if($count!=0){
 if ($count%$perpage==0) $maxpageno=$count/$perpage;
		else $maxpageno=floor($count/$perpage)+1;
	if ($page>$maxpageno) $page=$maxpageno;
	$pagemin=min( ($page-1)*$perpage , $count-1);
	$pagemax=min( $pagemin+$perpage-1, $count-1);
	for ($i=$pagemin; $i<=$pagemax; $i++) {
	 $detail=explode("|",$softg_list[$i]);
$file_name=chop($detail[2]);
  $a_info=@file("data/data/$file_name.php");  list($txt_category_id,$txt_class_id,$txtshowname,$txtfilename,$txtshow,$txtfilename1,$txtshow1,$txtfilename2,$txtshow2,$txtfilename3,$txtshow3,$fromurl,$size,$order,$hot,$hots,$hide,$usrtool,$runsystem,$txtnote,$times,$imgurl)=explode("|",$a_info[1]);
  $txtnote=str_replace("<br>","��",$txtnote);
  if (strlen($txtnote)>=50) $txtnote=substr($txtnote,0,49)."...";
list($viewnum,$downnum,$tviewnum,$tdownnum,$pinfeng,$viewtimes)=explode("|",$a_info[2]);
$times=get_date($times);
?>
<table width="99%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="20" class="font"><a href="show.php?id=<?echo $file_name;?>"><b><?echo $txtshowname?></b></a></td>
  </tr>
  <tr> 
    <td height="40" align="right"> 
      <table width="98%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td height="20" class="font">
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr class="font"> 
            <td width="66%" align=left><?echo $nouse;?> </td>
                <td width="14%" align=center class="font"><?echo $size;?></td>
                <td width="10%" align=center class="font"><?=$viewnum?></td>
                <td width="10%" align=right class="font"><?echo $order;?>&nbsp;</td>
              </tr>
            </table>
          </td>
        </tr>
        <tr>
          <td height="20" class="font">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td width="100%" bgcolor="#FFFFFF" class="font"><b>����ϵͳ</b>��<?echo $txtnote;?>&nbsp;&nbsp;<b>��Ȩ��ʽ:</b><?=$hot?>&nbsp;&nbsp;</td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="1" bgcolor="#FFCC99"></td>
  </tr>
</table>
<?

}
}else {echo "�������ʱ������";}
?></td>
        </tr>
		<form method=post action=news.php>
        <tr>
          <td bgcolor="#E4E4E4" height="22">&nbsp;<?
if ($maxpageno<=1) echo " �����ϼ�{$countnum}�� | ֻ��һҳ";
else { 
      $nextpage=$page+1;
      $previouspage=$page-1;
	  echo " �����ϼ�{$countnum}�� | ";
	  if ($page<=1) echo " ��ҳ����һҳ��<a href=news.php?page=$nextpage>��һҳ</a>��<a href=news.php?page=$maxpageno>βҳ</a> ";
	  elseif($page>=$maxpageno) echo " <a href=news.php?page=1>��ҳ</a>��<a href=news.php?page= $previouspage>��һҳ</a>����һҳ��βҳ ";
	 
	  else echo " <a href=news.php?page=1>��ҳ</a>��<a href=news.php?page= $previouspage>��һҳ</a>��<a href=news.php?page=$nextpage>��һҳ</a>��<a href=news.php?page=$maxpageno>βҳ</a> ";
	  echo " | $page/$maxpageno  20��/ҳ | ת�� <select name='page' size='1' style=\"border: 1px solid #429234; background-color: #FAFDF9\" onChange='javascript:submit()'>";
	for ($j=1; $j<=$maxpageno; $j++) {echo "<option value='".$j."'>��".$j."ҳ</option>";
	}
	echo "</select>";
}
?></td>
        </tr></form>
      </table>
    </td>
  </tr>
</table>
<?
require "footer.php";
?>