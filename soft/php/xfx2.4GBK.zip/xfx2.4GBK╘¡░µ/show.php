<?
//////////////////////////////////��ֹ����ˢ��/////////////////////////////
$timestamp=time();
$cookietime = $timestamp+3153600;
if ($REQUEST_URI == $HTTP_COOKIE_VARS['lastpath'] && ($timestamp-$HTTP_COOKIE_VARS['lastvisit_fr']<3)) {
die('������ʾ��ֹ��ԭ�򣺷���ͬһURL��ˢ��ʱ��С��3��');
	}
setCookie('lastpath', $REQUEST_URI, $cookietime);
setCookie('lastvisit_fr', $timestamp, $cookietime);
/////////////////////////////////////////////////////////////////////////////
require("fun.php");
if (file_exists("data/config.php"))	
{
$sys_info=explode("|",readfrom("data/config.php"));
static $atten;
static $email;
$atten=$sys_info[5];
$email=$sys_info[6];
}
if(empty($id)) { echo"�����������ڣ������ѱ�ɾ��������������ϵվ��";exit;}
if (!file_exists("data/data/$id.php")) { echo"�����������ڣ������ѱ�ɾ��������������ϵվ��";exit;}
$a_info=@file("data/data/$id.php");  list($txt_category_id,$txt_class_id,$txtshowname,$txtfilename,$txtshow,$txtfilename1,$txtshow1,$txtfilename2,$txtshow2,$txtfilename3,$txtshow3,$fromurl,$adddate,$size,$order,$hot,$hots,$hide,$usrtool,$runsystem,$txtnote,$times,$imgurl)=explode("|",$a_info[1]);
$classid=$txt_category_id;
$nclassid=$txt_class_id;
get_classid();
get_nclassid();
list($viewnum,$downnum,$tviewnum,$tdownnum,$pinfeng,$viewtimes,$viewtimes1)=explode("|",$a_info[2]);
$t=getdate($viewtimes1);	
$d=getdate($timestamp);
if($t['mday']==$d['mday']) {
$tviewnum++;
}else{
$tviewnum=1;
$viewtimes1=$timestamp;
writeto("data/viewhot.php","");
}
$viewnum=$viewnum+1;
$a_infoa=trim($a_info[0]);
$a_infob=trim($a_info[1]);
unset($a_info[0]);
unset($a_info[1]);
unset($a_info[2]);
$a_infoc="$viewnum|$downnum|$tviewnum|$tdownnum|$pinfeng|$viewtimes|$viewtimes1|";
$line_ff= $a_infoa."\n".$a_infob."\n".$a_infoc."\n".implode("",$a_info);
writeto("data/data/$id.php",$line_ff);
$view_hot=file("data/viewhot.php");
$view_hot_count=count($view_hot)-1;
$view_hot_info=explode("|",$view_hot[29]);
$ab_info=@file("data/data/$view_hot_info[2].php"); 
list($viewnumd,$downnumd,$tviewnumd,$tdownnumd,$pinfengd,$viewtimesd)=explode("|",$ab_info[2]);
if ($viewnum>=$viewnumd) {
for ($i=0;$i<=$view_hot_count;$i++){
    $view_hot_info=explode("|",$view_hot[$i]);
	$ab_info=@file("data/data/$view_hot_info[2].php"); 
list($viewnumd,$downnumd,$tviewnumd,$tdownnumd,$pinfengd,$viewtimesd)=explode("|",$ab_info[2]);
    if ($view_hot_info[2]==$id)
    continue;
    $rank_typearray[$view_hot[$i]]=$viewnumd;
}
$view_hot_show=$txt_category_id."|".$txt_class_id."|".$id."|".$txtshowname."|".$add_times."|\n";
$rank_typearray[$view_hot_show]=$viewnum;
arsort($rank_typearray);
reset($rank_typearray);
$fp=fopen("data/viewhot.php","w");
flock($fp,3);
for ($counter=1; $counter<=30; $counter++) {
    $keytype=key($rank_typearray);
    fwrite($fp,$keytype);
    if (!(next($rank_typearray))) break;
}
fclose($fp);
}
if($downnum=="")$downnum=0;
require "header.php";
?>

<link href="images/css.css" rel=stylesheet>
<table width="680" border="0" cellspacing="4" cellpadding="0" align="center" height="20">
  <tr> 
    <td bgcolor="#E4E4E4"><font color="#000000">����λ�ã�</font><a href=index.php><font color="#000000">��ҳ</font></a> <font color="#00000">-></font> <a href="sort.php"><font color="#000000">��������</font></a><font color="#000000"> -></font> <a href=list.php?classid=<?=$classid?>><font color="#000000"><?=$class_name?></font></a> <font color="#000000">-> </font><a href=list.php?classid=<?=$classid?>&nclassid=<?=$nclassid?>><font color="#000000"><?echo $nclass_name?></font></a> <font color="#000000">-></font>      <?=$txtshowname?></td>
  </tr>
</table>
<table width="680" border="0" cellspacing="0" cellpadding="0" align="center" height="60">
  <tr> 
    <td width="200" bgcolor="#FFFFFF" valign="top"> 
<table width="200" border="0" cellspacing="0" cellpadding="2">
        <tr> 
          <td height="20" align="center" bgcolor="#E4E4E4"><a href=list.php?classid=<?=$classid?>><font color="#000000"><b><?=$class_name?></b></font></a></td>
        </tr>
        <tr>
          <td height="20"><table width=98% border="0" cellspacing="0" cellpadding="1">
<?
$list=@file("data/nclass.php");
$count=count($list)-1;
$bclass="";
for ($i=0; $i<=$count; $i++) 
{
	$list_info=explode("|",$list[$i]);
	if ($list_info[0]==$classid) echo "<tr><td align=center><a href=\"list.php?classid=$list_info[0]&nclassid=$list_info[1]\"><font color=#330000>$list_info[2]</font></a></td></tr>";	
}
?>
          </table></td>
        </tr>
      </table>
	  <table width="200" border="0" cellspacing="0" cellpadding="2">
        <tr> 
          <td height="20" align="center" bgcolor="#E4E4E4"> <font color="#000000"><b>��Ʒ�Ƽ�</b></font></td>
        </tr>
        <tr>
          <td height="20" bgcolor="#FFFFFF">
		  <table width=98% border="0" cellspacing="0" cellpadding="1">
		  <tr><td bgcolor="#FFFFFF">
<?
$top10=@file("data/hots.php");

$c=min(count($top10),10); 
 for ($i=0; $i<$c; $i++){

 $detail=explode("|",$top10[$i]);      

 $file_name=chop($detail[2]);     

//if (strlen($detail[3])>=25) $detail[3]=substr($detail[3],0,22)."...";
 echo "<LI><a href=\"show.php?id=$detail[2]\">$detail[3]</a>";			
}
?>
</LI></td>
		  </tr>
		  </table></td>
        </tr>
      </table>
    </td>
    <td width="20">&nbsp;</td>
    <td> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td bgcolor="#E4E4E4" height="25" align="center"><font size="3"><b><font color="#000000"><?=$txtshowname?></font></b></font></td>
        </tr>
        <tr> 
          <td height="70" valign=top>
            <table width="100%" border="0" cellspacing="2" cellpadding="4">
              <tr> 
                <td height="9" colspan="2" bgcolor="#FFFFFF">                  <p class="font"><br>
                    <b>������С��</b>&nbsp;&nbsp;<?=$size?><br>
                    <b>��Ȩ��ʽ��</b>&nbsp;&nbsp;<?=$order?><br>
                    <b>�������</b>&nbsp;&nbsp;<?=$nclass_name?><br>
                    <b>Ӧ��ƽ̨��</b>&nbsp;&nbsp;<?=$runsystem?><br>
                    <b>����ʱ�䣺</b>&nbsp;&nbsp;<?=$adddate?><br>
                    <b>���������</b>&nbsp;&nbsp;<?=$downnum?>/<?=$viewnum?><br>
                    <b>�Ƽ��ȼ���</b>&nbsp;&nbsp;<? if($hot) {for ($i=0; $i<$hot; $i++){echo"<img src=images/star.gif>"; }}?><br>
                    <b>�� �� �̣�</b>&nbsp;&nbsp;<a target=_blank href=<?=$fromurl?>><?=$fromurl?></a><br>
                    <b>����������</b>&nbsp;&nbsp;<a href="vote.php?id=<?=$id?>"><strong>����ͶƱ</strong></a> <br>

                <p>&nbsp;</p>                </td>
                <td width="46%" height="219" valign=top bgcolor="#FFFFFF"><div align="center"><a href="<?=$txtfilename3;?>" target="_blank"><img src="<?=$txtfilename3;?>" alt="����Ԥ��[����Ŵ�]" width="230" height="219" border="0"></a>
  
              </div></td>
              </tr>
              <tr>
                <td height="10" colspan="2" align="center" bgcolor="#E4E4E4"><div align="left"><b> <font color="#000000">�������ܣ�</font></b></div></td>
                <td height="10" align="center" valign=top bgcolor="#E4E4E4"><div align="left"><strong> <font color="#000000">�����ͼ�Ŵ�ۿ�����Ԥ��ͼƬ</font></strong></div></td>
              </tr>
              <tr bgcolor="#FFFFFF"> 
                <td height="21" colspan="3" >&nbsp;&nbsp;&nbsp;&nbsp;<?=$txtnote;?></td>
              </tr>
              <tr bgcolor="#FFFFFF"> 
                <td height="21" colspan="3">&nbsp;</td>
              </tr>
              <tr align="center" bgcolor="#E4E4E4"> 
                <td height="21" colspan="3"><div align="left"><b> <font color="#000000">���ص�ַ��</font></b></div></td>
              </tr>
              <tr bgcolor="#FFFFFF"> 
                <td height="9" colspan="3"> &nbsp;<img src="images/down.gif" width="14" height="14"> ==&gt;&gt; <?
if ($txtfilename) echo"<a href=\"down.php?downid=1&id=$id\" target=_blank>$txtshow</a>��";
if ($txtfilename1) echo"<a href=\"down.php?downid=2&id=$id\" target=_blank>$txtshow1</a>��";
if ($txtfilename2) echo"<a href=\"down.php?downid=3&id=$id\" target=_blank>$txtshow2</a>��";
?>
                </td>
              </tr>
              <tr bgcolor="#FFFFFF">
                <td height="10" colspan="3">&nbsp;</td>
              </tr>
              <tr align="center" bgcolor="#E4E4E4"> 
                <td height="21" colspan="3"><div align="left"><strong> <a href="mailto:<?=$email?>"><font color="#000000">���ִ���</font></a><font color="#000000">[�����޷����ػ��߽�������]</font></strong></div></td>
              </tr>
              <tr bgcolor="#FFFFFF"> 
                <td height="21" colspan="3"></td>
              </tr>
              <tr align="center" bgcolor="#E4E4E4"> 
                <td height="9" colspan="3"> <div align="left"><strong><font color="#000000">ע�����</font></strong></div></td>
              </tr>
              <tr bgcolor="#FFFFFF">
                <td width="5%" height="10" class="font">&nbsp;                </td>
                <td height="10" colspan="2" class="font"><?echo $atten;?></td>
              </tr>
              <tr bgcolor="#FFFFFF">
                <td height="21" colspan="3">&nbsp;</td>
              </tr>
              <tr align="center" bgcolor="#E4E4E4"> 
                <td height="21" colspan="3"><div align="left"><b> <font color="#000000">�������ۣ�</font></b></div></td>
              </tr>
              <tr bgcolor="#FFFFFF"> 
                <td height="21" colspan="3" class="font">
				&nbsp;&nbsp;&nbsp;&nbsp;
<?
				$a_info=@file("data/data/$id.php");
list($viewnum,$downnum,$tviewnum,$tdownnum,$pinfeng,$viewtimes,$viewtimes1)=explode("|",$a_info[2]);
if (empty($page)) $page=1;
if ($page <1)  $page=1;
settype($page, integer);
$perpage=10;

$count=count($a_info);
$num=$count-3;
$count=$count-3;
if($num) $pinfeng=floor($pinfeng/$num); else $pinfeng=0;
if($count>0){
	$list_soft='<table board=0 width=100% cellspacing="0" cellpadding="0" border="0" style="border-collapse: collapse" bordercolor="#111111">';
 if ($count%$perpage==0) $maxpageno=$count/$perpage;
		else $maxpageno=floor($count/$perpage)+1;
	if ($page>$maxpageno) $page=$maxpageno;
	$pagemin=min( ($page-1)*$perpage , $count-1);
	$pagemax=min( $pagemin+$perpage-1, $count-1);
	for ($i=$pagemin+3; $i<=$pagemax+3; $i++) {
	$detail=explode("|",$a_info[$i]);
	$list_soft.="<tr><td width=90%><font color=\"#FF0000\">��</font><font color=\"green\"> </font>$detail[1]&nbsp;&nbsp;(��֣�$detail[0])</td></tr>";
	}
$list_soft.="</table>";
	}else
	$list_soft="��ʱû������";
	echo $list_soft;
	?>
                </td>
              </tr>
              <tr align="right" bgcolor="#FFFFFF"> 
                <td height="21" colspan="3"><a href="vote.php?id=<?=$id?>">����...</a></td>
              </tr>
              <tr bgcolor="#FFFFF7"> 
                <td height="21" colspan="3"> 
                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <form method=post action="vote.php" target=_blank><tr> 
                      <td height="20" bgcolor="#FFFFFF" class="font">����:
                        <select name="grade">
                          <option value="0">0</option>
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3" selected>3</option>
                          <option value="4">4</option>
                          <option value="5">5</option>
                        </select>
                      ����:<input type="text" name="content" size="30"><input name=id type=hidden value="<?=$id?>"><input type="hidden" name="action" value="save">
                        <input type="submit" name="Submit2" value="ȷ��">
                      </td>
                    </tr></form>
					<tr><td height=5 bgcolor="#FFFFFF"></td>
					</tr>
                </table>                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<?
require "footer.php";
?>