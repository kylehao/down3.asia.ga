<?
if (file_exists("data/config.php"))	
{
$sys_info=explode("|",readfrom("data/config.php"));
static $down_name;
static $down_url;
static $site_url;
$down_name=$sys_info[2];
$down_url=$sys_info[3];
$site_url=$sys_info[1];

}
?>
<html>
<head>
<title><? echo $down_name; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" href="images/css.css" type="text/css">
</head>

<body topmargin="0" leftmargin="0" bgcolor="#162a31">
<table width=680 height=24 border=0 align=center cellpadding=0 cellspacing=0 bordercolor="#5FB0D8" 
bgcolor=#dedec7>
  <tbody> 
  <tr> 
    <td width="35" height="20" align=center bgcolor="#FFFFFF" class="font"><div  class="font"> 
      <div align="left"></div>
    </div></td>
    <td width="628" align=center bgcolor="#FFFFFF" class="font"><div align="left">| <a href="index.php"><font color="#000000">��&nbsp;&nbsp;ҳ</font> </a>|<a href="sort.php" ><font color="#000000">��������</font></a> |<a href="news.php"> <font color="#000000">�������</font> </a>| <a href="hot.php"><font color="#000000">��������</font></a> | <a href="commends.php"><font color="#000000">��Ʒ�Ƽ�</font> </a>|</div></td>
    <td width="77" align=center bgcolor="#FFFFFF"><span class="style5">&nbsp;<a href="../"><span class="style8"><font color="#000000">������ҳ</font></a></span></td>
    <td width="20" align=center bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr align="left" bgcolor="#FFFFFF"> 
    <td height="6" colspan="4">	<img src="images/banner.jpg" width="680" height="245"></td>
  </tr>
  </tbody> 
</table>
<table width=680 border=0 align=center cellpadding=3 cellspacing=0 bordercolor="#5FB0D8">
  <tbody> 
  <tr bgcolor="#5FB0D8"> 
    <td width="23" height="20" bgcolor="#FFFFFF">&nbsp;      </td>
    <td width="680" height="20" bgcolor="#FFFFFF" class="font">&nbsp; <a href="index.php"><font color=black>������ҳ</font> </a><?
$list=file("data/class.php");
$count=count($list)-1;
for ($i=0; $i<=$count; $i++) {
	$list_info=explode("|",$list[$i]);
	echo" | <a href=\"list.php?classid=$list_info[0]\"><font color=#000000>$list_info[1]</font></a>";
}
?>
      | </td>
    </tr>
  </tbody>
</table>
<table width=680 border=0 align="center" cellpadding=0 cellspacing=4 bordercolor="#FFFFFF">
  <tbody> 
  <tr bgcolor="#FFFFFF"> 
    <td width="766" height=30 align=middle bgcolor="#FFFFFF"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <form method="post" action="search.php" name="Searchsoft">
          <tr> 
            <td width="4%" height="20" bgcolor="#FFFFFF">&nbsp; <b></b></td>
            <td width="84%" height="20" bgcolor="#FFFFFF"><span class="style8"><b>����������</b></span>
              <select name="action" size="1">
                <option value="title">����</option>
                <option value="content">���</option>
              </select>
              <input maxlength=40 
      size=16 name=keyword>
              <select name="sclass" size="1">
                <option value="all">ȫ�����</option>
                <?
$list=file("data/class.php");
$count=count($list);
for ($i=0; $i<$count; $i++) {
$list_info=explode("|",$list[$i]);
echo"<option value=$list_info[0]>$list_info[1]</option>";
}?>
              </select>
&nbsp;
<input type=submit value=���� name=Submit></td>
            <td width="12%" height="20" bgcolor="#FFFFFF">&nbsp;<a href="<?=$site_url?>" target="_blank" class="style8"><span class="style8"> </span></a></td>
          </tr>
        </form>
      </table>      

