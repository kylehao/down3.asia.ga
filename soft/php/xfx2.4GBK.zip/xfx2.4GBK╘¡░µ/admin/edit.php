<?
session_start();
function showclass() {
	$downlist=file("../data/nclass.php");
	$fcount=count($downlist);
	for ($i=0; $i<$fcount; $i++) {
$detail=explode("|",$downlist[$i]);
		echo "subcat[$i] = new Array(\"$detail[2]\",\"$detail[0]\",\"$detail[1]\");\n\n";
	}
	echo "onecount=$fcount;\n";
}
function showcategory() {
$downlist=file("../data/class.php");
global $category_id;
	$fcount=count($downlist);
	for ($i=0; $i<$fcount; $i++) {
	$detail=explode("|",$downlist[$i]);	
if($category_id==$detail[0])
		echo "				<OPTION VALUE=\"$detail[0]\" selected>$detail[1]</OPTION>\n";
else echo "				<OPTION VALUE=\"$detail[0]\" >$detail[1]</OPTION>\n";
	}
}
?>

<script language="JavaScript1.2">
function SetAction(A){
Action.actions.value=A;
	}
function popwin(id,path)
{
window.open("../show.php?id="+id+"&ppath="+path,"","height=460,width=560,resizable=yes,scrollbars=yes,status=yes");
}

function validate(theform) {
	if (theform.txtshowname.value=="" ) {
		alert("����д��������.");
		return false; }
		if (theform.txt_category_id.value=="" || theform.txt_class_id.value=="") {
		alert("����д����������Ŀ.");
		return false; }
		if (theform.txtfilename.value=="") {
		alert("����д�������ص�ַһ.");
		return false; }
	if (theform.txtnote.value=="") {
		alert("����д�������.");
		return false; }
	
}//-->
</script>
<script language = "JavaScript">
var onecount;
onecount=0;
subcat = new Array();
<?=showclass()?>
function changelocation(locationid)
    {
    document.FORM.txt_class_id.length = 0; 
    var locationid=locationid;
    var i;
    for (i=0;i < onecount; i++)
        {
            if (subcat[i][1] == locationid)
            { 
                document.FORM.txt_class_id.options[document.FORM.txt_class_id.length] = new Option(subcat[i][0], subcat[i][2]);
            } 
			if (document.FORM.txt_category_id.options[document.FORM.txt_category_id.selectedIndex].value == "" ) 
			{
			document.FORM.txt_class_id.options[document.FORM.txt_class_id.length] = new Option("[��ѡ���ӷ���]", "");
			}}} 
</script>


<?
$thisprog="edit.php";
require("global.php");
if (empty($page)) $page=1;
if ($page <1)  $page=1;
settype($page, integer);
$perpage=10;
if ($_SESSION["login_status"]=="yes" || $_SESSION["login_status"]=="ok"){
if (empty($actions)) {
print <<<EOT
  <tr><td bgcolor=#ADADAD colspan=2><font color=#ffffff>
  <b>��ӭ����������ʽ / ��������</b>
  </td></tr>
  <tr>
  <td bgcolor=#eeeeee valign=middle align=center colspan=2>
  <font color=#333333><b>�༭/ɾ������</b>
  </td></tr>
  <tr bgcolor=ffffff colspan=2><td height=5></td></tr>
  

  <tr>
  <td bgcolor=ffffff align=center colspan=2>
	 

 </td>
  </tr>
<tr bgcolor=ffffff>
	 <form action="$thisprog" method=post  name=Action  id=Action>
  <input type=hidden name="actions" value="edit">
   <td>��λ������ID��</td>
   <td><INPUT size=20  name=soft_id><input type=submit  value="�༭"> <input type="submit" onClick="SetAction('del')" value="ɾ��" ></td>
	 </form>
  </tr>
  <tr bgcolor=ffffff>
   <td colspan=2 align=left >
	   �����б���<br>
EOT;
  
$softg_list=@file("../data/list.php");
$countnum=count($softg_list);
$list_soft='';
$count=$countnum;
if($count!=0){
 if ($count%$perpage==0) $maxpageno=$count/$perpage;
		else $maxpageno=floor($count/$perpage)+1;
	if ($page>$maxpageno) $page=$maxpageno;
	$pagemin=min( ($page-1)*$perpage , $count-1);
	$pagemax=min( $pagemin+$perpage-1, $count-1);

	for ($i=$pagemin; $i<=$pagemax; $i++) {
	 $detail=explode("|",$softg_list[$i]);
echo"ID:$detail[2]��<a href=\"javascript:popwin($detail[2])\">$detail[3]</a>����<a href=$thisprog?soft_id=$detail[2]&actions=edit>�༭</a>����<a href=$thisprog?soft_id=$detail[2]&actions=del>ɾ��</a>����<br>";


	}
}
if ($maxpageno<=1) $pageinfo= "<p align='center'>&nbsp;&nbsp;<b>ֻ��һҳ</b>";
else { 
      $nextpage=$page+1;
      $previouspage=$page-1;
	  $pageinfo="<form method=Post action=$thispro><p align='center'>&nbsp;����<font color=red><b>$countnum</b></font>����";
	  if ($page<=1) $pageinfo.="	  ��ҳ����һҳ��<a href=$thispro?page=$nextpage>��һҳ</a>��<a href=$thispro?page=$maxpageno>βҳ</a>��";
	  elseif($page>=$maxpageno) $pageinfo.="	  <a href=$thispro?page=1>��ҳ</a>��<a href=$thispro?page= $previouspage>��һҳ</a>����һҳ��βҳ��";
	 
	  else $pageinfo.="	  <a href=$thispro?page=1>��ҳ</a>��<a href=$thispro?page= $previouspage>��һҳ</a>��<a href=$thispro?page=$nextpage>��һҳ</a>��<a href=$thispro?page=$maxpageno>βҳ</a>��";
	  $pageinfo.="ҳ�Σ�<strong><font color=red>$page</font>/$maxpageno</strong>ҳ  <b>10</b>������/ҳ��ת����<select name='page' size='1' style=\"border: 1px solid #429234; background-color: #FAFDF9\" onChange='javascript:submit()'>";
	for ($j=1; $j<=$maxpageno; $j++) {$pageinfo.="<option value='".$j."'>��".$j."ҳ</option>";
	}
$pageinfo.="</select></form>";
}
echo"$pageinfo</tr></td></tr></table></body></html>";
exit;
}elseif ($actions=="del") {
	if (file_exists("../data/data/$soft_id.php")) { 
$a_info=@file("../data/data/$soft_id.php");  list($category_id,$class_id,$txtshowname,$txtfilename,$txtshow,$txtfilename1,$txtshow1,$txtfilename2,$txtshow2,$txtfilename3,$txtshow3,$fromurl,$adddate,$size,$order,$hot,$hots,$hide,$usrtool,$runsystem,$txtnote,$times,$imgurl)=explode("|",$a_info[1]);}
	if(!$step){
		
		print <<<EOT
  <tr><td bgcolor=#ADADAD colspan=2><font color=#ffffff>
  <b>��ӭ����������ʽ / ��������</b>
  </td></tr>
  <tr>
  <td bgcolor=#eeeeee valign=middle align=center colspan=2>
  <font color=#333333><b>ɾ������</b>
  </td></tr>
  <tr bgcolor=ffffff colspan=2><td height=5></td></tr>
  

  <tr>
  <td bgcolor=ffffff align=center colspan=2>
	 
����ȷ�ϣ�<br><br>
	���Ҫɾ����<br><br><br>
		<a href=$thisprog?soft_id=$soft_id&actions=del&step=2>���ȷ��ɾ��</a>
 </td>
  </tr>

 
	</tr></td></tr></table></body></html>
EOT;
		exit;}
		elseif($step==2){
if($hots=='on'){
$list_temp=explode("\n",readfrom("../data/hots.php"));
$count=count($list_temp);

for ($i=0; $i<$count; $i++) {

	$list_info=explode("|",$list_temp[$i]);

	if ($list_info[2]==$soft_id) {		

		unset($list_temp[$i]);

		break;}
}

writeto("../data/hots.php",implode("\n",$list_temp));
unset($list_temp);
unset($list_info);

}
if($usrtool=='on'){
$list_temp=explode("\n",readfrom("../data/usrtool.php"));
$count=count($list_temp);

for ($i=0; $i<$count; $i++) {

	$list_info=explode("|",$list_temp[$i]);

	if ($list_info[2]==$soft_id) {		

		unset($list_temp[$i]);

		break;	}}
writeto("../data/usrtool.php",implode("\n",$list_temp));

unset($list_temp);
unset($list_info);}
$list_temp=explode("\n",readfrom("../data/list.php"));

$count=count($list_temp);

for ($i=0; $i<$count; $i++) {

	$list_info=explode("|",$list_temp[$i]);

	if ($list_info[2]==$soft_id){		

		unset($list_temp[$i]);		

		break;}
		}
writeto("../data/list.php",implode("\n",$list_temp));
unlink("../data/data/$soft_id.php");
print <<<EOT
  	<tr><td bgcolor=#ADADAD colspan=2><font color=#333333>
		<b>��ӭ����������ʽ</b>
		</td></tr>
		<tr>
		<td bgcolor=#eeeeee valign=middle colspan=2>
		<center><b>�ɹ�</b></center>
		</td></tr></table></body></html>
EOT;
	exit;}
}elseif ($actions=="edit") {
	if(empty($soft_id)) { echo"�����������ڣ������ѱ�ɾ��������������ϵվ��";exit;}
if (!file_exists("../data/data/$soft_id.php")) { echo"�����������ڣ������ѱ�ɾ��������������ϵվ��";exit;}
$a_info=@file("../data/data/$soft_id.php");  list($category_id,$class_id,$txtshowname,$txtfilename,$txtshow,$txtfilename1,$txtshow1,$txtfilename2,$txtshow2,$txtfilename3,$txtshow3,$fromurl,$adddate,$size,$order,$hot,$hots,$hide,$usrtool,$runsystem,$txtnote,$times,$imgurl)=explode("|",$a_info[1]);
	if(!$step){
		
$txtnote=str_replace('%a%','',$txtnote);$txtnote=str_replace("<br>","\r\n",$txtnote);
get_classid($category_id);
get_nclassid($category_id,$class_id);
if($txtshow=='�������') $show_1txtshow='selected';
elseif($txtshow=='��������') $show_2txtshow='selected';
elseif($txtshow=='����ҳ��') $show_3txtshow='selected';
if($txtshow1=='����վ��') $show_1txtshow1='selected';
elseif($txtshow1=='��������') $show_2txtshow1='selected';
elseif($txtshow1=='�ƽ��ļ�') $show_3txtshow1='selected';
elseif($txtshow1=='ע���ļ�') $show_4txtshow1='selected';
if($txtshow2=='����վ��') $show_1txtshow2='selected';
elseif($txtshow2=='��������') $show_2txtshow2='selected';
elseif($txtshow2=='�ƽ��ļ�') $show_3txtshow2='selected';
elseif($txtshow2=='ע���ļ�') $show_4txtshow2='selected';
if($txtshow3=='����վ��') $show_1txtshow3='selected';
elseif($txtshow3=='��������') $show_2txtshow3='selected';
elseif($txtshow3=='�ƽ��ļ�') $show_3txtshow3='selected';
elseif($txtshow3=='ע���ļ�') $show_4txtshow3='selected';
if($order=='�ƽ�ע��') $show_1order='selected';
elseif($order=='��������') $show_2order='selected';
elseif($order=='�������') $show_3order='selected';
elseif($order=='��ҵ����') $show_4order='selected';
elseif($order=='��������') $show_5order='selected';
elseif($order=='��������') $show_6order='selected';
if($hot==1) $show_1hot='selected';
elseif($hot==2) $show_2hot='selected';
elseif($hot==3) $show_3hot='selected';
elseif($hot==4) $show_4hot='selected';
elseif($hot==5) $show_5hot='selected';
if($runsystem=="Win9x/ME/NT/2000/XP") $show_1runsystem='selected';
elseif($runsystem=="Win9x/ME") $show_2runsystem='selected';
elseif($runsystem=="WinNT/2000") $show_3runsystem='selected';
elseif($runsystem=="Win9x/NT/2000/UNIX/Lunix") $show_4runsystem='selected';
elseif($runsystem=="UNIX/Lunix") $show_5runsystem='selected';
elseif($runsystem=="UNIX") $show_6runsystem='selected';
elseif($runsystem=="DOS") $show_7runsystem='selected';
elseif($runsystem=="Mac") $show_8runsystem='selected';
if($hots=="on") $show_hots='CHECKED';
if($hide=="on") $show_hide='CHECKED';
if($usrtool=="on") $show_usrtool='CHECKED';

		print <<<EOT
<head>
<script type="text/javascript">
  _editor_url = 'htmlarea/';
  _editor_lang = 'en';
</script>
<script type="text/javascript" src="htmlarea/htmlarea.js"></script>
<script type="text/javascript" src="htmlarea/dialog.js"></script>
<script tyle="text/javascript" src="htmlarea/lang/en.js"></script>
</head>
<noframes><body onload="HTMLArea.replace('TA')"></noframes>
		<tr><td bgcolor=#ADADAD colspan=2><font color=#ffffff>
  <b>��ӭ����������ʽ / �༭����</b>
  </td></tr>
  <tr>
  <td bgcolor=#eeeeee valign=middle align=center colspan=2>
  <font color=#333333><b>�༭����</b>
  </td></tr>
  <tr bgcolor=ffffff colspan=2><td height=5></td></tr>
  <form action="$thisprog" method="post" name="FORM"  >
  <input type=hidden name="actions" value="edit">
	  <input type=hidden name="step" value="2">
	  
  <input type=hidden name="soft_id" value=$soft_id>
  <tr>
  <td bgcolor=ffffff align=center colspan=2>
<table cellspacing="0" width="80%" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse">
<tr align="center"><td width="100%">
<table border="1" cellspacing="0" width="100%" cellpadding="0" style="border-collapse: collapse" bordercolor="#ADADAD" bgcolor="#ffffff">

<TR>
<TD align="right" width="20%" nowrap height="30">
<font color="#FF0000">����������</font></TD>
<TD width="80%" height="30">&nbsp;<select name="txt_category_id" onChange="changelocation(document.FORM.txt_category_id.options[document.FORM.txt_category_id.selectedIndex].value)">
 				
<!------------------ Show Category ------------------------>
EOT;
showcategory();
print <<<EOT
<!--------------------------- END ----------------------------->
		  </select>
        
        &nbsp;<font color="red">---</font>&nbsp; <select name="txt_class_id">
 				<option selected value="$class_id">$nclass_name</option>
          </select>
��</TD>
</TR>
<tr><td width="20%" align="right" height="30">
<font color="#FF0000">�������ƣ�</font></td>
<td width="80%" height="30">
&nbsp;<input type="text" name="txtshowname1" size="48" class="smallinput" maxlength="40" value="$txtshowname"></td></tr>
<tr><td width="20%" align="right" height="30">
<font color="#FF0000">���ص�һ��</font></td>
<td width="80%" height="30">
&nbsp;<input type="text" name="txtfilename1a" size="48" class="smallinput" maxlength="160" value="$txtfilename">
<select size="1" name="txtshow1a">
<option $show_1txtshow value="���ص�ַһ">���ص�ַһ</option>
<option $show_2txtshow value="��������">��������</option>
<option $show_3txtshow value="����ҳ��">����ҳ��</option>
</select></td></tr>

<tr><td width="20%" align="right" height="30">
<font color="#FF0000">ͼƬ��ַ��</font></td>
<td width="80%" height="30">
&nbsp;<input type="text" name="txtfilename31" size="48" class="smallinput" maxlength="160" value="$txtfilename3">
<select size="1" name="txtshow31">
<option $show_2txtshow value="����Ԥ��">����Ԥ��&nbsp;&nbsp;</option>
<option $show_1txtshow value="��ʾ��ַ">��ʾ��ַ&nbsp;&nbsp;</option>
</select></td></tr>
<tr><td width="20%" align="right" height="30">
<td width="80%" height="30">
<font color="blue">&nbsp;&nbsp;�����Ԥ��ͼƬ������дͼƬ��ַ����"http://"��ͷ��<br>&nbsp;&nbsp;���û��Ԥ��ͼƬ����д&nbsp; "images/nopic.gif"</font></td>

<tr><td width="20%" align="right" height="30">���صض���</td>
<td width="80%" height="30">
&nbsp;<input type="text" name="txtfilename11" size="48" class="smallinput" maxlength="160" value="$txtfilename1">
<select size="1" name="txtshow11">
<option value="���ص�ַ��"  $show_1txtshow1>���ص�ַ��</option>
<option value="��������"  $show_2txtshow1>��������</option>
<option value="�ƽ��ļ�"  $show_3txtshow1>�ƽ��ļ�</option>
<option value="ע���ļ�"  $show_4txtshow1>ע���ļ�</option>
</select></td></tr>
<tr><td width="20%" align="right" height="30">���ص�����</td>
<td width="80%" height="30">
&nbsp;<input type="text" name="txtfilename21" size="48" class="smallinput" maxlength="160" value="$txtfilename2">
<select size="1" name="txtshow21">
<option value="���ص�ַ��" $show_1txtshow2>���ص�ַ��</option>
<option value="��������" $show_2txtshow2>��������</option>
<option value="�ƽ��ļ�" $show_3txtshow2>�ƽ��ļ�</option>
<option value="ע���ļ�" $show_4txtshow2>ע���ļ�</option>
</select></td></tr>

<tr><td width="20%" align="right" height="30">������Դ��</td>
<td width="80%" height="30">
&nbsp;<input type="text" name="fromurl1" size="48" class="smallinput" maxlength="100" value="$fromurl"></td></tr>
<tr><td width="20%" align="right" height="30">
<td width="80%" height="30"><font color="blue">&nbsp;&nbsp;����"������Դ"����д��Դ��ַ����"http://"��ͷ��<br>&nbsp;&nbsp;���û�л��߶Դ���Ϣ���飬����д"��"</font></td>

<tr><td width="20%" align="right" height="30">����ʱ�䣺</td>
<td width="80%" height="30">
&nbsp;<input type="text" name="adddate1" size="12" class="smallinput" maxlength="20" value="$adddate"></font></td></tr>
<tr><td width="20%" align="right" height="30">������С��</td>
<td width="80%" height="30">
&nbsp;<input type="text" name="size1" size="12" class="smallinput" maxlength="20" value="$size"></font></td></tr>
<tr><td width="20%" align="right" height="30">��Ȩ��ʽ��</td>
<td width="80%" height="30">
&nbsp;<select name="order1" size="1">
<option value="�������" name="order" $show_3order>�������</option>
<option value="��������" name="order" $show_6order>��������</option>
<option value="�ƽ�ע��" name="order" $show_1order>�ƽ�ע��</option>
<option value="��������" name="order" $show_2order>��������</option>
<option value="��ҵ����" name="order" $show_4order>��ҵ����</option>
<option value="��������" name="order" $show_5order>��������</option>

</select></td></tr>
<tr><td width="20%" align="right" height="30">
�Ƽ����ȣ�</td>
<td width="80%" height="30">
&nbsp;<select name="hot1" size="1">
<option value="1" name="hot" $show_1hot>�͵ȡ�һ����</option>
<option value="2" name="hot" $show_2hot>�ϵ͡�������</option>
<option value="3" name="hot" $show_3hot>�еȡ�������</option>
<option value="4" name="hot" $show_4hot>�ϸߡ��ļ���</option>
<option value="5" name="hot" $show_5hot>��ߡ��弶��</option>
</select>��<input type="checkbox" name="hots1" $show_hots value="on" id=x><label for=x>���뾫Ʒ�Ƽ�</label>��<input type="checkbox" name="hide1"  $show_hide value="on" id=y><label for=y>��Ϊ����</label>��<input type="checkbox" name="usrtool1" $show_usrtool value="on" id=z><label for=z>���볣�ù���</label></td></tr>
<tr><td width="20%" align="right" height="30">
���л�����</td>
<td width="80%" height="30">
&nbsp; <select name="runsystem1">
              <option value="Win9x/ME/NT/2000/XP" $show_1runsystem>Win9x/ME/NT/2000/XP</option>
               <option value="Win9x/ME" $show_2runsystem>Win9x/ME</option>
              <option value="WinNT/2000" $show_3runsystem>WinNT/2000</option>
              <option value="Win9x/NT/2000/UNIX/Lunix" $show_4runsystem>Win9x/NT/2000/XP/UNIX/Lunix</option>
              <option value="UNIX/Lunix" $show_5runsystem>UNIX/Lunix</option>
              <option value="UNIX" $show_6runsystem>UNIX</option>
              <option value="DOS" $show_7runsystem>DOS</option>
              <option value="Mac" $show_8runsystem>Mac</option>
          </select>
</td></tr>
<tr><td width="20%" align="right" height="30">
<font color="#FF0000">������飺</font></td>
<td width="80%" height="30">
&nbsp;<textarea name="txtnote1" id="TA" style="width: 100%; height: 20em;">$txtnote</textarea></td></tr>


  <tr bgcolor=eeeeee>
   <td colspan=2 align=center ><input type=submit onclick="return validate(this.form)" value="�� ��"> <input type=reset value="�� ��">
  </tr>
</form>
  </td></tr></table></body></html>
EOT;
		
		
		exit;}
		elseif($step==2){

	$txtshowname1=stripslashes($txtshowname1); 
		$imgurl1=stripslashes($imgurl1);
        $fromurl1=stripslashes($fromurl1);
        $adddate1=stripslashes($adddate1);
        $txtnote1=stripslashes($txtnote1);
		$txtfilename1a=stripslashes($txtfilename1a);
		$txtfilename21=stripslashes($txtfilename21);
		$txtfilename31=stripslashes($txtfilename31);
		$txtfilename11=stripslashes($txtfilename11);
		$txtfilename11=kick_out($txtfilename11);
		$txtfilename21=kick_out($txtfilename21);
		$txtfilename31=kick_out($txtfilename31);
		$txtfilename1a=kick_out($txtfilename1a);
		$txtshowname1=kick_out($txtshowname1); 
		$imgurl1=kick_out($imgurl1);
		$fromurl1=kick_out($fromurl1);
		$adddate1=kick_out($adddate1);
        $newlist="$txt_category_id|$txt_class_id|$soft_id|$txtshowname1|$timestamp|\n";
		$hotslist="$txt_category_id|$txt_class_id|$soft_id|$txtshowname1|$timestamp|\n";
		$toollist="$txt_category_id|$txt_class_id|$soft_id|$txtshowname1|$timestamp|\n";
			if($txt_category_id == $category_id && $class_id == $txt_class_id && $txtshowname1 == $txtshowname){}else{
$list_temp=explode("\n",readfrom("../data/list.php"));

$count=count($list_temp);

for ($i=0; $i<$count; $i++) {

	$list_info=explode("|",$list_temp[$i]);

	if ($list_info[2]==$soft_id){		

		$list_info[0]=$txt_category_id;
		$list_info[1]=$txt_class_id;
		$list_info[3]=$txtshowname1;

		$list_temp[$i]=implode("|",$list_info);
		

		break;}
		

}

writeto("../data/list.php",implode("\n",$list_temp));

unset($list_temp);unset($list_info);
		$list_temp=explode("\n",readfrom("../data/hots.php"));
$count=count($list_temp);

for ($i=0; $i<$count; $i++) {

	$list_info=explode("|",$list_temp[$i]);

	if ($list_info[2]==$soft_id) {		

		$list_info[0]=$txt_category_id;
		$list_info[1]=$txt_class_id;
		$list_info[3]=$txtshowname1;

		$list_temp[$i]=implode("|",$list_info);

		break;	}}
writeto("../data/hots.php",implode("\n",$list_temp));
unset($list_temp);
unset($list_info);
$list_temp=explode("\n",readfrom("../data/usrtool.php"));
$count=count($list_temp);

for ($i=0; $i<$count; $i++) {

	$list_info=explode("|",$list_temp[$i]);

	if ($list_info[2]==$soft_id) {		

		$list_info[0]=$txt_category_id;
		$list_info[1]=$txt_class_id;
		$list_info[3]=$txtshowname1;

		$list_temp[$i]=implode("|",$list_info);

		break;	}}
writeto("../data/usrtool.php",implode("\n",$list_temp));
unset($list_temp);
unset($list_info);
	}

if($hots=='on' && !$hots1 ){
$list_temp=explode("\n",readfrom("../data/hots.php"));
$count=count($list_temp);

for ($i=0; $i<$count; $i++) {

	$list_info=explode("|",$list_temp[$i]);

	if ($list_info[2]==$soft_id) {		

		unset($list_temp[$i]);

		break;	}}
writeto("../data/hots.php",implode("\n",$list_temp));
unset($list_temp);
unset($list_info);
}
elseif($hots1=='on' && !$hots){
	if (file_exists("../data/hots.php")) $filehots=readfrom("../data/hots.php");	
			if (isset($filehots)) $hotslist.=$filehots;
			writeto("../data/hots.php",$hotslist); 

			}
if($usrtool=='on' && !$usrtool1 ){
	$list_temp=explode("\n",readfrom("../data/usrtool.php"));
$count=count($list_temp);

for ($i=0; $i<$count; $i++) {

	$list_info=explode("|",$list_temp[$i]);

	if ($list_info[2]==$soft_id) {		

		unset($list_temp[$i]);

		break;	}}
writeto("../data/usrtool.php",implode("\n",$list_temp));

}
elseif(!$usrtool && $usrtool1=='on'){
	if (file_exists("../data/usrtool.php")) $filetool=readfrom("../data/usrtool.php");	
			if (isset($filetool)) $toollist.=$filetool;
			writeto("../data/usrtool.php",$toollist); 
			}
		
	
		$file_line=array(
			$txt_category_id,
			$txt_class_id,
			$txtshowname1,
			$txtfilename1a,
			$txtshow1a,
			$txtfilename11,
			$txtshow11,
			$txtfilename21,
			$txtshow21,
			$txtfilename31,
			$txtshow31,
			$fromurl1,
			$adddate1,
            $size1,
			$order1,
			$hot1,
			$hots1,
			$hide1,
			$usrtool1,
			$runsystem1,			
			$txtnote1,
			$timestamp1,
			$imgurl1,
			);
		$line_cc=implode("|",$file_line)."|\n";
        $line_cc="<? exit;?>\n".$line_cc;
		writeto("../data/data/$soft_id.php",$line_cc);
		
  	print <<<EOT
  	<tr><td bgcolor=#ADADAD colspan=2><font color=#333333>
		<b>��ӭ����������ʽ</b>
		</td></tr>
		<tr>
		<td bgcolor=#eeeeee valign=middle colspan=2>
		<center><b>�ɹ�</b></center><br><br>&nbsp;&gt;&gt; <a href=$thisprog>����ִ����������</a>
		</td></tr></table></body></html>
EOT;
	exit;
}}
}else{
print <<<EOT
<tr>
  <td bgcolor=#ADADAD><font color=#ffffff>
<b>��ӭ���� С��������ϵͳ2.4 ��̨����ϵͳ</b>&nbsp;&nbsp;&nbsp;&nbsp;[��û�е�½���������<a href='login.php'>����</a>���е�½��]</td>

EOT;
exit;
}

?>