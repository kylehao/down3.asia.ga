<?
@extract($_SERVER, EXTR_SKIP); 
@extract($_SESSION, EXTR_SKIP); 
@extract($_POST, EXTR_SKIP); 
@extract($_FILES, EXTR_SKIP); 
@extract($_GET, EXTR_SKIP); 
@extract($_ENV, EXTR_SKIP); 
$timestamp=time();
admintitle();
global $thisprog;
function admintitle() {
global $checkpower;
print <<<EOT
    <html>
    <head>
    <title>С��������ϵͳ 2.4 [��̨����]</title>
    <meta http-equiv="Content-Type" content="text/html; charset=gb2312">
    <style type="text/css">
    BODY { COLOR: #FFFFFF; FONT-FAMILY: Verdana,Arial; FONT-SIZE: 9pt;
}
A:LINK		{COLOR: #3F3849; TEXT-DECORATION: none}
A:VISITED	{COLOR: #3F3849; TEXT-DECORATION: none}
A:HOVER		{COLOR: #0080FF; BACKGROUND-COLOR: #FFCECE}
A:ACTIVE	{COLOR: #0080FF; BACKGROUND-COLOR: #FFCECE}
.t     {	LINE-HEIGHT: 1.4}
TD,SELECT,TEXTAREA,DIV,FORM,OPTION,P{COLOR:333333; FONT-FAMILY: ����; FONT-SIZE: 9pt}
INPUT  {	FONT-FAMILY: ����; FONT-SIZE: 9pt; height:22px;	}
    </style>
    </head>
    <noframes><body bgcolor=#D8DEFF topmargin=5 leftmargin=5></noframes>
    <table width=95% cellpadding=0 cellspacing=1 border=0 bgcolor=#222244 align=center>
    <tr><td>
    <table width=100% cellpadding=0 cellspacing=1 border=0>
    <tr><td width=15% valign=top bgcolor=#FFFFFF>
    <table width=100% cellpadding=6 cellspacing=0 border=0>
    <tr><td bgcolor=#ADADAD><font color=#FFFFFF>
    <b>����ѡ��</b>
    </td></tr>
    <tr>
    <td bgcolor=#FFFFFF><p align="center"><br>
<a href="admin.php">������ҳ</a><br>
  <br> 
  <a href="system.php">ϵͳ����</a><br> 
  <br> 
  <a href="soft.php">��������</a><br> 
  <br> 
  <a href="edit.php">�޸�ɾ��</a><br>
  <br>
<a href=addclass.php>��Ŀ����</a><br>
  <br> 
  <a href=adduser.php>�û�����</a> <br>
  <br> 
  <a href=editmypwd.php>�����޸�</a> <br>
  <br> 
  <a href="../index.php" target=_blank>������ҳ</a><br>
  <br> 
  <a href="login.php?action=loginout">�˳�ϵͳ</a> </p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p></td>
    </tr>
    <td bgcolor=#FFFFFF>
    <table width=100% align=left cellspacing=0 cellpadding=0 bgcolor=333333>
    <tr><td>
    <table width=100% height="92" cellpadding=3 cellspacing=1>
    <tr>
      <td bgcolor=EEEEE8>
&nbsp;-= С��������ϵͳ2.4 =-<br>
&nbsp;�����д��С����<br>
&nbsp;��Ȩ���У�С���ܹ�����<br>
&nbsp;��վ��ַ��<a href="http://www.lfbear.cn" target="_blank">Www.LFBear.cN</a></td>
    </tr></table>
    </td></tr></table>
    </td></tr></table>
    </td><td width=70% valign=top bgcolor=#FFFFFF>
    <table width=100% cellpadding=6 cellspacing=0 border=0>
EOT;
}
///////////////��д����/////////////////
function readfrom($file_name) {
	$filenum=@fopen($file_name,"r");
	@flock($filenum,LOCK_SH);
	$file_data=@fread($filenum,filesize($file_name));
	@fclose($filenum);
	return $file_data;
}
function writeto($file_name,$infoata,$method="w") {
	$filenum=@fopen($file_name,$method);
	flock($filenum,LOCK_EX);
	$file_data=fwrite($filenum,$infoata);
	fclose($filenum);
	return $file_data;
}
//////////////////////////////////////////

////////////������һ�������ļ�///////////
function get_next_filename($list) {
  $list=explode("\n",$list,11);
  $count=min(count($list),11);
  $filecount=0;
  for ($i=0; $i<$count; $i++) {
    $temp=explode("|",$list[$i]);
    $thiscount=$temp[2];   
    if ($thiscount>$filecount) $filecount=$thiscount;
  }
  $filecount++;
  while (file_exists("../data/data/$filecount.php")) $filecount++;
  return("$filecount");
}
/////////////////���Σ���ַ�/////////
function kick_out($info) {
  $info = str_replace("\t","",$info);
  $info = str_replace("<","&lt;",$info);
  $info = str_replace(">","&gt;",$info);
  $info = str_replace("\r","<br>",$info);
  $info = str_replace("\n","",$info);
  $info = str_replace("|","��",$info);
  $info = str_replace("  "," &nbsp;",$info);
  return $info;
}
function get_classid($classid) {
global $class_name,$class_time,$ckeckid;
$list=file("../data/class.php");
$ckeckid=0;
	$count=count($list);
	for ($i=0; $i<$count; $i++) {
		$detail=explode("|", trim($list[$i]));
		if ($detail[0]==$classid) {
			$class_name=$detail[1];
			$class_time=$detail[2];
			$ckeckid=1;
			break;
		}
	}
}
function get_nclassid($classid,$nclassid) {
global $nclass_name,$nclass_time,$nckeckid;
$list=file("../data/nclass.php");
$nckeckid=0;
	$count=count($list);
	for ($i=0; $i<$count; $i++) {
		$detail=explode("|", trim($list[$i]));
		if ($detail[1]==$nclassid && $detail[0]==$classid) {
			$nclass_name=$detail[2];
			$nclass_time=$detail[3]; 
			$nckeckid=1;
			break;
		}
	}
}

/////////////��֤��ͼ������/////////////////////////////
function getimg($codec) { 
//global $fixmozillabug, $is_mozilla;
$part[0]=substr($codec,0,1); 
$part[1]=substr($codec,1,1); 
$part[2]=substr($codec,2,1); 
$part[3]=substr($codec,3,1); 
$plus=date("n", time())*date("d",time())+date("Y",time());
//if ($fixmozillabug==1 && $is_mozilla==0) {
//	$csscom="background-image: url(../images/code/bg.gif); backgound-position: top; border:1px #B2B2B2 solid;";} 
$out="<span style=\"width: 50px; height: 15px;  {$csscom}\">";
for ($i=0; $i<4;$i++) {
	$cnow=$part[$i];
	$out.="<img src=\"code.php?n=".strval($plus+$cnow).chr(rand(65,90))."\" title=\"\" />";
}
$out.="</span>";
return $out;
}
///////////////���±�����//////////////////
$tab_top="<table width=100% align=center cellspacing=0 cellpadding=0 bgcolor=333333>
	    <tr><td>
	    <table width=100% cellspacing=1 cellpadding=3>
	    <tr><td bgcolor=EEEEE8>
	<font face=verdana>";
$tab_bottom="</font>
	</td></tr></table>
	</td></tr></table>";
?>