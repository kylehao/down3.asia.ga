<?
session_start();
$thisprog="addclass.php";
require("global.php");
$classfile="../data/class.php";
$nclassfile="../data/nclass.php";
if ($_SESSION["login_status"]=="yes"){
print "<tr><td bgcolor=#ADADAD colspan=3><font color=#ffffff>
    <b>��ӭ����������ʽ / ��Ŀ�������</b>
    </td></tr>
";

if (file_exists($classfile)) {
	$classdata=file($classfile);
	$count=count($classdata);
}
if (file_exists($nclassfile)) {
	$nclassdata=file($nclassfile);
	$ncount=count($nclassdata);
}
if (empty($action)) {
	$classselect="";
	$list=file("../data/class.php");
$count=count($list)-1;
for ($i=0; $i<=$count; $i++) {
	$list_info=explode("|",$list[$i]);
	$classselect.=" <option value=\"$list_info[0]\">$list_info[1]</option>";
}

	$classselect.="</select>"; 
	unset($list_info);
	$nclassselect="";
	$list=file("../data/nclass.php");
$count=count($list)-1;
for ($i=0; $i<=$count; $i++) {
	$list_info=explode("|",$list[$i]);
	$nclassselect.=" <option value=\"$list_info[1]\">$list_info[2]</option>";
}
	
	$nclassselect.="</select>"; 
	print <<<EOT
    <tr><td bgcolor=#ffffff colspan=3>
    <b>1.�ܷ��������</b>
    <form action="$thisprog" method=POST><input type=hidden name="action" value="newitem">
    $tab_top
    ���ܷ��ࣺ   
    <input type=text name="name" size=20>
    <input type=submit value="�� ��">
    $tab_bottom</form>
	 <form action="$thisprog" method=POST><input type=hidden name="action" value="edititem">
    $tab_top
    ���ܷ�������<select name="item">$classselect  ����Ϊ
    <input type=text name="name" size=20>
    <input type=submit value="�� ��">
    $tab_bottom</form>
		<form action="$thisprog" method=POST><input type=hidden name="action" value="delitem">
    $tab_top
    ɾ���ܷ��ࡡ<select name="item">$classselect  
		&nbsp;&nbsp;<font color="red">[�˲�������ɾ�������µ���������]</font>
    &nbsp;&nbsp;<input type=submit value="ɾ����">
    $tab_bottom</form>
	 <form action="$thisprog" method=POST><input type=hidden name="action" value="modifyorder">
    $tab_top
    �ܷ���˳���޸İѡ�<select name="item">$classselect  �ŵ���<select name="item2">$classselect
    ����
    <input type=submit value="�ޡ���">
    $tab_bottom</form>
    <b>2.�ӷ��������</b>
   <form action="$thisprog" method=POST><input type=hidden name="action" value="newitemn">
    $tab_top
    ���ӷ��ࣺ   
    <input type=text name="name" size=20> �� <select name="item">$classselect 
    <input type=submit value="�� ��">
    $tab_bottom</form>
	 <form action="$thisprog" method=POST><input type=hidden name="action" value="edititemn">
    $tab_top
    ���ӷ�������<select name="itemn">$nclassselect  ����Ϊ
    <input type=text name="name" size=20>
    <input type=submit value="�� ��">
    $tab_bottom</form>
	 
		<form action="$thisprog" method=POST><input type=hidden name="action" value="modifyordern">
    $tab_top
    �ӷ���˳���޸İѡ�<select name="itemn">$nclassselect  �ŵ���<select name="itemn2">$nclassselect
    ����
    <input type=submit value="�ޡ���">
    $tab_bottom</form>
		<form action="$thisprog" method=POST><input type=hidden name="action" value="delitemn">
    $tab_top
    ɾ���ӷ��ࡡ<select name="itemn">$nclassselect  
	<br><input type=radio  name="job" value="del">��ɾ������<font color="red">[���ȰѴ˷���������ת��]</font>&nbsp;&nbsp;&nbsp;<input checked type=radio  name="job" value="delall">ɾ�����༰�˷�����������&nbsp;&nbsp;<font color="red">[��������϶࣬�����ԼӵȺ�]</font><br>
    <input type=submit value="ɾ����">$tab_bottom</form>
    <b>3.����ת��</b><form action="$thisprog" method=POST><input type=hidden name="action" value="moditem">
    $tab_top
    
   �ѣ�<select name="itemn">$nclassselect �µ�������ת�Ƶ���<select name="itemn2">$nclassselect  �� &nbsp;&nbsp;<font color="red">[��������϶࣬�����ԼӵȺ�]</font><br><input type=submit value="�� ��">
    $tab_bottom</form>
    </td></tr></td></tr></table></body></html>
EOT;
exit;
}elseif ($action=="newitem") {
unset($temp);
	$newstring="";
	print "<tr><td bgcolor=#ADADAD valign=middle align=center colspan=2><b>�½��ܷ���</b></td></tr>
	<tr><td bgcolor=ffffff colspan=2>";
		 $name=str_replace("|","",$name); $name=stripslashes($name); 
		$max=0;
		for ($i=0; $i<$count; $i++) {
			$temp=explode("|",$classdata[$i]);
			$max=max($max,$temp[0]);
		}
		$id=$max+1;		
		$newstring="$id|$name|$timestamp\n";
        
	$fp=fopen($classfile,"a");
	if (fwrite($fp,$newstring)) echo "<br><br>�ɹ���������<b></b><br>";
		else echo "<br><br>��̳�б�����ʧ�ܣ�����dataĿ¼��classdata.php֮����<b></b><br>";
	fclose($fp);
}elseif ($action=="edititem") {
unset($temp);
	print "<tr><td bgcolor=#ADADAD valign=middle align=center colspan=2><b>�޸��ܷ���</b></td></tr>
	<tr><td bgcolor=ffffff colspan=2>";

			
		for ($i=0; $i<$count; $i++) {
			$temp=explode("|",$classdata[$i]);
			if($temp[0]==$item){ 
		  $temp[1]=$name;
          $classdata[$i]="$item|$name|$timestamp\n";
		  break;}
			
		}
		$newstring=implode("",$classdata);
	writeto($classfile,$newstring);				        
	
	 echo "<br><br>�ɹ���������<b></b><br>";
}elseif ($action=="delitem") {
unset($temp);
	print "<tr><td bgcolor=#ADADAD valign=middle align=center colspan=2><b>ɾ���޸��ܷ���</b></td></tr>
	<tr><td bgcolor=ffffff colspan=2>";

	
		
		for ($i=0; $i<$count; $i++) {
			$temp=explode("|",$classdata[$i]);
			if($temp[0]==$item){ 		 
         unset($classdata[$i]);
		  break;}			
		}
		$newstring=implode("",$classdata);
	writeto($classfile,$newstring);				        
	unset($temp);
	for ($i=0; $i<$ncount; $i++) {
			$temp=explode("|",$nclassdata[$i]);
			if($temp[0]==$item)  unset($nclassdata[$i]);	
			
		}
		$newstring=implode("",$nclassdata);
	writeto($nclassfile,$newstring);			
	 echo "<br><br>�ɹ���������<b></b><br>";
 
		
}elseif ($action=="newitemn") {
unset($temp);
	$newstring="";
	print "<tr><td bgcolor=#ADADAD valign=middle align=center colspan=2><b>�½��ӷ���</b></td></tr>
	<tr><td bgcolor=ffffff colspan=2>";
		 $name=str_replace("|","",$name); $name=stripslashes($name); 
		$max=0;
		for ($i=0; $i<$ncount; $i++) {
			$temp=explode("|",$nclassdata[$i]);
			$max=max($max,$temp[1]);
		}
		$id=$max+1;		
		$newstring="$item|$id|$name|$timestamp\n";
        
	$fp=fopen($nclassfile,"a");
	if (fwrite($fp,$newstring)) echo "<br><br>�ɹ���������<b></b><br>";
		else echo "<br><br>����ʧ�ܣ�����dataĿ¼��classdata.php֮����<b></b><br>";
	fclose($fp);
}elseif ($action=="edititemn") {
unset($temp);
	$newstring="";
	print "<tr><td bgcolor=#ADADAD valign=middle align=center colspan=2><b>�޸��ӷ���</b></td></tr>
	<tr><td bgcolor=ffffff colspan=2>";
		 $name=str_replace("|","",$name); $name=stripslashes($name); 
	
		for ($i=0; $i<$ncount; $i++) {
			$temp=explode("|",$nclassdata[$i]);
			if($temp[1]==$itemn){ 
		  $temp[2]=$name;
          $nclassdata[$i]="$temp[0]|$itemn|$name|$timestamp\n";
		  break;}
			
		}
		$newstring=implode("",$nclassdata);
	writeto($nclassfile,$newstring);			
 echo "<br><br>�ɹ���������<b></b><br>";
}elseif ($action=="delitemn") {
unset($temp);
	$newstring="";
	print "<tr><td bgcolor=#ADADAD valign=middle align=center colspan=2><b>ɾ���ӷ���</b></td></tr>
	<tr><td bgcolor=ffffff colspan=2>";
	if($job=='delall'){
	if (file_exists("../data/hots.php")) {
	$hotsdata=file("../data/hots.php");
	$hotcount=count($hotsdata);
for ($i=0; $i<$hotcount; $i++) {
			$temp=explode("|",$hotsdata[$i]);
			if($temp[1]==$itemn)unset($hotsdata[$i]);	
			}

      $newstring=implode("",$hotsdata);
	writeto("../data/hots.php",$newstring);

}	 
	unset($temp);
	if (file_exists("../data/usrtool.php")) {
	$usrtooldata=file("../data/usrtool.php");
	$hotcount=count($usrtooldata);
for ($i=0; $i<$hotcount; $i++) {
			$temp=explode("|",$usrtooldata[$i]);
			if($temp[1]==$itemn) unset($usrtooldata[$i]);
			}
      $newstring=implode("",$usrtooldata);
	writeto("../data/usrtool.php",$newstring);


}	 
	unset($temp);

$list_temp=explode("\n",readfrom("../data/list.php"));

$count=count($list_temp);

for ($i=0; $i<$count; $i++) {

	$list_info=explode("|",$list_temp[$i]);

	if ($list_info[1]==$itemn){
		if (file_exists("../data/data/$list_info[2].php")) unlink("../data/data/$list_info[2].php");
		unset($list_temp[$i]);
	}
	}
writeto("../data/list.php",implode("\n",$list_temp));	

}
unset($temp);
		for ($i=0; $i<$ncount; $i++) {
			$temp=explode("|",$nclassdata[$i]);
			if($temp[1]==$itemn){ 		 
         unset($nclassdata[$i]);
		  break;}			
		}
		$newstring=implode("",$nclassdata);
	writeto($nclassfile,$newstring);				        
	echo "<br><br>�ɹ���������<b></b><br>";
}elseif ($action=="modifyorder") {
unset($temp);
	$newstring="";
	print "<tr><td bgcolor=#ADADAD valign=middle align=center colspan=2><b>�޸ķ���˳��</b></td></tr>
	<tr><td bgcolor=ffffff colspan=2>";
		 
	
		for ($i=0; $i<$count; $i++) {
			$temp=explode("|",$classdata[$i]);
			if($temp[0] != $item) $newstring.=$classdata[$i];
		  if($temp[0] == $item2){
			  for ($j=0; $j<$count; $j++) {
	       $temp2=explode("|",$classdata[$j]);
	       if ($temp2[0]==$item) $newstring.=$classdata[$j];
	    }
          }
		}
		
	writeto($classfile,$newstring);			
 echo "<br><br>�ɹ���������<b></b><br>";
}elseif ($action=="modifyordern") {
unset($temp);
	$newstring="";
	print "<tr><td bgcolor=#ADADAD valign=middle align=center colspan=2><b>�޸ķ���˳��</b></td></tr>
	<tr><td bgcolor=ffffff colspan=2>";
		 
	
		for ($i=0; $i<$ncount; $i++) {
			$temp=explode("|",$nclassdata[$i]);
			if($temp[1] != $itemn) $newstring.=$nclassdata[$i];
		  if($temp[1] == $itemn2){
			  for ($j=0; $j<$ncount; $j++) {
	       $temp2=explode("|",$nclassdata[$j]);
	       if ($temp2[1]==$itemn) $newstring.=$nclassdata[$j];
	    }
          }
		}
		
	writeto($nclassfile,$newstring);			
 echo "<br><br>�ɹ���������<b></b><br>";


}elseif ($action=="moditem") {
unset($temp);
	$newstring="";
	print "<tr><td bgcolor=#ADADAD valign=middle align=center colspan=2><b>����ת��</b></td></tr>
	<tr><td bgcolor=ffffff colspan=2>";
$list=file("../data/nclass.php");
	$count=count($list);
	for ($i=0; $i<$count; $i++) {
		$detail=explode("|", trim($list[$i]));
		if ($detail[1]==$itemn2 ) {$c_id=$detail[0];
			break;}
	}
	

	if($c_id){

	if (file_exists("../data/hots.php")) {
	$hotsdata=file("../data/hots.php");
	$hotcount=count($hotsdata);
for ($i=0; $i<$hotcount; $i++) {
			$temp=explode("|",$hotsdata[$i]);
			if($temp[1]==$itemn){$temp[0]=$c_id;$temp[1]=$itemn2;}
			$hotsdata[$i]=implode("|",$temp);
			}

      $newstring=implode("",$hotsdata);
	writeto("../data/hots.php",$newstring);

}	 
	unset($temp);
	if (file_exists("../data/usrtool.php")) {
	$usrtooldata=file("../data/usrtool.php");
	$hotcount=count($usrtooldata);
for ($i=0; $i<$hotcount; $i++) {
			$temp=explode("|",$usrtooldata[$i]);
			if($temp[1]==$itemn) {$temp[0]=$c_id;$temp[1]=$itemn2;}
			$usrtooldata[$i]=implode("|",$temp);
			}
      $newstring=implode("",$usrtooldata);
	writeto("../data/usrtool.php",$newstring);


}	 
	$list_temp=explode("\n",readfrom("../data/list.php"));

$count=count($list_temp);

for ($i=0; $i<$count; $i++) {

	$list_info=explode("|",$list_temp[$i]);

	if ($list_info[1]==$itemn){

		if (file_exists("../data/data/$list_info[2].php")) { 
$a_info=@file("../data/data/$list_info[2].php");  $tempabc=explode("|",$a_info[1]);
      
		$tempabc[0]=$c_id;
		$tempabc[1]=$itemn2;
		$a_info[1]=implode("|",$tempabc);
		$line_cc=implode("",$a_info);
		writeto("../data/data/$list_info[2].php",$line_cc);
		}

		$list_info[1]=$itemn2;
		$list_info[0]=$c_id;

		$list_temp[$i]=implode("|",$list_info);
	}
	}
	writeto("../data/list.php",implode("\n",$list_temp));	
 echo "<br><br>�ɹ���������<b></b><br>";
	}else {echo"<br><br>�д���<b></b><br>";}

}
print "<br><b>&nbsp;�������</b><br><br>&nbsp;&gt;&gt; <a href=$thisprog>����ִ����������</a></td></tr></table></body></html>";
exit;
}
elseif ($_SESSION["login_status"]=="ok"){
print <<<EOT
<tr>
  <td bgcolor=#ADADAD><font color=#ffffff>
<b>��ӭ���� С��������ϵͳ2.4 ��̨����ϵͳ</b>&nbsp;&nbsp;&nbsp;&nbsp;[<font color=red>�Բ���ֻ�ó�������Ա���ܹ����ⲿ�֡�</font>]</td>
EOT;
exit;
}
else
{
print <<<EOT
<tr>
  <td bgcolor=#ADADAD><font color=#ffffff>
<b>��ӭ���� С��������ϵͳ2.4 ��̨����ϵͳ</b>&nbsp;&nbsp;&nbsp;&nbsp;[��û�е�½���������<a href='login.php'>����</a>���е�½��]</td>

EOT;
exit;
}
?>
