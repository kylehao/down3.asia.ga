<?
/*
$timestamp=time();
$cookietime = $timestamp+3153600;
if ($REQUEST_URI == $HTTP_COOKIE_VARS['lastpath'] && ($timestamp-$HTTP_COOKIE_VARS['lastvisit_fr']<3)) {
die('������ʾ��ֹ��ԭ�򣺷���ͬһURL��ˢ��ʱ��С��3��');
	}
setCookie('lastpath', $REQUEST_URI, $cookietime);
	setCookie('lastvisit_fr', $timestamp, $cookietime);
*/

/////////////////���Ƿ��ַ�����////////////////
function kick_out($info) {
  $info = str_replace("\t","",$info);
  $info = str_replace("<","&lt;",$info);
  $info = str_replace(">","&gt;",$info);
  $info = str_replace("\r","<br>",$info);
  $info = str_replace("\n","",$info);
  $info = str_replace("|","��",$info);
  $info = str_replace("  "," &nbsp;",$info);
  return $info;
}

function get_classid() {
global $class_name,$classid,$class_time,$ckeckid;
$list=file("data/class.php");
$ckeckid=0;
	$count=count($list);
	for ($i=0; $i<$count; $i++) {
		$detail=explode("|", trim($list[$i]));
		if ($detail[0]==$classid) {
			$class_name=$detail[1];
			$class_time=$detail[2];
			$ckeckid=1;
			break;
		}
	}
}
function get_nclassid() {
global $nclass_name,$classid,$nclassid,$nclass_time,$nckeckid;
$list=file("data/nclass.php");
$nckeckid=0;
	$count=count($list);
	for ($i=0; $i<$count; $i++) {
		$detail=explode("|", trim($list[$i]));
		if ($detail[1]==$nclassid && $detail[0]==$classid) {
			$nclass_name=$detail[2];
			$nclass_time=$detail[3]; 
			$nckeckid=1;
			break;
		}
	}
}

///////////////��д����////////////////////



function readfrom($file_name) {
	$filenum=@fopen($file_name,"r");
	@flock($filenum,LOCK_SH);
	$file_data=@fread($filenum,filesize($file_name));
	@fclose($filenum);
	return $file_data;
}
function writeto($file_name,$infoata,$method="w") {
	$filenum=@fopen($file_name,$method);
	flock($filenum,LOCK_EX);
	$file_data=fwrite($filenum,$infoata);
	fclose($filenum);
	return $file_data;
}

//////////////////////////////////////////
@extract($_SERVER, EXTR_SKIP); 
@extract($_SESSION, EXTR_SKIP); 
@extract($_POST, EXTR_SKIP); 
@extract($_FILES, EXTR_SKIP); 
@extract($_GET, EXTR_SKIP); 
@extract($_ENV, EXTR_SKIP); 
//////////////////////////////////////////

/////////////���ڡ�ʱ�亯��//////////////


function get_time($infoatetime){
	$t=getdate($infoatetime);
	$hour=$t['hours'];
	$min=$t['minutes'];
	if (strlen($min)==1) $min="0".$min;
	return "{$hour}:{$min}";
}
function get_date($infoatetime){
	$t=getdate($infoatetime);
	$year=$t['year'];
	$mon=$t['mon'];
	$mday=$t['mday'];
	return "{$year}-{$mon}-{$mday}";
}
?>