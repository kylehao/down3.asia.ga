<?
require("fun.php");
require "header.php";
?>
<style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
</style>

<table width="680" border="0" cellspacing="4" cellpadding="0" align="center" height="20">
  <tr> 
    <td bgcolor="#E4E4E4"><span class="style1"><font color="#000000">����λ�ã�</font></span><a href=index.php><font color="#000000">��ҳ</font></a> <span class="style1"><font color="#000000">-></font></span> <span class="style1"><font color="#000000">��������</font></span></td>
  </tr>
</table>
<br>
<?
$classs="";
$list=file("data/class.php");
$count=count($list)-1;
for ($i=0; $i<=$count; $i++) {
	$classs.="<p>";
	$list_info=explode("|",$list[$i]);
	$classs.="<FONT face=Wingdings color=black>1</FONT> <a href=\"list.php?classid=$list_info[0]\">$list_info[1]</a><br><br>";
	$list1=file("data/nclass.php");
$list1=file("data/nclass.php");
$count1=count($list1)-1;
for ($i1=0; $i1<=$count1; $i1++) {
	$list_info1=explode("|",$list1[$i1]);
	if($list_info1[0]==$list_info[0])	$classs.="<a href=\"list.php?classid=$list_info[0]&nclassid=$list_info1[1]\">$list_info1[2]</a>������";

}
$classs.="</p>";
}
echo "
<table cellSpacing=0 cellPadding=0 width=590 border=0 align=center>
<tr>
<td style=\"line-height: 130%\" width=100%>
<p>
$classs
</p>

</td>
</tr>
</table>";
require "footer.php";?>