<?
if ($action=='save') setcookie("pef",$id,"100");
require("fun.php");
if (empty($page)) $page=1;
if ($page <1)  $page=1;
settype($page, integer);
$perpage=23;
if(empty($id)) { echo"�Բ��𣬴����������ڣ������ѱ�ɾ��������������ϵվ��";exit;}
if (!file_exists("data/data/$id.php")) { echo"�Բ��𣬴����������ڣ������ѱ�ɾ��������������ϵվ��";exit;}

if ($action=='save') {
	
if($pef==$id){
print <<<EOT
<script language=vbscript>
MsgBox "��ղ��Ѿ�Ͷ��Ʊ��"
location.href = "vote.php?id=$id"
</script>
EOT;
exit;
}
if(!$content){
print <<<EOT
<script language=vbscript>
MsgBox "���������������"
location.href = "vote.php?id=$id"
</script>
EOT;
exit;
}

$grade=kick_out($grade);
$content=kick_out($content);
$filecc=readfrom("data/data/$id.php");
$list=explode("\n",$filecc);
$counte=count($list);
$fsf=explode("|",$list[2]);
	$fsf[4]=$fsf[4]+$grade;
	$list[2]=implode("|",$fsf);
	$w=$list[0];
	$w1=$list[1];
	$w2=$list[2];
	unset($list[0]);
	unset($list[1]);
	unset($list[2]);

$line_ff="$grade|$content|\n";
$list= $w."\n".$w1."\n".$w2."\n".$line_ff.implode("\n",$list);
writeto("data/data/$id.php",$list);


}

$a_info=@file("data/data/$id.php");
list($viewnum,$downnum,$tviewnum,$tdownnum,$pinfeng,$viewtimes,$viewtimes1)=explode("|",$a_info[2]);

$count=count($a_info);
$num=$count-3;
$count=$count-3;
if($num) $pinfeng=floor($pinfeng/$num); else $pinfeng=0;
if($count>0){
	$list_soft='<table board=0 width=100% cellspacing="0" cellpadding="0" border="0" style="border-collapse: collapse" bordercolor="#111111">';
 if ($count%$perpage==0) $maxpageno=$count/$perpage;
		else $maxpageno=floor($count/$perpage)+1;
	if ($page>$maxpageno) $page=$maxpageno;
	$pagemin=min( ($page-1)*$perpage , $count-1);
	$pagemax=min( $pagemin+$perpage-1, $count-1);
	for ($i=$pagemin+3; $i<=$pagemax+3; $i++) {
	$detail=explode("|",$a_info[$i]);
	$list_soft.="<tr><td width=90%><font color=\"#FF0000\">��</font><font color=\"green\"> </font>$detail[1]&nbsp;&nbsp;[��֣�$detail[0]]</td></tr>";
	}
$list_soft.="</table>";
	}else
	$list_soft="��ʱû������";


if ($maxpageno<=1) $pageinfo= "<p align='center'>&nbsp;<b>ֻ��һҳ</b>";
else { 
      $nextpage=$page+1;
      $previouspage=$page-1;
	  $pageinfo="<form method=Post action=vote.php?id=$id><p align='center'>&nbsp;";
	  if ($page<=1) $pageinfo.="	  ��ҳ����һҳ��<a href=vote.php?id=$id&page=$nextpage>��һҳ</a>��<a href=vote.php?id=$id&page=$maxpageno>βҳ</a>��";
	  elseif($page>=$maxpageno) $pageinfo.="	  <a href=vote.php?id=$id&page=1>��ҳ</a>��<a href=vote.php?id=$id&page= $previouspage>��һҳ</a>����һҳ��βҳ��";
	 
	  else $pageinfo.="	  <a href=vote.php?id=$id&page=1>��ҳ</a>��<a href=vote.php?id=$id&page= $previouspage>��һҳ</a>��<a href=vote.php?id=$id&page=$nextpage>��һҳ</a>��<a href=vote.php?id=$id&page=$maxpageno>βҳ</a>��";
	  $pageinfo.="ҳ�Σ�<strong><font color=red>$page</font>/$maxpageno</strong>ҳ  <b>10</b>������/ҳ��ת����<select name='page' size='1' style=\"border: 1px solid #429234; background-color: #FAFDF9\" onChange='javascript:submit()'>";
	for ($j=1; $j<=$maxpageno; $j++) {$pageinfo.="<option value='".$j."'>��".$j."ҳ</option>";
	}
$pageinfo.="</select></form>";
}
?>
<html>
<head>
<meta HTTP-EQUIV="Content-Type" content="text/html; charset=gb2312">
<link href="images/download.css" rel=stylesheet>
<title>�������������</title>
<style type="text/css">
<!--
.style1 {
	color: #FFFFFF;
	font-weight: bold;
	font-size: 12px;
}
.style2 {
	color: #FFFFFF;
	font-size: 12px;
}
.style4 {font-size: 12px}
-->
</style>
</head>
<noframes><body leftMargin=5 topMargin=5 marginheight="0" marginwidth="0" link="#000000" vlink="#000000" alink="#000000"></noframes>
<table border="1" width="500" cellspacing="0" cellpadding="2" style="border-collapse: collapse" bordercolor="#2B77BD" align=center>
<tr>  
<td height=28 align=center bgcolor="#E4E4E4"><span class="style1"> <font color="#000000">�������������</font> </span></td>
</tr>
<tr>  
<td height="28" align=center bgcolor="#FFFFFF"><span class="style4"> Ŀǰ���������� <font color=#FF0000>
  <?=$num?>
</font> �˴�֣��ۺ�����Ϊ��<font color=#FF0000>
<?=$pinfeng?>
</font>
</span></td>
</tr>
<tr>
<form method=post action="vote.php"><td height="28" align=center bgcolor="#FFFFFF">
  <span class="style4">
  <input type="hidden" name="action" value="save">
  <input name=grade type=radio value=1>
1��
<input name=grade type=radio value=2>
2��
<input name=grade type=radio checked value=3>
3��
<input name=grade type=radio value=4 >
4��
<input name=grade type=radio value=5>
5
<input name=id type=hidden value="<?=$id?>">
  <br>
���ۣ�
<input name=content type=text size="30" class="smallinput" maxlength="100"> 
<input type=submit value="����" name="cmdok" class="buttonface">
  </span></td>
</form>
</tr>
<tr>  
<td height=28 align=center bgcolor="#E4E4E4"><b><span class="style2"><font color="#000000">�Ѿ�����������</font></span> </b></td>
</tr>
<tr>  
<td height="28" align=center bgcolor="#FFFFFF" class="style4"> 


<?=$list_soft?>
<?=$pageinfo?>

</td>
</tr>
</table>
<p align="center" class="style4"><a href="javascript:history.go(-1)"><font color="#000000">�� ��</font></a> | <a href="javascript:this.location.reload()"><font color="#000000">ˢ ��</font></a></p>
</body>
</html>

