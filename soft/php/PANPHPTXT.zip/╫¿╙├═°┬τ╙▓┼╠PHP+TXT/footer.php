<?php
//  ___  ____       _  ______ _ _        _   _           _   
//  |  \/  (_)     (_) |  ___(_) |      | | | |         | |  
//  | .  . |_ _ __  _  | |_   _| | ___  | |_| | ___  ___| |_ 
//  | |\/| | | '_ \| | |  _| | | |/ _ \ |  _  |/ _ \/ __| __|
//  | |  | | | | | | | | |   | | |  __/ | | | | (_) \__ \ |_ 
//  \_|  |_/_|_| |_|_| \_|   |_|_|\___| \_| |_/\___/|___/\__|
//
// by dvzx.com
////////////////////////////////////////////////////////
?>
<center><a class="toplinks" target=_blank href="http://www.dhtsky.com">Htsky.Com</a> - 
<a class="toplinks" target=_blank href="http://Free-Domain.Org.Ru">Free-Domain.Org.Ru</a> - 
<a class="toplinks" target=_blank href="http://0517.org">MY BLOG</a> - 
<a class="toplinks" target=_blank href="http://IEproxy.Net.Ru">IEproxy.Net.Ru</a></center>
<p><center><font color="white" face="Verdana" size="1">Copyright @ 2008 - <? echo $compname;?>. All Rights Reserved</font></b></p><center>  </center>

<? 
// Please Do Not Remove The Below Code 
// (If You Want To Remove It Please Donate And You Will Be Allowed To Do So)
include("./copyright.php"); ?>