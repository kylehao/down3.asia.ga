<?php
//  ___  ____       _  ______ _ _        _   _           _   
//  |  \/  (_)     (_) |  ___(_) |      | | | |         | |  
//  | .  . |_ _ __  _  | |_   _| | ___  | |_| | ___  ___| |_ 
//  | |\/| | | '_ \| | |  _| | | |/ _ \ |  _  |/ _ \/ __| __|
//  | |  | | | | | | | | |   | | |  __/ | | | | (_) \__ \ |_ 
//  \_|  |_/_|_| |_|_| \_|   |_|_|\___| \_| |_/\___/|___/\__|
//
// by dvzx.com
//////////////////////////////////////////////////////// 
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><? echo $compname . " - " . $slogan ;;?></title>
<style type="text/css">
body{
	margin:0px;
	font-family: Arial, sans-serif;
	font-size: 14px;
	height:100%;
	background: url(background.gif) repeat-x;
	background-color: #12519F;
	text-align: left;
}

p{
	text-align: left;
}


a{
	text-decoration: none;
	/* color:#12519F; */
	color:#0000AC;
}

a:hover{
	text-decoration: underline;
}

a:visited{
color:#0000AC;
}


a.headlink{
}

a.headlink:hover{
	text-decoration: none;
}

h1{
	font-size: 18px;
	text-align: left;
}

h2{
	text-align: justify;
	margin-top:15px;
	font-size:10px;
}

img{
	border:0px;
}


.steps{
	font-size:14px;
	margin-top:9px;
	margin-bottom:5px;
	font-weight:bold;
}

.cstep{
	font-size:14px;
}

.notice{
text-align: justify;
margin-top:15px;
font-size:11px;
}

.copyright{
font-size:11px;
color:#ffffff;
text-align:center;
margin-top:8px;
font-weight:bold;
}

.toplinks{
font-size:12px;
color:#ffffff;
font-weight:bold;
}


.toplinks:visited{
	color:#FFFFFF;
}

.extralink{
font-size:11px;
color:#ffffff;
font-weight:plain;
}


.extralink:visited{
	color:#FFFFFF;
}


.upinput{
width:420px;
background:url(input_back.gif);
border:1px solid #999999;
/*
margin-bottom:5px;
margin-top:5px;
*/	
}




input {
	background:url(input_back.gif);
	border:1px solid #999999;
}

textarea{
	background:url(input_back.gif) repeat-x;
	border:1px solid #999999;
}

form{
margin:0px;
}

.faqheader{
font-size:15px;
font-weight:bold;
margin-bottom:0px;
}

.faqbody{
font-size:13px;
margin-top:0px;
margin-bottom:15px;
text-align:justify;
}
</style>
<noscript>
<body>
</noscript>
<center><table style="margin-top:20px;width:790px;height:2;">
<tr><td style="padding-bottom:10px;" height="1">
<a class="headlink" href="index.php">
<p style="margin:0px;"><span style="font-size:32px;color:#FFFFFF;">Snowy</span><span 

style="font-size:22px;color:#FBB700">.Msk.Ru</span></p></a></td>
  <td align=right valign=bottom 

style="padding-bottom:10px;color:#ffffff" height="1"><a class="toplinks" href="index.php">Upload</a> 

 &nbsp;|&nbsp; <a class="toplinks" href="files.php">Files</a> 

&nbsp;|&nbsp; <a class="toplinks" href="index.php?page=tos">T.O.S</a> &nbsp;|&nbsp; <a class="toplinks"  

href="index.php?page=faq">F.A.Q</a>&nbsp;|&nbsp; <a class="toplinks" href="top.php">Top 10</a> &nbsp;|&nbsp; <a class="toplinks"  

href="admin.php">Admin</a></td></td></tr></center></head>