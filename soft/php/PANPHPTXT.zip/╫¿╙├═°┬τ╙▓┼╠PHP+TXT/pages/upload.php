<?php
//  ___  ____       _  ______ _ _        _   _           _   
//  |  \/  (_)     (_) |  ___(_) |      | | | |         | |  
//  | .  . |_ _ __  _  | |_   _| | ___  | |_| | ___  ___| |_ 
//  | |\/| | | '_ \| | |  _| | | |/ _ \ |  _  |/ _ \/ __| __|
//  | |  | | | | | | | | |   | | |  __/ | | | | (_) \__ \ |_ 
//  \_|  |_/_|_| |_|_| \_|   |_|_|\___| \_| |_/\___/|___/\__|
//
// by dvzx.com
//////////////////////////////////////////////////////// ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<META NAME="revisit-after" CONTENT="2 days">
<link rel="SHORTCUT ICON" href="favicon.ico">
</head><noscript>
<body>
</noscript>
<tr><td colspan=2 style="border:1px #AAAAAA solid;height:100%;background-color:#FFFFFF;padding:20px;text-align:left;" valign=top>
  	<? include("./ads.php"); ?>
<p><center>Snowy.Msk.Ru File Host is a free file hosting service. Feel free to upload your files here!. Just Browse The File And Click Upload And You Will Recieve A Download Link.</center></p>

<h1><center>Upload</center></h1>
	<br />
	<center>
	<form enctype="multipart/form-data" action="upload.php" id="form" method="post" onsubmit="a=document.getElementById('form').style;a.display='none';b=document.getElementById('part2').style;b.display='inline';" style="display: inline;">
	<strong>maximum filesize:</strong> <?php echo $maxfilesize; ?> MB<br />
	<?php echo $filetypes; ?>
	<input type="file" name="upfile" size="50" /><br />
	<?php if($emailoption) { ?>Email Address: <input type="text" name="myemail" size="30" /> <i>(Optional)</i><br /><?php } ?>
	<?php if($descriptionoption) { ?>File Description: <input type="text" name="descr" size="30" /> <i>(Optional)</i><br /><?php } ?>
	<?php if($passwordoption) { ?>Password Protection: <input type="text" name="pprotect" size="30" /> <i>(Optional)</i><br /><?php } ?>
	<?php if(isset($categorylist)) { echo $categorylist; } ?>
	By uploading your file, you agree to our <a href="?page=tos">terms of service</a>. <p><center><input type="submit" value="Upload!" id="upload" /></center>
	</form><div id="part2" style="display: none;">
<script language="javascript" src="xp_progress.js"></script>
Upload in progress. Please Wait... 
<BR><BR>
<script type="text/javascript">
var bar1= createBar(300,15,'white',1,'black','blue',85,7,3,"");
</script>
</div>	<br />Currently hosting <b><?php echo $total; ?></b> files. <b><?php echo $sizehosted; ?></b> MB Total!
<p>	<? include("./bottomads.php"); ?>
</center></td></tr></table><p style="margin:3px;text-align:center">