<?php
//  ___  ____       _  ______ _ _        _   _           _   
//  |  \/  (_)     (_) |  ___(_) |      | | | |         | |  
//  | .  . |_ _ __  _  | |_   _| | ___  | |_| | ___  ___| |_ 
//  | |\/| | | '_ \| | |  _| | | |/ _ \ |  _  |/ _ \/ __| __|
//  | |  | | | | | | | | |   | | |  __/ | | | | (_) \__ \ |_ 
//  \_|  |_/_|_| |_|_| \_|   |_|_|\___| \_| |_/\___/|___/\__|
//
// by dvzx.com
//////////////////////////////////////////////////////// ?>
<center><table style="margin-top:20px;width:790px;height:400px;"><tr><td style="border:1px #AAAAAA solid;height:100%;background-color:#FFFFFF;padding:20px;text-align:left;" valign=top>
 <h1>Terms of Service</h1>
	<p>You may not upload any files that infringe copyrights.</p>
	<p>You may not upload any files that are considered illegal in your country.</p>
	<p>You are responsible for the files you upload.</p>
	<p>The owner of this site reserves the right to delete any files hosted here for any reason.</p>
</center></td></tr></table><p style="margin:3px;text-align:center">