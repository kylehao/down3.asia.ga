<?php
//  ___  ____       _  ______ _ _        _   _           _   
//  |  \/  (_)     (_) |  ___(_) |      | | | |         | |  
//  | .  . |_ _ __  _  | |_   _| | ___  | |_| | ___  ___| |_ 
//  | |\/| | | '_ \| | |  _| | | |/ _ \ |  _  |/ _ \/ __| __|
//  | |  | | | | | | | | |   | | |  __/ | | | | (_) \__ \ |_ 
//  \_|  |_/_|_| |_|_| \_|   |_|_|\___| \_| |_/\___/|___/\__|
//
// by dvzx.com
//////////////////////////////////////////////////////// ?>

<? 
// Please Do Not Remove or Change The Below Code 
// (If You Want To Remove It Please Donate And You Will Be Allowed To Do So)
?>
<p><span style="color:white"><font face="Verdana" size="1"><center>Powered By <b>DVZX Free File Host</b> V1.1. <font color="#FFFFFF">
</font></font><p>