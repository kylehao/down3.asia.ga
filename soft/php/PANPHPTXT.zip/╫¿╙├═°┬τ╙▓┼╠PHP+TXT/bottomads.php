<!-- Search Google -->
<center>
<form method="get" action="http://www.google.cn/search" target="google_window">
<table bgcolor="#ffffff">
<tr><td nowrap="nowrap" valign="top" align="left">
<table bgcolor="#ffffff">
<tr><td nowrap="nowrap" valign="top" align="left" height="32">
<a href="http://www.google.com/">
<img src="http://www.google.com/logos/Logo_25wht.gif" border="0" alt="Google" align="middle"></img></a>
<label for="sbi" style="display: none">�������������ִ�</label>
<input type="text" name="q" size="31" maxlength="255" value="" id="sbi"></input>
<label for="sbb" style="display: none">�ύ��������</label>
<input type="submit" name="sa" value="����" id="sbb"></input>
<input type="hidden" name="client" value="pub-8742386847853865"></input>
<input type="hidden" name="forid" value="1"></input>
<input type="hidden" name="prog" value="aff"></input>
<input type="hidden" name="ie" value="GB2312"></input>
<input type="hidden" name="oe" value="GB2312"></input>
<input type="hidden" name="hl" value="zh-CN"></input>
</td></tr></table>
</td><td nowrap="nowrap" valign="top" align="left">
<script type="text/javascript"><!--
  google_ad_client = "pub-8742386847853865";
  google_ad_format = "200x30_sdo";
  google_link_target = 2;
  google_color_bg = "ffffff";
  google_color_link = "000000";
  google_encoding = "GB2312";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</td></tr></table>
</form>
</center>
<!-- Search Google -->
