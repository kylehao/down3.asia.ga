<?php return array (
  'password' => '123456',
  'host' => 'http://www.google.com/',
  'replaceDomain' => '0',
  'relativeHTML' => '0',
  'relativeCSS' => '0',
  'static' => '0',
  'diyStatic' => 'css|js|html|png|jpg',
  'cookies' => '0',
  'agent' => '0',
  'referer' => '0',
  'ip' => '0',
  'diyAgent' => '',
  'replaces' => 
  array (
  ),
  'pages' => 
  array (
  ),
);