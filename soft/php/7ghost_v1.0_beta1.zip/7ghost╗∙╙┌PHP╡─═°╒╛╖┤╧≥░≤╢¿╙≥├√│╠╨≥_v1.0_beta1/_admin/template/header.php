<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>7ghost������̨</title>
<link rel="stylesheet" type="text/css" href="./static/core.css" />
<script language="javascript" type="text/javascript" src="./static/jquery-1.5.1.min.js"></script> 
<script language="javascript" type="text/javascript" src="./static/admin.js"></script> 

</head>
<body>
<div class="doc">
	<div class="top">
		<div id='hd'>
			<h1>7ghost</h1>
			<div id='userinfo'>
				<ul><!--
					<li>
					<strong>
					admin
					</strong> |
					</li>
					<li>
					<a href="#">�˻�����</a> |
					</li>
					-->
					<li>
					<a href="./?m=index&a=logout">�˳�</a>
					</li>
				</ul>
			</div>
		</div>
		<div id="bar">
			<ul>
				<li>
					<strong>����</strong>
				</li>
			</ul>
		</div>
	</div>