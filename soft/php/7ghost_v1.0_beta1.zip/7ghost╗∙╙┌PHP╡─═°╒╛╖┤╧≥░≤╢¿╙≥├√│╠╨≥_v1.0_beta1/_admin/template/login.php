<form action="" method="post">
<table cellspacing="0">
<tbody>
<!--
<tr><th>�û���</th><td><input name="username" value="">
</td></tr>
-->
<tr><th>���룺</th><td><input type="password" name="password"><input type="submit" value="��¼">
</td></tr>
</tbody></table>
	<!--
<p><input type="submit" value="��¼">
</p><div></div>
-->
</form>