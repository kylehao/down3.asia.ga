<?php
error_reporting(E_ALL ^ E_NOTICE);

require_once('sheyee_com_inc/sheyee_com_settings.php');
printTopHTML();

if($settings['system'] == 2) {$settings['newline']="\r\n";}
elseif($settings['system'] == 3) {$settings['newline']="\r";}
else {$settings['newline']="\n";}

if(!(empty($_REQUEST['a']))) {
$a=$_REQUEST['a'];

		if ($a=="delete") {confirmDelete("$_REQUEST[num]","$_REQUEST[up]");}
        if ($a=="confirmdelete") {doDelete("$_REQUEST[pass]","$_REQUEST[num]","$_REQUEST[up]");}

    $name=htmlspecialchars("$_REQUEST[name]");
    if(empty($name)) {problem("Please enter your name!");}
    $message=htmlspecialchars("$_REQUEST[message]");
    if(empty($message)) {problem("Please write a message");}
    $email=htmlspecialchars("$_REQUEST[email]");
    if(!(empty($email)) && !(preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$email)))
        {problem("Please enter a valid e-mail address!");}
    else {$email="NO";}
        if ($a=="addnew")
            {
            $subject=htmlspecialchars("$_REQUEST[subject]");
   			if(empty($subject)) {problem("Please write a subject");}
            addNewTopic($name,$email,$subject,$message);
            }
        elseif ($a=="reply") {
        	$subject=htmlspecialchars("$_REQUEST[subject]");
   			if(empty($subject)) {problem("Please write a subject");}
            $_REQUEST['orig_id']=htmlspecialchars("$_REQUEST[orig_id]");
            $_REQUEST['orig_name']=htmlspecialchars("$_REQUEST[orig_name]");
            $_REQUEST['orig_subject']=htmlspecialchars("$_REQUEST[orig_subject]");
            $_REQUEST['orig_date']=htmlspecialchars("$_REQUEST[orig_date]");
            addNewReply($name,$email,$subject,$message,"$_REQUEST[orig_id]","$_REQUEST[orig_name]","$_REQUEST[orig_subject]","$_REQUEST[orig_date]");
            }
        else {problem("This is not a valid action.");}
}

?>

<html>
<head>
<title>�߼���̳</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<link Href="../images/css.css" Type=text/css Rel=stylesheet>
</head>
<body bgcolor="#FCFEFD" background="../images/bg1.gif" leftMargin=0 topMargin=0 marginheight="0" marginwidth="0">
<table border="0" cellpadding="0" cellspacing="0" width="100%" >
 <tr>
  <td align="center">
	 <table border="0" cellpadding="0" cellspacing="0" width="1098">
    <tr>
     <td background="../images/top.jpg" width="1098" height="183">
     	
     <table border="0" cellpadding="0" cellspacing="0" width="1098">
       <tr>
        <td height="153">
        </td>
       </tr>        	
       <tr>
        <td background="../images/btn.jpg" width="60" height="31" style="background-repeat:no-repeat" align="center" class="banner"><a href="../">��ҳ</a>
        </td>
        <td background="../images/btn.jpg" width="60" height="31" style="background-repeat:no-repeat" align="center" class="banner"><a href="#">���</a>
        </td>
        <td background="../images/btn.jpg" width="60" height="31" style="background-repeat:no-repeat" align="center" class="banner"><a href="#">���</a>
        </td>
        <td background="../images/btn.jpg" width="60" height="31" style="background-repeat:no-repeat" align="center" class="banner"><a href="#">����</a>
        </td>
        <td background="../images/btn.jpg" width="60" height="31" style="background-repeat:no-repeat" align="center" class="banner"><a href="#">С˵</a>
        </td>
        <td background="../images/btn.jpg" width="60" height="31" style="background-repeat:no-repeat" align="center" class="banner"><a href="#">����</a>
        </td>
        <td background="../images/btn.jpg" width="60" height="31" style="background-repeat:no-repeat" align="center" class="banner"><a href="#">��Ӱ</a>
        </td>
        <td background="../images/btn.jpg" width="60" height="31" style="background-repeat:no-repeat" align="center" class="banner"><a href="#">����</a>
        </td>
        <td background="../images/btn.jpg" width="60" height="31" style="background-repeat:no-repeat" align="center" class="banner"><a href="#">ʫ��</a>
        </td>
        <td background="../images/btn.jpg" width="60" height="31" style="background-repeat:no-repeat" align="center" class="banner"><a href="#">����</a>
        </td>
        <td background="../images/btn.jpg" width="60" height="31" style="background-repeat:no-repeat" align="center" class="banner"><a href="#">����</a>
        </td>
        <td background="../images/btn.jpg" width="60" height="31" style="background-repeat:no-repeat" align="center" class="banner"><a href="#">�ʾ�</a>
        </td>
        <td background="../images/btn.jpg" width="60" height="31" style="background-repeat:no-repeat" align="center" class="banner"><a href="#">����</a>
        </td>	
        <td width="240" height="31" ></a>
        </td>	
       </tr>        	
     	</table> 	
     
     
     </td>
    </tr>
    <tr>
     <td background="../images/banner.jpg" width="1098" height="82">
     	<table>
     	 <tr>
     	 	<td width="70" height="46" ></td>
     	  <td></td>
     	 </tr>
     	 <tr>
     	 	<td width="70"></td>
     	  <td>���û��֪ͨ���棡</td>
     	 </tr>
      </table>    	
     </td>
    </tr>
    <tr>
     <td background="../images/index_r4_c2.jpg" width="1098">
     	<table>
     	 <tr>
     	 	<td width="49"></td>
     	 	<td>
     	   <table border="0" cellpadding="0" cellspacing="0" width="983">
 				  <tr>
   				 <td><img src="../images/spacer.gif" width="13" height="1" border="0" alt=""></td>
  				 <td><img src="../images/spacer.gif" width="954" height="1" border="0" alt=""></td>
  				 <td><img src="../images/spacer.gif" width="16" height="1" border="0" alt=""></td>
  				 <td><img src="../images/spacer.gif" width="1" height="1" border="0" alt=""></td>
 					 </tr>
 					 <tr>
 					 	<td><img name="forum_r1_c1" src="../images/forum_r1_c1.jpg" width="13" height="60" border="0" alt=""></td>
 					 	<td background="../images/forum_r1_c2.jpg" bgcolor="#FFFFFF" width="954">
 					 	 <table>
     	        <tr>
     	 		     <td width="70"></td>
     	         <td><font color="#FFFFFF"><B>�ŵ���ѧ����</B></FONT></td>
     	        </tr>
     	        <tr>
     	      	 <td width="70" height="23"></td>
     	         <td></td>
     	        </tr>
             </table>	
 					 	</td>
 					 	<td><img name="forum_r1_c3" src="../images/forum_r1_c3.jpg" width="16" height="60" border="0" alt=""></td>
            <td><img src="../images/spacer.gif" width="1" height="60" border="0" alt=""></td>
           </tr>
           <tr>
           	<td background="../images/forum_r2_c1.jpg" bgcolor="#FFFFFF">&nbsp;</td> 
           	<td bgcolor="#FFFFFF">
           	<a href="post.php"><img name="forum_r1_c1" src="../images/post.png" width="61" height="28" border="0" alt=""></a>
           	<ul>
<?php
include_once "sheyee_com_inc/sheyee_com_threads.txt";
?>
</ul>
           		
           	</td>
   					<td background="../images/forum_r2_c3.jpg" bgcolor="#FFFFFF" valign="bottom">&nbsp;</td>
   					<td><img src="../images/spacer.gif" width="1" height="34" border="0" alt=""></td>
 					 </tr>
 					 <tr>
 					  <td><img name="forum_r3_c1" src="../images/forum_r3_c1.jpg" width="13" height="18" border="0" alt=""></td>
 				    <td background="../images/forum_r3_c2.jpg">&nbsp;</td>
  				  <td><img name="forum_r3_c3" src="../images/forum_r3_c3.jpg" width="16" height="18" border="0" alt=""></td>
  				  <td><img src="../images/spacer.gif" width="1" height="18" border="0" alt=""></td>
 					 </tr>
					</table>
         </td>
     	  </tr>
     	 <table>
     	</td>
    </tr>
    <tr>
     <td background="../images/index_r6_c2.png" width="1098" height="47">&nbsp;</td>
    </tr>
    <tr>
     <td background="../images/index_r7_c2.jpg" width="1098" height="98" align="center" class="banner">
<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1254665925'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s4.cnzz.com/stat.php%3Fid%3D1254665925%26show%3Dpic' type='text/javascript'%3E%3C/script%3E"));</script><br>
     	Copyright @ 2008-2015 <a href="./">�߼���̳</a> all right reserved. &nbsp;&nbsp;Power By <a href="http://sae.sina.com.cn">Sae App Engine</a>	
     	
     	</td>
    </tr>
   </table>
  </td>
 </tr>
</table>
</div>
<center>

<script type="text/javascript"><!--

google_ad_client = "pub-8742386847853865";

google_ad_width = 728;

google_ad_height = 90;

google_ad_format = "728x90_as";

google_ad_type = "text_image";

google_ad_channel ="";

//--></script>

<script type="text/javascript"

  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">

</script>

</center>
</body>
</html>




<?php
printCopyHTML();
printDownHTML();
exit();


// >>> START FUNCTIONS <<< //

function filter_bad_words($text) {
global $settings;
$file = 'sheyi_yeah_net_badwords/'.$settings['filter_lang'].'.php';

	if (file_exists($file))
    {
    	include_once($file);
    }
    else
    {
    	problem("The bad words file ($file) can't be found! Please check the
        name of the file. On most servers names are CaSe SeNsiTiVe!");
    }

	foreach ($settings['badwords'] as $k => $v)
    {
    	$text = preg_replace("/$k/i",$v,$text);
    }

return $text;
} // END filter_bad_words

function addNewReply($name,$email,$subject,$comments,$orig_id,$orig_name,$orig_subject,$orig_date) {
global $settings;
$date=date ("d/M/Y");

$comments = str_replace("\'","'",$comments);
$comments = str_replace("\&quot;","&quot;",$comments);
$comments = MakeUrl($comments);
$comments = str_replace("\r\n","<br>",$comments);
$comments = str_replace("\n","<br>",$comments);
$comments = str_replace("\r","<br>",$comments);

/* Let's strip those slashes */
$comments = stripslashes($comments);
$subject = stripslashes($subject);
$name = stripslashes($name);
$orig_name = stripslashes($name);
$orig_subject = stripslashes($subject);

if ($settings['smileys'] == 1 && $_REQUEST['nosmileys'] != "Y") {$comments = processsmileys($comments);}
if ($email != "NO") {$mail = "&lt;<a href=\"mailto:$email\">$email</a>&gt;";}
else {$mail=" ";}

if ($settings['filter']) {
$comments = filter_bad_words($comments);
$name = filter_bad_words($name);
$subject = filter_bad_words($subject);
}

$fp = fopen("sheyee_com_inc/sheyee_com_count.txt","rb") or problem("Can't open the count file (sheyee_com_inc/sheyee_com_count.txt) for reading!");
$count=fread($fp,6);
fclose($fp);
$count++;
$fp = fopen("sheyee_com_inc/sheyee_com_count.txt","wb") or problem("Can't open the count file (sheyee_com_inc/sheyee_com_count.txt) for writing! Please CHMOD this file to 666 (rw-rw-rw)");
fputs($fp,$count);
fclose($fp);

$threads = file("sheyee_com_inc/sheyee_com_threads.txt");

for ($i=0;$i<=count($threads);$i++) {
	if(preg_match("/<!--o $orig_id-->/",$threads[$i]))
    	{
        preg_match("/<\!--(.*)-->\s\((.*)\)/",$threads[$i],$matches);
        $number_of_replies=$matches[2];$number_of_replies++;
        $threads[$i] = "<!--o $orig_id--> ($number_of_replies)$settings[newline]";
        $threads[$i] .= "<!--z $count-->$settings[newline]";
        $threads[$i] .= "<!--s $count--><ul><li><a href=\"sheyee_com_msg/$count.$settings[extension]\">$subject</a> - <b>$name</b> <i>$date</i>$settings[newline]";
        $threads[$i] .= "<!--o $count--> (0)$settings[newline]";
        $threads[$i] .= "</li></ul><!--k $count-->$settings[newline]";
        break;
        }
}

$newthreads=implode('',$threads);

$fp = fopen("sheyee_com_inc/sheyee_com_threads.txt","wb") or problem("Couldn't open links file (sheyee_com_inc/sheyee_com_threads.txt) for writing! Please CHMOD it to 666 (rw-rw-rw)!");
fputs($fp,$newthreads);
fclose($fp);

$other = "in reply to <a href=\"$orig_id.$settings[extension]\">$orig_subject</a> posted by $orig_name on $orig_date";
createNewFile($name,$mail,$subject,$comments,$count,$date,$other,$orig_id);

$oldfile="sheyee_com_msg/".$orig_id.".".$settings['extension'];

$filecontent = file($oldfile);

for ($i=0;$i<=count($filecontent);$i++) {
	if(preg_match("/<!-- zacni -->/",$filecontent[$i]))
    	{
        $filecontent[$i] = "<!-- zacni -->".$settings['newline']."<!--s $count--><li><a href=\"$count.$settings[extension]\">$subject</a> - <b>$name</b> <i>$date</i></li>".$settings['newline'];
        break;
        }
}

$rewritefile=implode('',$filecontent);

$fp = fopen($oldfile,"wb") or problem("Couldn't open file $oldfile for writing! Please CHMOD the &quot;sheyee_com_msg&quot; folder to 777 (rwx-rwx-rwx)!");
fputs($fp,$rewritefile);
fclose($fp);

?>
<p>&nbsp;</p>

<p>&nbsp;</p>
<p align="center"><b>���������Ѿ��ɹ�����!</b></p>
<p align="center"><a href="index.php">�������ﷵ��</a></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

<p>&nbsp;</p>
<?php
printCopyHTML();
printDownHTML();
exit();
}

function createNewFile($name,$mail,$subject,$comments,$count,$date,$other="",$up="0") {
global $settings;
$header=implode('',file("sheyee_com_inc/sheyee_com_header.txt"));
$footer=implode('',file("sheyee_com_inc/sheyee_com_footer.txt"));
$content="<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">
<html>
<head>
<title>$subject</title>


<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\" />
<link href=\"../../sheyee_com_inc/sheyee_com_style.css\" type=\"text/css\" rel=\"stylesheet\">
<link Href=\"../../images/css.css\" Type=text/css Rel=stylesheet>
<META HTTP-EQUIV=\"Expires\" CONTENT=\"-1\">
<META HTTP-EQUIV=\"Pragma\" CONTENT=\"no-cache\">
<script language=\"Javascript\" src=\"$settings[sheyee_com_url]/sheyee_com_inc/sheyee_com_smileys.js\"><!--
//-->
</script>
</head>
<body bgcolor=\"#FCFEFD\" background=\"../../images/bg1.gif\" leftMargin=0 topMargin=0 marginheight=\"0\" marginwidth=\"0\">
";
$content.=$header;

$content.="

<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" >
 <tr>
  <td align=\"center\">
	 <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"1098\">
    <tr>
     <td background=\"../../images/top.jpg\" width=\"1098\" height=\"183\">
     
<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"1098\">
       <tr>
        <td height=\"153\">
        </td>
       </tr>        	
       <tr>
        <td background=\"../../images/btn.jpg\" width=\"60\" height=\"31\" style=\"background-repeat:no-repeat\" align=\"center\" class=\"banner\"><a href=\"../../\">��ҳ</a>
        </td>
        <td background=\"../../images/btn.jpg\" width=\"60\" height=\"31\" style=\"background-repeat:no-repeat\" align=\"center\" class=\"banner\"><a href=\"#\">���</a>
        </td>
        <td background=\"../../images/btn.jpg\" width=\"60\" height=\"31\" style=\"background-repeat:no-repeat\" align=\"center\" class=\"banner\"><a href=\"#\">���</a>
        </td>
        <td background=\"../../images/btn.jpg\" width=\"60\" height=\"31\" style=\"background-repeat:no-repeat\" align=\"center\" class=\"banner\"><a href=\"#\">����</a>
        </td>
        <td background=\"../../images/btn.jpg\" width=\"60\" height=\"31\" style=\"background-repeat:no-repeat\" align=\"center\" class=\"banner\"><a href=\"#\">С˵</a>
        </td>
        <td background=\"../../images/btn.jpg\" width=\"60\" height=\"31\" style=\"background-repeat:no-repeat\" align=\"center\" class=\"banner\"><a href=\"#\">����</a>
        </td>
        <td background=\"../../images/btn.jpg\" width=\"60\" height=\"31\" style=\"background-repeat:no-repeat\" align=\"center\" class=\"banner\"><a href=\"#\">��Ӱ</a>
        </td>
        <td background=\"../../images/btn.jpg\" width=\"60\" height=\"31\" style=\"background-repeat:no-repeat\" align=\"center\" class=\"banner\"><a href=\"#\">����</a>
        </td>
        <td background=\"../../images/btn.jpg\" width=\"60\" height=\"31\" style=\"background-repeat:no-repeat\" align=\"center\" class=\"banner\"><a href=\"#\">ʫ��</a>
        </td>
        <td background=\"../../images/btn.jpg\" width=\"60\" height=\"31\" style=\"background-repeat:no-repeat\" align=\"center\" class=\"banner\"><a href=\"#\">����</a>
        </td>
        <td background=\"../../images/btn.jpg\" width=\"60\" height=\"31\" style=\"background-repeat:no-repeat\" align=\"center\" class=\"banner\"><a href=\"#\">����</a>
        </td>
        <td background=\"../../images/btn.jpg\" width=\"60\" height=\"31\" style=\"background-repeat:no-repeat\" align=\"center\" class=\"banner\"><a href=\"#\">�ʾ�</a>
        </td>
        <td background=\"../../images/btn.jpg\" width=\"60\" height=\"31\" style=\"background-repeat:no-repeat\" align=\"center\" class=\"banner\"><a href=\"#\">����</a>
        </td>	
        <td width=\"240\" height=\"31\" ></a>
        </td>	
       </tr>        	
     	</table> 
     
     
     </td>
    </tr>
    <tr>
     <td background=\"../../images/banner.jpg\" width=\"1098\" height=\"82\">
     	<table>
     	 <tr>
     	 	<td width=\"70\" height=\"46\" ></td>
     	  <td></td>
     	 </tr>
     	 <tr>
     	 	<td width=\"70\"></td>
     	  <td>���û��֪ͨ���棡</td>
     	 </tr>
      </table>    	
     </td>
    </tr>
    <tr>
     <td background=\"../../images/index_r4_c2.jpg\" width=\"1098\">
     	<table>
     	<!--  �����Ǳ���������-->
     	 <tr>
     	 	<td width=\"49\"></td>
     	 	<td>
     	   <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"983\">
 				  <tr>
   				 <td><img src=\"../../images/spacer.gif\" width=\"13\" height=\"1\" border=\"0\" alt=\"\"></td>
  				 <td><img src=\"../../images/spacer.gif\" width=\"954\" height=\"1\" border=\"0\" alt=\"\"></td>
  				 <td><img src=\"../../images/spacer.gif\" width=\"16\" height=\"1\" border=\"0\" alt=\"\"></td>
  				 <td><img src=\"../../images/spacer.gif\" width=\"1\" height=\"1\" border=\"0\" alt=\"\"></td>
 					 </tr>
 					 <tr>
 					 	<td><img name=\"forum_r1_c1\" src=\"../../images/forum_r1_c1.jpg\" width=\"13\" height=\"60\" border=\"0\" alt=\"\"></td>
 					 	<td background=\"../../images/forum_r1_c2.jpg\" bgcolor=\"#FFFFFF\" width=\"954\">
 					 	 <table>
     	        <tr>
     	 		     <td width=\"70\"></td>
     	         <td><font color=\"#FFFFFF\"><B>�ŵ���ѧ���� �� $subject</B></FONT></td>
     	        </tr>
     	        <tr>
     	      	 <td width=\"70\" height=\"23\"></td>
     	         <td></td>
     	        </tr>
             </table>	
 					 	</td>
 					 	<td><img name=\"forum_r1_c3\" src=\"../../images/forum_r1_c3.jpg\" width=\"16\" height=\"60\" border=\"0\" alt=\"\"></td>
            <td><img src=\"../../images/spacer.gif\" width=\"1\" height=\"60\" border=\"0\" alt=\"\"></td>
           </tr>
           <tr>
           	<td background=\"../../images/forum_r2_c1.jpg\" bgcolor=\"#FFFFFF\">&nbsp;</td> 
           	<td bgcolor=\"#FFFFFF\">
           	<a href=\"post.php\"><a href=\"#new\">�ظ�����</a> ||
<a href=\"$settings[sheyee_com_url]/index.php\">���� $settings[sheyee_com_title]</a>
<hr>
<p align=\"center\"><b>$subject</b></p>



<p><a href=\"$settings[sheyee_com_url]/index.php?a=delete&num=$count&up=$up\"><img
src=\"$settings[sheyee_com_url]/sheyee_com_images/delete.gif\" width=\"16\" height=\"14\" border=\"0\" alt=\"Delete this post\"></a>
Submitted by $name $mail on $date $other";

if ($settings['display_IP']==1) {$content .= "<br><font class=\"ip\">$_SERVER[REMOTE_ADDR]</font>";}

$content .= "</p>

<p><b>����</b>:</p>

<p>$comments</p>

<hr>



<p align=\"center\"><b>������Ļظ�</b></p>
<ul>
<!-- zacni --><p>��ʱû�лظ�</p>
</ul>
<hr>
           		
           	</td>
   					<td background=\"../../images/forum_r2_c3.jpg\" bgcolor=\"#FFFFFF\" valign=\"bottom\">&nbsp;</td>
   					<td><img src=\"../../images/spacer.gif\" width=\"1\" height=\"34\" border=\"0\" alt=\"\"></td>
 					 </tr>
 					 <tr>
 					  <td><img name=\"forum_r3_c1\" src=\"../../images/forum_r3_c1.jpg\" width=\"13\" height=\"18\" border=\"0\" alt=\"\"></td>
 				    <td background=\"../../images/forum_r3_c2.jpg\">&nbsp;</td>
  				  <td><img name=\"forum_r3_c3\" src=\"../../images/forum_r3_c3.jpg\" width=\"16\" height=\"18\" border=\"0\" alt=\"\"></td>
  				  <td><img src=\"../../images/spacer.gif\" width=\"1\" height=\"18\" border=\"0\" alt=\"\"></td>
 					 </tr>
					</table>
         </td>
     	  </tr>


<!--  �����ǻظ�������-->

       <tr>
     	 	<td width=\"49\"></td>
     	 	<td>
     	   <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"983\">
 				  <tr>
   				 <td><img src=\"../../images/spacer.gif\" width=\"13\" height=\"1\" border=\"0\" alt=\"\"></td>
  				 <td><img src=\"../../images/spacer.gif\" width=\"954\" height=\"1\" border=\"0\" alt=\"\"></td>
  				 <td><img src=\"../../images/spacer.gif\" width=\"16\" height=\"1\" border=\"0\" alt=\"\"></td>
  				 <td><img src=\"../../images/spacer.gif\" width=\"1\" height=\"1\" border=\"0\" alt=\"\"></td>
 					 </tr>
 					 <tr>
 					 	<td><img name=\"forum_r1_c1\" src=\"../../images/forum_r1_c1.jpg\" width=\"13\" height=\"60\" border=\"0\" alt=\"\"></td>
 					 	<td background=\"../../images/forum_r1_c2.jpg\" bgcolor=\"#FFFFFF\" width=\"954\">
 					 	 <table>
     	        <tr>
     	 		     <td width=\"70\"></td>
     	         <td><font color=\"#FFFFFF\"><B>�ظ�������</B></FONT></td>
     	        </tr>
     	        <tr>
     	      	 <td width=\"70\" height=\"23\"></td>
     	         <td></td>
     	        </tr>
             </table>	
 					 	</td>
 					 	<td><img name=\"forum_r1_c3\" src=\"../../images/forum_r1_c3.jpg\" width=\"16\" height=\"60\" border=\"0\" alt=\"\"></td>
            <td><img src=\"../../images/spacer.gif\" width=\"1\" height=\"60\" border=\"0\" alt=\"\"></td>
           </tr>
           <tr>
           	<td background=\"../../images/forum_r2_c1.jpg\" bgcolor=\"#FFFFFF\">&nbsp;</td> 
           	<td bgcolor=\"#FFFFFF\">
           	
           	
           	<p align=\"center\"><a name=\"new\"></a><b>�ظ�������</b></p>
<div align=\"center\"><center>
<table border=\"0\"><tr>
<td>

<form method=post action=\"$settings[sheyee_com_url]/index.php\" name=\"form\">
<p><input type=\"hidden\" name=\"a\" value=\"reply\"><b>�ʺ�:</b><br><input type=text name=\"name\" size=30 maxlength=30><br>
���� (��ѡ):<br><input type=text name=\"email\" size=30 maxlength=50><br>
<b>����:</b><br><input type=text name=\"subject\" value=\"Re: $subject\" size=30 maxlength=100><br><br>
<b>����:</b><br><textarea cols=50 rows=9 name=\"message\"></textarea>
<input type=\"hidden\" name=\"orig_id\" value=\"$count\">
<input type=\"hidden\" name=\"orig_name\" value=\"$name\">
<input type=\"hidden\" name=\"orig_subject\" value=\"$subject\">
<input type=\"hidden\" name=\"orig_date\" value=\"$date\">
";

if ($settings['smileys'] == 1) {
$content.="<br><a href=\"javascript:openSmiley('$settings[sheyee_com_url]/sheyee_com_inc/sheyee_com_smileys.htm')\">�������</a>
(���´���)<br>
<input type=\"checkbox\" name=\"nosmileys\" value=\"Y\"> ���ñ���ͼƬ";
}

$content.="
</p>
<p><input type=submit value=\"ȷ��\">
</form>
</td>
</tr></table>
</center></div>
";

$content.="

           		
           	</td>
   					<td background=\"../../images/forum_r2_c3.jpg\" bgcolor=\"#FFFFFF\" valign=\"bottom\">&nbsp;</td>
   					<td><img src=\"../../images/spacer.gif\" width=\"1\" height=\"34\" border=\"0\" alt=\"\"></td>
 					 </tr>
 					 <tr>
 					  <td><img name=\"forum_r3_c1\" src=\"../../images/forum_r3_c1.jpg\" width=\"13\" height=\"18\" border=\"0\" alt=\"\"></td>
 				    <td background=\"../../images/forum_r3_c2.jpg\">&nbsp;</td>
  				  <td><img name=\"forum_r3_c3\" src=\"../../images/forum_r3_c3.jpg\" width=\"16\" height=\"18\" border=\"0\" alt=\"\"></td>
  				  <td><img src=\"../../images/spacer.gif\" width=\"1\" height=\"18\" border=\"0\" alt=\"\"></td>
 					 </tr>
          </table>
       	 </td>
        </tr> 
     	 </table>
     	</td>
    </tr>
    <tr>
     <td background=\"../../images/index_r6_c2.png\" width=\"1098\" height=\"47\">&nbsp;</td>
    </tr>
    <tr>
     <td background=\"../../images/index_r7_c2.jpg\" width=\"1098\" height=\"98\" align=\"center\" class=\"banner\">
<script type=\"text/javascript\">var cnzz_protocol = ((\"https:\" == document.location.protocol) ? \" https://\" : \" http://\");document.write(unescape(\"%3Cspan id='cnzz_stat_icon_1254665925'%3E%3C/span%3E%3Cscript src='\" + cnzz_protocol + \"s4.cnzz.com/stat.php%3Fid%3D1254665925%26show%3Dpic' type='text/javascript'%3E%3C/script%3E\"));</script><br>
     	Copyright @ 2008-2015 <a href=\"./\">�߼���̳</a> all right reserved. &nbsp;&nbsp;Power By <a href=\"http://sae.sina.com.cn\">Sae App Engine</a>
     
     </td>
    </tr>
   </table>
  </td>
 </tr>
</table>
<center>
<script type=\"text/javascript\"><!--
google_ad_client = \"pub-8742386847853865\";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = \"728x90_as\";
google_ad_type = \"text_image\";
google_ad_channel =\"\";
//--></script>
<script type=\"text/javascript\"
  src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>
</center>
</div>
</body>
</html>
";

$newfile="sheyee_com_msg/".$count.".".$settings['extension'];
$fp = fopen($newfile,"wb") or problem("Couldn't create file &quot;$newfile&quot;! Please CHMOD the &quot;sheyee_com_msg&quot; folder to 666 (rw-rw-rw)!");
fputs($fp,$content);
fclose($fp);
unset($content);
unset($header);
unset($footer);

/* Notify admin */
if ($settings['notify'] == 1)
	{
    $message = "Hello!

Someone has just posted a new message on your forum! Visit the below URL to view the message:

$settings[sheyee_com_url]/$newfile

End of message
";

    mail("$settings[admin_email]","New forum post",$message);
    }

/* Delete old posts */
$count -= $settings['maxposts'];
$newfile="sheyee_com_msg/".$count.".".$settings['extension'];
if (file_exists($newfile))
	{
    	deleteOld($count,$newfile);
    }

}

function addNewTopic($name,$email,$subject,$comments) {
global $settings;
$date=date ("d/M/Y");

$comments = str_replace("\'","'",$comments);
$comments = str_replace("\&quot;","&quot;",$comments);
$comments = MakeUrl($comments);
$comments = str_replace("\r\n","<br>",$comments);
$comments = str_replace("\n","<br>",$comments);
$comments = str_replace("\r","<br>",$comments);

/* Let's strip those slashes */
$comments = stripslashes($comments);
$subject = stripslashes($subject);
$name = stripslashes($name);

if ($settings['smileys'] == 1 && $_REQUEST['nosmileys'] != "Y") {$comments = processsmileys($comments);}
if ($email != "NO") {$mail = "&lt;<a href=\"mailto:$email\">$email</a>&gt;";}
else {$mail=" ";}

if ($settings['filter']) {
$comments = filter_bad_words($comments);
$name = filter_bad_words($name);
$subject = filter_bad_words($subject);
}

$fp = fopen("sheyee_com_inc/sheyee_com_count.txt","rb") or problem("Can't open the count file (sheyee_com_inc/sheyee_com_count.txt) for reading!");
$count=fread($fp,6);
fclose($fp);
$count++;
$fp = fopen("sheyee_com_inc/sheyee_com_count.txt","wb") or problem("Can't open the count file (sheyee_com_inc/sheyee_com_count.txt) for writing! Please CHMOD this file to 666 (rw-rw-rw)");
fputs($fp,$count);
fclose($fp);

$addline = "<!--z $count-->$settings[newline]";
$addline .= "<!--s $count--><p><li><a href=\"sheyee_com_msg/$count.$settings[extension]\">$subject</a> - <b>$name</b> <i>$date</i>$settings[newline]";
$addline .= "<!--o $count--> (0)$settings[newline]";
$addline .= "</li><!--k $count-->$settings[newline]";

$fp = @fopen("sheyee_com_inc/sheyee_com_threads.txt","rb") or problem("Can't open the log file (sheyee_com_inc/sheyee_com_threads.txt) for reading!");
$threads = @fread($fp,filesize("sheyee_com_inc/sheyee_com_threads.txt"));
fclose($fp);
$addline .= $threads;
$fp = fopen("sheyee_com_inc/sheyee_com_threads.txt","wb") or problem("Couldn't open links file (sheyee_com_inc/sheyee_com_threads.txt) for writing! Please CHMOD it to 666 (rw-rw-rw)!");
fputs($fp,$addline);
fclose($fp);
createNewFile($name,$mail,$subject,$comments,$count,$date);

?>
<p>&nbsp;</p>


<p>&nbsp;</p>
<p align="center"><b>���������Ѿ��ɹ�����!</b></p>
<p align="center"><a href="index.php">�����������</a></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>


<p>&nbsp;</p>
<?php
printCopyHTML();
printDownHTML();
exit();
}

function deleteOld($num,$file) {
global $settings;

	if ($settings['keepoldmsg'] == 0) {unlink($file);}

// Delete input from sheyee_com_inc/sheyee_com_threads.txt
$keep = "YES";
$threads = file("sheyee_com_inc/sheyee_com_threads.txt");
for ($i=0;$i<=count($threads);$i++) {
	if(preg_match("/<!--z $num-->/",$threads[$i])) {unset($threads[$i]); $keep = "NO";}
    elseif(preg_match("/<!--k $num-->/",$threads[$i])) {unset($threads[$i]); break;}
    elseif($keep == "NO") {unset($threads[$i]);}
    else {continue;}
}
$newthreads=implode('',$threads);
$fp = fopen("sheyee_com_inc/sheyee_com_threads.txt","wb") or problem("Couldn't open links file (sheyee_com_inc/sheyee_com_threads.txt) for writing! Please CHMOD it to 666 (rw-rw-rw)!");
fputs($fp,$newthreads);
fclose($fp);

}

function doDelete($pass,$num,$up) {
global $settings;
if ($pass != $settings[apass]) {problem("Wrong password! The entry hasn't been deleted.");}

	if ($settings['keepoldmsg'] == 0)
    {
		unlink("sheyee_com_msg/$num.$settings[extension]") or problem("Can't delete this post,
        access denied or post doesn't exist!");
    }

// Delete input from sheyee_com_inc/sheyee_com_threads.txt
$keep = "YES";
$threads = file("sheyee_com_inc/sheyee_com_threads.txt");
for ($i=0;$i<=count($threads);$i++) {

	if(!(empty($up)) && preg_match("/<!--o $up-->/",$threads[$i]))
    	{
        preg_match("/<\!--(.*)-->\s\((.*)\)/",$threads[$i],$matches);
        $number_of_replies=$matches[2];$number_of_replies--;
        $threads[$i] = "<!--o $up--> ($number_of_replies)$settings[newline]";
        }

	elseif(preg_match("/<!--z $num-->/",$threads[$i])) {unset($threads[$i]); $keep = "NO";}
    elseif(preg_match("/<!--k $num-->/",$threads[$i])) {unset($threads[$i]); break;}
    elseif($keep == "NO") {unset($threads[$i]);}
    else {continue;}
}
$newthreads=implode('',$threads);
$fp = fopen("sheyee_com_inc/sheyee_com_threads.txt","wb") or problem("Couldn't open links file (sheyee_com_inc/sheyee_com_threads.txt) for writing! Please CHMOD it to 666 (rw-rw-rw)!");
fputs($fp,$newthreads);
fclose($fp);

// Delete input from upper file if any
$upfile="sheyee_com_msg/$up.$settings[extension]";
if(!(empty($up)) && file_exists($upfile)) {
$threads = file($upfile);
for ($i=0;$i<=count($threads);$i++) {
    if(preg_match("/<!--s $num-->/",$threads[$i])) {unset($threads[$i]); break;}
}
$newthreads=implode('',$threads);
$fp = fopen($upfile,"wb") or problem("Couldn't open file $upfile for writing! Please CHMOD it to 666 (rw-rw-rw)!");
fputs($fp,$newthreads);
fclose($fp);
}
?>
<hr>
<p>&nbsp;</p>
<p>&nbsp;</p>


<p align="center"><b>ѡ�������ͻظ��Ѿ��ɹ�ɾ��!</b></p>
<p align="center"><a href="<?php echo($settings[sheyee_com_url]); ?>/index.php">�����������</a></p>
<p>&nbsp;</p>


<p>&nbsp;</p>
<?php
printCopyHTML();
printDownHTML();
exit();
}

function confirmDelete($num,$up) {
global $settings;
?>
<hr>
<p>&nbsp;</p>
<p>&nbsp;</p>
<form action="<?php echo($settings[sheyee_com_url]); ?>/index.php" method="POST"><input type="hidden" name="a" value="confirmdelete">
<input type="hidden" name="num" value="<?php echo($num); ?>"><input type="hidden" name="up" value="<?php echo($up); ?>">
<p align="center"><b>Please enter your administration password:</b><br>
<input type="password" name="pass" size="20"></p>
<p align="center"><b>Are you sure you want to delete this post and all replies to it? This action cannot be undone!</b></p>
<p align="center"><input type="submit" value="YES, delete this entry and replies to it"> | <a href="<?php echo($settings[sheyee_com_url]); ?>/index.php">NO, I changed my mind</a></p>
</form>
<p>&nbsp;</p>
<p>&nbsp;</p>


<?php
printCopyHTML();
printDownHTML();
exit();
}

function MakeUrl($strUrl)
{
global $settings;
$strUrl = preg_replace("/(http(s)?:\/\/[^\s\n\"\']*)\b(\/)?/i","<a href=\"$settings[sheyee_com_url]/sheyee_com_inc/sheyee_com_go.php?url=\\0\" target=\"_blank\">\\0</a>",$strUrl);
return $strUrl;
}

function processsmileys($text) {
global $settings;
$text = preg_replace("/\:\)/","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/icon_smile.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:\(/","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/icon_frown.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:D/","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/icon_biggrin.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\;\)/","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/icon_wink.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:o/","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/icon_redface.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:p/i","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/icon_razz.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:cool\:/i","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/icon_cool.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:rolleyes\:/i","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/icon_rolleyes.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:mad\:/i","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/icon_mad.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:eek\:/i","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/icon_eek.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:clap\:/i","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/yelclap.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:bonk\:/i","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/bonk.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:chased\:/i","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/chased.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:crazy\:/i","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/crazy.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:cry\:/i","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/cry.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:curse\:/i","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/curse.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:err\:/i","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/errr.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:livid\:/i","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/livid.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:rotflol\:/i","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/rotflol.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:love\:/i","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/love.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:nerd\:/i","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/nerd.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:nono\:/i","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/nono.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:smash\:/i","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/smash.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:thumbsup\:/i","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/thumbup.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:toast\:/i","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/toast.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:welcome\:/i","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/welcome.gif\" border=\"0\" alt=\"\">",$text);
$text = preg_replace("/\:ylsuper\:/i","<img src=\"$settings[sheyee_com_url]/sheyee_com_images/ylsuper.gif\" border=\"0\" alt=\"\">",$text);
return "$text";
}

function problem($myproblem) {
echo"<p>&nbsp;</p>
<p>&nbsp;</p>


<p align=\"center\"><b>Error</b></p>
<p align=\"center\">$myproblem</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>";
printCopyHTML();
printDownHTML();
exit();
}

function printTopHTML() {
header("Expires: Mon, 26 Jul 2000 05:00:00 GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
global $settings;
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">
<html>
<head>
<title>$settings[sheyee_com_title]</title>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\" />
<link href=\"sheyee_com_inc/sheyee_com_style.css\" type=\"text/css\" rel=\"stylesheet\">
<link Href=\"../images/css.css\" Type=text/css Rel=stylesheet>
</head>
<body>
";
include_once "sheyee_com_inc/sheyee_com_header.txt";
}

function printDownHTML() {
global $settings;
include_once "sheyee_com_inc/sheyee_com_footer.txt";
echo "</body>
</html>";
}

function printCopyHTML() {
global $settings;
echo "<hr width=\"95%\">
<!-- Please leave the \"Powered by\" links. Thank you. -->


<p align=\"center\">Copyright @ 2005 <a href=\"http://www.icxcn.com/\" target=\"_blank\">�߼���̳</a> All Rights Reserved <a href=\"http://www.miibeian.gov.cn/\" target=\"_blank\">��ICP��05075041��</a></p>";
}
?>


