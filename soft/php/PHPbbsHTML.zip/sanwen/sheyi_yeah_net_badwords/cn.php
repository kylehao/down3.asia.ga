<?php
# Bad words file
# Language: ENGLISH
# File name: en.php
# PHP Sheyi board (SheyiBBS) 
# Version: 1.0
# Written 9th September 2004 by Roy She (info@sheyee.com)
# http://www.Sheyee.com

#------------------------------------------------------#
#                 ������ΪSHEYI�������ṩ             	#
#               SheyiBBS�Զ�����HTML(PHP+TXT):       	#
#                         ע��� v2.88               	#
#                                                      #
#     �������Ȩ��Sheyi���������У��κ��˽Կ�����      	#
#     ʹ�ñ������ڷ���ҵ��;����ҵ��;���븶����          #
#     ���500Ԫ��                                    	#
#                                                   	#
#                    лл��ʹ�ñ����򡡡�sheyi         	#
#                    E-mail: sheyee@163.com           	#
#		     QQ:709345		             	#
#		     MSN:sheyee@msn.com                 	#
#                    http://sheyi.126.com             	#
#                                                     	#
#     ������Ϊ��������ѳ��򣬸��˿���ʹ�ñ����򣬵���   	#
#     �뱣��Sheyi������(http://sheyi.yeah.net)�����ӣ� 	#
#------------------------------------------------------#

$settings['badwords'] = array (

/* All bad words should be in this format:
	"BADWORD" => "REPLACEMENT",
You can add as many bad words as you wish.
INSERT NEW BAD WORDS BELOW THIS LINE */



/* DO NOT EDIT BELOW */

	"asinine" => "a*******",
	"a.s.i.n.i.n.e" => "a*******",
	"a s i n i n e" => "a*******",
	" ass " => " a** ",
	"a s s" => "a**",
	"a.s.s" => "a**",
	"ass fucker" => "a** f*****",
	"a.s.s.f.u.c.k.e.r" => "a** f*****",
	"a s s f u c k e r" => "a** f*****",
	"asshole" => "a******",
	"a s s h o l e" => "a******",
	"a.s.s.h.o.l.e" => "a******",
	"ass hole" => "a******",
	"a.s.s h.o.l.e" => "a******",
	"bastard" => "b******",
	"b.a.s.t.a.r.d" => "b******",
	"b a s t a r d" => "b******",
	"bitch" => "b****",
	"b i t c h" => "b****",
	"b.i.t.c.h" => "b****",
	"blowjob" => "b******",
	"b.l.o.w.j.o.b" => "b******",
	"b l o w j o b" => "b******",
	"bollocks" => "b*******",
	"b.o.l.l.o.c.k.s" => "b*******",
	"b o l l o c k s" => "b*******",
	" butt " => " b*** ",
	"buttfucker" => "b*********",
	"b u t t f u c k e r" => "b*********",
	"b.u.t.t.f.u.c.k.e.r" => "b*********",
	"butt fucker" => "b*********",
	"b.u.t.t f.u.c.k.e.r" => "b*********",
	"b u t t" => "b***",
	"b.u.t.t" => "b***",
	"christ sakes" => "c***** s****",
	"c.h.r.i.s.t.s.a.k.e.s" => "c***** s****",
	"c h r i s t s a k e s" => "c***** s****",
	"christs sakes" => "c***** s****",
	"c.h.r.i.s.t.s.s.a.k.e.s" => "c***** s****",
	"c h r i s t s s a k e s" => "c***** s****",
	"christ's sakes" => "c***** s****",
	"clit" => "c***",
	"c.l.i.t" => "c***",
	"c l i t" => "c***",
	" cock " => " c*** ",
	"c o c k" => "c***",
	"c.o.c.k" => "c***",
	"cocksucker" => "c*********",
	"c.o.c.k.s.u.c.k.e.r" => "c*********",
	"c o c k s u c k e r" => "c*********",
	"crap" => "c***",
	"c r a p" => "c***",
	"c.r.a.p" => "c***",
	"cunt" => "c***",
	"c u n t" => "c***",
	"c.u.n.t" => "c***",
	"cuck" => "c***",
	"c u c k" => "c***",
	"c.u.c.k" => "c***",
	"d i c k" => "d***",
	"d.i.c.k" => "d***",
	"fag" => "f**",
	"f.a.g" => "f**",
	"f a g" => "f**",
	"fuck" => "f***",
	"f u c k" => "f***",
	"f.u.c.k" => "f***",
	"fucking" => "f******",
	"f u c k i n g" => "f******",
	"f.u.c.k.i.n.g" => "f******",
	"fuk" => "f***",
	"f u k" => "f***",
	"f.u.k" => "f***",
	"handjob" => "h******",
	"h.a.n.d.j.o.b" => "h******",
	"h a n d j o b" => "h******",
	"jackass" => "j*** a**",
	"jack ass" => "j*** a**",
	"j a c k a s s" => "j*** a**",
	"j.a.c.k.a.s.s" => "j*** a**",
	"jerk" => "j***",
	"j e r k" => "j***",
	"j.e.r.k" => "j***",
	"jerck" => "j***",
	"j e r c k" => "j***",
	"j.e.r.c.k" => "j***",
	"jerq" => "j***",
	"j e r q" => "j***",
	"j.e.r.q" => "j***",
	"motherfucker" => "m***********",
	"m o t h e r f u c k e r" => "m***********",
	"m.o.t.h.e.r.f.u.c.k.e.r" => "m***********",
	"mother fucker" => "m***********",
	"m.o.t.h.e.r f.u.c.k.e.r" => "m***********",
	"my cock" => "my c***",
	"my dick" => "my d***",
	"nigger" => "n*****",
	"n.i.g.g.e.r" => "n*****",
	"n i g g e r" => "n*****",
	"piss" => "p***",
	"p.i.s.s" => "p***",
	"p i s s" => "p***",
	"poop" => "p***",
	"p o o p" => "p***",
	"p.o.o.p" => "p***",
	"shit" => "s***",
	"s h i t" => "s***",
	"s.h.i.t" => "s***",
	"slut" => "s***",
	"s.l.u.t" => "s***",
	"s l u t" => "s***",
	"s o n o f a" => "s** ** *",
	"s.o.n o.f a" => "s** ** *",
	"s.o.n.o.f.a." => "s** ** *",
	"suck" => "s***",
	"s u c k" => "s***",
	"s.u.c.k" => "s***",
	"whore" => "w****",
	"w.h.o.r.e" => "w****",
	"w h o r e" => "w****",
	"your cock" => "your c***",
	"your dick" => "your d***"

);


?>