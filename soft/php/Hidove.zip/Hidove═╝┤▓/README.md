**说明**
利用空余时间重新写了个新图床，缘由是自己和朋友都需要，自己也不喜欢用现成的，喜欢写一个，方便自己添加新功能


## 特点
+ 十多种接口
+ 分发上传
+ 用户中心
+ 鉴黄
+ 上传API
+ bootstrap4简约界面
+ layui后台

## 演示

Github：https://github.com/Hidove/image

演示地址

免费版    <https://img.abcyun.co/free>

Pro版    <https://img.abcyun.co>

![1][1]
![2][2]
![3][3]


Ivey：`loliconla@qq.com`

  [1]: https://blog.hidove.cn/usr/uploads/2019/10/1049055436.png
  [2]: https://blog.hidove.cn/usr/uploads/2019/10/1147895906.png
  [3]: https://blog.hidove.cn/usr/uploads/2019/10/2357076147.png