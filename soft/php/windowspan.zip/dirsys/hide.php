<?php exit() ?>

# Ce fichier contient la liste des dossiers/fichiers cach� par l'explorer!
# la 1ere ligne de ce fichier ne dois pas etre supprim�: elle protege le 
# fichier contre la lecture!
# chaque fichiers/dossier doivent etre ecrit sur une ligne en ecrivant le
# chemin complet a partir du document_root de l'explorer!
# vous pouvez ajouter des commentaire en faisant commencer la ligne par
# le symbole '#'
# Il existe une autre methode pour cacher un fichier ou un dossier :
# il suffit faire commencer son nom par un '.'
# il est dailleur preferable d'utiliser cette methode l� car elle fonctionne
# a un niveau inferieur et assure donc une plus grande securit�!
# en bref, n'utilisez ce fichier pour cacher du contenu que si vous n'avez
# pas d'autres choix...

# exemple : 
# /dossier/tres/tres/tres/confidentiel/
# /fichier/tres/tres/confidentiel.jpg

# ceci permet de cacher le dossier 'sessions' sur les hebergement free!
/sessions
/dirsys