<?php
$CONFIG['MAIN_TITLE'] = '�������� - Power By 0321.TK ';
$CONFIG['SYS_LANG'] = 'cn';
$CONFIG['WIDTH_TREE_FRAME'] = 240;
$CONFIG['FRAME_BORDER'] = true;
$CONFIG['WIDTH_FRAME_BORDER'] = 1;
$CONFIG['WIDTH_FRAME_SPACING'] = 3;
$CONFIG['SCROLING_TREE_FRAME'] = 'AUTO';
$CONFIG['RESIZE_FRAME'] = true;
$CONFIG['DOCUMENT_ROOT'] = '/upload/';
$CONFIG['DIRSYS'] = 'dirsys';
$CONFIG['WIDTH_TD_SIZE'] = 60;
$CONFIG['WIDTH_TD_TYPE'] = 160;
$CONFIG['WIDTH_TD_DATE'] = 120;
$CONFIG['STYLE'] = 2;
$CONFIG['CSS'] = 'styleXP1.css';
$CONFIG['TOTALSIZE'] = 100;
$CONFIG['MASK_TYPE_FILES'] = 'php,php3,php4,php5,pl,db';
$CONFIG['CHECK_MAJ'] = true;
$CONFIG['IMAGE_BROWSER'] = true;
$CONFIG['IMAGE_TN'] = true;
$CONFIG['GD2'] = true;
$CONFIG['IMAGE_JPG'] = true;
$CONFIG['IMAGE_GIF'] = true;
$CONFIG['IMAGE_BMP'] = false;
$CONFIG['IMAGE_TN_SIZE'] = 100;
$CONFIG['IMAGE_TN_COMPRESSION'] = 60;
$CONFIG['NB_COLL_TN'] = 6;
$CONFIG['EXIF_READER'] = true;
$CONFIG['SLIDE_SHOW'] = true;
$CONFIG['DEBUG'] = true;
$CONFIG['SLIDE_SHOW_INT'] = 5;
$CONFIG['BACK'] = true;
$CONFIG['WRITE_TN'] = true;
$CONFIG['AUTO_RESIZE'] = true;
$CONFIG['DETAILS'] = true;
$CONFIG['DIRINFO_LIFE'] = 7;
$CONFIG['activer_Message'] = false;
$CONFIG['Message'] = 'Mettez un message un lien ...';
#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
# NE PAS TOUCHER TOUT CE QUI SUIT
if(!include_once(dirname(__FILE__).'/lang.inc.php'));
if(!include_once(dirname(__FILE__).'/functions.inc.php'));
if(!include_once(dirname(__FILE__).'/makeconfig.inc.php'));
if (isset($_SESSION['lang']) && file_exists(dirname(__FILE__).'/lang/lang.'.$_SESSION['lang'].'.ini'))	$CONFIG['SYS_LANG'] = $_SESSION['lang'];?>