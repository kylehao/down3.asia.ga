<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------

//   -------------------------------------------------------------------------------
//  | Language: Portugu�s Brasileiro                                                |
//   -------------------------------------------------------------------------------
//  | Vagner Marques <> 14.01.2005                                                  |
//   -------------------------------------------------------------------------------
//  |                                                                               |
//  |                              INSTRUCTIONS                                     |
//  |                                                                               |
//  |  The messages to translate are listed below.                                  |
//  |  The structure of each line is like this:                                     |
//  |     $message["Hello world!"] = "Hello world!";                                |
//  |                                                                               |
//  |  Keep the text between square brackets [] as it is.                           |
//  |  Translate the 2nd part, keeping the same punctuation and HTML tags.          |
//  |                                                                               |
//  |  The English message, for example                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is written in PHP!";    |
//  |  should become after translation:                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp est ecrit en PHP!";     |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is geschreven in PHP!"; |
//  |                                                                               |
//  |  Note that the variable starts with a dollar sign $, that the value is        |
//  |  enclosed in double quotes " and that the line ends with a semi-colon ;       |
//  |  Be careful when editing this file, do not erase those special characters.    |
//  |                                                                               |
//  |  Some messages also contain one or more variables which start with a percent  |
//  |  sign, for example %1\$s or %2\$s. The English message, for example           |
//  |     $messages[...] = ["The file %1\$s was copied to %2\$s "]                  |
//  |  should becomes after translation:                                            |
//  |     $messages[...] = ["Le fichier %1\$s a �t� copi� vers %2\$s "]             |
//  |                                                                               |
//  |  When a real percent sign % is needed in the text it is entered as %%         |
//  |  otherwise it is interpreted as a variable. So no, it's not a mistake.        |
//  |                                                                               |
//  |  Between the messages to translate there is additional PHP code, for example: |
//  |     if ($state2 == "rename") {                               // <-- PHP code  |
//  |     $messages["Rename directories"] = "Rename directories";  // <-- message   |
//  |     }                                                        // <-- PHP code  |
//  |  This code is needed to load the messages only when they are actually needed. |
//  |  There is no need to change or delete any of that PHP code; translate only    |
//  |  the message.                                                                 |
//  |                                                                               |
//  |  Thanks in advance to all the translators!                                    |
//  |  David.                                                                       |
//  |                                                                               |
//   -------------------------------------------------------------------------------

function getMessages() {
global $state, $state2;


// -------------------------------------------------------------------------
// Used encoding
// -------------------------------------------------------------------------
$messages["iso-8859-1"] = "iso-8859-1";


// -------------------------------------------------------------------------
// Status messages
// -------------------------------------------------------------------------
// When translating these messages, keep in mind that the text should not be too long
// It should fit in the status textbox
$messages["Connecting to the FTP server"] = "Conectando o servidor FTP";
$messages["Getting the list of directories and files"] = "Obtendo a lista de pastas e arquivos";
$messages["Printing the list of directories and files"] = "Gerando lista de pastas e arquivos";
$messages["Processing the entries"] = "das entradas processadas";
$messages["Checking files"] = "Checando arquivos";
$messages["Transferring files to the FTP server"] = "Transferindo arquivos para o servidor";
$messages["Decompressing archives and transferring files"] = "Decomprimindo e transferindo arquivos";
$messages["Searching the files..."] = "Procurando os arquivos ...";
$messages["Uploading new file"] = "Enviando novo arquivo";
$messages["Reading the new file"] = "Lendo o arquivo novo";
$messages["Reading the old file"] = "Lendo o arquivo velho";
$messages["Comparing the 2 files"] = "Comparando os 2 arquivos";
$messages["Printing the comparison"] = "Imprimindo a compara��o";
$messages["Script finished in %1\$s seconds"] = "carregado em %1\$s segundos";
$messages["Script halted"] = "Programa travado";


// -------------------------------------------------------------------------
// index.php
// -------------------------------------------------------------------------
$messages["Unexpected state string. Exiting."] = "Unexpected state string. Exiting.";
$messages["This beta function is not activated on this server."] = "This beta function is not activated on this server.";
$messages["This function has been disabled by the Administrator of this website."] = "This function has been disabled by the Administrator of this website.";


// -------------------------------------------------------------------------
// admin.inc.php
if ($state == "admin") {
// -------------------------------------------------------------------------
$messages["Admin functions"] = "Fun��es administrativas";

$messages["Version information"] = "Informa��o da vers�o";
$messages["This version of net2ftp is up-to-date"] = "Esta vers�o do net2ftp est� atualizada";
$messages["The latest version could not be retrieved from the net2ftp.com server. Check the security settings of your browser, which may prevent the loading of a small file from the net2ftp.com server."] = "The latest version could not be retrieved from the net2ftp.com server. Check the security settings of your browser, which may prevent the loading of a small file from the net2ftp.com server.";

$messages["Logging"] = "Logging";
$messages["Date from:"] = "Date from:";
$messages["to:"] = "to:";
$messages["Empty logs"] = "Empty";
$messages["View logs"] = "View logs";
$messages["No data"] = "No data";

$messages["Setup MySQL tables"] = "Setup MySQL tables";
$messages["Go"] = "Go";
$messages["Create the MySQL database tables"] = "Create the MySQL database tables";
$messages["Create tables"] = "Create tables";
$messages["The handle of file %1\$s could not be opened"] = "The handle of file %1\$s could not be opened";
$messages["The file %1\$s could not be opened"] = "The file %1\$s could not be opened";
$messages["The handle of file %1\$s could not be closed"] = "The handle of file %1\$s could not be closed";
$messages["MySQL username"] = "MySQL username";
$messages["MySQL password"] = "MySQL password";
$messages["MySQL database"] = "MySQL database";
$messages["MySQL server"] = "MySQL server";
$messages["This SQL query is going to be executed:"] = "This SQL query is going to be executed:";
$messages["Execute"] = "Execute";
$messages["Settings used:"] = "Settings used:";
$messages["MySQL password length"] = "MySQL password length";
$messages["Results:"] = "Results:";
$messages["The connection to the server <b>%1\$s</b> could not be set up"] = "The connection to the server <b>%1\$s</b> could not be set up";
$messages["Unable to select the database <b>%1\$s</b>"] = "Unable to select the database <b>%1\$s</b>";
$messages["The SQL query could not be executed"] = "The SQL query could not be executed";
$messages["The tables were created successfully"] = "The tables were created successfully";

$messages["Beta functions"] = "Beta functions";
$messages["View logs"] = "View logs";
$messages["Empty logs"] = "Empty logs";
$messages["The table <b>%1\$s</b> was emptied successfully."] = "The table <b>%1\$s</b> was emptied successfully.";
$messages["The table <b>%1\$s</b> could not be emptied."] = "The table <b>%1\$s</b> could not be emptied.";
$messages["The table <b>%1\$s</b> was optimized successfully."] = "The table <b>%1\$s</b> was optimized successfully.";
$messages["The table <b>%1\$s</b> could not be optimized."] = "The table <b>%1\$s</b> could not be optimized.";

} // end admin

// -------------------------------------------------------------------------
// advanced.inc.php
if ($state == "advanced") {
// -------------------------------------------------------------------------

// advanced()
$messages["The site command functions are not available on this webserver."] = "The site command functions are not available on this webserver.";
$messages["The Apache functions are not available on this webserver."] = "The Apache functions are not available on this webserver.";
$messages["The MySQL functions are not available on this webserver."] = "The MySQL functions are not available on this webserver.";
$messages["Unexpected state2 string. Exiting."] = "Unexpected state2 string. Exiting.";

// printAdvancedFunctions()
$messages["Advanced functions"] = "Advanced functions";
$messages["Go"] = "Go";
$messages["Troubleshooting functions"] = "Troubleshooting functions";
$messages["Troubleshoot net2ftp on this webserver"] = "Troubleshoot net2ftp on this webserver";
$messages["Troubleshoot an FTP server"] = "Troubleshoot an FTP server";
$messages["Test the net2ftp list parsing rules"] = "Test the net2ftp list parsing rules";
$messages["Translation functions"] = "Translation functions";
$messages["Introduction to the translation functions"] = "Introduction to the translation functions";
$messages["Extract messages to translate from code files"] = "Extract messages to translate from code files";
$messages["Check if there are new or obsolete messages"] = "Check if there are new or obsolete messages";
$messages["Beta functions"] = "Beta functions";
$messages["Send a site command to the FTP server"] = "Send a site command to the FTP server";
$messages["Apache: password-protect a directory, create custom error pages"] = "Apache: password-protect a directory, create custom error pages";
$messages["MySQL: execute an SQL query"] = "MySQL: execute an SQL query";

// troubleshoot_webserver()
$messages["Troubleshoot your net2ftp installation"] = "Troubleshoot your net2ftp installation";
$messages["Checking if the FTP module of PHP is installed: "] = "Checking if the FTP module of PHP is installed: ";
$messages["yes"] = "yes";
$messages["no - please install it!"] = "no - please install it!";
$messages["Checking the permissions of the directory on the web server: a small file will be written to the /temp folder and then deleted."] = "Checking the permissions of the directory on the web server: a small file will be written to the /temp folder and then deleted.";
$messages["Creating filename: "] = "Creating filename: ";
$messages["OK. Filename: %1\$s"] = "OK. Filename: %1\$s";
$messages["not OK"] = "not OK";
$messages["OK"] = "OK";
$messages["not OK. Check the permissions of the %1\$s directory"] = "not OK. Check the permissions of the %1\$s directory";
$messages["Opening the file in write mode: "] = "Opening the file in write mode: ";
$messages["Writing some text to the file: "] = "Writing some text to the file: ";
$messages["Closing the file: "] = "Closing the file: ";
$messages["Deleting the file: "] = "Deleting the file: ";

// troubleshoot_ftpserver()
$messages["Troubleshoot an FTP server"] = "Troubleshoot an FTP server";
$messages["FTP server port"] = "FTP server port";
$messages["Connection settings:"] = "Connection settings:";
$messages["Password length"] = "Password length";
$messages["Language"] = "L�ngua";
$messages["Skin number"] = "N�mero tema";
$messages["Connecting to the FTP server: "] = "Connecting to the FTP server: ";
$messages["Logging into the FTP server: "] = "Logging into the FTP server: ";
$messages["Setting the passive mode: "] = "Setting the passive mode: ";
$messages["Getting the FTP server system type: "] = "Getting the FTP server system type: ";
$messages["Changing to the directory %1\$s: "] = "Changing to the directory %1\$s: ";
$messages["The directory from the FTP server is: %1\$s "] = "The directory from the FTP server is: %1\$s ";
$messages["Getting the raw list of directories and files: "] = "Getting the raw list of directories and files: ";
$messages["Trying a second time to get the raw list of directories and files: "] = "Trying a second time to get the raw list of directories and files: ";
$messages["Closing the connection: "] = "Closing the connection: ";
$messages["Raw list of directories and files:"] = "Raw list of directories and files:";
$messages["Parsed list of directories and files:"] = "Parsed list of directories and files:";

// test_list_parsing()
$messages["Sample input"] = "Sample input";
$messages["Parsed output"] = "Parsed output";
$messages["Test list parsing message"]  = "";
$messages["Test list parsing message"] .= "Every FTP server sends the list of directories and files in a different format.\n";
$messages["Test list parsing message"] .= "net2ftp has to parse this in order to identify the filename, the file size, the modification time, etc.";
$messages["Test list parsing message"] .= "This function tests the net2ftp parsing rules on a set of samples.";

// printTranslationFunctions()
$messages["net2ftp translation functions"] = "net2ftp translation functions";
$messages["A PHP application can be translated using the standard <a href=\"http://www.php.net/gettext\">gettext</a> functions, or using a self-made translation function."] = "A PHP application can be translated using the standard <a href=\"http://www.php.net/gettext\">gettext</a> functions, or using a self-made translation function.";
$messages["In both cases, the steps to take are similar."] = "In both cases, the steps to take are similar.";
$messages["Step 1: change code"] = "Step 1: change code";
$messages["All messages must be translated using a translation function, for example translate()."] = "All messages must be translated using a translation function, for example translate().";
$messages["This Hello World code:"] = "This Hello World code:";
$messages["must be changed to this:"] = "must be changed to this:";
$messages["Step 2: extract messages"] = "Step 2: extract messages";
$messages["All messages which are used by the translate() function must be extracted from the code files, and copied to a <b>main message file</b>."] = "All messages which are used by the translate() function must be extracted from the code files, and copied to a <b>main message file</b>.";
$messages["Step 3: translate messages"] = "Step 3: translate messages";
$messages["The main message file is given to translators, who rename the file and replace the messages in English by the translation."] = "The main message file is given to translators, who rename the file and replace the messages in English by the translation.";
$messages["The translators return the <b>translated message files</b>."] = "The translators return the <b>translated message files</b>.";
$messages["Each time the application is modified, a new main message file must be generated, as in step 2."] = "Each time the application is modified, a new main message file must be generated, as in step 2.";
$messages["In order to avoid translating everything all over again, it must then be compared to all translated message files, to check if there are new or obsolete messages."] = "In order to avoid translating everything all over again, it must then be compared to all translated message files, to check if there are new or obsolete messages.";
$messages["net2ftp can help in step 2 to extract messages to translate from code files"] = "net2ftp can help in step 2 to extract messages to translate from code files";
$messages["net2ftp can help in step 4 to check if there are new or obsolete messages"] = "net2ftp can help in step 4 to check if there are new or obsolete messages";

// translate_extract()
$messages["Extract messages from code files"] = "Extract messages from code files";
$messages["Directory containing code files:"] = "Directory containing code files:";
$messages["Translation function used in the code:"] = "Translation function used in the code:";
$messages["File to generate:"] = "File to generate:";
$messages["Extracted messages:"] = "Extracted messages:";
$messages["No messages were found, so no file was put on the FTP server."] = "No messages were found, so no file was put on the FTP server.";
$messages["The main language file <b>%1\$s</b> was transferred to directory <b>%2\$s</b>."] = "The main language file <b>%1\$s</b> was transferred to directory <b>%2\$s</b>.";

// translate_check()
$messages["Main language file:"] = "Arquivo de linguagem:";
$messages["Directory containing translated language files:"] = "Diret�rio contendo arquivo de tradu��o:";
$messages["File %1\$s was skipped because it could not be read, or because it was empty."] = "File %1\$s was skipped because it could not be read, or because it was empty.";
$messages["File nr %1\$s <b>%2\$s</b>"] = "File nr %1\$s <b>%2\$s</b>";
$messages["New messages:"] = "New messages:";
$messages["Obsolete messages:"] = "Obsolete messages:";
$messages["All the files have been processed"] = "All the files have been processed";

// sendsitecommand()
$messages["Send site command"] = "Send site command";
$messages["Enter the site command"] = "Enter the site command";
$messages["The commands you can use depends on your FTP server. These commands are not standard and vary a lot from one server to the other."] = "The commands you can use depends on your FTP server. These commands are not standard and vary a lot from one server to the other.";
$messages["Note that net2ftp cannot display the output of the FTP server, it can only tell if the command returned TRUE or FALSE. This is not a limitation of net2ftp but of PHP, the language in which net2ftp is written."] = "Note that net2ftp cannot display the output of the FTP server, it can only tell if the command returned TRUE or FALSE. This is not a limitation of net2ftp but of PHP, the language in which net2ftp is written.";
$messages["The command <b>%1\$s</b> was executed successfully."] = "The command <b>%1\$s</b> was executed successfully.";

// apache(), mysqlfunctions()
// Not yet translated

} // end advanced



// -------------------------------------------------------------------------
// authorizations.inc.php
// -------------------------------------------------------------------------

// checkAuthorization()
$messages["The FTP server <b>%1\$s</b> is not in the list of allowed FTP servers."] = "The FTP server <b>%1\$s</b> is not in the list of allowed FTP servers.";
$messages["The FTP server <b>%1\$s</b> is in the list of banned FTP servers."] = "The FTP server <b>%1\$s</b> is in the list of banned FTP servers.";
$messages["Your IP address (%1\$s) is in the list of banned IP addresses."] = "Your IP address (%1\$s) is in the list of banned IP addresses.";
$messages["The FTP server port %1\$s may not be used."] = "The FTP server port %1\$s may not be used.";
$messages["You don't have the authorizations to view directory <b>%1\$s</b>."] = "You don't have the authorizations to view directory <b>%1\$s</b>.";

// logAccess(), logLogin(), logError()
// Not yet translated


// -------------------------------------------------------------------------
// bookmark.inc.php
if ($state == "bookmark") {
// -------------------------------------------------------------------------
$messages["Add this link to your bookmarks:"] = "Add this link to your bookmarks:";
$messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer: right-click on the link and choose \"Add to Favorites...\"";
$messages["Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\"";
$messages["Note: when you will use this bookmark, a popup window will ask you for your username and password."] = "Note: when you will use this bookmark, a popup window will ask you for your username and password.";

} // end bookmark


// -------------------------------------------------------------------------
// browse.inc.php
if ($state == "browse") {
// -------------------------------------------------------------------------

// browse()
$messages["Directories with names containing \' cannot be displayed correctly. They can only be deleted. Please go back and select another subdirectory."] = "Directories with names containing \' cannot be displayed correctly. They can only be deleted. Please go back and select another subdirectory.";

$messages["Consumption message"]  = "";
$messages["Consumption message"] .= "<b>Daily limit reached: you will not be able to transfer data</b><br /><br />\n";
$messages["Consumption message"] .= "In order to guarantee the fair use of the web server for everyone, the data transfer volume and script execution time are limited per user, and per day. Once this limit is reached, you can still browse the FTP server but not transfer data to/from it.<br /><br />\n";
$messages["Consumption message"] .= "If you need unlimited usage, please install net2ftp on your own web server.<br />\n";

// ftp_getlist()
$messages["The directory <b>%1\$s</b> does not exist or could not be selected, so the root directory <b>/</b> is shown instead."] = "The directory <b>%1\$s</b> does not exist or could not be selected, so the root directory <b>/</b> is shown instead.";

// printdirfilelist()
// Keep this short, it must fit in a small button!
$messages["New dir"] = "Nova pasta";
$messages["New file"] = "Novo arquivo";
$messages["HTML templates"] = "HTML templates";
$messages["Upload"] = "Enviar";
$messages["Java Upload"] = "Java Enviar";
$messages["Advanced"] = "Avan�ado";
$messages["Copy"] = "Copiar";
$messages["Move"] = "Mover";
$messages["Delete"] = "Apagar";
$messages["Rename"] = "Renomear";
$messages["Chmod"] = "Permiss�es";
$messages["Download"] = "Baixar";
$messages["Zip"] = "Compactar";
$messages["Size"] = "Tamanho";
$messages["Search"] = "Busca";
$messages["Go to the parent directory"] = "Ir para pasta inicial";
$messages["Transform selected entries: "] = "A��es poss�veis para as entradas selecionadas: ";
$messages["Make a new subdirectory in directory %1\$s"] = "Criar nova sub-pasta na pasta %1\$s";
$messages["Create a new file in directory %1\$s"] = "Criar novo arquivo na pasta %1\$s";
$messages["Create a website easily using ready-made templates"] = "Create a website easily using ready-made templates";
$messages["Upload new files in directory %1\$s"] = "Enviar novo arquivo na pasta %1\$s";
$messages["Upload directories and files using a Java applet"] = "Upload directories and files using a Java applet";
$messages["Go to the advanced functions"] = "Ir para fun��es avan�adas";
$messages["Copy the selected entries"] = "Copiar entradas selecionadas";
$messages["Move the selected entries"] = "Mover entradas selecionadas";
$messages["Delete the selected entries"] = "Deletar entradas selecionadas";
$messages["Rename the selected entries"] = "Renomear entradas selecionadas";
$messages["Chmod the selected entries (only works on Unix/Linux/BSD servers)"] = "Mudar permiss�es das entradas selecionadas";
$messages["Download a zip file containing all selected entries"] = "Compactar todos os selecionados e baixar";
$messages["Zip the selected entries to save or email them"] = "Compactar todos os selecionados e envi�-lo por e-mail";
$messages["Calculate the size of the selected entries"] = "Calcular o tamanho das entradas selecionadas";
$messages["Find files which contain a particular word"] = "Buscar arquivos que contenham uma palavra";
$messages["Click to sort by %1\$s in descending order"] = "Clique para classificar por %1\$s - descendente";
$messages["Click to sort by %1\$s in ascending order"] = "Clique para classificar por %1\$s - ascendente";
$messages["Ascending order"] = "Ordem crescente";
$messages["Descending order"] = "Ordem decrescente";
//$messages["Click to sort by %1\$s in ascending order"] = "Clique para classificar por %1\$s - ascendente";
$messages["Up"] = "Acima";
$messages["Click to check or uncheck all rows"] = "Clique para ligar ou desligar todas as linhas";
$messages["All"] = "Todas";
$messages["Name"] = "Nome";
$messages["Type"] = "Tipo";
//$messages["Size"] = "Tamanho";
$messages["Owner"] = "Dono";
$messages["Group"] = "Grupo";
$messages["Perms"] = "Perm.";
$messages["Mod Time"] = "Mod Time";
$messages["Actions"] = "A��es";
$messages["Download the file %1\$s"] = "Baixar o arquivo %1\$s";
$messages["View"] = "Ver";
$messages["Edit"] = "Editar";
$messages["Update"] = "Atualizar";
$messages["Open"] = "Abrir";
$messages["View the highlighted source code of file %1\$s"] = "View the highlighted source code of file %1\$s";
$messages["Edit the source code of file %1\$s"] = "Edit the source code of file %1\$s";
$messages["Upload a new version of the file %1\$s and merge the changes"] = "Enviar nova vers�o do arquivo %1\$s e mesclar mudan�as";
$messages["View image %1\$s"] = "Ver imagem %1\$s";
$messages["View the file %1\$s from your HTTP web server"] = "Ver o arquivo %1\$s do seu servidor HTTP";
$messages["(Note: This link may not work if you don't have your own domain name.)"] = "(Nota: Este link pode n�o funcionar se voc� tiver seu pr�prio dom�nio.)";
$messages["This folder is empty"] = "Pasta vazia";

// printSeparatorRow()
$messages["Directories"] = "Pastas";
$messages["Files"] = "Arquivos";
$messages["Symlinks"] = "Link simb�lico";
$messages["Unrecognized FTP output"] = "Saida FPT desconhecida";
$messages["Number"] = "Number";
$messages["Size"] = "Size";
$messages["Skipped"] = "Skipped";

// printLocationActions()
$messages["Language:"] = "L�ngua:";
$messages["Skin:"] = "Tema:";
$messages["View mode:"] = "Modo de vis�o:";
$messages["Directory Tree"] = "�rvore de pastas";

// printURL()
$messages["Execute %1\$s in a new window"] = "Execute %1\$s in a new window";

// printDirectorySelect()
$messages["Double-click to go to a subdirectory:"] = "Duplo clique para ir para uma sub-pasta:";
$messages["Choose"] = "Escolha";
$messages["Up"] = "Subir um n�vel nas pastas";

} // end browse


// -------------------------------------------------------------------------
// consumption.inc.php
// -------------------------------------------------------------------------
$messages["Unable to determine your IP address."] = "Unable to determine your IP address.";
$messages["Table net2ftp_logConsumptionIpaddress contains duplicate rows."] = "Table net2ftp_logConsumptionIpaddress contains duplicate rows.";
$messages["Table net2ftp_logConsumptionFtpserver contains duplicate rows."] = "Table net2ftp_logConsumptionFtpserver contains duplicate rows.";
$messages["The variable <b>consumption_ipaddress_dataTransfer</b> is not numeric."] = "The variable <b>consumption_ipaddress_dataTransfer</b> is not numeric.";
$messages["Table net2ftp_logConsumptionIpaddress could not be updated."] = "Table net2ftp_logConsumptionIpaddress could not be updated.";
$messages["Table net2ftp_logConsumptionIpaddress contains duplicate entries."] = "Table net2ftp_logConsumptionIpaddress contains duplicate entries.";
$messages["Table net2ftp_logConsumptionFtpserver could not be updated."] = "Table net2ftp_logConsumptionFtpserver could not be updated.";
$messages["Table net2ftp_logConsumptionFtpserver contains duplicate entries."] = "Table net2ftp_logConsumptionFtpserver contains duplicate entries.";
$messages["Daily limit reached: the file <b>%1\$s</b> will not be transferred"] = "Daily limit reached: the file <b>%1\$s</b> will not be transferred";


// -------------------------------------------------------------------------
// database.inc.php
// -------------------------------------------------------------------------
$messages["Unable to connect to the DB"] = "Unable to connect to the DB";
$messages["Unable to select the DB"] = "Unable to select the DB";


// -------------------------------------------------------------------------
// easywebsite.inc.php
if ($state == "easyWebsite") {
// -------------------------------------------------------------------------
$messages["Create a website in 4 easy steps"] = "Create a website in 4 easy steps";
$messages["Template overview"] = "Template overview";
$messages["Template details"] = "Template details";
$messages["Files are copied"] = "Files are copied";
$messages["Edit your pages"] = "Edit your pages";

// Screen 1 - printTemplateOverview
$messages["Click on the image to view the details of a template."] = "Click on the image to view the details of a template.";
$messages["Back to the Browse screen"] = "Back to the Browse screen";
$messages["Template"] = "Template";
$messages["Click on the image to view the details of this template"] = "Click on the image to view the details of this template";

// Screen 2 - printTemplateDetails
$messages["The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?"] = "The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?";
$messages["Preview"] = "Preview";
$messages["Install"] = "Install";
$messages["Size"] = "Size";
$messages["Preview page"] = "Preview page";
$messages["opens in a new window"] = "opens in a new window";

// Screen 3
$messages["Please wait while the template files are being transferred to your server: "] = "Please wait while the template files are being transferred to your server: ";
$messages["Done."] = "Done.";
$messages["Continue"] = "Continue";

// Screen 4 - printEasyAdminPanel
$messages["Edit page"] = "Edit page";
$messages["Browse the FTP server"] = "Browse the FTP server";
$messages["Add this link to your favorites to return to this page later on!"] = "Add this link to your favorites to return to this page later on!";
$messages["Edit website at %1\$s"] = "Edit website at %1\$s";
$messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer: right-click on the link and choose \"Add to Favorites...\"";
$messages["Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\"";

// ftp_copy_local2ftp
$messages["WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing..."] = "WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing...";
$messages["Created target subdirectory <b>%1\$s</b>"] = "Created target subdirectory <b>%1\$s</b>";
$messages["WARNING: Unable to copy the file <b>%1\$s</b>. Continuing..."] = "WARNING: Unable to copy the file <b>%1\$s</b>. Continuing...";
$messages["Copied file <b>%1\$s</b>"] = "Copied file <b>%1\$s</b>";
}


// -------------------------------------------------------------------------
// edit.inc.php
if ($state == "manage" && ($state2 == "edit" || $state2 == "newfile")) {
// -------------------------------------------------------------------------

// edit()
$messages["Unable to open the template file"] = "Unable to open the template file";
$messages["Unable to read the template file"] = "Unable to read the template file";
$messages["Please specify a filename"] = "Please specify a filename";

// printEditForm()
$messages["Directory: "] = "Pasta: ";
$messages["File: "] = "Arquivo: ";
$messages["New file name: "] = "Nome do novo arquivo: ";
$messages["Note: changing the textarea type will save the changes"] = "Nota: mudando o tipo da �rea de texto, as mudan�as ser�o preservadas";
$messages["Status: This file has not yet been saved"] = "Status: O arquivo ainda n�o foi salvo";
$messages["Status: Saved on <b>%1\$s</b> using mode %2\$s"] = "Status: Salvo como <b>%1\$s</b> usando modo %2\$s";
$messages["Status: <b>This file could not be saved</b>"] = "Status: <b>Este arquivo n�o p�de ser salvo</b>";

} // end if edit newfile


// -------------------------------------------------------------------------
// errorhandling.inc.php
// -------------------------------------------------------------------------
$messages["An error has occured"] = "Ocorreu um erro";
$messages["Go back"] = "Voltar";
$messages["Go to the login page"] = "Voltar para o login";


// -------------------------------------------------------------------------
// filesystem.inc.php
// -------------------------------------------------------------------------

// ftp_openconnection()
$messages["The <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this FTP module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">php.net</a><br />"] = "The <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this FTP module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">php.net</a><br />";
$messages["Unable to connect to FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "Unable to connect to FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />";
$messages["Unable to login to FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "Unable to login to FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />";
$messages["Unable to switch to the passive mode on FTP server <b>%1\$s</b>."] = "Unable to switch to the passive mode on FTP server <b>%1\$s</b>.";

// ftp_openconnection2()
$messages["Unable to connect to the second (target) FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the second (target) FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "Unable to connect to the second (target) FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the second (target) FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />";
$messages["Unable to login to the second (target) FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "Unable to login to the second (target) FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />";
$messages["Unable to switch to the passive mode on the second (target) FTP server <b>%1\$s</b>."] = "Unable to switch to the passive mode on the second (target) FTP server <b>%1\$s</b>.";

// ftp_myrename()
$messages["Unable to rename directory or file <b>%1\$s</b> into <b>%2\$s</b>"] = "Unable to rename directory or file <b>%1\$s</b> into <b>%2\$s</b>";

// ftp_mychmod()
$messages["Unable to execute site command <b>%1\$s</b>. Note that the CHMOD command is only available on Unix FTP servers, not on Windows FTP servers."] = "Unable to execute site command <b>%1\$s</b>. Note that the CHMOD command is only available on Unix FTP servers, not on Windows FTP servers.";
$messages["Directory <b>%1\$s</b> successfully chmodded to <b>%2\$s</b>"] = "Directory <b>%1\$s</b> successfully chmodded to <b>%2\$s</b>";
$messages["File <b>%1\$s</b> was successfully chmodded to <b>%2\$s</b>"] = "File <b>%1\$s</b> was successfully chmodded to <b>%2\$s</b>";
$messages["All the selected directories and files have been processed."] = "All the selected directories and files have been processed.";

// ftp_rmdir2()
$messages["Unable to delete the directory <b>%1\$s</b>"] = "Unable to delete the directory <b>%1\$s</b>";

// ftp_delete2()
$messages["Unable to delete the file <b>%1\$s</b>"] = "Unable to delete the file <b>%1\$s</b>";

// ftp_newdirectory()
$messages["Unable to create the directory <b>%1\$s</b>"] = "Unable to create the directory <b>%1\$s</b>";

// ftp_readfile()
$messages["Unable to create the temporary file"] = "Unable to create the temporary file";
$messages["Unable to get the file <b>%1\$s</b> from the FTP server and to save it as temporary file <b>%2\$s</b>.<br />Check the permissions of the %3\$s directory.<br />"] = "Unable to get the file <b>%1\$s</b> from the FTP server and to save it as temporary file <b>%2\$s</b>.<br />Check the permissions of the %3\$s directory.<br />";
$messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "Unable to open the temporary file. Check the permissions of the %1\$s directory.";
$messages["Unable to read the temporary file"] = "Unable to read the temporary file";
$messages["Unable to close the handle of the temporary file"] = "Unable to close the handle of the temporary file";
$messages["Unable to delete the temporary file"] = "Unable to delete the temporary file";

// ftp_writefile()
$messages["Unable to create the temporary file. Check the permissions of the %1\$s directory."] = "Unable to create the temporary file. Check the permissions of the %1\$s directory.";
$messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "Unable to open the temporary file. Check the permissions of the %1\$s directory.";
$messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory.";
$messages["Unable to close the handle of the temporary file"] = "Unable to close the handle of the temporary file";
$messages["Unable to put the file <b>%1\$s</b> on the FTP server.<br />You may not have write permissions on the directory."] = "Unable to put the file <b>%1\$s</b> on the FTP server.<br />You may not have write permissions on the directory.";
$messages["Unable to delete the temporary file"] = "Unable to delete the temporary file";

// ftp_copymovedelete()
$messages["Processing directory <b>%1\$s</b>"] = "Processando pasta <b>%1\$s</b>";
$messages["The target directory <b>%1\$s</b> is the same as or a subdirectory of the source directory <b>%2\$s</b>, so this directory will be skipped"] = "A pasta destino <b>%1\$s</b> � a mesma ou a sub-pasta est� na mesma pasta de origem <b>%2\$s</b>. Esta pasta ser� desconsiderada.";
$messages["Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing the copy/move process..."] = "N�o p�de criar a sub-pasta <b>%1\$s</b>. Pode j� existir. Continuando processo de copiar/mover ..";
$messages["Created target subdirectory <b>%1\$s</b>"] = "Sub-pasta destino criada <b>%1\$s</b>";
$messages["Unable to delete the subdirectory <b>%1\$s</b> - it may not be empty"] = "N�o p�de apagar a sub-pasta <b>%1\$s</b> - pode n�o estar vazia";
$messages["Deleted subdirectory <b>%1\$s</b>"] = "Apagando subpasta <b>%1\$s</b>";
$messages["Processing of directory <b>%1\$s</b> completed"] = "Processando a pasta <b>%1\$s</b> completo";
$messages["The target for file <b>%1\$s</b> is the same as the source, so this file will be skipped"] = "The target for file <b>%1\$s</b> is the same as the source, so this file will be skipped";
$messages["Unable to copy the file <b>%1\$s</b>"] = "N�o p�de copiar o arquivo <b>%1\$s</b>";
$messages["Copied file <b>%1\$s</b>"] = "Arquivo copiado <b>%1\$s</b>";
$messages["Unable to move the file <b>%1\$s</b>"] = "N�o p�de mover o arquivo <b>%1\$s</b>";
$messages["Moved file <b>%1\$s</b>"] = "Arquivo movido <b>%1\$s</b>";
$messages["Unable to delete the file <b>%1\$s</b>"] = "N�o p�de apagar o arquivo <b>%1\$s</b>";
$messages["Deleted file <b>%1\$s</b>"] = "Arquivo apagado <b>%1\$s</b>";
$messages["All the selected directories and files have been processed."] = "Todas as pastas e arquivos selecionados foram processados.";

// ftp_processfiles()

// ftp_getfile()
$messages["Unable to copy the remote file <b>%1\$s</b> to the local file using FTP mode <b>%2\$s</b>"] = "Unable to copy the remote file <b>%1\$s</b> to the local file using FTP mode <b>%2\$s</b>";
$messages["Unable to delete file <b>%1\$s</b>"] = "Unable to delete file <b>%1\$s</b>";

// ftp_putfile()
$messages["Unable to copy the local file to the remote file <b>%1\$s</b> using FTP mode <b>%2\$s</b>"] = "Unable to copy the local file to the remote file <b>%1\$s</b> using FTP mode <b>%2\$s</b>";
$messages["Unable to delete the local file"] = "Unable to delete the local file";

// ftp_downloadfile()
$messages["Unable to delete the temporary file"] = "Unable to delete the temporary file";
$messages["Unable to send the file to the browser"] = "Unable to send the file to the browser";

// ftp_zip()
$messages["Unable to create the temporary file"] = "Unable to create the temporary file";
$messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory.";
$messages["Unable to close the handle of the temporary file"] = "Unable to close the handle of the temporary file";
$messages["The zip file has been saved on the FTP server as <b>%1\$s</b>"] = "O arquivo compactado foi salvo no servidor FPT como <b>%1\$s</b>";
$messages["Requested files"] = "Requested files";

$messages["Zip email message"]  = "";
$messages["Zip email message"] .= "Dear, \n\n";
$messages["Zip email message"] .= "Someone has requested the files in attachment to be sent to this email account (%1\$s).\n";
$messages["Zip email message"] .= "If you know nothing about this or if you don't trust that person, please delete this email without opening the Zip file in attachment.\n";
$messages["Zip email message"] .= "Note that if you don't open the Zip file, the files inside cannot harm your computer.\n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "Information about the sender:\n";
$messages["Zip email message"] .= "IP address: %2\$s\n";
$messages["Zip email message"] .= "Time of sending: %3\$s\n";
$messages["Zip email message"] .= "Sent via the net2ftp application installed on this website: %4\$s \n";
$messages["Zip email message"] .= "Webmaster's email: %5\$s \n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "Message of the sender:\n";
$messages["Zip email message"] .= "%6\$s \n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "net2ftp is free software, released under the GNU/GPL license. For more information, go to http://www.net2ftp.com\n\n\n";

$messages["The zip file has been sent to <b>%1\$s</b>."] = "O arquivo compactado foi enviado para <b>%1\$s</b>.";

// acceptFiles()
$messages["File <b>%1\$s</b> is too big. This file will not be uploaded."] = "File <b>%1\$s</b> is too big. This file will not be uploaded.";
$messages["Could not generate a temporary file."] = "Could not generate a temporary file.";
$messages["File <b>%1\$s</b> could not be moved"] = "File <b>%1\$s</b> could not be moved";
$messages["File <b>%1\$s</b> is OK"] = "File <b>%1\$s</b> is OK";
$messages["Unable to move the uploaded file to the temp directory.<br /><br />The administrator of this website has to <b>chmod 777</b> the /temp directory of net2ftp."] = "Unable to move the uploaded file to the temp directory.<br /><br />The administrator of this website has to <b>chmod 777</b> the /temp directory of net2ftp.";
$messages["You did not provide any file to upload."] = "You did not provide any file to upload.";

// ftp_transferfiles()
$messages["File <b>%1\$s</b> could not be transferred to the FTP server"] = "File <b>%1\$s</b> could not be transferred to the FTP server";
$messages["File <b>%1\$s</b> has been transferred to the FTP server using FTP mode <b>%2\$s</b>"] = "File <b>%1\$s</b> has been transferred to the FTP server using FTP mode <b>%2\$s</b>";
$messages["Transferring files to the FTP server"] = "Transferring files to the FTP server";

// ftp_unziptransferfiles()
$messages["Processing archive nr %1\$s: <b>%2\$s</b>"] = "Processando arquivo n� %1\$s: <b>%2\$s</b>";
$messages["Unable to open the archive <b>%1\$s</b> (file %2\$s)"] = "Impossibilitado de abrir o arquivo <b>%1\$s</b> (file %2\$s)";
$messages["Could not create directory <b>%1\$s</b>"] = "Pasta n�o p�de ser criada <b>%1\$s</b>";
$messages["Created directory <b>%1\$s</b>"] = "Pasta criada <b>%1\$s</b>";
$messages["File Contents:"] = "Conte�dos arquivo:";
$messages["Could not put the file <b>%1\$s</b> to the directory <b>%2\$s</b>"] = "N�o p�de colocar o arquivo <b>%1\$s</b> na pasta <b>%2\$s</b>";
$messages["Transferred file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "Arquivo transferido <b>%1\$s</b> para a pasta <b>%2\$s</b>";
$messages["Unable to delete the archive <b>%1\$s</b> (file %2\$s)"] = "N�o p�de apagar o arquivo <b>%1\$s</b> (arquivo %2\$s)";
$messages["Unable to get the list of the contents of the Zip archive. Error code: %1\$s"] = "N�o p�de ler o conte�do do arquivo Zip. C�digo de erro: %1\$s";
$messages["Unable to get the list of the contents of the Tar archive."] = "N�o p�de ler o conte�do do arquivo Tar.";
$messages["Could not create directory <b>%1\$s</b>"] = "N�o p�de criar a pasta <b>%1\$s</b>";
$messages["Created directory <b>%1\$s</b>"] = "Pasta criada <b>%1\$s</b>";
$messages["Unable to create the temporary file"] = "Arquivo tempor�rio n�o p�de ser criado ";
$messages["Unable to extract file nr <b>%1\$s</b> from the archive."] = "N�o p�de extrair o arquivo n� <b>%1\$s</b> do arquivo.";
$messages["Could not put file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "N�o p�de colocar o arquivo <b>%1\$s</b> na pasta <b>%2\$s</b>";
$messages["Transferred file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "Transferindo arquivo <b>%1\$s</b> para a pasta <b>%2\$s</b>";
$messages["Unable to delete the temporary file <b>%1\$s</b>."] = "Arquivo tempor�rio n�o p�de ser apagado <b>%1\$s</b>.";
$messages["Archive <b>%1\$s</b> was not processed because its filename extension was not recognized. Only zip, tar, tgz and gz archives are supported at the moment."] = "Arquivo <b>%1\$s</b> n�o p�de ser processado porque a extens�o � desconhecida. Somente zip, tar, tgz and gz s�o suportados.";
$messages["Unzipping and transferring files"] = "Descompactando e transferindo arquivos";

// ftp_mysite()
$messages["Unable to execute site command <b>%1\$s</b>"] = "Unable to execute site command <b>%1\$s</b>";

// shutdown()
$messages["Shutdown message"]  = "";
$messages["Shutdown message"] .= "<b>Your task was stopped</b><br /><br />";
$messages["Shutdown message"] .= "The task you wanted to perform with net2ftp took more time than the allowed %1\$s seconds, and therefor that task was stopped.<br />";
$messages["Shutdown message"] .= "This time limit guarantees the fair use of the web server for everyone.<br /><br />";
$messages["Shutdown message"] .= "Try to split your task in smaller tasks: restrict your selection of files, and omit the biggest files.<br /><br />";
$messages["Shutdown message"] .= "If you really need net2ftp to be able to handle big tasks which take a long time, consider installing net2ftp on your own server.";

// SendMail()
$messages["You did not provide any text to send by email!"] = "You did not provide any text to send by email!";
$messages["You did not supply a From address."] = "You did not supply a From address.";
$messages["You did not supply a To address."] = "You did not supply a To address.";
$messages["Due to technical problems the email to <b>%1\$s</b> could not be sent."] = "Due to technical problems the email to <b>%1\$s</b> could not be sent.";

// printFunctionTags()
$messages["Output generated by function %1\$s"] = "Output generated by function %1\$s";



// -------------------------------------------------------------------------
// homepage.inc.php
if ($state == "homepage") {
// -------------------------------------------------------------------------
$messages["net2ftp features short"]  = "Once you are logged in, you will be able to: \n";
$messages["net2ftp features short"] .= "<ul>\n";
$messages["net2ftp features short"] .= "<li> Navigate the FTP server<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "Once you have logged in, you can browse from directory to directory and see all the subdirectories and files.</span></li>\n";
$messages["net2ftp features short"] .= "<li> Upload files<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "There are 3 different ways to upload files: the standard upload form, the upload-and-unzip functionality, and the Java Applet.</span></li>\n";
$messages["net2ftp features short"] .= "<li> Download files<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "Click on a filename to quickly download one file.<br />\n";
$messages["net2ftp features short"] .= "Select multiple files and click on Download; the selected files will be downloaded in a zip archive.</span></li>\n";
$messages["net2ftp features short"] .= "<li> Zip files<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "... and save the zip archive on the FTP server, or email it to someone.</span></li>\n";
$messages["net2ftp features short"] .= "<li> Copy, move and delete<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "Directories are handled recursively, meaning that their content (subdirectories and files) will also be copied, moved or deleted.</span></li>\n";
$messages["net2ftp features short"] .= "<li> Copy or move to a 2nd FTP server<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "Handy to import files to your FTP server, or to export files from your FTP server to another FTP server.</span></li>\n";
$messages["net2ftp features short"] .= "<li> Rename and chmod<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "Chmod handles directories recursively.</span></li>\n";
$messages["net2ftp features short"] .= "<li> View code with syntax highlighting<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "PHP functions are linked to the documentation on php.net.</span></li>\n";
$messages["net2ftp features short"] .= "<li> Plain text editor<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "Edit text right from your browser; every time you save the changes the new file is transferred to the FTP server.</span></li>\n";
$messages["net2ftp features short"] .= "<li> HTML editors<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "Edit HTML a What-You-See-Is-What-You-Get (WYSIWYG) form; there are 3 different editors to choose from.</span></li>\n";
$messages["net2ftp features short"] .= "<li> Code editor<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "Edit HTML and PHP in an editor with syntax highlighting.</span></li>\n";
$messages["net2ftp features short"] .= "<li> Search for words or phrases<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "Filter out files based on the filename, last modification time and filesize.</span></li>\n";
$messages["net2ftp features short"] .= "<li> Calculate size<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "Calculate the size of directories and files.</span></li>\n";
$messages["net2ftp features short"] .= "</ul>\n";

} // end homepage


// -------------------------------------------------------------------------
// net2ftp_loginform.inc.php
// -------------------------------------------------------------------------
$messages["FTP server"] = "Servidor FTP";
$messages["Example"] = "Exemplo";
$messages["Username"] = "Usu�rio";
$messages["Password"] = "Senha";
$messages["Anonymous"] = "An�nimo";
$messages["Passive mode"] = "Modo passivo";
$messages["Initial directory"] = "Direct�rio inicial";
$messages["Language"] = "L�ngua";
$messages["Skin"] = "Tema";
$messages["FTP mode"] = "Modo FTP";
$messages["Login"] = "Login";
$messages["Clear cookies"] = "Apagar cookies";


// -------------------------------------------------------------------------
// html.inc.php
// -------------------------------------------------------------------------

// HtmlBegin()
$messages["Status:"] = "Status:";

// HtmlEnd()
$messages["net2ftp Help Guide"] = "net2ftp guia de ajuda";
$messages["net2ftp Forums"] = "net2ftp f�runs";
$messages["License"] = "License";
$messages["Powered by"] = "Powered by";

// printJavascriptFunctions()
$messages["Choose a directory"] = "Escolha um diret�rio";
$messages["Please wait..."] = "Aguarde ...";
$messages["Uploading... please wait..."] = "Enviando... aguarde ...";
$messages["If the upload takes more than the allowed <b>%1\$s seconds<\/b>, you will have to try again with less/smaller files."] = "If the upload takes more than the allowed <b>%1\$s seconds<\/b>, you will have to try again with less/smaller files.";
$messages["This window will close automatically in a few seconds."] = "This window will close automatically in a few seconds.";
$messages["Close window now"] = "Close window now";


// -------------------------------------------------------------------------
// httpheaders.inc.php
// -------------------------------------------------------------------------
// Nothing to translate


// -------------------------------------------------------------------------
// manage.inc.php
if ($state == "manage") {
// -------------------------------------------------------------------------

// manage()
$messages["Please select at least one directory or file!"] = "Selecione pelo menos um arquivo ou pasta!";
$messages["Unexpected state2 string. Exiting."] = "Unexpected state2 string. Exiting.";

// renameentry()
if ($state2 == "rename") {
$messages["Rename directories and files"] = "Renomear pastas e arquivos";
$messages["Old name: "] = "Nome antigo: ";
$messages["New name: "] = "Novo nome: ";
$messages["The new name may not contain any dots. This entry was not renamed to <b>%1\$s</b>"] = "O novo nome n�o pode conter pontos. Esta entrada n�o ser� renomeada para <b>%1\$s</b>";
$messages["<b>%1\$s</b> was successfully renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> renomeado com sucesso para <b>%2\$s</b>";
$messages["<b>%1\$s</b> could not be renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> n�o p�de ser renomeado para <b>%2\$s</b>";
}

// chmodentry()
if ($state2 == "chmod") {
$messages["Chmod directories and files"] = "Chmod pastas e arquivos";
$messages["Set all permissions"] = "Selecione todas";
$messages["Read"] = "Ler";
$messages["Write"] = "Gravar";
$messages["Execute"] = "Executar";
$messages["Owner"] = "Dono";
$messages["Group"] = "Grupo";
$messages["Everyone"] = "Todos";
$messages["To set all permissions to the same values, enter those permissions above and click on the button \"Set all permissions\""] = "Para ajustar todas as permiss�es aos mesmos valores, clique no bot�o \"Selecione todas\"";
$messages["Set the permissions of directory <b>%1\$s</b> to: "] = "Ajustar permiss�es para a pasta <b>%1\$s</b> para: ";
$messages["Set the permissions of file <b>%1\$s</b> to: "] = "Ajustar permiss�es do arquivo <b>%1\$s</b> para: ";
$messages["Set the permissions of symlink <b>%1\$s</b> to: "] = "Ajustar permiss�es para link simb�lico <b>%1\$s</b> para: ";
$messages["Chmod value"] = "Valor";
$messages["Chmod also the subdirectories within this directory"] = "Mude permiss�es das sub-pastas desta pasta";
$messages["Chmod also the files within this directory"] = "Mude permiss�es dos arquivos desta pasta";
$messages["The chmod nr <b>%1\$s</b> is out of the range 000-777. Please try again."] = "The chmod nr <b>%1\$s</b> is out of the range 000-777. Please try again.";
}

// copymovedeleteentry()
if ($state2 == "copy" || $state2 == "move" || $state2 == "delete") {
$messages["Copy directories and files"] = "Copiar pastas e arquivos";
$messages["Move directories and files"] = "Mover pastas e arquivos";
$messages["Delete directories and files"] = "Apagar pastas e arquivos";
$messages["Are you sure you want to delete these directories and files?"] = "Voc� tem certeza que deseja apagar estas pastas e arquivos?";
$messages["All the subdirectories and files of the selected directories will also be deleted!"] = "Todas as sub-pastas e arquivos da pasta selecionada ser�o apagados!";
$messages["Set all targetdirectories"] = "Selecione como destino";
$messages["To set a common target directory, enter that target directory in the textbox above and click on the button \"Set all targetdirectories\"."] = "Para escolher uma pasta de destino, selecione a pasta desejada e pressione o bot�o \"Selecione como destino\".";
$messages["Note: the target directory must already exist before anything can be copied into it."] = "Nota: a pasta destino dever� existir antes de iniciar a c�pia para ela.";
$messages["Different target FTP server:"] = "Servidor FTP diferente:";
$messages["Leave empty if you want to copy the files to the same FTP server."] = "Deixe vazio se desejar copiar para o mesmo servidor FTP.";
$messages["If you want to copy the files to another FTP server, enter your login data."] = "Se desejar copiar para outro servidor FTP, entre com seus dados de login.";
$messages["Leave empty if you want to move the files to the same FTP server."] = "Deixe vazio se desejar copiar para o mesmo servidor FTP.";
$messages["If you want to move the files to another FTP server, enter your login data."] = "Se desejar mover para outro servidor FTP, entre com seus dados de login.";
$messages["Copy directory <b>%1\$s</b> to:"] = "Copiar pasta <b>%1\$s</b> para:";
$messages["Move directory <b>%1\$s</b> to:"] = "Mover pasta <b>%1\$s</b> para:";
$messages["Directory <b>%1\$s</b>"] = "Pasta <b>%1\$s</b>";
$messages["Copy file <b>%1\$s</b> to:"] = "Copiar arquivo <b>%1\$s</b> para:";
$messages["Move file <b>%1\$s</b> to:"] = "Mover arquivo <b>%1\$s</b> para:";
$messages["File <b>%1\$s</b>"] = "Arquivo <b>%1\$s</b>";
$messages["Copy symlink <b>%1\$s</b> to:"] = "Copy symlink <b>%1\$s</b> para:";
$messages["Move symlink <b>%1\$s</b> to:"] = "Move symlink <b>%1\$s</b> para:";
$messages["Symlink <b>%1\$s</b>"] = "Link simb�lico <b>%1\$s</b>";
$messages["Target directory:"] = "Pasta destino:";
$messages["Target name:"] = "Nome destino:";
$messages["Processing the entries:"] = "Processando a entrada:";
}

// newdirectory()
if ($state2 == "newdirectory") {
$messages["Create new directories"] = "Criar nova pasta";
$messages["The new directories will be created in <b>%1\$s</b>."] = "A nova pasta ser� criada em <b>%1\$s</b>.";
$messages["New directory name:"] = "Nome da nova pasta:";
$messages["Directory <b>%1\$s</b> was successfully created."] = "Pasta <b>%1\$s</b> criada com sucesso.";
}

// uploadfile()
if ($state2 == "uploadfile") {
$messages["Upload files and archives"] = "Enviando arquivos";
$messages["Upload results"] = "Resultado do envio";
$messages["Checking files:"] = "Checando arquivos:";
$messages["Transferring files to the FTP server:"] = "Transferindo arquivos para o servidor:";
$messages["Decompressing archives and transferring files to the FTP server:"] = "Decomprimindo arquivos e transferindo para o servidor:";
$messages["Upload more files and archives"] = "Enviar mais arquivos";
}

// printUploadForm()
if ($state2 == "uploadfile") {
$messages["Upload to directory:"] = "Enviar para a pasta:";
$messages["Files"] = "Arquivos";
$messages["Archives"] = "Arquivos";
$messages["Files entered here will be transferred to the FTP server."] = "Os arquivos selecionados aqui, ser�o enviados para o servidor.";
$messages["Archives entered here will be decompressed, and the files inside will be transferred to the FTP server."] = "Os arquivos selecionados aqui, ser�o descompactados e enviado para o servidor.";
$messages["Add another"] = "Adicionar outro";
$messages["Use folder names (creates subdirectories automatically)"] = "Use os nomes das pastas (cria subpastas automaticamente)";
$messages["Restrictions:"] = "Restri��es:";
$messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s kB</b> and by PHP to <b>%2\$s</b>"] = "O tamanho m�ximo de arquivo limitado pelo net2ftp � <b>%1\$s kB</b> e pelo PHP � <b>%2\$s</b>";
$messages["The maximum execution time is <b>%1\$s seconds</b>"] = "O tempo m�ximo de execu��o � <b>%1\$s segundos</b>";
$messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "O modo de transfer�ncia (ASCII ou BINARY) ser� automaticamente determinado, baseado na extens�o do arquivo";
$messages["If the destination file already exists, it will be overwritten"] = "Se os arquivos j� existirem no destino, ser�o sobre-escritos";

$messages["Upload directories and files using a Java applet"] = "Upload directories and files using a Java applet";
$messages["Number of files:"] = "Number of files:";
$messages["Size of files:"] = "Size of files:";
$messages["Add"] = "Add";
$messages["Remove"] = "Remove";
$messages["Upload"] = "Upload";
$messages["Add files to the upload queue"] = "Add files to the upload queue";
$messages["Remove files from the upload queue"] = "Remove files from the upload queue";
$messages["Upload the files which are in the upload queue"] = "Upload the files which are in the upload queue";
$messages["Maximum server space exceeded. Please select less/smaller files."] = "Maximum server space exceeded. Please select less/smaller files.";
$messages["Total size of the files is too big. Please select less/smaller files."] = "Total size of the files is too big. Please select less/smaller files.";
$messages["Total number of files is too high. Please select fewer files."] = "Total number of files is too high. Please select fewer files.";
$messages["Note: to use this applet, Sun's Java plugin must be installed (version 1.4 or newer)."] = "Note: to use this applet, Sun's Java plugin must be installed (version 1.4 or newer).";

$messages["Browser does not support Java applets"] = "Your browser does not support applets, or you have disabled applets in your browser settings.\n";
$messages["Browser does not support Java applets"] .= "To use this applet, please install the newest version of Sun's java. You can get it from <a href=\"http://www.java.com/\">java.com</a>. Click on Get It Now.\n";
$messages["Browser does not support Java applets"] .= "The online installation is about 1-2 MB and the offline installation is about 13 MB. This 'end-user' java is called JRE (Java Runtime Environment).\n";
$messages["Browser does not support Java applets"] .= "Alternatively, use net2ftp's normal upload or upload-and-unzip functionality.\n";
}

// zipentry()
if ($state2 == "zip") {
$messages["Zip entries"] = "Arquivos ou pastas compactadas";
$messages["Save the zip file on the FTP server as:"] = "Salvar o arquivo compactado no servidor FTP como:";
$messages["Email the zip file in attachment to:"] = "Enviar o arquivo compactado como anexo para:";
$messages["Note that sending files is not anonymous: your IP address as well as the time of the sending will be added to the email."] = "Note que enviar um e-mail n�o � anonimo: seu IP ser� colocado no cabe�alho do e-mail ao ser enviado.";
$messages["Some additional comments to add in the email:"] = "Coment�rios adicionais a serem inseridos no e-mail:";
$messages["You did not enter a filename for the zipfile. Go back and enter a filename."] = "Voc� n�o forneu um nome para o arquivo compactado. Volte e forne�a um nome.";
$messages["The email address you have entered (%1\$s) does not seem to be valid.<br />Please enter an address in the format <b>username@domain.com</b>"] = "O e-mail informado (%1\$s) n�o parece ser v�lido.<br />Informe um e-mail no formato <b>usu�rio@dominio.com.br</b>";
}

// calculatesize()
if ($state2 == "calculatesize") {
$messages["Size of selected directories and files"] = "Tamanho das pastas e arquivos selecionados";
$messages["The total size taken by the selected directories and files is:"] = "O tamanho total das pastas e arquivos selecionados �:";
$messages["The nr of files which were skipped:"] = "N�mero de arquivos que foram desconsiderados:";
}

// findstring()
if ($state2 == "findstring") {
$messages["Search directories and files"] = "Search directories and files";
$messages["Search results"] = "Search results";
$messages["Please enter a valid search word or phrase."] = "Please enter a valid search word or phrase.";
$messages["Please enter a valid filename."] = "Please enter a valid filename.";
$messages["Please enter a valid file size in the \"from\" textbox, for example 0."] = "Please enter a valid file size in the \"from\" textbox, for example 0.";
$messages["Please enter a valid file size in the \"to\" textbox, for example 500000."] = "Please enter a valid file size in the \"to\" textbox, for example 500000.";
$messages["Please enter a valid date in Y-m-d format in the \"from\" textbox."] = "Please enter a valid date in Y-m-d format in the \"from\" textbox.";
$messages["Please enter a valid date in Y-m-d format in the \"to\" textbox."] = "Please enter a valid date in Y-m-d format in the \"to\" textbox.";
$messages["The word <b>%1\$s</b> was not found in the selected directories and files."] = "The word <b>%1\$s</b> was not found in the selected directories and files.";
$messages["The word <b>%1\$s</b> was found in the following files:"] = "The word <b>%1\$s</b> was found in the following files:";
$messages["Search again"] = "Search again";
}

// printFindstringForm()
if ($state2 == "findstring") {
$messages["Search for a word or phrase"] = "Procurar uma palavra ou frase";
$messages["Case sensitive search"] = "Diferenciar mai�sculas de min�sculas";
$messages["Restrict the search to:"] = "Restringir busca para:";
$messages["files with a filename like"] = "arquivos cujo nome seja";
$messages["(wildcard character is *)"] = "(o caracter coringa � o *)";
$messages["files with a size"] = "arquivos com tamanho";
$messages["from"] = "de";
$messages["to"] = "at�";
$messages["files which were last modified"] = "arquivos com a �ltima modifica��o";
}

// updatefile()
if ($state2 == "updatefile") {
$messages["Update file"] = "Update file";
$messages["<b>WARNING: THIS FUNCTION IS STILL IN EARLY DEVELOPMENT. USE IT ONLY ON TEST FILES! YOU HAVE BEEN WARNED!"] = "<b>WARNING: THIS FUNCTION IS STILL IN EARLY DEVELOPMENT. USE IT ONLY ON TEST FILES! YOU HAVE BEEN WARNED!";
$messages["Known bugs: - erases tab characters - doesn't work well with big files (> 50kB) - was not tested yet on files containing non-standard characters</b>"] = "Known bugs: - erases tab characters - doesn't work well with big files (> 50kB) - was not tested yet on files containing non-standard characters</b>";
$messages["This function allows you to upload a new version of the selected file, to view what are the changes and to accept or reject each change. Before anything is saved, you can edit the merged files."] = "This function allows you to upload a new version of the selected file, to view what are the changes and to accept or reject each change. Before anything is saved, you can edit the merged files.";
$messages["Old file:"] = "Old file:";
$messages["New file:"] = "New file:";
$messages["Restrictions:"] = "Restrictions:";
$messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s kB</b> and by PHP to <b>%2\$s</b>"] = "The maximum size of one file is restricted by net2ftp to <b>%1\$s kB</b> and by PHP to <b>%2\$s</b>";
$messages["The maximum execution time is <b>%1\$s seconds</b>"] = "The maximum execution time is <b>%1\$s seconds</b>";
$messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension";
$messages["If the destination file already exists, it will be overwritten"] = "If the destination file already exists, it will be overwritten";
$messages["You did not provide any files or archives to upload."] = "You did not provide any files or archives to upload.";
$messages["Unable to delete the new file"] = "Unable to delete the new file";
}

// printComparisonSelect()
if ($state2 == "updatefile") {
$messages["Please wait..."] = "Please wait...";
$messages["Select lines below, accept or reject changes and submit the form."] = "Select lines below, accept or reject changes and submit the form.";
}

} // end manage


// -------------------------------------------------------------------------
// registerglobals.inc.php
// -------------------------------------------------------------------------
$messages["Please enter your username and password for FTP server "] = "Please enter your username and password for FTP server ";
$messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below.";
$messages["Access to the net2ftp Admin panel is disabled, because no password has been set in the file settings.inc.php. Enter a password in that file, and reload this page."] = "Access to the net2ftp Admin panel is disabled, because no password has been set in the file settings.inc.php. Enter a password in that file, and reload this page.";
$messages["Please enter your Admin username and password"] = "Please enter your Admin username and password"; 
$messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below.";
$messages["Wrong username or password for the net2ftp Admin panel. The username and password can be set in the file settings.inc.php."] = "Wrong username or password for the net2ftp Admin panel. The username and password can be set in the file settings.inc.php.";


// -------------------------------------------------------------------------
// skins.inc.php
// -------------------------------------------------------------------------
$messages["Blue"] = "Blue";
$messages["Grey"] = "Grey";
$messages["Black"] = "Black";
$messages["Yellow"] = "Yellow";
$messages["Pastel"] = "Pastel";

// getMime()
$messages["Directory"] = "Pasta";
$messages["Symlink"] = "Link simb�lico";
$messages["ASP script"] = "ASP script";
$messages["Cascading Style Sheet"] = "Cascading Style Sheet";
$messages["HTML file"] = "Arquivo HTML";
$messages["Java source file"] = "Java source file";
$messages["JavaScript file"] = "JavaScript file";
$messages["PHP Source"] = "PHP Source";
$messages["PHP script"] = "PHP script";
$messages["Text file"] = "Arquivo texto";
$messages["Bitmap file"] = "Arquivo Bitmap";
$messages["GIF file"] = "Arquivo GIF";
$messages["JPEG file"] = "Arquivo JPEG";
$messages["PNG file"] = "Arquivo PNG";
$messages["TIF file"] = "Arquivo TIF";
$messages["GIMP file"] = "Arquivo GIMP";
$messages["Executable"] = "Execut�vel";
$messages["Shell script"] = "Shell script";
$messages["MS Office - Word document"] = "MS Office - Word document";
$messages["MS Office - Excel spreadsheet"] = "MS Office - Excel spreadsheet";
$messages["MS Office - PowerPoint presentation"] = "MS Office - PowerPoint presentation";
$messages["MS Office - Access database"] = "MS Office - Access database";
$messages["MS Office - Visio drawing"] = "MS Office - Visio drawing";
$messages["MS Office - Project file"] = "MS Office - Project file";
$messages["OpenOffice - Writer 6.0 document"] = "OpenOffice - Writer 6.0 document";
$messages["OpenOffice - Writer 6.0 template"] = "OpenOffice - Writer 6.0 template";
$messages["OpenOffice - Calc 6.0 spreadsheet"] = "OpenOffice - Calc 6.0 spreadsheet";
$messages["OpenOffice - Calc 6.0 template"] = "OpenOffice - Calc 6.0 template";
$messages["OpenOffice - Draw 6.0 document"] = "OpenOffice - Draw 6.0 document";
$messages["OpenOffice - Draw 6.0 template"] = "OpenOffice - Draw 6.0 template";
$messages["OpenOffice - Impress 6.0 presentation"] = "OpenOffice - Impress 6.0 presentation";
$messages["OpenOffice - Impress 6.0 template"] = "OpenOffice - Impress 6.0 template";
$messages["OpenOffice - Writer 6.0 global document"] = "OpenOffice - Writer 6.0 global document";
$messages["OpenOffice - Math 6.0 document"] = "OpenOffice - Math 6.0 document";
$messages["StarOffice - StarWriter 5.x document"] = "StarOffice - StarWriter 5.x document";
$messages["StarOffice - StarWriter 5.x global document"] = "StarOffice - StarWriter 5.x global document";
$messages["StarOffice - StarCalc 5.x spreadsheet"] = "StarOffice - StarCalc 5.x spreadsheet";
$messages["StarOffice - StarDraw 5.x document"] = "StarOffice - StarDraw 5.x document";
$messages["StarOffice - StarImpress 5.x presentation"] = "StarOffice - StarImpress 5.x presentation";
$messages["StarOffice - StarImpress Packed 5.x file"] = "StarOffice - StarImpress Packed 5.x file";
$messages["StarOffice - StarMath 5.x document"] = "StarOffice - StarMath 5.x document";
$messages["StarOffice - StarChart 5.x document"] = "StarOffice - StarChart 5.x document";
$messages["StarOffice - StarMail 5.x mail file"] = "StarOffice - StarMail 5.x mail file";
$messages["Adobe Acrobat document"] = "Adobe Acrobat document";
$messages["ARC archive"] = "Arquivo ARC";
$messages["ARJ archive"] = "Arquivo ARJ";
$messages["RPM"] = "RPM";
$messages["GZ archive"] = "Arquivo GZ";
$messages["TAR archive"] = "Arquivo TAR";
$messages["Zip archive"] = "Arquivo Zip";
$messages["MOV movie file"] = "Arquivo MOV movie file";
$messages["MPEG movie file"] = "Arquivo MPEG movie file";
$messages["Real movie file"] = "Real movie file";
$messages["Quicktime movie file"] = "Quicktime movie file";
$messages["Shockwave flash file"] = "Shockwave flash file";
$messages["Shockwave file"] = "Shockwave file";
$messages["WAV sound file"] = "WAV sound file";
$messages["Font file"] = "Font file";
$messages["%1\$s File"] = "%1\$s File";
$messages["File"] = "Arquivo";

// getAction()
$messages["Back"] = "Voltar";
$messages["Submit"] = "Submeter";
$messages["Refresh"] = "Atualizar";
$messages["Details"] = "Detalhes";
$messages["Icons"] = "�cones";
$messages["List"] = "Lista";
$messages["Logout"] = "Logout";
$messages["Help"] = "Ajuda";
$messages["Bookmark"] = "Favoritos";
$messages["Save"] = "Salvar";
$messages["Default"] = "Padr�o";


// -------------------------------------------------------------------------
// view.inc.php
// -------------------------------------------------------------------------
$messages["Image"] = "Image";
$messages["View Macromedia ShockWave Flash movie %1\$s"] = "View Macromedia ShockWave Flash movie %1\$s";
$messages["View file %1\$s"] = "View file %1\$s";
$messages["To save the image, right-click on it and choose 'Save picture as...'"] = "To save the image, right-click on it and choose 'Save picture as...'";



// ----------------------------------------------------------------------------------
// DO NOT CHANGE ANYTHING BELOW THIS LINE
// ----------------------------------------------------------------------------------

return $messages;

} // end function getMessages

?>