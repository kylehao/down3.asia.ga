<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------

//   -------------------------------------------------------------------------------
//  | Language: Czech                                                               |
//   -------------------------------------------------------------------------------
//  | Jakub Vr�na <jakub -AT- php DOT net> 2004-05-03                               |
//   -------------------------------------------------------------------------------
//  |                                                                               |
//  |                              INSTRUCTIONS                                     |
//  |                                                                               |
//  |  The messages to translate are listed below.                                  |
//  |  The structure of each line is like this:                                     |
//  |     $message["Hello world!"] = "Hello world!";                                |
//  |                                                                               |
//  |  Keep the text between square brackets [] as it is.                           |
//  |  Translate the 2nd part, keeping the same punctuation and HTML tags.          |
//  |                                                                               |
//  |  The English message, for example                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is written in PHP!";    |
//  |  should become after translation:                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp est ecrit en PHP!";     |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is geschreven in PHP!"; |
//  |                                                                               |
//  |  Note that the variable starts with a dollar sign $, that the value is        |
//  |  enclosed in double quotes " and that the line ends with a semi-colon ;       |
//  |  Be careful when editing this file, do not erase those special characters.    |
//  |                                                                               |
//  |  Some messages also contain one or more variables which start with a percent  |
//  |  sign, for example %1\$s or %2\$s. The English message, for example           |
//  |     $messages[...] = ["The file %1\$s was copied to %2\$s "]                  |
//  |  should becomes after translation:                                            |
//  |     $messages[...] = ["Le fichier %1\$s a �t� copi� vers %2\$s "]             |
//  |                                                                               |
//  |  When a real percent sign % is needed in the text it is entered as %%         |
//  |  otherwise it is interpreted as a variable. So no, it's not a mistake.        |
//  |                                                                               |
//  |  Between the messages to translate there is additional PHP code, for example: |
//  |     if ($state2 == "rename") {                               // <-- PHP code  |
//  |     $messages["Rename directories"] = "Rename directories";  // <-- message   |
//  |     }                                                        // <-- PHP code  |
//  |  This code is needed to load the messages only when they are actually needed. |
//  |  There is no need to change or delete any of that PHP code; translate only    |
//  |  the message.                                                                 |
//  |                                                                               |
//  |  Thanks in advance to all the translators!                                    |
//  |  David.                                                                       |
//  |                                                                               |
//   -------------------------------------------------------------------------------

function getMessages() {
global $state, $state2;


// -------------------------------------------------------------------------
// Used encoding
// -------------------------------------------------------------------------
$messages["iso-8859-1"] = "windows-1250";


// -------------------------------------------------------------------------
// Status messages
// -------------------------------------------------------------------------
// When translating these messages, keep in mind that the text should not be too long
// It should fit in the status textbox
$messages["Connecting to the FTP server"] = "P�ipojov�n� k FTP serveru";
$messages["Getting the list of directories and files"] = "Z�sk�v�n� seznamu adres��� a soubor�";
$messages["Printing the list of directories and files"] = "Vypisov�n� seznamu adres��� a soubor�";
$messages["Processing the entries"] = "Zpracov�v�n� z�znam�";
$messages["Checking files"] = "Kontrolov�n� soubor�";
$messages["Transferring files to the FTP server"] = "P�en�en� soubor� na FTP server";
$messages["Decompressing archives and transferring files"] = "Rozbalov�n� archiv� a p�en�en� soubor�";
$messages["Searching the files..."] = "Prohled�v�n� soubor�...";
$messages["Uploading new file"] = "P�en�en� nov�ho souboru";
$messages["Reading the new file"] = "�ten� nov�ho souboru";
$messages["Reading the old file"] = "�ten� star�ho souboru";
$messages["Comparing the 2 files"] = "Porovn�v�n� dvou soubor�";
$messages["Printing the comparison"] = "Vypisov�n� porovn�n�";
$messages["Script finished in %1\$s seconds"] = "Skript skon�il za %1\$s sekund";
$messages["Script halted"] = "Skript zastavil";


// -------------------------------------------------------------------------
// index.php
// -------------------------------------------------------------------------
$messages["Unexpected state string. Exiting."] = "Neo�ek�van� stavov� �et�zec. Kon��m.";
$messages["This beta function is not activated on this server."] = "This beta function is not activated on this server.";
$messages["This function has been disabled by the Administrator of this website."] = "This function has been disabled by the Administrator of this website.";


// -------------------------------------------------------------------------
// admin.inc.php
if ($state == "admin") {
// -------------------------------------------------------------------------
$messages["Admin functions"] = "Administr�torsk� funkce";

$messages["Version information"] = "Informace o verzi";
$messages["This version of net2ftp is up-to-date"] = "Tato verze net2ftp je aktu�ln�";
$messages["The latest version could not be retrieved from the net2ftp.com server. Check the security settings of your browser, which may prevent the loading of a small file from the net2ftp.com server."] = "Nelze st�hnout posledn� verzi ze serveru net2ftp.com. Zkontrolujte bezpe�nostn� nastaven� sv�ho prohl�e�e, kter� mohou zabra�ovat nahr�n� mal�ho souboru ze serveru net2ftp.com.";

$messages["Logging"] = "Z�znamy";
$messages["Date from:"] = "Datum od:";
$messages["to:"] = "do:";
$messages["Empty logs"] = "Vypr�zdnit z�znamy";
$messages["View logs"] = "Zobrazit z�znamy";
$messages["No data"] = "��dn� data";

$messages["Setup MySQL tables"] = "Nastavit MySQL tabulky";
$messages["Go"] = "OK";
$messages["Create the MySQL database tables"] = "Vytvo�it datab�zov� MySQL tabulky";
$messages["Create tables"] = "Vytvo�it tabulky";
$messages["The handle of file %1\$s could not be opened"] = "Z�znam souboru %1\$s nem��e b�t otev�en";
$messages["The file %1\$s could not be opened"] = "Soubor %1\$s nem��e b�t otev�en";
$messages["The handle of file %1\$s could not be closed"] = "Soubor %1\$s nem��e b�t zav�en";
$messages["MySQL username"] = "MySQL u�ivatelsk� jm�no";
$messages["MySQL password"] = "MySQL heslo";
$messages["MySQL database"] = "MySQL datab�ze";
$messages["MySQL server"] = "MySQL server" ;
$messages["This SQL query is going to be executed:"] = "Vykon� se tento SQL dotaz:";
$messages["Execute"] = "Spu�t�n�";
$messages["Settings used:"] = "Pou�it� nastaven�:";
$messages["MySQL password length"] = "D�lka MySQL hesla";
$messages["Results:"] = "V�sledky:";
$messages["The connection to the server <b>$dbserver2</b> could not be set up"] = "Nepoda�ilo se p�ipojit k serveru <b>$dbserver2</b>";
$messages["Unable to select the database <b>$dbname2</b>"] = "Nepoda�ilo se vybrat datab�zi <b>$dbname2</b>";
$messages["The SQL query could not be executed"] = "Nepoda�ilo se vykonat SQL dotaz";
$messages["The tables were created successfully"] = "Tabulky byly v po��dku vytvo�eny";

$messages["Beta functions"] = "Beta funkce";
$messages["View logs"] = "Zobrazit z�znamy";
$messages["Empty logs"] = "Vypr�zdnit z�znamy";
$messages["The table <b>%1\$s</b> was emptied successfully."] = "Tabulka <b>%1\$s</b> byla �sp�n� vypr�zdn�na.";
$messages["The table <b>%1\$s</b> could not be emptied."] = "Nepoda�ilo se vypr�zdnit tabulku <b>%1\$s</b>.";
$messages["The table <b>%1\$s</b> was optimized successfully."] = "The table <b>%1\$s</b> was optimized successfully.";
$messages["The table <b>%1\$s</b> could not be optimized."] = "The table <b>%1\$s</b> could not be optimized.";

} // end admin

// -------------------------------------------------------------------------
// advanced.inc.php
if ($state == "advanced") {
// -------------------------------------------------------------------------

// advanced()
$messages["The site command functions are not available on this webserver."] = "Funkce ovl�d�n� serveru nejsou na tomto webov�m serveru k dispozici.";
$messages["The Apache functions are not available on this webserver."] = "Funkce Apache nejsou na tomto webov�m serveru k dispozici.";
$messages["The MySQL functions are not available on this webserver."] = "Funkce MySQL nejsou na tomto webov�m serveru k dispozici.";
$messages["Unexpected state2 string. Exiting."] = "Neo�ek�van� stavov� �et�zec 2. Kon��m.";

// printAdvancedFunctions()
$messages["Advanced functions"] = "Pokro�il� funkce";
$messages["Go"] = "P�ej�t";
$messages["Troubleshooting functions"] = "Funkce pro odstra�ov�n� probl�m�";
$messages["Troubleshoot net2ftp on this webserver"] = "�e�en� probl�m� net2ftp na tomto webov�m serveru";
$messages["Troubleshoot an FTP server"] = "�e�en� probl�m� FTP serveru";
$messages["Test the net2ftp list parsing rules"] = "Test the net2ftp list parsing rules";
$messages["Translation functions"] = "P�ekladatelsk� funkce";
$messages["Introduction to the translation functions"] = "�vod k p�ekladatelsk�m funkc�m";
$messages["Extract messages to translate from code files"] = "Z�skat zpr�vy k p�eklady ze zdrojov�ch soubor�";
$messages["Check if there are new or obsolete messages"] = "Zkontrolovat p��tomnost nov�ch nebo zastaral�ch zpr�v";
$messages["Beta functions"] = "Beta funkce";
$messages["Send a site command to the FTP server"] = "Poslat serverov� p��kaz FTP serveru";
$messages["Apache: password-protect a directory, create custom error pages"] = "Apache: chr�nit adres�� heslem, vytvo�it vlastn� chybov� str�nky";
$messages["MySQL: execute an SQL query"] = "MySQL: spustit SQL dotaz";

// troubleshoot_webserver()
$messages["Troubleshoot your net2ftp installation"] = "�e�en� probl�m� va�� instalace net2ftp";
$messages["Checking if the FTP module of PHP is installed: "] = "Kontrolov�n� p��tomnosti FTP modulu PHP: ";
$messages["yes"] = "ano";
$messages["no - please install it!"] = "ne - pros�m nainstalujte ho";
$messages["Checking the permissions of the directory on the web server: a small file will be written to the /temp folder and then deleted."] = "Kontrolov�n� pr�v adres��e na webov�m serveru: do /temp bude zaps�n a n�sledn� smaz�n mal� soubor.";
$messages["Creating filename: "] = "Vytv��en� souboru: ";
$messages["OK. Filename: %1\$s"] = "OK. Soubor: %1\$s";
$messages["not OK"] = "nen� OK";
$messages["OK"] = "OK" ;
$messages["not OK. Check the permissions of the %1\$s directory"] = "nen� OK. Zkontrolujte opr�vn�n� adres��e %1\$s.";
$messages["Opening the file in write mode: "] = "Otev�r�n� souboru v re�imu z�pisu: ";
$messages["Writing some text to the file: "] = "Zapisov�n� n�jak�ho textu do souboru: ";
$messages["Closing the file: "] = "Zav�r�n� souboru: ";
$messages["Deleting the file: "] = "Maz�n� souboru: ";

// troubleshoot_ftpserver()
$messages["Troubleshoot an FTP server"] = "�e�en� probl�m� FTP serveru";
$messages["FTP server port"] = "Port FTP serveru";
$messages["Connection settings:"] = "Nastaven� p�ipojen�:";
$messages["Password length"] = "D�lka hesla";
$messages["Language"] = "Jazyk";
$messages["Skin number"] = "��slo motivu";
$messages["Connecting to the FTP server: "] = "P�ipojov�n� k FTP serveru: ";
$messages["Logging into the FTP server: "] = "Logov�n� na FTP server: ";
$messages["Setting the passive mode: "] = "Nastavov�n� pasivn�ho re�imu: ";
$messages["Getting the FTP server system type: "] = "Z�sk�v�n� typu syst�mu FTP serveru: ";
$messages["Changing to the directory %1\$s: "] = "Zm�na adres��e na %1\$s: ";
$messages["The directory from the FTP server is: %1\$s "] = "Adres�� z FTP serveru je: %1\$s";
$messages["Getting the raw list of directories and files: "] = "Z�sk�v�n� syrov�ho seznamu adres��� a soubor�: ";
$messages["Trying a second time to get the raw list of directories and files: "] = "Druh� pokus z�sk�n� syrov�ho seznamu adres��� a soubor�: ";
$messages["Closing the connection: "] = "Zav�r�n� p�ipojen�: ";
$messages["Raw list of directories and files:"] = "Syrov� seznam adres��� a soubor�:";
$messages["Parsed list of directories and files:"] = "Zpracovan� seznam adres��� a soubor�:";

// test_list_parsing()
$messages["Sample input"] = "Sample input";
$messages["Parsed output"] = "Parsed output";
$messages["Test list parsing message"]  = "";
$messages["Test list parsing message"] .= "Every FTP server sends the list of directories and files in a different format.\n";
$messages["Test list parsing message"] .= "net2ftp has to parse this in order to identify the filename, the file size, the modification time, etc.";
$messages["Test list parsing message"] .= "This function tests the net2ftp parsing rules on a set of samples.";

// printTranslationFunctions()
$messages["net2ftp translation functions"] = "P�ekladatelsk� funkce net2ftp";
$messages["A PHP application can be translated using the standard <a href=\"http://www.php.net/gettext\">gettext</a> functions, or using a self-made translation function."] = "PHP aplikace mohou b�t p�elo�en� pomoc� standardn�ch <a href=\"http://www.php.net/gettext\">gettext</a> funkc� nebo vytvo�en�m vlastn� p�ekladov� funkce.";
$messages["In both cases, the steps to take are similar."] = "V obou p��padech je postup podobn�.";
$messages["Step 1: change code"] = "Krok 1: zm�nit k�d";
$messages["All messages must be translated using a translation function, for example translate()."] = "V�echny zpr�vy mus� b�t p�elo�en� pomoc� p�ekladov� funkce, nap��klad translate().";
$messages["This Hello World code:"] = "Tento k�d Hello World:";
$messages["must be changed to this:"] = "mus� b�t zm�n�n takhle:";
$messages["Step 2: extract messages"] = "Krok 2: z�skat zpr�vy";
$messages["All messages which are used by the translate() function must be extracted from the code files, and copied to a <b>main message file</b>."] = "V�echny zpr�vy, kter� se pou��vaj� funkc� translate() mus� b�t z�sk�ny ze zdrojov�ch soubor� a zkop�rov�ny do <b>hlavn�ho souboru zpr�v</b>.";
$messages["Step 3: translate messages"] = "Krok 3: p�elo�it zpr�vy";
$messages["The main message file is given to translators, who rename the file and replace the messages in English by the translation."] = "Hlavn� soubor zpr�v je p�ed�n p�ekladatel�m, kte�� soubor p�ejmenuj� a nahrad� zpr�vy v angli�tin� p�ekladem.";
$messages["The translators return the <b>translated message files</b>."] = "P�ekladatel� mus� vr�tit <b>p�elo�en� soubor zpr�v</b>.";
$messages["Each time the application is modified, a new main message file must be generated, as in step 2."] = "Poka�d�, kdy� je aplikace zm�n�na, mus� b�t hlavn� soubor zpr�v znovu vytvo�en, stejn� jako ve druh�m kroku.";
$messages["In order to avoid translating everything all over again, it must then be compared to all translated message files, to check if there are new or obsolete messages."] = "Aby nemuselo b�t v�echno vytv��eno v�dy znovu od za��tku, mus� b�t zpr�vy porovn�ny se v�emi p�elo�en�mi soubory zpr�v k ov��en�, zda obsahuj� nov� nebo zastaral� zpr�vy.";
$messages["net2ftp can help in step 2 to extract messages to translate from code files"] = "net2ftp m��e pomoci ve druh�m kroku se z�sk�n�m zpr�v k p�ekladu ze zdrojov�ch soubor�";
$messages["net2ftp can help in step 4 to check if there are new or obsolete messages"] = "net2ftp m��e pomoci ve �tvrt�m kroku s ov��en�m nov�ch nebo zastaral�ch zpr�v";

// translate_extract()
$messages["Extract messages from code files"] = "Z�skat zpr�vy ze zdrojov�ch soubor�";
$messages["Directory containing code files:"] = "Adres��e obsahuj�c� zdrojov� soubory:";
$messages["Translation function used in the code:"] = "P�ekladov� funkce pou��van� v k�du:";
$messages["File to generate:"] = "Soubor pro vytvo�en�:";
$messages["Extracted messages:"] = "Z�skan� zpr�vy:";
$messages["No messages were found, so no file was put on the FTP server."] = "Nebyly nalezeny ��dn� zpr�vy, tak�e na FTP server nebyl nahr�n ��dn� soubor.";
$messages["The main language file <b>%1\$s</b> was transferred to directory <b>%2\$s</b>."] = "Hlavn� jazykov� soubor <b>%1\$s</b> byl p�enesen do adres��e <b>%2\$s</b>.";

// translate_check()
$messages["Main language file:"] = "Hlavn� jazykov� soubor:";
$messages["Directory containing translated language files:"] = "Adres�� obsahuj�c� p�elo�en� jazykov� soubory:";
$messages["File %1\$s was skipped because it could not be read, or because it was empty."] = "Soubor %1\$s byl p�esko�en, proto�e nem��e b�t na�ten nebo je pr�zdn�.";
$messages["File nr %1\$s <b>%2\$s</b>"] = "Soubor ��slo %1\$s <b>%2\$s</b>";
$messages["New messages:"] = "Nov� zpr�vy:";
$messages["Obsolete messages:"] = "Zastaral� zpr�vy:";
$messages["All the files have been processed"] = "Byly zpracov�ny v�echny soubory";

// sendsitecommand()
$messages["Send site command"] = "Poslat serverov� p��kaz";
$messages["Enter the site command"] = "Zadejte serverov� p��kaz";
$messages["The commands you can use depends on your FTP server. These commands are not standard and vary a lot from one server to the other."] = "P��kazy, kter� lze pou��t, z�vis� na va�em FTP serveru. Tyto p��kazy nejsou standardn� a hodn� se li�� server od serveru.";
$messages["Note that net2ftp cannot display the output of the FTP server, it can only tell if the command returned TRUE or FALSE. This is not a limitation of net2ftp but of PHP, the language in which net2ftp is written."] = "Vezm�te na v�dom�, �e net2ftp nem��e zobrazit v�stup FTP serveru, ale pouze m��e ozn�mit, zda p��kaz vr�til TRUE nebo FALSE. Nejedn� se o omezen� net2ftp, ale jazyka PHP, ve kter�m je net2ftp naps�no.";
$messages["The command <b>$command</b> was executed successfully."] = "P��kaz <b>$command</b> byl �sp�n� proveden.";

// apache(), mysqlfunctions()
// Not yet translated

} // end advanced



// -------------------------------------------------------------------------
// authorizations.inc.php
// -------------------------------------------------------------------------

// checkAuthorization()
$messages["The FTP server <b>%1\$s</b> is not in the list of allowed FTP servers."] = "FTP server <b>%1\$s</b> nen� na seznamu povolen�ch server�.";
$messages["The FTP server <b>%1\$s</b> is in the list of banned FTP servers."] = "FTP server <b>%1\$s</b> je na seznamu zak�zan�ch server�.";
$messages["Your IP address (%1\$s) is in the list of banned IP addresses."] = "Va�e IP adresa (%1\$s) je na seznamu zak�zan�ch adres.";
$messages["The FTP server port %1\$s may not be used."] = "Port %1\$s FTP serveru nem��e b�t pou�it.";
$messages["You don't have the authorizations to view directory <b>%1\$s</b>."] = "Nem�te opr�vn�n� prohl�et adres�� <b>%1\$s</b>.";

// logAccess(), logLogin(), logError()
// Not yet translated


// -------------------------------------------------------------------------
// bookmark.inc.php
if ($state == "bookmark") {
// -------------------------------------------------------------------------
$messages["Add this link to your bookmarks:"] = "P�idejte tento odkaz do sv�ch z�lo�ek:";
$messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer: klikn�te na odkaz prav�m tla��tkem my�i a vyberte \"P�idat k obl�ben�m polo�k�m...\"";
$messages["Netscape, Mozilla, Firebird: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla, Firebird: klikn�te na odkaz prav�m tla��tkem my�i a vyberte \"P�idejte k z�lo�k�m...\"";
$messages["Note: when you will use this bookmark, a popup window will ask you for your username and password."] = "Pozn�mka: Kdy� pou�ijete tento odkaz, zept� se v�s vyskakovac� ok�nko na u�ivatelsk� jm�no a heslo.";

} // end bookmark


// -------------------------------------------------------------------------
// browse.inc.php
if ($state == "browse") {
// -------------------------------------------------------------------------

// browse()
$messages["Directories with names containing \' cannot be displayed correctly. They can only be deleted. Please go back and select another subdirectory."] = "Adres��e, jejich� jm�no obsahuje \', nemohou b�t korektn� zobrazeny. Mohou b�t pouze smaz�ny. Pros�m vra�te se zp�t a vyberte jin� jin� podadres��.";

$messages["Consumption message"]  = "";
$messages["Consumption message"] .= "<b>Denn� limit byl dosa�en: nebudete moci p�en�et data</b><br /><br />\n";
$messages["Consumption message"] .= "Pro zaji�t�n� spravedliv�ho u��v�n� webov�ho serveru k�mkoliv je objem p�ene�en�ch dat a �asu spu�t�n� skript� omezen pro ka�dou dvojici u�ivatel - den. Jakmile je tento limit dosa�en, m��ete proch�zet FTP server, ale u� na n�j ani z n�j nem��ete p�en�et data.<br /><br />\n";
$messages["Consumption message"] .= "Pokud pot�ebujete neomezen� pou�it�, tak pros�m net2ftp nainstalujte na vlastn� webov� server.<br />\n";

// ftp_getlist()
$messages["The directory <b>%1\$s</b> does not exist or could not be selected, so the root directory <b>/</b> is shown instead."] = "Adres�� <b>%1\$s</b> neexistuje nebo nem��e b�t vybr�n, tak�e je m�sto n�ho zobrazen ko�enov� adres�� <b>/</b>.";

// printdirfilelist()
// Keep these short, they must fit in a small buttons!
$messages["New dir"] = "Nov� adres��";
$messages["New file"] = "Nov� soubor";
$messages["HTML templates"] = "HTML templates";
$messages["Upload"] = "Nahr�t";
$messages["Java Upload"] = "Java Nahr�t";
$messages["Advanced"] = "Pokro�il�";
$messages["Copy"] = "Kop�rovat";
$messages["Move"] = "P�esunout";
$messages["Delete"] = "Smazat";
$messages["Rename"] = "P�ejmenovat";
$messages["Chmod"] = "Pr�va";
$messages["Download"] = "St�hnout";
$messages["Zip"] = "Zip" ;
$messages["Size"] = "Velikost";
$messages["Search"] = "Vyhledat";
$messages["Go to the parent directory"] = "P�ej�t do nad�azen�ho adres��e";
$messages["Transform selected entries: "] = "Zm�nit vybran� polo�ky: ";
$messages["Make a new subdirectory in directory %1\$s"] = "Vytvo�it nov� podadres�� v adres��i %1\$s";
$messages["Create a new file in directory %1\$s"] = "Vytvo�it nov� soubor v adres��i %1\$s";
$messages["Create a website easily using ready-made templates"] = "Create a website easily using ready-made templates";
$messages["Upload new files in directory %1\$s"] = "Nahr�t nov� soubory do adres��e %1\$s";
$messages["Upload directories and files using a Java applet"] = "Upload directories and files using a Java applet";
$messages["Go to the advanced functions"] = "P�ej�t na pokro�il� funkce";
$messages["Copy the selected entries"] = "Zkop�rovat vybran� polo�ky";
$messages["Move the selected entries"] = "P�esunout vybran� polo�ky";
$messages["Delete the selected entries"] = "Smazat vybran� polo�ky";
$messages["Rename the selected entries"] = "P�ejmenovat vybran� polo�ky";
$messages["Chmod the selected entries (only works on Unix/Linux/BSD servers)"] = "Zm�nit pr�va u vybran�ch polo�ek (funguje pouze na serverech Unix/Linux/BSD)";
$messages["Download a zip file containing all selected entries"] = "St�hnout ZIP soubor obsahuj�c� v�echny vybran� polo�ky";
$messages["Zip the selected entries to save or email them"] = "Zazipovat vybran� polo�ky a ulo�it nebo poslat e-mailem";
$messages["Calculate the size of the selected entries"] = "Spo��tat velikost vybran�ch polo�ek";
$messages["Find files which contain a particular word"] = "Naj�t soubory obsahuj�c� zadan� slovo";
$messages["Click to sort by %1\$s in descending order"] = "Klikn�te pro sestupn� set��d�n� podle sloupce %1\$s.";
$messages["Click to sort by %1\$s in ascending order"] = "Klikn�te pro vzestupn� set��d�n� podle sloupce %1\$s.";
$messages["Ascending order"] = "Vzestupn� t��d�n�";
$messages["Descending order"] = "Sestupn� t��d�n�";
//$messages["Click to sort by %1\$s in ascending order"] = "Klikn�te pro set��d�n� podle %1\$s vzestupn�.";
$messages["Up"] = "V��e";
$messages["Click to check or uncheck all rows"] = "P�epnout za�krtnut� v�ech ��dek";
$messages["All"] = "V�e";
$messages["Name"] = "N�zev";
$messages["Type"] = "Typ";
//$messages["Size"] = "Velikost";
$messages["Owner"] = "Vlastn�k";
$messages["Group"] = "Skupina";
$messages["Perms"] = "Pr�va";
$messages["Mod Time"] = "�as zm�ny";
$messages["Actions"] = "Akce";
$messages["Download the file %1\$s"] = "St�hnout soubor %1\$s";
$messages["View"] = "Zobrazit";
$messages["Edit"] = "Upravit";
$messages["Update"] = "Aktualizovat";
$messages["Open"] = "Otev��t";
$messages["View the highlighted source code of file %1\$s"] = "Zobrazit zv�razn�n� zdrojov� k�d souboru %1\$s";
$messages["Edit the source code of file %1\$s"] = "Upravit zdrojov� k�d souboru %1\$s";
$messages["Upload a new version of the file %1\$s and merge the changes"] = "Nahr�t novou verzi souboru %1\$s a slou�it zm�ny";
$messages["View image %1\$s"] = "Zobrazit obr�zek %1\$s";
$messages["View the file %1\$s from your HTTP web server"] = "Zobrazit soubor %1\$s z va�eho HTTP webov�ho serveru";
$messages["(Note: This link may not work if you don't have your own domain name.)"] = "(Pozn�mka: tento odkaz nemus� fungovat, pokud nem�te vlastn� dom�nu.)";
$messages["This folder is empty"] = "Tento adres�� je pr�zdn�";

// printSeparatorRow()
$messages["Directories"] = "Adres��e";
$messages["Files"] = "Soubory";
$messages["Symlinks"] = "Symlinky";
$messages["Unrecognized FTP output"] = "Nerozpoznan� FTP v�stup";
$messages["Number"] = "Number";
$messages["Size"] = "Size";
$messages["Skipped"] = "Skipped";

// printLocationActions()
$messages["Language:"] = "Jazyk:";
$messages["Skin:"] = "Motiv:";
$messages["View mode:"] = "Re�im zobrazen�:";
$messages["Directory Tree"] = "Strom adres���";

// printURL()
$messages["Execute %1\$s in a new window"] = "Spustit %1\$s v nov�m okn�";

// printDirectorySelect()
$messages["Double-click to go to a subdirectory:"] = "Poklepejte pro p�echod do podadres��e:";
$messages["Choose"] = "Vybrat";
$messages["Up"] = "Nahoru";

} // end browse


// -------------------------------------------------------------------------
// consumption.inc.php
// -------------------------------------------------------------------------
$messages["Unable to determine your IP address."] = "Nepoda�ilo se zjistit va�i IP adresu.";
$messages["Table net2ftp_logConsumptionIpaddress contains duplicate rows."] = "Tabulka net2ftp_logConsumptionIpaddress obsahuje duplicitn� z�znamy.";
$messages["Table net2ftp_logConsumptionFtpserver contains duplicate rows."] = "Tabulka net2ftp_logConsumptionFtpserver obsahuje duplicitn� z�znamy.";
$messages["The variable <b>consumption_ipaddress_dataTransfer</b> is not numeric."] = "Prom�nn� <b>consumption_ipaddress_dataTransfer</b> nen� ��seln�.";
$messages["Table net2ftp_logConsumptionIpaddress could not be updated."] = "Tabulka net2ftp_logConsumptionIpaddress nemohla b�t aktualizov�na.";
$messages["Table net2ftp_logConsumptionIpaddress contains duplicate entries."] = "Tabulka net2ftp_logConsumptionIpaddress obsahuje duplicitn� z�znamy.";
$messages["Table net2ftp_logConsumptionFtpserver could not be updated."] = "Tabulka net2ftp_logConsumptionFtpserver nemohla b�t aktualizov�na.";
$messages["Table net2ftp_logConsumptionFtpserver contains duplicate entries."] = "Tabulka net2ftp_logConsumptionFtpserver obsahuje duplicitn� z�znamy.";
$messages["Daily limit reached: the file <b>%1\$s</b> will not be transferred"] = "Denn� limit dosa�en: soubor <b>%1\$s</b> nebude p�enesen";


// -------------------------------------------------------------------------
// database.inc.php
// -------------------------------------------------------------------------
$messages["Unable to connect to the DB"] = "Nepoda�ilo se p�ipojit k datab�zi";
$messages["Unable to select the DB"] = "Nepoda�ilo se vybrat datab�zi";


// -------------------------------------------------------------------------
// easywebsite.inc.php
if ($state == "easyWebsite") {
// -------------------------------------------------------------------------
$messages["Create a website in 4 easy steps"] = "Create a website in 4 easy steps";
$messages["Template overview"] = "Template overview";
$messages["Template details"] = "Template details";
$messages["Files are copied"] = "Files are copied";
$messages["Edit your pages"] = "Edit your pages";

// Screen 1 - printTemplateOverview
$messages["Click on the image to view the details of a template."] = "Click on the image to view the details of a template.";
$messages["Back to the Browse screen"] = "Back to the Browse screen";
$messages["Template"] = "Template";
$messages["Copyright"] = "Copyright";
$messages["Click on the image to view the details of this template"] = "Click on the image to view the details of this template";

// Screen 2 - printTemplateDetails
$messages["The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?"] = "The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?";
$messages["Install template to directory: "] = "Install template to directory: ";
$messages["Install"] = "Install";
$messages["Size"] = "Size";
$messages["Preview page"] = "Preview page";
$messages["opens in a new window"] = "opens in a new window";

// Screen 3
$messages["Please wait while the template files are being transferred to your server: "] = "Please wait while the template files are being transferred to your server: ";
$messages["Done."] = "Done.";
$messages["Continue"] = "Continue";

// Screen 4 - printEasyAdminPanel
$messages["Edit page"] = "Edit page";
$messages["Browse the FTP server"] = "Browse the FTP server";
$messages["Add this link to your favorites to return to this page later on!"] = "Add this link to your favorites to return to this page later on!";
$messages["Edit website at %1\$s"] = "Edit website at %1\$s";
$messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer: right-click on the link and choose \"Add to Favorites...\"";
$messages["Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\"";

// ftp_copy_local2ftp
$messages["WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing..."] = "WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing...";
$messages["Created target subdirectory <b>%1\$s</b>"] = "Created target subdirectory <b>%1\$s</b>";
$messages["WARNING: Unable to copy the file <b>%1\$s</b>. Continuing..."] = "WARNING: Unable to copy the file <b>%1\$s</b>. Continuing...";
$messages["Copied file <b>%1\$s</b>"] = "Copied file <b>%1\$s</b>";
}


// -------------------------------------------------------------------------
// edit.inc.php
if ($state == "manage" && ($state2 == "edit" || $state2 == "newfile")) {
// -------------------------------------------------------------------------

// edit()
$messages["Unable to open the template file"] = "Nepoda�ilo se otev��t soubor se �ablonami";
$messages["Unable to read the template file"] = "Nepoda�ilo se na��st soubor se �ablonami";
$messages["Please specify a filename"] = "Vyberte pros�m soubor";

// printEditForm()
$messages["Directory: "] = "Adres��: ";
$messages["File: "] = "Soubor: ";
$messages["New file name: "] = "Nov� n�zev souboru: ";
$messages["Note: changing the textarea type will save the changes"] = "Pozn�mka: zm�n�n� textov�ho pole ulo�� zm�ny";
$messages["Status: This file has not yet been saved"] = "Stav: Tento soubor je�t� nebyl ulo�en";
$messages["Status: Saved on <b>%1\$s</b> using mode %2\$s"] = "Stav: Ulo�en� <b>%1\$s</b> v m�du %2\$s";
$messages["Status: <b>This file could not be saved</b>"] = "Stav: <b>Tento soubor nem��e b�t ulo�en</b>";

} // end if edit newfile


// -------------------------------------------------------------------------
// errorhandling.inc.php
// -------------------------------------------------------------------------
$messages["An error has occured"] = "Do�lo k chyb�";
$messages["Go back"] = "P�ej�t zp�t";
$messages["Go to the login page"] = "P�ej�t na p�ihla�ovac� str�nku";


// -------------------------------------------------------------------------
// filesystem.inc.php
// -------------------------------------------------------------------------

// ftp_openconnection()
$messages["The <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this FTP module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">php.net</a><br />"] = "<a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP modul PHP</a> nen� nainstalov�n.<br /><br /> Administr�tor tohoto webov�ho serveru by tento FTP modul m�l nainstalovat. Instrukce pro instalaci jsou k dispozici na <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">php.net</a><br />";
$messages["Unable to connect to FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "Nepoda�ilo se p�ipojit k FTP serveru <b>%1\$s</b> na portu <b>%2\$s</b>.<br /><br />V�te jist�, �e se jedn� o adresu FTP serveru? Ta se �asto li�� od adresy HTTP (webov�ho) serveru. Pro z�sk�n� pomoci pros�m kontaktujte odbornou pomoc sv�ho ISP nebo syst�mov�ho administr�tora.<br />";
$messages["Unable to login to FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "Nepoda�ilo se p�ihl�sit k FTP serveru <b>%1\$s</b> pod u�ivatelsk�m jm�nem <b>%2\$s</b>.<br /><br />Jste si jist, �e je u�ivatelsk� jm�no a heslo spr�vn�? Pro z�sk�n� pomoci pros�m kontaktujte odbornou pomoc sv�ho ISP nebo syst�mov�ho administr�tora.<br />";
$messages["Unable to switch to the passive mode on FTP server <b>%1\$s</b>."] = "Nepoda�ilo se p�epnout do pasivn�ho re�imu na FTP serveru <b>%1\$s</b>.";

// ftp_openconnection2()
$messages["Unable to connect to the second (target) FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the second (target) FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "Nepoda�ilo se p�ipojit ke druh�mu (c�lov�mu) FTP serveru <b>%1\$s</b> na portu <b>%2\$s</b>.<br /><br />.V�te ur�it�, �e se jedn� o adresu druh�ho (c�lov�ho) FTP serveru? Ta se �asto li�� od adresy HTTP (webov�ho) serveru. Pro z�sk�n� pomoci pros�m kontaktujte odbornou pomoc sv�ho ISP nebo syst�mov�ho administr�tora.<br />";
$messages["Unable to login to the second (target) FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "Nepoda�ilo se p�ihl�sit ke druh�mu (c�lov�mu) FTP serveru <b>%1\$s</b> pod u�ivatelsk�m jm�nem <b>%2\$s</b>.<br /><br />. Jste si jisti, �e zadan� u�ivatelsk� jm�no a heslo jsou spr�vn�? Pro z�sk�n� pomoci pros�m kontaktujte odbornou pomoc sv�ho ISP nebo syst�mov�ho administr�tora.<br />";
$messages["Unable to switch to the passive mode on the second (target) FTP server <b>%1\$s</b>."] = "Nepoda�ilo se p�epnout do pasivn�ho re�imu na druh�m (c�lov�m) FTP serveru <b>%1\$s</b>.";

// ftp_myrename()
$messages["Unable to rename directory or file <b>%1\$s</b> into <b>%2\$s</b>"] = "Nepoda�ilo se p�ejmenovat adres�� nebo soubor <b>%1\$s</b> na <b>%2\$s</b>";

// ftp_mychmod()
$messages["Unable to execute site command <b>%1\$s</b>. Note that the CHMOD command is only available on Unix FTP servers, not on Windows FTP servers."] = "Nepoda�ilo se vykonat serverov� p��kaz <b>%1\$s</b>. Vezm�te pros�m na v�dom�, �e p��kaz CHMOD je k dispozici pouze na Unixov�ch FTP serverech a ne na FTP serverech pod Windows.";
$messages["Directory <b>%1\$s</b> successfully chmodded to <b>%2\$s</b>"] = "Pr�va adres��e <b>%1\$s</b> byla v po��dku zm�n�na na <b>%2\$s</b>";
$messages["File <b>%1\$s</b> was successfully chmodded to <b>%2\$s</b>"] = "Pr�va souboru <b>%1\$s</b> byla v po��dku zm�n�na na <b>%2\$s</b>";
$messages["All the selected directories and files have been processed."] = "V�echny ozna�en� adres��e a soubory byly zpracov�ny.";

// ftp_rmdir2()
$messages["Unable to delete the directory <b>%1\$s</b>"] = "Nepoda�ilo se smazat adres�� <b>%1\$s</b>";

// ftp_delete2()
$messages["Unable to delete the file <b>%1\$s</b>"] = "Nepoda�ilo se smazat soubor <b>%1\$s</b>";

// ftp_newdirectory()
$messages["Unable to create the directory <b>%1\$s</b>"] = "Nepoda�ilo se vytvo�it adres�� <b>%1\$s</b>";

// ftp_readfile()
$messages["Unable to create the temporary file"] = "Nepoda�ilo se vytvo�it do�asn� soubor";
$messages["Unable to get the file <b>%1\$s</b> from the FTP server and to save it as temporary file <b>%2\$s</b>.<br />Check the permissions of the %3\$s directory.<br />"] = "Nepoda�ilo se z�skat soubor <b>%1\$s</b> z FTP serveru a ulo�it ho do do�asn�ho souboru <b>%2\$s</b>.<br />Zkontrolujte opr�vn�n� adres��e %3\$s.<br />";
$messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "Nepoda�ilo se otev��t do�asn� soubor. Zkontrolujte opr�vn�n� adres��e %1\$s.";
$messages["Unable to read the temporary file"] = "Nepoda�ilo se p�e��st do�asn� soubor";
$messages["Unable to close the handle of the temporary file"] = "Nepoda�ilo se uzav��t do�asn� soubor";
$messages["Unable to delete the temporary file"] = "Nepoda�ilo se smazat do�asn� soubor";

// ftp_writefile()
$messages["Unable to create the temporary file. Check the permissions of the %1\$s directory."] = "Nepoda�ilo se vytvo�it do�asn� soubor. Zkontrolujte opr�vn�n� adres��e %1\$s.";
$messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "Nepoda�ilo se otev��t do�asn� soubor. Zkontrolujte opr�vn�n� adres��e %1\$s.";
$messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "Nepoda�ilo se zapsat �et�zec do do�asn�ho souboru <b>%1\$s</b>.<br />Zkontrolujte opr�vn�n� adres��e %2\$s.";
$messages["Unable to close the handle of the temporary file"] = "Nepoda�ilo se uzav��t do�asn� soubor";
$messages["Unable to put the file <b>%1\$s</b> on the FTP server.<br />You may not have write permissions on the directory."] = "Nepoda�ilo se nahr�t soubor <b>%1\$s</b> na FTP server.<br />Mo�n� nem�te pr�va z�pisu do dan�ho adres��e.";
$messages["Unable to delete the temporary file"] = "Nepoda�ilo se smazat do�asn� soubor";

// ftp_copymovedelete()
$messages["Processing directory <b>%1\$s</b>"] = "Zpracov�n� adres��e <b>%1\$s</b>";
$messages["The target directory <b>%1\$s</b> is the same as or a subdirectory of the source directory <b>%2\$s</b>, so this directory will be skipped"] = "C�lov� adres�� <b>%1\$s</b> je stejn� jako zdrojov� adres�� <b>%2\$s</b> nebo je jeho podadres��em, tento adres�� proto bude p�esko�en";
$messages["Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing the copy/move process..."] = "Nepoda�ilo se vytvo�it podadres�� <b>%1\$s</b>. Mo�n� u� existuje. Pokra�uje se v kop�rov�n�/p�esouv�n�...";
$messages["Created target subdirectory <b>%1\$s</b>"] = "C�lov� podadres�� <b>%1\$s</b> byl vytvo�en";
$messages["Unable to delete the subdirectory <b>%1\$s</b> - it may not be empty"] = "Nepoda�ilo se smazat podadres�� <b>%1\$s</b> - mo�n� nen� pr�zdn�";
$messages["Deleted subdirectory <b>%1\$s</b>"] = "Podadres�� <b>%1\$s</b> byl smaz�n";
$messages["Processing of directory <b>%1\$s</b> completed"] = "Zpracov�n� adres��e <b>%1\$s</b> bylo dokon�eno";
$messages["The target for file <b>%1\$s</b> is the same as the source, so this file will be skipped"] = "C�lov� um�st�n� souboru <b>%1\$s</b> je stejn� jako zdrojov�, proto bude tento soubor p�esko�en";
$messages["Unable to copy the file <b>%1\$s</b>"] = "Nepoda�ilo se zkop�rovat soubor <b>%1\$s</b>";
$messages["Copied file <b>%1\$s</b>"] = "Soubor <b>%1\$s</b> byl zkop�rov�n";
$messages["Unable to move the file <b>%1\$s</b>"] = "Nepoda�ilo se p�esunout soubor <b>%1\$s</b>";
$messages["Moved file <b>%1\$s</b>"] = "Soubor <b>%1\$s</b> byl p�esunut";
$messages["Unable to delete the file <b>%1\$s</b>"] = "Nepoda�ilo se smazat soubor <b>%1\$s</b>";
$messages["Deleted file <b>%1\$s</b>"] = "Soubor <b>%1\$s</b> byl smaz�n";
$messages["All the selected directories and files have been processed."] = "V�echny vybran� adres��e a soubory byly zpracov�ny.";

// ftp_processfiles()

// ftp_getfile()
$messages["Unable to copy the remote file <b>%1\$s</b> to the local file using FTP mode <b>%2\$s</b>"] = "Nepoda�ilo se zkop�rovat vzd�len� soubor <b>%1\$s</b> do m�stn�ho v FTP re�imu <b>%2\$s</b>";
$messages["Unable to delete file <b>%1\$s</b>"] = "Nepoda�ilo se smazat soubor <b>%1\$s</b>";

// ftp_putfile()
$messages["Unable to copy the local file to the remote file <b>%1\$s</b> using FTP mode <b>%2\$s</b>"] = "Nepoda�ilo se zkop�rovat m�stn� soubor do vzd�len�ho souboru <b>%1\$s</b> v FTP re�imu <b>%2\$s</b>";
$messages["Unable to delete the local file"] = "Nepoda�ilo se smazat m�stn� soubor";

// ftp_downloadfile()
$messages["Unable to delete the temporary file"] = "Nepoda�ilo se smazat do�asn� soubor";
$messages["Unable to send the file to the browser"] = "Nepoda�ilo se odeslat soubor prohl�e�i";

// ftp_zip()
$messages["Unable to create the temporary file"] = "Nepoda�ilo se vytvo�it do�asn� soubor";
$messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "Do do�asn�ho souboru <b>%1\$s</b> se nepoda�ilo zapsat �et�zec.<br />Zkontrolujte opr�vn�n� adres��e %2\$s.";
$messages["Unable to close the handle of the temporary file"] = "Nepoda�ilo se zav��t do�asn� soubor";
$messages["The zip file has been saved on the FTP server as <b>%1\$s</b>"] = "Soubor ZIP byl na FTP server ulo�en jako <b>%1\$s</b>";
$messages["Requested files"] = "Po�adovan� soubory";

$messages["Zip email message"]  = "";
$messages["Zip email message"] .= "V�en�,\n\n";
$messages["Zip email message"] .= "N�kdo po��dal o posl�n� soubor� v p��loze na va�i e-mailovou adresu (%1\$s).\n";
$messages["Zip email message"] .= "Pokud o tom nic nev�te nebo doty�n� osob� ned�v��ujete, tak pros�m tento e-mail sma�te, ani� byste Zip soubor v p��loze otev�rali.";
$messages["Zip email message"] .= "Pokud Zip soubor neotev�ete, nemohou soubory uvnit� po�kodit v� po��ta�.";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "Informace o odes�lateli:\n";
$messages["Zip email message"] .= "IP adresa: %2\$s\n";
$messages["Zip email message"] .= "�as odesl�n�: %3\$s\n";
$messages["Zip email message"] .= "Posl�no aplikac� net2ftp nainstalovanou na tomto webov�m serveru: %4\$s \n";
$messages["Zip email message"] .= "E-mail webmastera: %5\$s \n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "Zpr�va odes�latele:\n";
$messages["Zip email message"] .= "%6\$s \n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "net2ftp je voln� software, uvoln�n� pod licenc� GNU/GPL. Pro v�ce informac� nav�tivte http://www.net2ftp.com\n\n\n";

$messages["The zip file has been sent to <b>%1\$s</b>."] = "Soubor ZIP byl odesl�n na adresu <b>%1\$s</b>.";

// acceptFiles()
$messages["File <b>%1\$s</b> is too big. This file will not be uploaded."] = "Soubor <b>%1\$s</b> je moc velk�. Tento soubor nebude nahr�n.";
$messages["Could not generate a temporary file."] = "Nepoda�ilo se vytvo�it do�asn� soubor.";
$messages["File <b>%1\$s</b> could not be moved"] = "Soubor <b>%1\$s</b> nem��e b�t p�esunut";
$messages["File <b>%1\$s</b> is OK"] = "Soubor <b>%1\$s</b> je v po��dku";
$messages["Unable to move the uploaded file to the temp directory.<br /><br />The administrator of this website has to <b>chmod 777</b> the /temp directory of net2ftp."] = "Nepoda�ilo se p�esunout nahran� soubor do do�asn�ho adres��e.<br /><br />Administr�tor tohoto webov�ho serveru mus� na adres�� net2ftp /temp prov�st <b>chmod 777</b>.";
$messages["You did not provide any file to upload."] = "Neposkytl jste ��dn� soubor, kter� se m� nahr�t";

// ftp_transferfiles()
$messages["File <b>%1\$s</b> could not be transferred to the FTP server"] = "Soubor <b>%1\$s</b> nemohl b�t p�enesen na FTP server";
$messages["File <b>%1\$s</b> has been transferred to the FTP server using FTP mode <b>%2\$s</b>"] = "Soubor <b>%1\$s</b> byl na FTP server p�enesen v re�imu <b>%2\$s</b>";
$messages["Transferring files to the FTP server"] = "P�en�en� soubor� na FTP server";

// ftp_unziptransferfiles()
$messages["Processing archive nr %1\$s: <b>%2\$s</b>"] = "Zpracov�n� archivu �. %1\$s: <b>%2\$s</b>";
$messages["Unable to open the archive <b>%1\$s</b> (file %2\$s)"] = "Nepoda�ilo se otev��t archiv <b>%1\$s</b> (soubor %1\$s)";
$messages["Could not create directory <b>%1\$s</b>"] = "Nepoda�ilo se vytvo�it adres�� <b>%1\$s</b>";
$messages["Created directory <b>%1\$s</b>"] = "Adres�� <b>%1\$s</b> byl vytvo�en";
$messages["File Contents:"] = "Obsah souboru:";
$messages["Could not put the file <b>%1\$s</b> to the directory <b>%2\$s</b>"] = "Nepoda�ilo se ulo�it soubor <b>%1\$s</b> do adres��e <b>%2\$s</b>";
$messages["Transferred file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "Soubor <b>%1\$s</b> byl p�enesen do adres��e <b>%1\$s</b>";
$messages["Unable to delete the archive <b>%1\$s</b> (file %2\$s)"] = "Nepoda�ilo se smazat archiv <b>%1\$s</b> (soubor %2\$s)";
$messages["Unable to get the list of the contents of the Zip archive. Error code: %1\$s"] = "Nepoda�ilo se z�skat seznam soubor� v Zip archivu. Chybov� k�d: %1\$s";
$messages["Unable to get the list of the contents of the Tar archive."] = "Nepoda�ilo se z�skat seznam soubor� v Tar archivu.";
$messages["Could not create directory <b>%1\$s</b>"] = "Nepoda�ilo se vytvo�it adres�� <b>%1\$s</b>";
$messages["Created directory <b>%1\$s</b>"] = "Adres�� <b>%1\$s</b> byl vytvo�en";
$messages["Unable to create the temporary file"] = "Nepoda�ilo se vytvo�it do�asn� soubor";
$messages["Unable to extract file nr <b>%1\$s</b> from the archive."] = "Z archivu se nepoda�ilo rozbalit soubor �. <b>%1\$s</b>.";
$messages["Could not put file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "Nepoda�ilo se ulo�it soubor <b>%1\$s</b> do adres��e <b>%2\$s</b>";
$messages["Transferred file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "Soubor <b>%1\$s</b> byl p�enesen do adres��e <b>%2\$s</b>";
$messages["Unable to delete the temporary file <b>%1\$s</b>."] = "Nepoda�ilo se smazat do�asn� soubor <b>%1\$s</b>.";
$messages["Archive <b>%1\$s</b> was not processed because its filename extension was not recognized. Only zip, tar, tgz and gz archives are supported at the moment."] = "Archiv <b>%1\$s</b> nebyl zpracov�n, proto�e p��ponu jeho souboru se nepoda�ilo rozpoznat. Moment�ln� jsou podporov�ny pouze archivy zip, tar, tgz a gz.";
$messages["Unzipping and transferring files"] = "Rozbaluji a p�en��m soubory";

// ftp_mysite()
$messages["Unable to execute site command <b>%1\$s</b>"] = "Nepoda�ilo se vykonat p��kaz serveru <b>%1\$s</b>";

// shutdown()
$messages["Shutdown message"]  = "";
$messages["Shutdown message"] .= "<b>Va�e �loha byla zastavena</b><br /><br />";
$messages["Shutdown message"] .= "�loha, kterou jste cht�li pomoc� net2ftp prov�st, trvala v�ce ne� povolen�ch %1\$s sekund, a proto byla zastavena.<br />";
$messages["Shutdown message"] .= "Tento �asov� limit zaru�uje spravedliv� vyu�it� webov�ho serveru v�emi u�ivateli.<br /><br />";
$messages["Shutdown message"] .= "Pokuste se va�e �lohy rozd�lit na men�� ��sti: omezte v�b�r soubor� a vynechejte ty nejv�t��.<br /><br />";
$messages["Shutdown message"] .= "Pokud opravdu pot�ebujete, aby net2ftp dok�zalo zpracovat n�ro�n� dlouhotrvaj�c� �lohy, zva�te instalaci net2ftp na vlastn�m serveru.";

// SendMail()
$messages["You did not provide any text to send by email!"] = "Neuvedl jste ��dn� text, kter� by se m�l poslat e-mailem!";
$messages["You did not supply a From address."] = "Neuvedl jste adresu odes�latele.";
$messages["You did not supply a To address."] = "Neuvedl jste adresu p��jemce.";
$messages["Due to technical problems the email to <b>%1\$s</b> could not be sent."] = "Kv�li technick�m probl�m�m nebylo mo�n� odeslat e-mail na adresu <b>%1\$s</b>.";

// printFunctionTags()
$messages["Output generated by function %1\$s"] = "V�stup vygenerov�n funkc� %1\$s";



// -------------------------------------------------------------------------
// homepage.inc.php
if ($state == "homepage") {
// -------------------------------------------------------------------------
$messages["net2ftp features short"]  = "Once you are logged in, you will be able to: \n";
$messages["net2ftp features short"] .= "<ul>\n";
$messages["net2ftp features short"] .= "<li> Navigate the FTP server<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "Once you have logged in, you can browse from directory to directory and see all the subdirectories and files.</span></li>\n";
$messages["net2ftp features short"] .= "<li> Upload files<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "There are 3 different ways to upload files: the standard upload form, the upload-and-unzip functionality, and the Java Applet.</span></li>\n";
$messages["net2ftp features short"] .= "<li> Download files<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "Click on a filename to quickly download one file.<br />\n";
$messages["net2ftp features short"] .= "Select multiple files and click on Download; the selected files will be downloaded in a zip archive.</span></li>\n";
$messages["net2ftp features short"] .= "<li> Zip files<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "... and save the zip archive on the FTP server, or email it to someone.</span></li>\n";
$messages["net2ftp features short"] .= "<li> Copy, move and delete<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "Directories are handled recursively, meaning that their content (subdirectories and files) will also be copied, moved or deleted.</span></li>\n";
$messages["net2ftp features short"] .= "<li> Copy or move to a 2nd FTP server<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "Handy to import files to your FTP server, or to export files from your FTP server to another FTP server.</span></li>\n";
$messages["net2ftp features short"] .= "<li> Rename and chmod<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "Chmod handles directories recursively.</span></li>\n";
$messages["net2ftp features short"] .= "<li> View code with syntax highlighting<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "PHP functions are linked to the documentation on php.net.</span></li>\n";
$messages["net2ftp features short"] .= "<li> Plain text editor<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "Edit text right from your browser; every time you save the changes the new file is transferred to the FTP server.</span></li>\n";
$messages["net2ftp features short"] .= "<li> HTML editors<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "Edit HTML a What-You-See-Is-What-You-Get (WYSIWYG) form; there are 3 different editors to choose from.</span></li>\n";
$messages["net2ftp features short"] .= "<li> Code editor<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "Edit HTML and PHP in an editor with syntax highlighting.</span></li>\n";
$messages["net2ftp features short"] .= "<li> Search for words or phrases<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "Filter out files based on the filename, last modification time and filesize.</span></li>\n";
$messages["net2ftp features short"] .= "<li> Calculate size<br /> <span style=\"font-size: 80%%\">\n";
$messages["net2ftp features short"] .= "Calculate the size of directories and files.</span></li>\n";
$messages["net2ftp features short"] .= "</ul>\n";

} // end homepage


// -------------------------------------------------------------------------
// net2ftp_loginform.inc.php
// -------------------------------------------------------------------------
$messages["FTP server"] = "FTP server" ;
$messages["Example"] = "P��klad";
$messages["Username"] = "U�ivatelsk� jm�no";
$messages["Password"] = "Heslo";
$messages["Anonymous"] = "Anonymn�";
$messages["Passive mode"] = "Pasivn� re�im";
$messages["Initial directory"] = "V�choz� adres��";
$messages["Language"] = "Jazyk";
$messages["Skin"] = "Motiv";
$messages["FTP mode"] = "FTP m�d";
$messages["Login"] = "P�ihl�sit";
$messages["Clear cookies"] = "Vymazat cookies";
$messages["Please enter an FTP server."] = "Please enter an FTP server.";
$messages["Please enter a username."] = "Please enter a username.";
$messages["Please enter a password."] = "Please enter a password.";


// -------------------------------------------------------------------------
// html.inc.php
// -------------------------------------------------------------------------

// HtmlBegin()
$messages["Status:"] = "Stav:";

// HtmlEnd()
$messages["net2ftp Help Guide"] = "N�pov�da net2ftp";
$messages["net2ftp Forums"] = "F�ra net2ftp";
$messages["License"] = "Licence";
$messages["Powered by"] = "B�� d�ky";

// printJavascriptFunctions()
$messages["Choose a directory"] = "Vyberte adres��";
$messages["Please wait..."] = "Pros�m �ekejte...";
$messages["Uploading... please wait..."] = "Nahr�v�m... pros�m �ekejte...";
$messages["If the upload takes more than the allowed <b>%1\$s seconds<\/b>, you will have to try again with less/smaller files."] = "Pokud nahr�n� bude trvat d�le ne� povolen�ch <b>%1\$s sekund<\/b>, mus�te to zkusit znovu s m�n� nebo men��mi soubory.";
$messages["This window will close automatically in a few seconds."] = "Toto okno se za n�kolik vte�in automaticky zav�e.";
$messages["Close window now"] = "Zav��t okno hned";


// -------------------------------------------------------------------------
// httpheaders.inc.php
// -------------------------------------------------------------------------
// Nothing to translate


// -------------------------------------------------------------------------
// manage.inc.php
if ($state == "manage") {
// -------------------------------------------------------------------------

// manage()
$messages["Please select at least one directory or file!"] = "Vyberte pros�m alespo� jeden adres�� nebo soubor!";
$messages["Unexpected state2 string. Exiting."] = "Neo�ek�van� stavov� �et�zec 2. Kon��m.";

// renameentry()
if ($state2 == "rename") {
$messages["Rename directories and files"] = "P�ejmenovat adres��e nebo soubory";
$messages["Old name: "] = "Star� jm�no: ";
$messages["New name: "] = "Nov� jm�no: ";
$messages["The new name may not contain any dots. This entry was not renamed to <b>%1\$s</b>"] = "Nov� jm�no nesm� obsahovat ��dn� te�ky. Tato polo�ka byla p�ejmenov�na na <b>%1\$s</b>";
$messages["<b>%1\$s</b> was successfully renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> byl �sp�n� p�ejmenov�n na <b>%2\$s</b>";
$messages["<b>%1\$s</b> could not be renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> nemohl b�t p�ejmenov�n na <b>%2\$s</b>";
}

// chmodentry()
if ($state2 == "chmod") {
$messages["Chmod directories and files"] = "Zm�nit pr�va adres���m a soubor�m";
$messages["Set all permissions"] = "Nastavit v�echna pr�va";
$messages["Read"] = "�ten�";
$messages["Write"] = "Z�pis";
$messages["Execute"] = "Spu�t�n�";
$messages["Owner"] = "Vlastn�k";
$messages["Group"] = "Skupina";
$messages["Everyone"] = "Kdokoliv";
$messages["To set all permissions to the same values, enter those permissions above and click on the button \"Set all permissions\""] = "Pokud chcete nastavit v�echna pr�va na stejnou hodnotu, zadejte tato pr�va v��e a stiskn�te tla��tko \"Nastavit v�echna pr�va\"";
$messages["Set the permissions of directory <b>%1\$s</b> to: "] = "Nastavit pr�va adres��e <b>%1\$s</b> na: ";
$messages["Set the permissions of file <b>%1\$s</b> to: "] = "Nastavit pr�va souboru <b>%1\$s</b> na: ";
$messages["Set the permissions of symlink <b>%1\$s</b> to: "] = "Nastavit pr�va symlinku <b>%1\$s</b> na: ";
$messages["Chmod value"] = "Hodnota pro chmod";
$messages["Chmod also the subdirectories within this directory"] = "Zm�nit pr�va tak� v�em podadres���m v tomto adres��i";
$messages["Chmod also the files within this directory"] = "Zm�nit pr�va tak� v�em soubor�m v tomto adres��i";
$messages["The chmod nr <b>%1\$s</b> is out of the range 000-777. Please try again."] = "��slo pro chmod <b>%1\$s</b> je mimo rozsah 000-777. Zkuste to pros�m znovu.";
}

// copymovedeleteentry()
if ($state2 == "copy" || $state2 == "move" || $state2 == "delete") {
$messages["Copy directories and files"] = "Kop�rovat adres��e a soubory";
$messages["Move directories and files"] = "P�esunout adres��e a soubory";
$messages["Delete directories and files"] = "Smazat adres��e a soubory";
$messages["Are you sure you want to delete these directories and files?"] = "Jste si jist, �e chcete smazat tyto adres��e a soubory?";
$messages["All the subdirectories and files of the selected directories will also be deleted!"] = "Ve vybran�ch adres���ch budou smaz�ny tak� v�echny podadres��e a soubory!";
$messages["Set all targetdirectories"] = "Nastavit v�echny c�lov� adres��e";
$messages["To set a common target directory, enter that target directory in the textbox above and click on the button \"Set all targetdirectories\"."] = "Pokud chcete nastavit obvykl� c�lov� adres��, zadejte ho do textov�ho pol��ka v��e a stiskn�te tla��tko \"Nastavit v�echny c�lov� adres��e\".";
$messages["Note: the target directory must already exist before anything can be copied into it."] = "Pozn�mka: c�lov� adres�� mus� existovat d��ve, ne� do n�j bude cokoliv zkop�rov�no.";
$messages["Different target FTP server:"] = "Jin� c�lov� FTP server:";
$messages["Leave empty if you want to copy the files to the same FTP server."] = "Nechte pr�zdn�, pokud chcete soubory zkop�rovat na stejn� FTP server.";
$messages["If you want to copy the files to another FTP server, enter your login data."] = "Pokud chcete soubory zkop�rovat na jin� FTP server, zadejte va�e p�ihla�ovac� �daje.";
$messages["Leave empty if you want to move the files to the same FTP server."] = "Nechte pr�zdn�, pokud chcete soubory p�esunout na stejn� FTP server.";
$messages["If you want to move the files to another FTP server, enter your login data."] = "Pokud chcete soubory p�esunout na jin� FTP server, zadejte va�e p�ihla�ovac� �daje.";
$messages["Copy directory <b>%1\$s</b> to:"] = "Zkop�rovat adres�� <b>%1\$s</b> do:";
$messages["Move directory <b>%1\$s</b> to:"] = "P�esunout adres�� <b>%1\$s</b> do:";
$messages["Directory <b>%1\$s</b>"] = "Adres�� <b>%1\$s</b>";
$messages["Copy file <b>%1\$s</b> to:"] = "Zkop�rovat soubor <b>%1\$s</b> do:";
$messages["Move file <b>%1\$s</b> to:"] = "P�esunout soubor <b>%1\$s</b> do:";
$messages["File <b>%1\$s</b>"] = "Soubor <b>%1\$s</b>";
$messages["Copy symlink <b>%1\$s</b> to:"] = "Zkop�rovat symlink <b>%1\$s</b> do:";
$messages["Move symlink <b>%1\$s</b> to:"] = "P�esunout symlink <b>%1\$s</b> do:";
$messages["Symlink <b>%1\$s</b>"] = "Symlink <b>%1\$s</b>" ;
$messages["Target directory:"] = "C�lov� adres��:";
$messages["Target name:"] = "C�lov� jm�no:";
$messages["Processing the entries:"] = "Zpracov�n� polo�ek:";
}

// newdirectory()
if ($state2 == "newdirectory") {
$messages["Create new directories"] = "Vytvo�it nov� adres��e";
$messages["The new directories will be created in <b>%1\$s</b>."] = "Nov� adres��e budou vytvo�en� v <b>%1\$s</b>.";
$messages["New directory name:"] = "Jm�no nov�ho adres��e:";
$messages["Directory <b>%1\$s</b> was successfully created."] = "Adres�� <b>%1\$s</b> byl v po��dku vytvo�en.";
}

// uploadfile()
if ($state2 == "uploadfile") {
$messages["Upload files and archives"] = "Nahr�t soubory a archivy";
$messages["Upload results"] = "V�sledky nahr�n�";
$messages["Checking files:"] = "Kontroluji soubory:";
$messages["Transferring files to the FTP server:"] = "P�en�en� soubor� na FTP server:";
$messages["Decompressing archives and transferring files to the FTP server:"] = "Rozbalov�n� archiv� a p�en�en� soubor� na FTP server:";
$messages["Upload more files and archives"] = "Nahr�t v�ce soubor� a archiv�";
}

// printUploadForm() and javaupload()
if ($state2 == "uploadfile" || $state2 == "javaupload") {
$messages["Upload to directory:"] = "Nahr�t do adres��e:";
$messages["Files"] = "Soubory";
$messages["Archives"] = "Archiv�";
$messages["Files entered here will be transferred to the FTP server."] = "Zde zadan� soubory budou p�enesen� na FTP server.";
$messages["Archives entered here will be decompressed, and the files inside will be transferred to the FTP server."] = "Zde zadan� archivy budou rozbaleny a soubory uvnit� budou p�eneseny na FTP server.";
$messages["Add another"] = "P�idat dal��";
$messages["Use folder names (creates subdirectories automatically)"] = "Pou��t jm�na adres��� (automaticky vytvo�it podadres��e)";
$messages["Restrictions:"] = "Omezen�:";
$messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s kB</b> and by PHP to <b>%2\$s</b>"] = "Maxim�ln� velikost jednoho souboru je v net2ftp omezena na <b>%1\$s kB</b> a v PHP na <b>%2\$s</b>";
$messages["The maximum execution time is <b>%1\$s seconds</b>"] = "Maxim�ln� �as prov�d�n� je <b>%1\$s sekund</b>";
$messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "Re�im FTP p�enosu (ASCII nebo BINARY) bude automaticky nastaven podle koncovky";
$messages["If the destination file already exists, it will be overwritten"] = "Pokud c�lov� soubor existuje, bude p�eps�n";

$messages["Upload directories and files using a Java applet"] = "Upload directories and files using a Java applet";
$messages["Number of files:"] = "Number of files:";
$messages["Size of files:"] = "Size of files:";
$messages["Add"] = "Add";
$messages["Remove"] = "Remove";
$messages["Upload"] = "Upload";
$messages["Add files to the upload queue"] = "Add files to the upload queue";
$messages["Remove files from the upload queue"] = "Remove files from the upload queue";
$messages["Upload the files which are in the upload queue"] = "Upload the files which are in the upload queue";
$messages["Maximum server space exceeded. Please select less/smaller files."] = "Maximum server space exceeded. Please select less/smaller files.";
$messages["Total size of the files is too big. Please select less/smaller files."] = "Total size of the files is too big. Please select less/smaller files.";
$messages["Total number of files is too high. Please select fewer files."] = "Total number of files is too high. Please select fewer files.";
$messages["Note: to use this applet, Sun's Java plugin must be installed (version 1.4 or newer)."] = "Note: to use this applet, Sun's Java plugin must be installed (version 1.4 or newer).";

$messages["Browser does not support Java applets"] = "Your browser does not support applets, or you have disabled applets in your browser settings.\n";
$messages["Browser does not support Java applets"] .= "To use this applet, please install the newest version of Sun's java. You can get it from <a href=\"http://www.java.com/\">java.com</a>. Click on Get It Now.\n";
$messages["Browser does not support Java applets"] .= "The online installation is about 1-2 MB and the offline installation is about 13 MB. This 'end-user' java is called JRE (Java Runtime Environment).\n";
$messages["Browser does not support Java applets"] .= "Alternatively, use net2ftp's normal upload or upload-and-unzip functionality.\n";
}

// zipentry()
if ($state2 == "zip") {
$messages["Zip entries"] = "Zazipovat polo�ky";
$messages["Save the zip file on the FTP server as:"] = "Ulo�it zip na FTP serveru jako:";
$messages["Email the zip file in attachment to:"] = "Poslat zip v p��loze e-mailem na:";
$messages["Note that sending files is not anonymous: your IP address as well as the time of the sending will be added to the email."] = "Vezm�te pros�m na v�dom�, �e p�en�en� soubor� nen� anonymn�: do e-mailu bude p�id�na va�e IP adresa a �as odesl�n�.";
$messages["Some additional comments to add in the email:"] = "Dal�� koment��, kter� chcete p�ipojit k e-mailu:";
$messages["You did not enter a filename for the zipfile. Go back and enter a filename."] = "Nezadali jste jm�no zip souboru. Vra�te se zp�t a zadejte jm�no souboru.";
$messages["The email address you have entered (%1\$s) does not seem to be valid.<br />Please enter an address in the format <b>username@domain.com</b>"] = "Zd� se, �e e-mailov� adresa, kterou jste zadal (%1\$s), nen� platn�.<br />Zadejte pros�m adresu ve form�tu <b>uzivatel@domena.cz</b>";
}

// calculatesize()
if ($state2 == "calculatesize") {
$messages["Size of selected directories and files"] = "Velikost vybran�ch adres��� a soubor�";
$messages["The total size taken by the selected directories and files is:"] = "Celkov� velikost vybran�ch adres��� a soubor� je:";
$messages["The nr of files which were skipped:"] = "Po�et soubor�, kter� byly p�esko�eny:";
}

// findstring()
if ($state2 == "findstring") {
$messages["Search directories and files"] = "Prohledat adres��e a soubory";
$messages["Search results"] = "V�sledky vyhled�v�n�";
$messages["Please enter a valid search word or phrase."] = "Zadejte pros�m platn� slovo nebo slovn� spojen� pro vyhled�v�n�.";
$messages["Please enter a valid filename."] = "Zadejte pros�m platn� jm�no souboru.";
$messages["Please enter a valid file size in the \"from\" textbox, for example 0."] = "Zadejte pros�m platnou velikost souboru do textov�ho pole \"od\", nap��klad 0.";
$messages["Please enter a valid file size in the \"to\" textbox, for example 500000."] = "Zadejte pros�m platnou velikost souboru do textov�ho pole \"do\", nap��klad 50000.";
$messages["Please enter a valid date in Y-m-d format in the \"from\" textbox."] = "Zadejte pros�m platn� datum ve form�tu Y-m-d do textov�ho pole \"od\".";
$messages["Please enter a valid date in Y-m-d format in the \"to\" textbox."] = "Zadejte pros�m platn� datum ve form�tu Y-m-d do textov�ho pole \"do\".";
$messages["The word <b>%1\$s</b> was not found in the selected directories and files."] = "Slovo <b>%1\$s</b> nebylo ve vybran�ch adres���ch a souborech nalezeno.";
$messages["The word <b>%1\$s</b> was found in the following files:"] = "Slovo <b>%1\$s</b> bylo nalezeno v t�chto souborech:";
$messages["Search again"] = "Hledat znovu";
}

// printFindstringForm()
if ($state2 == "findstring") {
$messages["Search for a word or phrase"] = "Hledat slovo nebo slovn� spojen�";
$messages["Case sensitive search"] = "Rozli�ovat velikost p�smen";
$messages["Restrict the search to:"] = "Omezit vyhled�v�n� na:";
$messages["files with a filename like"] = "soubory se jm�nem vyhovuj�c�mu";
$messages["(wildcard character is *)"] = "(z�stupn� znak je *)";
$messages["files with a size"] = "soubory s velikost�";
$messages["from"] = "od";
$messages["to"] = "do";
$messages["files which were last modified"] = "soubory, kter� byly naposledy zm�n�ny";
}

// updatefile()
if ($state2 == "updatefile") {
$messages["Update file"] = "Aktualizovat soubor";
$messages["<b>WARNING: THIS FUNCTION IS STILL IN EARLY DEVELOPMENT. USE IT ONLY ON TEST FILES! YOU HAVE BEEN WARNED!"] = "<b>VAROV�N�: TATO FUNKCE JE ST�LE V PO��TE�N� F�ZI V�VOJE. POU��VEJTE JI POUZE NA TESTOVAC� SOUBORY! BYL JSTE VAROV�N!</b>";
$messages["Known bugs: - erases tab characters - doesn't work well with big files (> 50kB) - was not tested yet on files containing non-standard characters</b>"] = "Zn�m� pot�e: - odstra�uje tabul�tory - nepracuje korektn� s velk�mi soubory (> 50kB) - dosud nebylo testov�no se soubory, kter� obsahuj� nestandardn� znaky</b>";
$messages["This function allows you to upload a new version of the selected file, to view what are the changes and to accept or reject each change. Before anything is saved, you can edit the merged files."] = "Tato funkce v�m umo��uje nahr�t novou verzi vybran�ho souboru, abyste se mohli pod�vat, jak� byly provedeny zm�ny, a n�sledn� mohli ka�dou zm�nu schv�lit nebo zam�tnout. P�ed t�m, ne� je cokoliv ulo�eno, m��ete slou�en� soubor editovat.";
$messages["Old file:"] = "Star� soubor:";
$messages["New file:"] = "Nov� soubor:";
$messages["Restrictions:"] = "Omezen�:";
$messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s kB</b> and by PHP to <b>%2\$s</b>"] = "Maxim�ln� velikost jednoho souboru je v net2ftp omezena na <b>%1\$s kB</b> a v PHP na <b>%2\$s</b>";
$messages["The maximum execution time is <b>%1\$s seconds</b>"] = "Maxim�ln� �as prov�d�n� je <b>%1\$s sekund</b>";
$messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "Re�im FTP p�enosu (ASCII nebo BINARY) bude automaticky nastaven podle koncovky";
$messages["If the destination file already exists, it will be overwritten"] = "Pokud c�lov� soubor existuje, bude p�eps�n";
$messages["You did not provide any files or archives to upload."] = "Neposkytl jste ��dn� soubory nebo archivy, kter� chcete nahr�t.";
$messages["Unable to delete the new file"] = "Nepoda�ilo se smazat nov� soubor";
}

// printComparisonSelect()
if ($state2 == "updatefile") {
$messages["Please wait..."] = "Pros�m �ekejte...";
$messages["Select lines below, accept or reject changes and submit the form."] = "Vyberte ��dky n�e, schvalte nebo zam�tn�te zm�ny a ode�lete formul��.";
}

} // end manage


// -------------------------------------------------------------------------
// registerglobals.inc.php
// -------------------------------------------------------------------------
$messages["Please enter your username and password for FTP server "] = "Pros�m zadejte sv� p�ihla�ovac� jm�no a heslo k FTP serveru ";
$messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "Nevyplnili jste p�ihla�ovac� informace do vyskakovac�ho ok�nka.<br />N�e klikn�te na \"P�ej�t na p�ihla�ovac� str�nku\".";
$messages["Access to the net2ftp Admin panel is disabled, because no password has been set in the file settings.inc.php. Enter a password in that file, and reload this page."] = "P��stup k Administra�n�mu panelu net2ftp je zak�zan�, proto�e v souboru settings.inc.php nebylo nastaveno ��dn� heslo. Vlo�te heslo do tohoto souboru a aktualizujte tuto str�nku.";
$messages["Please enter your Admin username and password"] = "Zadejte pros�m sv� administr�torsk� u�ivatelsk� jm�no a heslo"; 
$messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "Ve vyskakovac�m ok�nku jste nevyplnili sv� p�ihla�ovac� �daje.<br />N�e klikn�te na \"P�ej�t na p�ihla�ovac� str�nku\".";
$messages["Wrong username or password for the net2ftp Admin panel. The username and password can be set in the file settings.inc.php."] = "�ptan� u�ivatelsk� jm�no nebo heslo pro Administra�n� panel net2ftp. U�ivatelsk� jm�no a heslo m��e b�t nastaveno v souboru settings.inc.php.";


// -------------------------------------------------------------------------
// skins.inc.php
// -------------------------------------------------------------------------
$messages["Blue"] = "Modr�";
$messages["Grey"] = "�ed�";
$messages["Black"] = "�ern�";
$messages["Yellow"] = "�lut�";
$messages["Pastel"] = "Pastelov�";

// getMime()
$messages["Directory"] = "Adres��";
$messages["Symlink"] = "Symlink" ;
$messages["ASP script"] = "ASP skript";
$messages["Cascading Style Sheet"] = "Kask�dov� styl";
$messages["HTML file"] = "HTML soubor";
$messages["Java source file"] = "Zdrojov� soubor Java";
$messages["JavaScript file"] = "soubor JavaScript";
$messages["PHP Source"] = "PHP zdrojov� k�d";
$messages["PHP script"] = "PHP skript";
$messages["Text file"] = "Textov� soubor";
$messages["Bitmap file"] = "Bitmapa";
$messages["GIF file"] = "Obr�zek GIF";
$messages["JPEG file"] = "Obr�zek JPEG";
$messages["PNG file"] = "Obr�zek PNG";
$messages["TIF file"] = "Obr�zek TIF";
$messages["GIMP file"] = "Obr�zek GIMP";
$messages["Executable"] = "Spustiteln� soubor";
$messages["Shell script"] = "Shellovsk� skript";
$messages["MS Office - Word document"] = "MS Office - dokument Word";
$messages["MS Office - Excel spreadsheet"] = "MS Office - tabulka Excel";
$messages["MS Office - PowerPoint presentation"] = "MS Office - prezentace PowerPoint";
$messages["MS Office - Access database"] = "MS Office - datab�ze Access";
$messages["MS Office - Visio drawing"] = "MS Office - kresba Visio";
$messages["MS Office - Project file"] = "MS Office - projekt aplikace Project";
$messages["OpenOffice - Writer 6.0 document"] = "OpenOffice - dokument Writer 6.0";
$messages["OpenOffice - Writer 6.0 template"] = "OpenOffice - �ablona Writer 6.0";
$messages["OpenOffice - Calc 6.0 spreadsheet"] = "OpenOffice - tabulka Calc 6.0";
$messages["OpenOffice - Calc 6.0 template"] = "OpenOffice - �ablona Calc 6.0";
$messages["OpenOffice - Draw 6.0 document"] = "OpenOffice - dokument Draw 6.0";
$messages["OpenOffice - Draw 6.0 template"] = "OpenOffice - �ablona Draw 6.0";
$messages["OpenOffice - Impress 6.0 presentation"] = "OpenOffice - prezentace Impress 6.0";
$messages["OpenOffice - Impress 6.0 template"] = "OpenOffice - �ablona Impress 6.0";
$messages["OpenOffice - Writer 6.0 global document"] = "OpenOffice - glob�ln� dokument Writer 6.0";
$messages["OpenOffice - Math 6.0 document"] = "OpenOffice - dokument Math 6.0";
$messages["StarOffice - StarWriter 5.x document"] = "StarOffice - dokument StarWriter 5.x";
$messages["StarOffice - StarWriter 5.x global document"] = "StarOffice - glob�ln� dokument StarWriter 5.x";
$messages["StarOffice - StarCalc 5.x spreadsheet"] = "StarOffice - tabulka StarCalc 5.x";
$messages["StarOffice - StarDraw 5.x document"] = "StarOffice - dokument StarDraw 5.x";
$messages["StarOffice - StarImpress 5.x presentation"] = "StarOffice - prezentace StarImpress 5.x";
$messages["StarOffice - StarImpress Packed 5.x file"] = "StarOffice - soubor StarImpress Packed 5.x";
$messages["StarOffice - StarMath 5.x document"] = "StarOffice - dokument StarMath 5.x";
$messages["StarOffice - StarChart 5.x document"] = "StarOffice - dokument StarChart 5.x";
$messages["StarOffice - StarMail 5.x mail file"] = "StarOffice - soubor po�ty StarMail 5.x";
$messages["Adobe Acrobat document"] = "dokument Adobe Acrobat";
$messages["ARC archive"] = "Archiv ARC";
$messages["ARJ archive"] = "Archiv ARJ";
$messages["RPM"] = "RPM" ;
$messages["GZ archive"] = "Archiv GZ";
$messages["TAR archive"] = "Archiv TAR";
$messages["Zip archive"] = "Archiv Zip";
$messages["MOV movie file"] = "Video MOV";
$messages["MPEG movie file"] = "Video MPEG";
$messages["Real movie file"] = "Video Real";
$messages["Quicktime movie file"] = "Video Quicktime";
$messages["Shockwave flash file"] = "Shockwave Flash";
$messages["Shockwave file"] = "Soubor Shockwave";
$messages["WAV sound file"] = "Zvuk WAV";
$messages["Font file"] = "Soubor fontu";
$messages["%1\$s File"] = "Soubor %1\$s";
$messages["File"] = "Soubor";

// getAction()
$messages["Back"] = "Zp�t";
$messages["Submit"] = "Odeslat";
$messages["Refresh"] = "Obnovit";
$messages["Details"] = "Detaily";
$messages["Icons"] = "Ikony";
$messages["List"] = "Seznam";
$messages["Logout"] = "Odhl�sit";
$messages["Help"] = "N�pov�da";
$messages["Bookmark"] = "Obl�ben�";
$messages["Save"] = "Ulo�it";
$messages["Default"] = "V�choz�";


// -------------------------------------------------------------------------
// view.inc.php
// -------------------------------------------------------------------------
$messages["Image"] = "Obr�zek";
$messages["View Macromedia ShockWave Flash movie %1\$s"] = "Prohl�dnout si klip Macromedia ShockWave Flash %1\$s";
$messages["View file %1\$s"] = "Zobrazit soubor %1\$s";
$messages["To save the image, right-click on it and choose 'Save picture as...'"] = "Pokud chcete ulo�it obr�zek, tak na n�j klikn�te prav�m tla��tkem my�i a zvolte 'Ulo�it obr�zek jako...'";



// ----------------------------------------------------------------------------------
// DO NOT CHANGE ANYTHING BELOW THIS LINE
// ----------------------------------------------------------------------------------

return $messages;

} // end function getMessages

?>