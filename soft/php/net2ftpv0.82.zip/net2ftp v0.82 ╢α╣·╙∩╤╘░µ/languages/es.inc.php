<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------

//   -------------------------------------------------------------------------------
//  | Language: Spanish                                                             |
//   -------------------------------------------------------------------------------
//  | Jos� Biskofski <email> 2004-05-24                                             |
//   -------------------------------------------------------------------------------
//  |                                                                               |
//  |                              INSTRUCTIONS                                     |
//  |                                                                               |
//  |  The messages to translate are listed below.                                  |
//  |  The structure of each line is like this:                                     |
//  |     $message["Hello world!"] = "Hello world!";                                |
//  |                                                                               |
//  |  Keep the text between square brackets [] as it is.                           |
//  |  Translate the 2nd part, keeping the same punctuation and HTML tags.          |
//  |                                                                               |
//  |  The English message, for example                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is written in PHP!";    |
//  |  should become after translation:                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp est ecrit en PHP!";     |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is geschreven in PHP!"; |
//  |                                                                               |
//  |  Note that the variable starts with a dollar sign $, that the value is        |
//  |  enclosed in double quotes " and that the line ends with a semi-colon ;       |
//  |  Be careful when editing this file, do not erase those special characters.    |
//  |                                                                               |
//  |  Some messages also contain one or more variables which start with a percent  |
//  |  sign, for example %1\$s or %2\$s. The English message, for example           |
//  |     $messages[...] = ["The file %1\$s was copied to %2\$s "]                  |
//  |  should becomes after translation:                                            |
//  |     $messages[...] = ["Le fichier %1\$s a �t� copi� vers %2\$s "]             |
//  |                                                                               |
//  |  When a real percent sign % is needed in the text it is entered as %%         |
//  |  otherwise it is interpreted as a variable. So no, it's not a mistake.        |
//  |                                                                               |
//  |  Between the messages to translate there is additional PHP code, for example: |
//  |     if ($state2 == "rename") {                               // <-- PHP code  |
//  |     $messages["Rename directories"] = "Rename directories";  // <-- message   |
//  |     }                                                        // <-- PHP code  |
//  |  This code is needed to load the messages only when they are actually needed. |
//  |  There is no need to change or delete any of that PHP code; translate only    |
//  |  the message.                                                                 |
//  |                                                                               |
//  |  Thanks in advance to all the translators!                                    |
//  |  David.                                                                       |
//  |                                                                               |
//   -------------------------------------------------------------------------------

function getMessages() {
global $state, $state2;


// -------------------------------------------------------------------------
// Used encoding
// -------------------------------------------------------------------------
$messages["iso-8859-1"] = "iso-8859-1";


// -------------------------------------------------------------------------
// Status messages
// -------------------------------------------------------------------------
// When translating these messages, keep in mind that the text should not be too long
// It should fit in the status textbox
$messages["Connecting to the FTP server"] = "Conectando con el servidor FTP";
$messages["Getting the list of directories and files"] = "Obteniendo la lista de directorios y archivos";
$messages["Printing the list of directories and files"] = "Organizando la lista de archivos y directorios";
$messages["Processing the entries"] = "Procesando las peticiones";
$messages["Checking files"] = "Comprobando la estructura de los archivos";
$messages["Transferring files to the FTP server"] = "Transfiriendo archivos al servidor FTP";
$messages["Decompressing archives and transferring files"] = "Descomprimiendo y transfiriendo archivos";
$messages["Searching the files..."] = "Buscando en los archivos...";
$messages["Uploading new file"] = "Transfiriendo el archivo nuevo";
$messages["Reading the new file"] = "Leyendo el archivo nuevo";
$messages["Reading the old file"] = "Leyendo el archivo viejo";
$messages["Comparing the 2 files"] = "Comparando los dos archivos";
$messages["Printing the comparison"] = "Imprimiendo la comparaci�n de archivos";
$messages["Script finished in %1\$s seconds"] = "El programa termino en %1\$s segundos";
$messages["Script halted"] = "El programa se ha detenido";


// -------------------------------------------------------------------------
// index.php
// -------------------------------------------------------------------------
$messages["Unexpected state string. Exiting."] = "Cadena de estado inesperada. Terminando.";
$messages["This beta function is not activated on this server."] = "Esta funci�n beta no esta activada en el servidor.";
$messages["This function has been disabled by the Administrator of this website."] = "This function has been disabled by the Administrator of this website.";


// -------------------------------------------------------------------------
// admin.inc.php
if ($state == "admin") {
// -------------------------------------------------------------------------
$messages["Admin functions"] = "Admin functions";

$messages["Version information"] = "Version information";
$messages["This version of net2ftp is up-to-date"] = "This version of net2ftp is up-to-date";
$messages["The latest version could not be retrieved from the net2ftp.com server. Check the security settings of your browser, which may prevent the loading of a small file from the net2ftp.com server."] = "The latest version could not be retrieved from the net2ftp.com server. Check the security settings of your browser, which may prevent the loading of a small file from the net2ftp.com server.";

$messages["Logging"] = "Logging";
$messages["Date from:"] = "Date from:";
$messages["to:"] = "to:";
$messages["Empty logs"] = "Empty";
$messages["View logs"] = "View logs";
$messages["No data"] = "No data";

$messages["Setup MySQL tables"] = "Setup MySQL tables";
$messages["Go"] = "Go";
$messages["Create the MySQL database tables"] = "Create the MySQL database tables";
$messages["Create tables"] = "Create tables";
$messages["The handle of file %1\$s could not be opened"] = "The handle of file %1\$s could not be opened";
$messages["The file %1\$s could not be opened"] = "The file %1\$s could not be opened";
$messages["The handle of file %1\$s could not be closed"] = "The handle of file %1\$s could not be closed";
$messages["MySQL username"] = "MySQL username";
$messages["MySQL password"] = "MySQL password";
$messages["MySQL database"] = "MySQL database";
$messages["MySQL server"] = "MySQL server";
$messages["This SQL query is going to be executed:"] = "This SQL query is going to be executed:";
$messages["Execute"] = "Ejecutar";
$messages["Settings used:"] = "Settings used:";
$messages["MySQL password length"] = "MySQL password length";
$messages["Results:"] = "Results:";
$messages["The connection to the server <b>%1\$s</b> could not be set up"] = "The connection to the server <b>%1\$s</b> could not be set up";
$messages["Unable to select the database <b>%1\$s</b>"] = "Unable to select the database <b>%1\$s</b>";
$messages["The SQL query could not be executed"] = "The SQL query could not be executed";
$messages["The tables were created successfully"] = "The tables were created successfully";

$messages["Beta functions"] = "Beta functions";
$messages["View logs"] = "View logs";
$messages["Empty logs"] = "Empty logs";
$messages["The table <b>%1\$s</b> was emptied successfully."] = "The table <b>%1\$s</b> was emptied successfully.";
$messages["The table <b>%1\$s</b> could not be emptied."] = "The table <b>%1\$s</b> could not be emptied.";

} // end admin

// -------------------------------------------------------------------------
// advanced.inc.php
if ($state == "advanced") {
// -------------------------------------------------------------------------

// advanced()
$messages["The site command functions are not available on this webserver."] = "Las funciones de comando de sitio no est�n disponibles en este servidor.";
$messages["The Apache functions are not available on this webserver."] = "Las funciones integradas de Apache no est�n disponibles en este servidor.";
$messages["The MySQL functions are not available on this webserver."] = "Las funciones integradas de MySQL no est�n disponibles en este servidor.";
$messages["Unexpected state2 string. Exiting."] = "Cadena de estado dos inesperada. Terminando.";

// printAdvancedFunctions()
$messages["Advanced functions"] = "Funciones avanzadas";
$messages["Go"] = "Ir";
$messages["Troubleshooting functions"] = "Troubleshooting functions";
$messages["Troubleshoot net2ftp on this webserver"] = "Depurar net2ftp en este servidor";
$messages["Troubleshoot an FTP server"] = "Depurar un servidor FTP externo";
$messages["Translation functions"] = "Translation functions";
$messages["Introduction to the translation functions"] = "Introduction to the translation functions";
$messages["Extract messages to translate from code files"] = "Extract messages to translate from code files";
$messages["Check if there are new or obsolete messages"] = "Check if there are new or obsolete messages";
$messages["Beta functions"] = "Beta functions";
$messages["Send a site command to the FTP server"] = "Send a site command to the FTP server";
$messages["Apache: password-protect a directory, create custom error pages"] = "Apache: password-protect a directory, create custom error pages";
$messages["MySQL: execute an SQL query"] = "MySQL: execute an SQL query";

// troubleshoot_webserver()
$messages["Troubleshoot your net2ftp installation"] = "Depurar tu instalacion de net2ftp";
$messages["Checking if the FTP module of PHP is installed: "] = "Revisando si el modulo FTP de PHP esta activado";
$messages["yes"] = "si";
$messages["no - please install it!"] = "no - �por favor instalalo!";
$messages["Checking the permissions of the directory on the web server: a small file will be written to the /temp folder and then deleted."] = "Revisando los permisos del directorio en el Servidor: un peque�o archivo ser� colocado en tu directorio /temp y despu�s ser� eliminado.";
$messages["Creating filename: "] = "Creando el archivo llamado: ";
$messages["OK. Filename: %1\$s"] = "OK. Nombre de archivo: %tempfilename";
$messages["not OK"] = "Error";
$messages["OK"] = "OK";
$messages["not OK. Check the permissions of the %1\$s directory"] = "Error. Revisa los permisos del directorio %1\$s";
$messages["Opening the file in write mode: "] = "Opening the file in write mode: ";
$messages["Writing some text to the file: "] = "Escribiendo texto en el archivo: ";
$messages["Closing the file: "] = "Cerrando el archivo: ";
$messages["Deleting the file: "] = "Eliminando el archivo: ";

// troubleshoot_ftpserver()
$messages["Troubleshoot an FTP server"] = "Depurar un servidor FTP";
$messages["FTP server port"] = "Puerto del servidor FTP";
$messages["Connection settings:"] = "Configuracion de la conexion:";
$messages["Password length"] = "Tama�o de la contrase�a";
$messages["Language"] = "Idioma";
$messages["Skin number"] = "Numero de plantilla";
$messages["Connecting to the FTP server: "] = "Conectando al servidor FTP: ";
$messages["Logging into the FTP server: "] = "Iniciando sesi�n en el servidor FTP: ";
$messages["Setting the passive mode: "] = "Iniciando modo pasivo de transferencia: ";
$messages["Getting the FTP server system type: "] = "Getting the FTP server system type: ";
$messages["Changing to the directory %1\$s: "] = "Cambiando al directorio %1\$s: ";
$messages["The directory from the FTP server is: %1\$s "] = "El directorio en el servidor FTP es: %1\$s ";
$messages["Getting the raw list of directories and files: "] = "Obteniendo la lista de archivos y directorios: ";
$messages["Trying a second time to get the raw list of directories and files: "] = "Intentando por segunda vez obtener la lista de directorios y archivos: ";
$messages["Closing the connection: "] = "Cerrando la conexion: ";
$messages["Raw list of directories and files:"] = "Lista de directorios y archivos:";
$messages["Parsed list of directories and files:"] = "Lista organizada de directorios y archivos:";

// printTranslationFunctions()
$messages["net2ftp translation functions"] = "net2ftp translation functions";
$messages["A PHP application can be translated using the standard <a href=\"http://www.php.net/gettext\">gettext</a> functions, or using a self-made translation function."] = "A PHP application can be translated using the standard <a href=\"http://www.php.net/gettext\">gettext</a> functions, or using a self-made translation function.";
$messages["In both cases, the steps to take are similar."] = "In both cases, the steps to take are similar.";
$messages["Step 1: change code"] = "Step 1: change code";
$messages["All messages must be translated using a translation function, for example translate()."] = "All messages must be translated using a translation function, for example translate().";
$messages["This Hello World code:"] = "This Hello World code:";
$messages["must be changed to this:"] = "must be changed to this:";
$messages["Step 2: extract messages"] = "Step 2: extract messages";
$messages["All messages which are used by the translate() function must be extracted from the code files, and copied to a <b>main message file</b>."] = "All messages which are used by the translate() function must be extracted from the code files, and copied to a <b>main message file</b>.";
$messages["Step 3: translate messages"] = "Step 3: translate messages";
$messages["The main message file is given to translators, who rename the file and replace the messages in English by the translation."] = "The main message file is given to translators, who rename the file and replace the messages in English by the translation.";
$messages["The translators return the <b>translated message files</b>."] = "The translators return the <b>translated message files</b>.";
$messages["Each time the application is modified, a new main message file must be generated, as in step 2."] = "Each time the application is modified, a new main message file must be generated, as in step 2.";
$messages["In order to avoid translating everything all over again, it must then be compared to all translated message files, to check if there are new or obsolete messages."] = "In order to avoid translating everything all over again, it must then be compared to all translated message files, to check if there are new or obsolete messages.";
$messages["net2ftp can help in step 2 to extract messages to translate from code files"] = "net2ftp can help in step 2 to extract messages to translate from code files";
$messages["net2ftp can help in step 4 to check if there are new or obsolete messages"] = "net2ftp can help in step 4 to check if there are new or obsolete messages";

// translate_extract()
$messages["Extract messages from code files"] = "Extract messages from code files";
$messages["Directory containing code files:"] = "Directory containing code files:";
$messages["Translation function used in the code:"] = "Translation function used in the code:";
$messages["File to generate:"] = "File to generate:";
$messages["Extracted messages:"] = "Extracted messages:";
$messages["No messages were found, so no file was put on the FTP server."] = "No messages were found, so no file was put on the FTP server.";
$messages["The main language file <b>%1\$s</b> was transferred to directory <b>%2\$s</b>."] = "The main language file <b>%1\$s</b> was transferred to directory <b>%2\$s</b>.";

// translate_check()
$messages["Main language file:"] = "Main language file:";
$messages["Directory containing translated language files:"] = "Directory containing translated language files:";
$messages["File %1\$s was skipped because it could not be read, or because it was empty."] = "File %1\$s was skipped because it could not be read, or because it was empty.";
$messages["File nr %1\$s <b>%2\$s</b>"] = "File nr %1\$s <b>%2\$s</b>";
$messages["New messages:"] = "New messages:";
$messages["Obsolete messages:"] = "Obsolete messages:";
$messages["All the files have been processed"] = "All the files have been processed";

// sendsitecommand()
$messages["Send site command"] = "Send site command";
$messages["Enter the site command"] = "Enter the site command";
$messages["The commands you can use depends on your FTP server. These commands are not standard and vary a lot from one server to the other."] = "The commands you can use depends on your FTP server. These commands are not standard and vary a lot from one server to the other.";
$messages["Note that net2ftp cannot display the output of the FTP server, it can only tell if the command returned TRUE or FALSE. This is not a limitation of net2ftp but of PHP, the language in which net2ftp is written."] = "Note that net2ftp cannot display the output of the FTP server, it can only tell if the command returned TRUE or FALSE. This is not a limitation of net2ftp but of PHP, the language in which net2ftp is written.";
$messages["The command <b>%1\$s</b> was executed successfully."] = "The command <b>%1\$s</b> was executed successfully.";

// apache(), mysqlfunctions()
// Not yet translated

} // end advanced



// -------------------------------------------------------------------------
// authorizations.inc.php
// -------------------------------------------------------------------------

// checkAuthorization()
$messages["The FTP server <b>%1\$s</b> is not in the list of allowed FTP servers."] = "El servidor FTP <b>%1\$s</b> no esta en la lista de servidores permitidos.";
$messages["The FTP server <b>%1\$s</b> is in the list of banned FTP servers."] = "El servidor FTP <b>%1\$s</b> esta en la lista de servidores no permitidos.";
$messages["Your IP address (%1\$s) is in the list of banned IP addresses."] = "Tu direcci�n IP (%1\$s) esta en la lista de IPS no permitidas.";
$messages["The FTP server port %1\$s may not be used."] = "El puerto %1\$s del servidor FTP no puede ser utilizado.";
$messages["You don't have the authorizations to view directory <b>%1\$s</b>."] = "No tienes permisos para ver el contenido del directorio <b>%1\$s</b>.";

// logAccess(), logLogin(), logError()
// Not yet translated


// -------------------------------------------------------------------------
// bookmark.inc.php
if ($state == "bookmark") {
// -------------------------------------------------------------------------
$messages["Add this link to your bookmarks:"] = "Agrega este link a tus Favoritos:";
$messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer: haz clic derecho en el link y elige \"Agregar a Favoritos...\"";
$messages["Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla y Firefox: haz clic derecho en el link y elige \"Agregar a Favoritos...\"";
$messages["Note: when you will use this bookmark, a popup window will ask you for your username and password."] = "Nota: cuando uses este Favorito, aparecer� una ventana pidi�ndote nombre de usuario y contrase�a.";

} // end bookmark


// -------------------------------------------------------------------------
// browse.inc.php
if ($state == "browse") {
// -------------------------------------------------------------------------

// browse()
$messages["Directories with names containing \' cannot be displayed correctly. They can only be deleted. Please go back and select another subdirectory."] = "Los directorios que contienen el car�cter \' no pueden ser vistos correctamente. Solo pueden ser eliminados. Por favor vuelve atr�s y elige otro subdirectorio.";

$messages["Consumption message"]  = "";
$messages["Consumption message"] .= "<b>Daily limit reached: you will not be able to transfer data</b><br /><br />\n";
$messages["Consumption message"] .= "In order to guarantee the fair use of the web server for everyone, the data transfer volume and script execution time are limited per user, and per day. Once this limit is reached, you can still browse the FTP server but not transfer data to/from it.<br /><br />\n";
$messages["Consumption message"] .= "If you need unlimited usage, please install net2ftp on your own web server.<br />\n";

// ftp_getlist()
$messages["The directory <b>%1\$s</b> does not exist or could not be selected, so the root directory <b>/</b> is shown instead."] = "El directorio <b>%1\$s</b> no existe, o no pudo ser seleccionado. Mostrando el directorio <b>/</b> en su lugar.";

// printdirfilelist()
// Keep this short, it must fit in a small button!
$messages["New dir"] = "Nuevo directorio";
$messages["New file"] = "Nuevo archivo";
$messages["HTML templates"] = "HTML templates";
$messages["Upload"] = "Subir archivo";
$messages["Java Upload"] = "Java Upload";
$messages["Advanced"] = "Avanzado";
$messages["Copy"] = "Copiar";
$messages["Move"] = "Mover";
$messages["Delete"] = "Eliminar";
$messages["Rename"] = "Renombrar";
$messages["Chmod"] = "Chmod";
$messages["Download"] = "Descargar";
$messages["Zip"] = "Comprimir";
$messages["Size"] = "Tama�o";
$messages["Search"] = "Buscar";
$messages["Go to the parent directory"] = "Go to the parent directory";
$messages["Transform selected entries: "] = "Transformar los elementos seleccionados: ";
$messages["Make a new subdirectory in directory %1\$s"] = "Crear un nuevo subdirectorio en el directorio %1\$s";
$messages["Create a new file in directory %1\$s"] = "Crear nuevo archivo en el directorio %1\$s";
$messages["Upload new files in directory %1\$s"] = "Transferir un archivo al directorio %1\$s";
$messages["Go to the advanced functions"] = "Ir a las funciones avanzadas";
$messages["Copy the selected entries"] = "Copiar los elementos seleccionados";
$messages["Move the selected entries"] = "Mover los elementos seleccionados";
$messages["Delete the selected entries"] = "Eliminar los elementos seleccionados";
$messages["Rename the selected entries"] = "Renombrar los elementos seleccionados";
$messages["Chmod the selected entries (only works on Unix/Linux/BSD servers)"] = "Configurar permisos de los elementos seleccionados (solo funciona en servidor Unix/Linux/BSD)";
$messages["Download a zip file containing all selected entries"] = "Descargar un archivo comprimido con todos los elementos";
$messages["Zip the selected entries to save or email them"] = "Comprimir los elementos seleccionados para guardarlos o mandarlos por correo electr�nico";
$messages["Calculate the size of the selected entries"] = "Calcular el tama�o de los elementos seleccionados";
$messages["Find files which contain a particular word"] = "Buscar archivos que contengan una palabra";
$messages["Click to sort by %1\$s in descending order"] = "Haz click para organizar los %1\$s en orden descendente";
$messages["Click to sort by %1\$s in ascending order"] = "Haz click para organizar los %1\$s en orden ascendente";
$messages["Ascending order"] = "Orden ascendente";
$messages["Descending order"] = "Orden descendente";
//$messages["Click to sort by %1\$s in ascending order"] = "Click to sort by %1\$s in ascending order";
$messages["Up"] = "Arriba";
$messages["Click to check or uncheck all rows"] = "Click to check or uncheck all rows";
$messages["All"] = "All";
$messages["Name"] = "Nombre";
$messages["Type"] = "Tipo";
//$messages["Size"] = "Size";
$messages["Owner"] = "Propietario";
$messages["Group"] = "Grupo";
$messages["Perms"] = "Permisos";
$messages["Mod Time"] = "Hora de mod.";
$messages["Actions"] = "Acciones";
$messages["Download the file %1\$s"] = "Download the file %1\$s";
$messages["View"] = "Ver";
$messages["Edit"] = "Editar";
$messages["Update"] = "Actualizar";
$messages["Open"] = "Abrir";
$messages["View the highlighted source code of file %1\$s"] = "Ver el codigo seleccionado del archivo %1\$s";
$messages["Edit the source code of file %1\$s"] = "Editar el codigo del archivo %1\$s";
$messages["Upload a new version of the file %1\$s and merge the changes"] = "Subir una nueva version del archivo %1\$s y actualiza los cambios";
$messages["View image %1\$s"] = "Ver imagen %1\$s";
$messages["View the file %1\$s from your HTTP web server"] = "Ver los archivos %1\$s desde tu servidor web";
$messages["(Note: This link may not work if you don't have your own domain name.)"] = "(Nota: Este link puede que no funcione si no tienes tu propio nombre de dominio.)";
$messages["This folder is empty"] = "El directorio esta vacio";

// printSeparatorRow()
$messages["Directories"] = "Directorios";
$messages["Files"] = "Archivos";
$messages["Symlinks"] = "Enlaces";
$messages["Unrecognized FTP output"] = "Respuesta FTP no reconocida";
$messages["Number"] = "Number";
$messages["Size"] = "Size";
$messages["Skipped"] = "Skipped";

// printLocationActions()
$messages["Language:"] = "Idioma:";
$messages["Skin:"] = "Plantilla:";
$messages["View mode:"] = "Modo de vista:";
$messages["Directory Tree"] = "Arbol de directorios";

// printURL()
$messages["Execute %1\$s in a new window"] = "Ejecutar %1\$s en una ventana nueva";

// printDirectorySelect()
$messages["Double-click to go to a subdirectory:"] = "Haz doble click para ir al subdirectorio:";
$messages["Choose"] = "Elegir";
$messages["Up"] = "Arriba";

} // end browse


// -------------------------------------------------------------------------
// consumption.inc.php
// -------------------------------------------------------------------------
$messages["Unable to determine your IP address."] = "Unable to determine your IP address.";
$messages["Table net2ftp_logConsumptionIpaddress contains duplicate rows."] = "Table net2ftp_logConsumptionIpaddress contains duplicate rows.";
$messages["Table net2ftp_logConsumptionFtpserver contains duplicate rows."] = "Table net2ftp_logConsumptionFtpserver contains duplicate rows.";
$messages["The variable <b>consumption_ipaddress_dataTransfer</b> is not numeric."] = "The variable <b>consumption_ipaddress_dataTransfer</b> is not numeric.";
$messages["Table net2ftp_logConsumptionIpaddress could not be updated."] = "Table net2ftp_logConsumptionIpaddress could not be updated.";
$messages["Table net2ftp_logConsumptionIpaddress contains duplicate entries."] = "Table net2ftp_logConsumptionIpaddress contains duplicate entries.";
$messages["Table net2ftp_logConsumptionFtpserver could not be updated."] = "Table net2ftp_logConsumptionFtpserver could not be updated.";
$messages["Table net2ftp_logConsumptionFtpserver contains duplicate entries."] = "Table net2ftp_logConsumptionFtpserver contains duplicate entries.";
$messages["Daily limit reached: the file <b>%1\$s</b> will not be transferred"] = "Daily limit reached: the file <b>%1\$s</b> will not be transferred";


// -------------------------------------------------------------------------
// database.inc.php
// -------------------------------------------------------------------------
$messages["Unable to connect to the DB"] = "Imposible conectar con la base de datos";
$messages["Unable to select the DB"] = "Error al elegir la base de datos";


// -------------------------------------------------------------------------
// easywebsite.inc.php
if ($state == "easyWebsite") {
// -------------------------------------------------------------------------
$messages["Create a website in 4 easy steps"] = "Create a website in 4 easy steps";
$messages["Template overview"] = "Template overview";
$messages["Template details"] = "Template details";
$messages["Files are copied"] = "Files are copied";
$messages["Edit your pages"] = "Edit your pages";

// Screen 1 - printTemplateOverview
$messages["Click on the image to view the details of a template."] = "Click on the image to view the details of a template.";
$messages["Back to the Browse screen"] = "Back to the Browse screen";
$messages["Template"] = "Template";
$messages["Copyright"] = "Copyright";
$messages["Click on the image to view the details of this template"] = "Click on the image to view the details of this template";

// Screen 2 - printTemplateDetails
$messages["The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?"] = "The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?";
$messages["Preview"] = "Preview";
$messages["Install"] = "Install";
$messages["Size"] = "Size";
$messages["Preview page"] = "Preview page";
$messages["opens in a new window"] = "opens in a new window";

// Screen 3
$messages["Please wait while the template files are being transferred to your server: "] = "Please wait while the template files are being transferred to your server: ";
$messages["Done."] = "Done.";
$messages["Continue"] = "Continue";

// Screen 4 - printEasyAdminPanel
$messages["Edit page"] = "Edit page";
$messages["Browse the FTP server"] = "Browse the FTP server";
$messages["Add this link to your favorites to return to this page later on!"] = "Add this link to your favorites to return to this page later on!";
$messages["Edit website at %1\$s"] = "Edit website at %1\$s";
$messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer: right-click on the link and choose \"Add to Favorites...\"";
$messages["Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\"";

// ftp_copy_local2ftp
$messages["WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing..."] = "WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing...";
$messages["Created target subdirectory <b>%1\$s</b>"] = "Created target subdirectory <b>%1\$s</b>";
$messages["WARNING: Unable to copy the file <b>%1\$s</b>. Continuing..."] = "WARNING: Unable to copy the file <b>%1\$s</b>. Continuing...";
$messages["Copied file <b>%1\$s</b>"] = "Copied file <b>%1\$s</b>";
}


// -------------------------------------------------------------------------
// edit.inc.php
if ($state == "manage" && ($state2 == "edit" || $state2 == "newfile")) {
// -------------------------------------------------------------------------

// edit()
$messages["Unable to open the template file"] = "Error al abrir la plantilla";
$messages["Unable to read the template file"] = "Error al leer la plantilla";
$messages["Please specify a filename"] = "Por favor espicifique un nombre de archivo";

// printEditForm()
$messages["Directory: "] = "Directorio: ";
$messages["File: "] = "Archivo: ";
$messages["New file name: "] = "Nuevo nombre de archivo: ";
$messages["Note: changing the textarea type will save the changes"] = "Nota: Al cambiar el tipo de texto se guardaran los cambios";
$messages["Status: This file has not yet been saved"] = "Estado: Este archivo no ha sido guardado";
$messages["Status: Saved on <b>%1\$s</b> using mode %2\$s"] = "Estado: Guardado <b>%1\$s</b> mediante modo %2\$s";
$messages["Status: <b>This file could not be saved</b>"] = "Estado: <b>Este archivo no pudo ser guardado</b>";

} // end if edit newfile


// -------------------------------------------------------------------------
// errorhandling.inc.php
// -------------------------------------------------------------------------
$messages["An error has occured"] = "Se ha producido un error";
$messages["Go back"] = "Volver";
$messages["Go to the login page"] = "Volver a iniciar sesi�n";


// -------------------------------------------------------------------------
// filesystem.inc.php
// -------------------------------------------------------------------------

// ftp_openconnection()
$messages["The <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this FTP module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">php.net</a><br />"] = "El <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">modulo FTP de PHP</a> no esta instalado.<br /><br /> El administrador del servidor tiene que habilitar este modulo. Se pueden encontrar instrucciones de como instalar este modulo <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">aqui.</a><br />";
$messages["Unable to connect to FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "Imposible conectarse al servidor FTP <b>%1\$s</b> en el puerto <b>%2\$s</b>.<br /><br />�Estas seguro que esta es la direcci�n correcta del servidor FTP? Normalmente esta direcci�n es distinta a la direcci�n para acceder por web. Por favor comun�cate con tu proveedor de Internet o tu administrador de sistemas para solicitar ayuda.<br />";
$messages["Unable to login to FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "Imposible iniciar sesi�n en el servidor FTP <b>%1\$s</b> utilizando el nombre de usuario <b>%2\$s</b>.<br /><br />�Estas seguro que tu nombre de usuario y contrase�a son correctos? <br />";
$messages["Unable to switch to the passive mode on FTP server <b>%1\$s</b>."] = "Imposible cambiar a modo pasivo en el servidor <b>%1\$s</b>.";

// ftp_openconnection2()
$messages["Unable to connect to the second (target) FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the second (target) FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "Imposible conectar al segundo servidor FTP <b>%1\$s</b> en el puerto <b>%2\$s</b>.<br /><br />�Estas seguro que esta es la direcci�n correcta del servidor FTP? Normalmente esta direcci�n es distinta a la direcci�n para acceder por HTTP. Por favor comun�cate con tu proveedor de Internet o tu administrador de sistemas para solicitar ayuda.<br />";
$messages["Unable to login to the second (target) FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "Imposible iniciar sesi�n en el segundo servidor FTP <b>%1\$s</b> utilizando el nombre de usuario <b>%2\$s</b>.<br /><br />�Estas seguro que tu nombre de usuario y contrase�a son correctos? Por favor comun�cate con tu proveedor de Internet o tu administrador de sistemas para solicitar ayuda.<br />";
$messages["Unable to switch to the passive mode on the second (target) FTP server <b>%1\$s</b>."] = "Imposible cambiar a modo pasivo de transferencia en el segundo servidor FTP <b>%1\$s</b>.";

// ftp_myrename()
$messages["Unable to rename directory or file <b>%1\$s</b> into <b>%2\$s</b>"] = "Imposible renombrar el archivo o directorio <b>%1\$s</b> a <b>%2\$s</b>";

// ftp_mychmod()
$messages["Unable to execute site command <b>%1\$s</b>. Note that the CHMOD command is only available on Unix FTP servers, not on Windows FTP servers."] = "Imposible ejecutar el comando <b>%1\$s</b>. El comando CHMOD solo esta disponible en servidores Unix, no en servidores Windows.";
$messages["Directory <b>%1\$s</b> successfully chmodded to <b>%2\$s</b>"] = "Se cambiaron los permisos del directorio <b>%1\$s</b> a <b>%2\$s</b>";
$messages["File <b>%1\$s</b> was successfully chmodded to <b>%2\$s</b>"] = "Se cambiaron los permisos del archivo <b>%1\$s</b> a <b>%2\$s</b>";
$messages["All the selected directories and files have been processed."] = "Todos los directorios y archivos seleccionados fueron procesados exitosamente.";

// ftp_rmdir2()
$messages["Unable to delete the directory <b>%1\$s</b>"] = "Unable to delete the directory <b>%1\$s</b>";

// ftp_delete2()
$messages["Unable to delete the file <b>%1\$s</b>"] = "Unable to delete the file <b>%1\$s</b>";

// ftp_newdirectory()
$messages["Unable to create the directory <b>%1\$s</b>"] = "Imposible crear el directorio <b>%1\$s</b>";

// ftp_readfile()
$messages["Unable to create the temporary file"] = "Imposible crear el archivo temporal";
$messages["Unable to get the file <b>%1\$s</b> from the FTP server and to save it as temporary file <b>%2\$s</b>.<br />Check the permissions of the %3\$s directory.<br />"] = "Imposible descargar el archivo <b>%1\$s</b> del servidor FTP y guardarlo temporalmente como <b>%2\$s</b>.<br />Revisa los permisos del directorio %3\$s .<br />";
$messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "Imposible abrir el archivo temporal. Revisa los permisos del directorio %1\$s .";
$messages["Unable to read the temporary file"] = "Imposible leer el archivo temporal";
$messages["Unable to close the handle of the temporary file"] = "Imposible cerrar el archivo temporal";
$messages["Unable to delete the temporary file"] = "Imposible eliminar el archivo temporal";

// ftp_writefile()
$messages["Unable to create the temporary file. Check the permissions of the %1\$s directory."] = "Imposible crear el archivo temporal. Revisa los permisos del directorio %1\$s .";
$messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "Imposible abrir el archivo temporal. Revisa los permisos del directorio %1\$s .";
$messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "Imposible escribir en el archivo temporal <b>%1\$s</b>.<br />Revisa los permisos del directorio %1\$s .";
$messages["Unable to close the handle of the temporary file"] = "Imposible cerrar el archivo temporal";
$messages["Unable to put the file <b>%1\$s</b> on the FTP server.<br />You may not have write permissions on the directory."] = "Imposible transferir el archivo <b>%1\$s</b> al servidor FTP.<br />Es posible que no tengas los permisos adecuados.";
$messages["Unable to delete the temporary file"] = "Imposible eliminar el archivo temporal";

// ftp_copymovedelete()
$messages["Processing directory <b>%1\$s</b>"] = "Procesando el directorio <b>%1\$s</b>";
$messages["The target directory <b>%1\$s</b> is the same as or a subdirectory of the source directory <b>%2\$s</b>, so this directory will be skipped"] = "El directorio <b>%1\$s</b> es el mismo que el subdirectorio<b>%2\$s</b>, este directorio sera omitido.";
$messages["Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing the copy/move process..."] = "Imposible crear el directorio <b>%1\$s</b>. Puede que ya exista. Continuando con el proceso de copiar y mover...";
$messages["Created target subdirectory <b>%1\$s</b>"] = "Se ha creado el subdirectorio <b>%1\$s</b>";
$messages["Unable to delete the subdirectory <b>%1\$s</b> - it may not be empty"] = "Imposible eliminar el subdirectorio <b>%1\$s</b> - es posible que no este vaci�";
$messages["Deleted subdirectory <b>%1\$s</b>"] = "Subdirectorio eliminado <b>%1\$s</b>";
$messages["Processing of directory <b>%1\$s</b> completed"] = "Procesamiento del directorio <b>%1\$s</b> completado";
$messages["The target for file <b>%1\$s</b> is the same as the source, so this file will be skipped"] = "El destino del archivo <b>%1\$s</b> es el mismo que su origen, este archivo sera omitido";
$messages["Unable to copy the file <b>%1\$s</b>"] = "Imposible copiar el archivo <b>%1\$s</b>";
$messages["Copied file <b>%1\$s</b>"] = "El archivo <b>%1\$s</b> fue copiado";
$messages["Unable to move the file <b>%1\$s</b>"] = "Imposible mover el archivo <b>%1\$s</b>";
$messages["Moved file <b>%1\$s</b>"] = "El archivo <b>%1\$s</b> fue movido";
$messages["Unable to delete the file <b>%1\$s</b>"] = "Imposible eliminar el archivo <b>%1\$s</b>";
$messages["Deleted file <b>%1\$s</b>"] = "El archivo <b>%1\$s</b> fue eliminado";
$messages["All the selected directories and files have been processed."] = "Todos los elementos seleccionados fueron procesados exitosamente.";

// ftp_processfiles()

// ftp_getfile()
$messages["Unable to copy the remote file <b>%1\$s</b> to the local file using FTP mode <b>%2\$s</b>"] = "Imposible copiar el archivo remoto <b>%1\$s</b> al directorio local utilizando <b>%2\$s</b>";
$messages["Unable to delete file <b>%1\$s</b>"] = "Imposible eliminar el archivo <b>%1\$s</b>";

// ftp_putfile()
$messages["Unable to copy the local file to the remote file <b>%1\$s</b> using FTP mode <b>%2\$s</b>"] = "Imposible copiar el archivo local <b>%1\$s</b> al servidor remoto utilizando <b>%2\$s</b>";
$messages["Unable to delete the local file"] = "Imposible eliminar el archivo local";

// ftp_downloadfile()
$messages["Unable to delete the temporary file"] = "Imposible eliminar el archivo temporal";
$messages["Unable to send the file to the browser"] = "Unable to send the file to the browser";

// ftp_zip()
$messages["Unable to create the temporary file"] = "Imposible crear el archivo temporal";
$messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "Imposible escribir en el archivo <b>%1\$s</b>.<br />Revisa los permisos del directorio %2\$s .";
$messages["Unable to close the handle of the temporary file"] = "Imposible cerrar el archivo temporal";
$messages["The zip file has been saved on the FTP server as <b>%1\$s</b>"] = "El archivo comprimido fue guardado en el servidor como <b>%1\$s</b>";
$messages["Requested files"] = "Archivos solicitados";

$messages["Zip email message"]  = "";
$messages["Zip email message"] .= "Estimado/a, \n\n";
$messages["Zip email message"] .= "Alguien ah solicitado que los archivos adjuntos en este correo electr�nico fueran enviados a esta direcci�n (%1\$s).\n";
$messages["Zip email message"] .= "Si no sabes de que se trata, o no conf�as en esta persona, por favor elimina este correo sin abrir los archivos adjuntos.\n";
$messages["Zip email message"] .= "Si no abres los archivos adjuntos, tu ordenador no puede sufrir ning�n tipo de da�o.\n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "Informacion del remitente:\n";
$messages["Zip email message"] .= "Direccion IP: %2\$s\n";
$messages["Zip email message"] .= "Hora en la que fue enviado: %3\$s\n";
$messages["Zip email message"] .= "Enviado por medio del programa net2ftp en este servidor: %4\$s \n";
$messages["Zip email message"] .= "Correo electr�nico del encargado: %5\$s \n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "Mensaje:\n";
$messages["Zip email message"] .= "%6\$s \n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "net2ftp es software gratuito, distribuido bajo la licencia GNU/GPL. Para mas informaci�n, visita http://www.net2ftp.com\n\n\n";

$messages["The zip file has been sent to <b>%1\$s</b>."] = "El archivo comprimido ha sido enviado a <b>%1\$s</b>.";

// acceptFiles()
$messages["File <b>%1\$s</b> is too big. This file will not be uploaded."] = "El archivo <b>%1\$s</b> es demasiado grande. Este archivo no ser� subido al servidor.";
$messages["Could not generate a temporary file."] = "Imposible generar el archivo temporal.";
$messages["File <b>%1\$s</b> could not be moved"] = "El archivo <b>%1\$s</b> no pudo ser movido.";
$messages["File <b>%1\$s</b> is OK"] = "El archivo <b>%1\$s</b> es correcto";
$messages["Unable to move the uploaded file to the temp directory.<br /><br />The administrator of this website has to <b>chmod 777</b> the /temp directory of net2ftp."] = "Imposible mover el archivo transferido al directorio temporal.<br /><br />El administrador de este servidor debe dar permisos con <b>chmod 777</b> el directorio /temp que utiliza net2ftp.";
$messages["You did not provide any file to upload."] = "No has seleccionado ning�n archivo para ser subido.";

// ftp_transferfiles()
$messages["File <b>%1\$s</b> could not be transferred to the FTP server"] = "El archivo <b>%1\$s</b> no pudo ser transferido al servidor FTP";
$messages["File <b>%1\$s</b> has been transferred to the FTP server using FTP mode <b>%2\$s</b>"] = "El archivo <b>%1\$s</b> ha sido transferido al servidor utilizando <b>%2\$s</b>";
$messages["Transferring files to the FTP server"] = "Transferring files to the FTP server";

// ftp_unziptransferfiles()
$messages["Processing archive nr %1\$s: <b>%2\$s</b>"] = "Procesando el archivo %1\$s: <b>%2\$s</b>";
$messages["Unable to open the archive <b>%1\$s</b> (file %2\$s)"] = "Imposible abrir el archivo <b>%1\$s</b> (file %2\$s)";
$messages["Could not create directory <b>%1\$s</b>"] = "Imposible crear el directorio <b>%1\$s</b>";
$messages["Created directory <b>%1\$s</b>"] = "Directorio creado <b>%1\$s</b>";
$messages["File Contents:"] = "Contenido del archivo:";
$messages["Could not put the file <b>%1\$s</b> to the directory <b>%2\$s</b>"] = "Imposible copiar el archivo <b>%1\$s</b> al directorio <b>%2\$s</b>";
$messages["Transferred file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "El archivo <b>%1\$s</b> fue transferido al directorio <b>%2\$s</b>";
$messages["Unable to delete the archive <b>%1\$s</b> (file %2\$s)"] = "Imposible eliminar el archivo <b>%1\$s</b> (file %2\$s)";
$messages["Unable to get the list of the contents of the Zip archive. Error code: %1\$s"] = "Imposible ver el contenido del archivo comprimido. Codigo de error: %1\$s";
$messages["Unable to get the list of the contents of the Tar archive."] = "Imposible ver el contenido del archivo .tar.";
$messages["Could not create directory <b>%1\$s</b>"] = "Imposible crear el directorio <b>%1\$s</b>";
$messages["Created directory <b>%1\$s</b>"] = "El directorio <b>%1\$s</b> fue creado";
$messages["Unable to create the temporary file"] = "Imposible crear el archivo temporal";
$messages["Unable to extract file nr <b>%1\$s</b> from the archive."] = "Imposible extraer el archivo <b>%1\$s</b> del archivo comprimido.";
$messages["Could not put file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "Imposible copiar el archivo <b>%1\$s</b> al directorio <b>%2\$s</b>";
$messages["Transferred file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "El archivo <b>%1\$s</b> fue transferido al directorio <b>%2\$s</b>";
$messages["Unable to delete the temporary file <b>%1\$s</b>."] = "Imposible eliminar el archivo temporal <b>%1\$s</b>.";
$messages["Archive <b>%1\$s</b> was not processed because its filename extension was not recognized. Only zip, tar, tgz and gz archives are supported at the moment."] = "El archivo <b>%1\$s</b> no fue procesado porque su extensi�n no es reconocida. Por el momento net2ftp solo soporta archivos comprimidos zip, tar, tgz o gz.";
$messages["Unzipping and transferring files"] = "Unzipping and transferring files";

// ftp_mysite()
$messages["Unable to execute site command <b>%1\$s</b>"] = "Imposible ejecutar el comando <b>%1\$s</b>";

// shutdown()
$messages["Shutdown message"]  = "";
$messages["Shutdown message"] .= "<b>Tu proceso fue detenido</b><br /><br />";
$messages["Shutdown message"] .= "El proceso que ejecutaste con net2ftp tard� mas de %1\$s segundos, y por lo tanto fue detenido.<br />";
$messages["Shutdown message"] .= "Este tiempo limite garantiza una distribuci�n equitativa para todos los usuarios.<br /><br />";
$messages["Shutdown message"] .= "Intenta dividir tu proceso: intenta transferir menos archivos, intenta transferir los archivos mas grandes por separado.<br /><br />";
$messages["If you really need net2ftp to be able to handle big tasks which take a long time, consider installing net2ftp on your own server."] = "Si en verdad necesitas que net2ftp ejecute procesos tan grandes, considera instalar net2ftp en tu propio servidor.";

// SendMail()
$messages["You did not provide any text to send by email!"] = "�No escribiste nada para ser enviado por correo electr�nico!";
$messages["You did not supply a From address."] = "No especificaste la direcci�n del remitente.";
$messages["You did not supply a To address."] = "No especificaste la direcci�n del destinatario.";
$messages["Due to technical problems the email to <b>%1\$s</b> could not be sent."] = "Debido a problemas t�cnicos el correo electronico a <b>%1\$s</b> no pudo ser enviado.";

// printFunctionTags()
$messages["Output generated by function %1\$s"] = "Salida generada por la funcion %1\$s";



// -------------------------------------------------------------------------
// homepage.inc.php
if ($state == "homepage") {
// -------------------------------------------------------------------------
$messages["net2ftp features short"] ="Una vez que inicies la sesi�n podras: \n";
$messages["net2ftp features short"] .="<ul>\n";
$messages["net2ftp features short"] .="<li> Navegar en el servidor FTP</li>\n";
$messages["net2ftp features short"] .="<li> Descargar y subir archivos <span style=\"font-size: 80%%; color: red;\">nuevo: numero ilimitado de archivos a transferir.</span></li>\n";
$messages["net2ftp features short"] .="<li> copiar, mover, eliminar, renombrar, chmod</li>\n";
$messages["net2ftp features short"] .="<li> copiar, mover a un segundo servidor FTP</li>\n";
$messages["net2ftp features short"] .="<li> ver codigo con secciones seleccionadas</li>\n";
$messages["net2ftp features short"] .="<li> ver imagenes <span style=\"font-size: 80%%; color: red;\">nuevo</span></li>\n";
$messages["net2ftp features short"] .="<li> editar archivos de texto</li>\n";
$messages["net2ftp features short"] .="<li> editar HTML en varios editores HTML <span style=\"font-size: 80%%; color: red;\">nuevo</span></li>\n";
$messages["net2ftp features short"] .="<li> editar HTML y PHP con codigo seleccionado <span style=\"font-size: 80%%; color: red;\">nuevo</span></li>\n";
$messages["net2ftp features short"] .="<li> comprimir archivos para descargar, enviarlos por correo electr�nico o salvarlos en el servidor FTP</li>\n";
$messages["net2ftp features short"] .="<li> transferir y descomprimir (zip, tar, tgz, gz)</li>\n";
$messages["net2ftp features short"] .="<li> hacer b�squedas por palabras o frases</li>\n";
$messages["net2ftp features short"] .="<li> calcular el tama�o de directorios y archivos</li>\n";
$messages["net2ftp features short"] .="</ul>\n";

} // end homepage


// -------------------------------------------------------------------------
// net2ftp_loginform.inc.php
// -------------------------------------------------------------------------
$messages["FTP server"] = "Servidor FTP";
$messages["Example"] = "Ejemplo";
$messages["Username"] = "Nombre de Usuario";
$messages["Password"] = "Contrase�a";
$messages["Anonymous"] = "Anonimo";
$messages["Passive mode"] = "Modo pasivo";
$messages["Initial directory"] = "Directorio inicial";
$messages["Language"] = "Idioma";
$messages["Skin"] = "Plantilla";
$messages["FTP mode"] = "FTP mode";
$messages["Login"] = "Login";
$messages["Clear cookies"] = "Borrar cookies";
$messages["Please enter an FTP server."] = "Please enter an FTP server.";
$messages["Please enter a username."] = "Please enter a username.";
$messages["Please enter a password."] = "Please enter a password.";


// -------------------------------------------------------------------------
// html.inc.php
// -------------------------------------------------------------------------

// HtmlBegin()
$messages["Status:"] = "Estado:";

// HtmlEnd()
$messages["net2ftp Help Guide"] = "Guia de ayuda de net2ftp";
$messages["net2ftp Forums"] = "Foros de net2ftp";
$messages["License"] = "Licencia";
$messages["Powered by"] = "Powered by";

// printJavascriptFunctions()
$messages["Choose a directory"] = "Selecciona un directorio";
$messages["Please wait..."] = "Por favor espera...";
$messages["Uploading... please wait..."] = "Subiendo al servidor... por favor espera...";
$messages["If the upload takes more than the allowed <b>%1\$s seconds<\/b>, you will have to try again with less/smaller files."] = "Si la transferencia dura mas de <b>%1\$s segundos<\/b>, tendr�s que volver a intentarlo con menos archivos.";
$messages["This window will close automatically in a few seconds."] = "Esta ventana se cerrara autom�ticamente en unos segundos.";
$messages["Close window now"] = "Cerrar ventana";


// -------------------------------------------------------------------------
// httpheaders.inc.php
// -------------------------------------------------------------------------
// Nothing to translate


// -------------------------------------------------------------------------
// manage.inc.php
if ($state == "manage") {
// -------------------------------------------------------------------------

// manage()
$messages["Please select at least one directory or file!"] = "�Por favor selecciona por lo menos un archivo o directorio!";
$messages["Unexpected state2 string. Exiting."] = "Estado dos de cadena inesperado. Terminando.";

// renameentry()
if ($state2 == "rename") {
$messages["Rename directories and files"] = "Renombrar directorios y archivos";
$messages["Old name: "] = "Nombre antiguo: ";
$messages["New name: "] = "Nombre nuevo: ";
$messages["The new name may not contain any dots. This entry was not renamed to <b>%1\$s</b>"] = "El nombre nuevo no puede contener puntos. El elemento no fue renombrado a <b>%1\$s</b>";
$messages["<b>%1\$s</b> was successfully renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> fue renombrado a <b>%2\$s</b>";
$messages["<b>%1\$s</b> could not be renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> could not be renamed to <b>%2\$s</b>";
}

// chmodentry()
if ($state2 == "chmod") {
$messages["Chmod directories and files"] = "Cambiar permisos de directorios y archivos";
$messages["Set all permissions"] = "Cambiar todos los permidos";
$messages["Read"] = "Leer";
$messages["Write"] = "Escribir";
$messages["Execute"] = "Ejecutar";
$messages["Owner"] = "Propietario";
$messages["Group"] = "Grupo";
$messages["Everyone"] = "Todos";
$messages["To set all permissions to the same values, enter those permissions above and click on the button \"Set all permissions\""] = "Para dar permisos a todos de igual manera, elige los permisos y haz click en \"Dar permisos a todos\"";
$messages["Set the permissions of directory <b>%1\$s</b> to: "] = "Dar permisos al directorio <b>%1\$s</b> como: ";
$messages["Set the permissions of file <b>%1\$s</b> to: "] = "Dar permisos al archivo <b>%1\$s</b> como: ";
$messages["Set the permissions of symlink <b>%1\$s</b> to: "] = "Dar permisos al enlace <b>%1\$s</b> como: ";
$messages["Chmod value"] = "Valor Chmod";
$messages["Chmod also the subdirectories within this directory"] = "Dar permisos tambien los subdirectorios dentro de este directorio";
$messages["Chmod also the files within this directory"] = "Dar permisos tambien los archivos dentro de este directorio";
$messages["The chmod nr <b>%1\$s</b> is out of the range 000-777. Please try again."] = "El c�digo de permiso <b>%1\$s</b> esta fuera del rango 000-777. Porfavor intenta de nuevo.";
}

// copymovedeleteentry()
if ($state2 == "copy" || $state2 == "move" || $state2 == "delete") {
$messages["Copy directories and files"] = "Copiar directorios y archivos";
$messages["Move directories and files"] = "Mover directorios y archivos";
$messages["Delete directories and files"] = "Eliminar directorios y archivos";
$messages["Are you sure you want to delete these directories and files?"] = "�Estas seguro que quieres eliminar estos directorios y archivos?";
$messages["All the subdirectories and files of the selected directories will also be deleted!"] = "�Todos los archivos y subdirectorios dentro de los directorios seleccionados ser�n eliminados!";
$messages["Set all targetdirectories"] = "Especificar el directorio destino";
$messages["To set a common target directory, enter that target directory in the textbox above and click on the button \"Set all targetdirectories\"."] = "Para especificar un directorio destino com�n, escribe el nombre del directorio en el campo que esta arriba y haz clic en \"Especificar directorio destino comun\".";
$messages["Note: the target directory must already exist before anything can be copied into it."] = "Nota: El directorio destino debe existir antes de poder copiar archivos dentro de el.";
$messages["Different target FTP server:"] = "Servidor FTP de destino:";
$messages["Leave empty if you want to copy the files to the same FTP server."] = "Deja en blanco si quieres copiar los archivos al mismo servidor FTP.";
$messages["If you want to copy the files to another FTP server, enter your login data."] = "Si quieres copiar los archivos a un servidor FTP distingo, escribe tu nombre de usuario, contrase�a y otros datos.";
$messages["Leave empty if you want to move the files to the same FTP server."] = "Deja en blanco si quieres mover los archivos al mismo servidor FTP.";
$messages["If you want to move the files to another FTP server, enter your login data."] = "Si quieres mover los archivos a un servidor FTP distingo, escribe tu nombre de usuario, contrase�a y otros datos.";
$messages["Copy directory <b>%1\$s</b> to:"] = "Copiar directorio <b>%1\$s</b> to:";
$messages["Move directory <b>%1\$s</b> to:"] = "Mover directorio <b>%1\$s</b> to:";
$messages["Directory <b>%1\$s</b>"] = "Directorio <b>%1\$s</b>";
$messages["Copy file <b>%1\$s</b> to:"] = "Copiar archivo <b>%1\$s</b> to:";
$messages["Move file <b>%1\$s</b> to:"] = "Mover archivo <b>%1\$s</b> to:";
$messages["File <b>%1\$s</b>"] = "Archivo <b>%1\$s</b>";
$messages["Copy symlink <b>%1\$s</b> to:"] = "Copiar enlace <b>%1\$s</b> to:";
$messages["Move symlink <b>%1\$s</b> to:"] = "Mover enlace <b>%1\$s</b> to:";
$messages["Symlink <b>%1\$s</b>"] = "Enlace <b>%1\$s</b>";
$messages["Target directory:"] = "Directorio destino:";
$messages["Target name:"] = "Nombre de destino:";
$messages["Processing the entries:"] = "Procesando los elementos:";
}

// newdirectory()
if ($state2 == "newdirectory") {
$messages["Create new directories"] = "Crear nuevo directorio";
$messages["The new directories will be created in <b>%1\$s</b>."] = "El nuevo directorio ser� creado dentro de <b>%1\$s</b>.";
$messages["New directory name:"] = "Nombre del directorio nuevo:";
$messages["Directory <b>%1\$s</b> was successfully created."] = "El directorio <b>%1\$s</b> fue creado.";
}

// uploadfile()
if ($state2 == "uploadfile") {
$messages["Upload files and archives"] = "Subir archivos";
$messages["Upload results"] = "Subir resultados";
$messages["Checking files:"] = "Revisando archivos:";
$messages["Transferring files to the FTP server:"] = "Transfiriendo archivos al servidor FTP:";
$messages["Decompressing archives and transferring files to the FTP server:"] = "Descomprimiendo y transfiriendo los archivos al servidor FTP:";
$messages["Upload more files and archives"] = "Subir mas archivos al servidor";
}

// printUploadForm() and javaupload()
if ($state2 == "uploadfile" || $state2 == "javaupload") {
$messages["Upload to directory:"] = "Transferir al directorio:";
$messages["Files"] = "Archivos";
$messages["Archives"] = "Archivos";
$messages["Files entered here will be transferred to the FTP server."] = "Los archivos seleccionados seran transferidos al servidor FTP.";
$messages["Archives entered here will be decompressed, and the files inside will be transferred to the FTP server."] = "Los archivos seleccionados ser�n descomprimidos y transferidos al servidor FTP.";
$messages["Add another"] = "Agregar nuevo";
$messages["Use folder names (creates subdirectories automatically)"] = "Conservar estructura del directorio (los subdirectorios ser�n creados autom�ticamente)";
$messages["Restrictions:"] = "Restricciones:";
$messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s kB</b> and by PHP to <b>%2\$s</b>"] = "El tama�o maximo de un archivo esta restringido por net2ftp a <b>%1\$s kB</b> y por PHP a <b>%2\$s</b>";
$messages["The maximum execution time is <b>%1\$s seconds</b>"] = "El tiempo maximo de ejecucion es de <b>%1\$s segundos</b>";
$messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "El modo de transferencia FTP (ASCII or BINARY) sera elegido automaticamente, basandose en la extencion del archivo";
$messages["If the destination file already exists, it will be overwritten"] = "Si el archivo ya existe, sera sobreescrito";

$messages["Upload directories and files using a Java applet"] = "Upload directories and files using a Java applet";
$messages["Number of files:"] = "Number of files:";
$messages["Size of files:"] = "Size of files:";
$messages["Add"] = "Add";
$messages["Remove"] = "Remove";
$messages["Upload"] = "Upload";
$messages["Add files to the upload queue"] = "Add files to the upload queue";
$messages["Remove files from the upload queue"] = "Remove files from the upload queue";
$messages["Upload the files which are in the upload queue"] = "Upload the files which are in the upload queue";
$messages["Maximum server space exceeded. Please select less/smaller files."] = "Maximum server space exceeded. Please select less/smaller files.";
$messages["Total size of the files is too big. Please select less/smaller files."] = "Total size of the files is too big. Please select less/smaller files.";
$messages["Total number of files is too high. Please select fewer files."] = "Total number of files is too high. Please select fewer files.";
$messages["Note: to use this applet, Sun's Java plugin must be installed (version 1.4 or newer)."] = "Note: to use this applet, Sun's Java plugin must be installed (version 1.4 or newer).";

$messages["Browser does not support Java applets"] = "Your browser does not support applets, or you have disabled applets in your browser settings.\n";
$messages["Browser does not support Java applets"] .= "To use this applet, please install the newest version of Sun's java. You can get it from <a href=\"http://www.java.com/\">java.com</a>. Click on Get It Now.\n";
$messages["Browser does not support Java applets"] .= "The online installation is about 1-2 MB and the offline installation is about 13 MB. This 'end-user' java is called JRE (Java Runtime Environment).\n";
$messages["Browser does not support Java applets"] .= "Alternatively, use net2ftp's normal upload or upload-and-unzip functionality.\n";
}

// zipentry()
if ($state2 == "zip") {
$messages["Zip entries"] = "Archivos comprimidos";
$messages["Save the zip file on the FTP server as:"] = "Salvar el archivo comprimido en el servidor como:";
$messages["Email the zip file in attachment to:"] = "Enviar el archivo comprimido por correo electronico a:";
$messages["Note that sending files is not anonymous: your IP address as well as the time of the sending will be added to the email."] = "Enviar archivos de esta manera no es an�nimo: Tu direcci�n IP y la hora de envi� ser�n visibles en el correo electr�nico.";
$messages["Some additional comments to add in the email:"] = "Comentarios adicionales:";
$messages["You did not enter a filename for the zipfile. Go back and enter a filename."] = "No especificaste un nombre para el archivo comprimido. Por favor vuelve y especifica un nombre.";
$messages["The email address you have entered (%1\$s) does not seem to be valid.<br />Please enter an address in the format <b>username@domain.com</b>"] = "La direccion de correo electronico (%1\$s) no es valida.<br />Porfavor especifica una direccion con el formato <b>usuario@dominio.com</b>";
}

// calculatesize()
if ($state2 == "calculatesize") {
$messages["Size of selected directories and files"] = "Tama�o de los directorios y archivos seleccionados";
$messages["The total size taken by the selected directories and files is:"] = "El tama�o total de los archivos y directorios seleccionados es de:";
$messages["The nr of files which were skipped:"] = "El numero de archivos que fueron omitidos:";
}

// findstring()
if ($state2 == "findstring") {
$messages["Search directories and files"] = "Buscar directorios y archivos";
$messages["Search results"] = "Resultados de la b�squeda";
$messages["Please enter a valid search word or phrase."] = "Por favor escribe una palabra o frase valida de b�squeda.";
$messages["Please enter a valid filename."] = "Por favor escribe un nombre de archivo valido.";
$messages["Please enter a valid file size in the \"from\" textbox, for example 0."] = "Por favor escribe un tama�o de archivo valido en el cuadro de texto \"De\", por ejemplo: 0.";
$messages["Please enter a valid file size in the \"to\" textbox, for example 500000."] = "Por favor escribe un tama�o de archivo valido en la caja de texto \"A\",  por ejemplo: 500000.";
$messages["Please enter a valid date in Y-m-d format in the \"from\" textbox."] = "Por favor escribe un fecha valida en formato A-m-d en la caja de texto \"De\".";
$messages["Please enter a valid date in Y-m-d format in the \"to\" textbox."] = "Por favor escribe un fecha valida en formato A-m-d en la caja de texto \"A\".";
$messages["The word <b>%1\$s</b> was not found in the selected directories and files."] = "La palabra <b>%1\$s</b> no fue encontrada en los archivos y directorios seleccionados.";
$messages["The word <b>%1\$s</b> was found in the following files:"] = "La palabra <b>%1\$s</b> fue encontrada en los siguientes archivos:";
$messages["Search again"] = "Buscar de nuevo";
}

// printFindstringForm()
if ($state2 == "findstring") {
$messages["Search for a word or phrase"] = "Buscar frase o palabra";
$messages["Case sensitive search"] = "Buscar frase o palabra exacta incluyendo min�sculas y may�sculas";
$messages["Restrict the search to:"] = "Restringir la busqueda a:";
$messages["files with a filename like"] = "archivos con un nombre como";
$messages["(wildcard character is *)"] = "(el caracter comodin es *)";
$messages["files with a size"] = "archivos del tama�o";
$messages["from"] = "De";
$messages["to"] = "A";
$messages["files which were last modified"] = "archivos que fueron modificados por ultima vez";
}

// updatefile()
if ($state2 == "updatefile") {
$messages["Update file"] = "Actualizar archivo";
$messages["<b>WARNING: THIS FUNCTION IS STILL IN EARLY DEVELOPMENT. USE IT ONLY ON TEST FILES! YOU HAVE BEEN WARNED!"] = "<b>CUIDADO: �ESTA FUNCION ESTA EN DESARROLLO! �USALA SOLO EN ARCHIVOS QUE NO SEAN IMPORTANTES! �HAS SIDO ADVERTIDO!";
$messages["Known bugs: - erases tab characters - doesn't work well with big files (> 50kB) - was not tested yet on files containing non-standard characters</b>"] = "Errores conocidos: - elimina tabulaciones - no funciona bien con archivos grandes (> 50kB) - no ha sido probado en archivos que contengan caracteres fuera de lo normal</b>";
$messages["This function allows you to upload a new version of the selected file, to view what are the changes and to accept or reject each change. Before anything is saved, you can edit the merged files."] = "Esta funci�n te permite subir una versi�n nueva del archivo seleccionado, revisar que cambios tendr�n efecto y aprobar o desaprobar cada cambio. Antes de salvar cualquier cambio, puedes editar los archivos.";
$messages["Old file:"] = "Archivo antiguo:";
$messages["New file:"] = "Archivo nuevo:";
$messages["Restrictions:"] = "Restricciones:";
$messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s kB</b> and by PHP to <b>%2\$s</b>"] = "El tama�o maximo de un archivo esta restringido por net2ftp a <b>%1\$s kB</b> y por PHP a <b>%2\$s</b>";
$messages["The maximum execution time is <b>%1\$s seconds</b>"] = "El tiempo maximo de ejecucion es de <b>%1\$s segundos</b>";
$messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "El modo de transferencia (ASCII o BINARY) sera elegido automaticamente, basandose en la extension del nombre de archivo";
$messages["If the destination file already exists, it will be overwritten"] = "Si el archivo destino ya existe sera sobreescrito";
$messages["You did not provide any files or archives to upload."] = "No seleccionaste directorios o archivos para transferir.";
$messages["Unable to delete the new file"] = "Imposible eliminar el archivo nuevo";
}

// printComparisonSelect()
if ($state2 == "updatefile") {
$messages["Please wait..."] = "Por favor espera...";
$messages["Select lines below, accept or reject changes and submit the form."] = "Selecciona las siguientes l�neas, aprueba o desaprueba cada cambio y salva los cambios.";
}

} // end manage


// -------------------------------------------------------------------------
// registerglobals.inc.php
// -------------------------------------------------------------------------
$messages["Please enter your username and password for FTP server "] = "Please enter your username and password for FTP server ";
$messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below.";
$messages["Access to the net2ftp Admin panel is disabled, because no password has been set in the file settings.inc.php. Enter a password in that file, and reload this page."] = "Access to the net2ftp Admin panel is disabled, because no password has been set in the file settings.inc.php. Enter a password in that file, and reload this page.";
$messages["Please enter your Admin username and password"] = "Please enter your Admin username and password"; 
$messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below.";
$messages["Wrong username or password for the net2ftp Admin panel. The username and password can be set in the file settings.inc.php."] = "Wrong username or password for the net2ftp Admin panel. The username and password can be set in the file settings.inc.php.";


// -------------------------------------------------------------------------
// skins.inc.php
// -------------------------------------------------------------------------
$messages["Blue"] = "Azul";
$messages["Grey"] = "Gris";
$messages["Black"] = "Negro";
$messages["Yellow"] = "Amarillo";
$messages["Pastel"] = "Pastel";

// getMime()
$messages["Directory"] = "Directorio";
$messages["Symlink"] = "Enlace";
$messages["ASP script"] = "Script ASP";
$messages["Cascading Style Sheet"] = "Hoja de estilos";
$messages["HTML file"] = "Archivo HTML";
$messages["Java source file"] = "Archivo de codigo JAVA";
$messages["JavaScript file"] = "Archivo JavaScript";
$messages["PHP Source"] = "Codigo PHP";
$messages["PHP script"] = "Script PHP";
$messages["Text file"] = "Archivo de texto";
$messages["Bitmap file"] = "Imagen Bitmap";
$messages["GIF file"] = "Imagen GIF";
$messages["JPEG file"] = "Imagen JPEG";
$messages["PNG file"] = "Imagen PNG";
$messages["TIF file"] = "Imagen TIF";
$messages["GIMP file"] = "Imagen GIMP";
$messages["Executable"] = "Ejecutable";
$messages["Shell script"] = "Script de shell";
$messages["MS Office - Word document"] = "MS Office - Documento Word";
$messages["MS Office - Excel spreadsheet"] = "MS Office - Tabla Excel";
$messages["MS Office - PowerPoint presentation"] = "MS Office - Presentacion PowerPoint";
$messages["MS Office - Access database"] = "MS Office - Base de datos Access";
$messages["MS Office - Visio drawing"] = "MS Office - Imagen Visio";
$messages["MS Office - Project file"] = "MS Office - Archivo de proyecto";
$messages["OpenOffice - Writer 6.0 document"] = "OpenOffice - Documento Writer 6.0";
$messages["OpenOffice - Writer 6.0 template"] = "OpenOffice - Plantilla Writer 6.0";
$messages["OpenOffice - Calc 6.0 spreadsheet"] = "OpenOffice - Tabla Calc 6.0";
$messages["OpenOffice - Calc 6.0 template"] = "OpenOffice - Plantilla Calc 6.0";
$messages["OpenOffice - Draw 6.0 document"] = "OpenOffice - Docuemento Draw 6.0";
$messages["OpenOffice - Draw 6.0 template"] = "OpenOffice - Plantilla Draw 6.0";
$messages["OpenOffice - Impress 6.0 presentation"] = "OpenOffice - Presentacion Impress 6.0";
$messages["OpenOffice - Impress 6.0 template"] = "OpenOffice - Plantilla Impress 6.0";
$messages["OpenOffice - Writer 6.0 global document"] = "OpenOffice - Documento global Writer 6.0";
$messages["OpenOffice - Math 6.0 document"] = "OpenOffice - Documento Math 6.0";
$messages["StarOffice - StarWriter 5.x document"] = "StarOffice - Documento StarWriter 5.x";
$messages["StarOffice - StarWriter 5.x global document"] = "StarOffice - Documento global StarWriter 5.x";
$messages["StarOffice - StarCalc 5.x spreadsheet"] = "StarOffice - Tabla StarCalc 5.x";
$messages["StarOffice - StarDraw 5.x document"] = "StarOffice - Documento StarDraw 5.x";
$messages["StarOffice - StarImpress 5.x presentation"] = "StarOffice - Presentacion StarImpress 5.x";
$messages["StarOffice - StarImpress Packed 5.x file"] = "StarOffice - Archivo StarImpress Packed 5.x";
$messages["StarOffice - StarMath 5.x document"] = "StarOffice - Documento StarMath 5.x";
$messages["StarOffice - StarChart 5.x document"] = "StarOffice - Documento StarChart 5.x";
$messages["StarOffice - StarMail 5.x mail file"] = "StarOffice - Archivo de correo StarMail 5.x";
$messages["Adobe Acrobat document"] = "Documento Adobe Acrobat";
$messages["ARC archive"] = "Archivo ARC";
$messages["ARJ archive"] = "Archivo ARJ";
$messages["RPM"] = "RPM";
$messages["GZ archive"] = "Archivo GZ";
$messages["TAR archive"] = "Archivo TAR";
$messages["Zip archive"] = "Archivo Zip";
$messages["MOV movie file"] = "Pelicula MOV";
$messages["MPEG movie file"] = "Pelicula MPEG";
$messages["Real movie file"] = "Pelicula Real";
$messages["Quicktime movie file"] = "Pelicula Quicktime";
$messages["Shockwave flash file"] = "Pelicula Flash Shockwave";
$messages["Shockwave file"] = "Archivo Shockwave";
$messages["WAV sound file"] = "Archivo de sonido WAV";
$messages["Font file"] = "Archivo de fuente";
$messages["%1\$s File"] = "Archivo %1\$s";
$messages["File"] = "Archivo";

// getAction()
$messages["Back"] = "Volver";
$messages["Submit"] = "Aceptar";
$messages["Refresh"] = "Actualizar";
$messages["Details"] = "Detalles";
$messages["Icons"] = "Iconos";
$messages["List"] = "Lista";
$messages["Logout"] = "Cerrar sesi�n";
$messages["Help"] = "Ayuda";
$messages["Bookmark"] = "Favorito";
$messages["Save"] = "Salvar";
$messages["Default"] = "Defecto";


// -------------------------------------------------------------------------
// view.inc.php
// -------------------------------------------------------------------------
$messages["Image"] = "Image";
$messages["View Macromedia ShockWave Flash movie %1\$s"] = "View Macromedia ShockWave Flash movie %1\$s";
$messages["View file %1\$s"] = "View file %1\$s";
$messages["To save the image, right-click on it and choose 'Save picture as...'"] = "To save the image, right-click on it and choose 'Save picture as...'";


// ----------------------------------------------------------------------------------
// DO NOT CHANGE ANYTHING BELOW THIS LINE
// ----------------------------------------------------------------------------------

return $messages;

} // end function getMessages

?>