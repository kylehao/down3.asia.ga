<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------

//   -------------------------------------------------------------------------------
//  | Language: Polish                                                              |
//   -------------------------------------------------------------------------------
//  | mastergigi <email> 2004-07-02                                                 |
//   -------------------------------------------------------------------------------
//  |                                                                               |
//  |                              INSTRUCTIONS                                     |
//  |                                                                               |
//  |  The messages to translate are listed below.                                  |
//  |  The structure of each line is like this:                                     |
//  |     $message["Hello world!"] = "Hello world!";                                |
//  |                                                                               |
//  |  Keep the text between square brackets [] as it is.                           |
//  |  Translate the 2nd part, keeping the same punctuation and HTML tags.          |
//  |                                                                               |
//  |  The English message, for example                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is written in PHP!";    |
//  |  should become after translation:                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp est ecrit en PHP!";     |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is geschreven in PHP!"; |
//  |                                                                               |
//  |  Note that the variable starts with a dollar sign $, that the value is        |
//  |  enclosed in double quotes " and that the line ends with a semi-colon ;       |
//  |  Be careful when editing this file, do not erase those special characters.    |
//  |                                                                               |
//  |  Some messages also contain one or more variables which start with a percent  |
//  |  sign, for example %1\$s or %2\$s. The English message, for example           |
//  |     $messages[...] = ["The file %1\$s was copied to %2\$s "]                  |
//  |  should becomes after translation:                                            |
//  |     $messages[...] = ["Le fichier %1\$s a �t� copi� vers %2\$s "]             |
//  |                                                                               |
//  |  When a real percent sign % is needed in the text it is entered as %%         |
//  |  otherwise it is interpreted as a variable. So no, it's not a mistake.        |
//  |                                                                               |
//  |  Between the messages to translate there is additional PHP code, for example: |
//  |     if ($state2 == "rename") {                               // <-- PHP code  |
//  |     $messages["Rename directories"] = "Rename directories";  // <-- message   |
//  |     }                                                        // <-- PHP code  |
//  |  This code is needed to load the messages only when they are actually needed. |
//  |  There is no need to change or delete any of that PHP code; translate only    |
//  |  the message.                                                                 |
//  |                                                                               |
//  |  Thanks in advance to all the translators!                                    |
//  |  David.                                                                       |
//  |                                                                               |
//   -------------------------------------------------------------------------------

function getMessages() {
global $state, $state2;


// -------------------------------------------------------------------------
// Used encoding
// -------------------------------------------------------------------------
$messages["iso-8859-1"] = "iso-8859-2";


// -------------------------------------------------------------------------
// Status messages
// -------------------------------------------------------------------------
// When translating these messages, keep in mind that the text should not be too long
// It should fit in the status textbox
$messages["Connecting to the FTP server"] = "��czenie z serwerem FTP";
$messages["Getting the list of directories and files"] = "Pobieranie listy plik�w i katalog�w";
$messages["Printing the list of directories and files"] = "Tworzenie listy plik�w i katalog�w";
$messages["Processing the entries"] = "Przetwarzanie sk�adowych listy";
$messages["Checking files"] = "Sprawdzanie plik�w";
$messages["Transferring files to the FTP server"] = "Przesy�anie plik�w na serwer FTP";
$messages["Decompressing archives and transferring files"] = "Dekompresja plik�w i przesy�anie";
$messages["Searching the files..."] = "Szukanie plik�w...";
$messages["Uploading new file"] = "Przesy�anie nowego pliku";
$messages["Reading the new file"] = "Czytanie nowego pliku";
$messages["Reading the old file"] = "Czytanie starego pliku";
$messages["Comparing the 2 files"] = "Por�wnywanie dw�ch plik�w";
$messages["Printing the comparison"] = "Wyprowadzanie wyniku por�wnania";
$messages["Script finished in %1\$s seconds"] = "Czas wykonania skryptu %1\$s sekund";
$messages["Script halted"] = "Skrypt zatrzymany";


// -------------------------------------------------------------------------
// index.php
// -------------------------------------------------------------------------
$messages["Unexpected state string. Exiting."] = "Nieznana wartos� zmiennej state. Ko�czenie dzia�ania.";
$messages["This beta function is not activated on this server."] = "Ta funkcja beta nie jest aktywna na tym serwerze.";
$messages["This function has been disabled by the Administrator of this website."] = "This function has been disabled by the Administrator of this website.";


// -------------------------------------------------------------------------
// admin.inc.php
if ($state == "admin") {
// -------------------------------------------------------------------------
$messages["Admin functions"] = "Admin functions";

$messages["Version information"] = "Version information";
$messages["This version of net2ftp is up-to-date"] = "This version of net2ftp is up-to-date";
$messages["The latest version could not be retrieved from the net2ftp.com server. Check the security settings of your browser, which may prevent the loading of a small file from the net2ftp.com server."] = "The latest version could not be retrieved from the net2ftp.com server. Check the security settings of your browser, which may prevent the loading of a small file from the net2ftp.com server.";

$messages["Logging"] = "Logging";
$messages["Date from:"] = "Date from:";
$messages["to:"] = "to:";
$messages["Empty logs"] = "Empty";
$messages["View logs"] = "View logs";
$messages["No data"] = "No data";

$messages["Setup MySQL tables"] = "Setup MySQL tables";
$messages["Go"] = "Go";
$messages["Create the MySQL database tables"] = "Create the MySQL database tables";
$messages["Create tables"] = "Create tables";
$messages["The handle of file %1\$s could not be opened"] = "The handle of file %1\$s could not be opened";
$messages["The file %1\$s could not be opened"] = "The file %1\$s could not be opened";
$messages["The handle of file %1\$s could not be closed"] = "The handle of file %1\$s could not be closed";
$messages["MySQL username"] = "MySQL username";
$messages["MySQL password"] = "MySQL password";
$messages["MySQL database"] = "MySQL database";
$messages["MySQL server"] = "MySQL server";
$messages["This SQL query is going to be executed:"] = "This SQL query is going to be executed:";
$messages["Execute"] = "Wykonywanie";
$messages["Settings used:"] = "Settings used:";
$messages["MySQL password length"] = "MySQL password length";
$messages["Results:"] = "Results:";
$messages["The connection to the server <b>%1\$s</b> could not be set up"] = "The connection to the server <b>%1\$s</b> could not be set up";
$messages["Unable to select the database <b>%1\$s</b>"] = "Unable to select the database <b>%1\$s</b>";
$messages["The SQL query could not be executed"] = "The SQL query could not be executed";
$messages["The tables were created successfully"] = "The tables were created successfully";

$messages["Beta functions"] = "Beta functions";
$messages["View logs"] = "View logs";
$messages["Empty logs"] = "Empty logs";
$messages["The table <b>%1\$s</b> was emptied successfully."] = "The table <b>%1\$s</b> was emptied successfully.";
$messages["The table <b>%1\$s</b> could not be emptied."] = "The table <b>%1\$s</b> could not be emptied.";

} // end admin

// -------------------------------------------------------------------------
// advanced.inc.php
if ($state == "advanced") {
// -------------------------------------------------------------------------

// advanced()
$messages["The site command functions are not available on this webserver."] = "Lokalne polecenia nie s� dost�pne na tym serwerze.";
$messages["The Apache functions are not available on this webserver."] = "Funkcje Apacha nie s� dost�pne na tym serwerze.";
$messages["The MySQL functions are not available on this webserver."] = "Funkcje MySQL nie s� dost�pne na tym serwerze.";
$messages["Unexpected state2 string. Exiting."] = "Nieznana wartos� zmiennej state2. Ko�czenie dzia�ania.";

// printAdvancedFunctions()
$messages["Advanced functions"] = "Zaawansowane funkcje";
$messages["Go"] = "Poka�";
$messages["Troubleshooting functions"] = "Troubleshooting functions";
$messages["Troubleshoot net2ftp on this webserver"] = "Status net2ftp na tym serwerze";
$messages["Troubleshoot an FTP server"] = "Status serwera FTP";
$messages["Translation functions"] = "T�umaczenie";
$messages["Introduction to the translation functions"] = "Introduction to the translation functions";
$messages["Extract messages to translate from code files"] = "Extract messages to translate from code files";
$messages["Check if there are new or obsolete messages"] = "Check if there are new or obsolete messages";
$messages["Beta functions"] = "Beta functions";
$messages["Send a site command to the FTP server"] = "Send a site command to the FTP server";
$messages["Apache: password-protect a directory, create custom error pages"] = "Apache: password-protect a directory, create custom error pages";
$messages["MySQL: execute an SQL query"] = "MySQL: execute an SQL query";

// troubleshoot_webserver()
$messages["Troubleshoot your net2ftp installation"] = "Status obecnej instalacji net2ftp";
$messages["Checking if the FTP module of PHP is installed: "] = "Sprawdzanie czy modu� FTP jest zaninstalowany w PHP: ";
$messages["yes"] = "tak";
$messages["no - please install it!"] = "nie - konieczna jest jego instalacja!";
$messages["Checking the permissions of the directory on the web server: a small file will be written to the /temp folder and then deleted."] = "Sprawdzanie uprawnie� katalog�w na serwerze: w katalogu /temp zostanie utworzony a nast�pnie skasowany ma�y plik.";
$messages["Creating filename: "] = "Tworzenie pliku: ";
$messages["OK. Filename: %1\$s"] = "OK. Plik: %1\$s";
$messages["not OK"] = "B��d";
$messages["OK"] = "OK";
$messages["not OK. Check the permissions of the %1\$s directory"] = "B��d. Sprawd� uprawnienia katalogu %1\$s";
$messages["Opening the file in write mode: "] = "Opening the file in write mode: ";
$messages["Writing some text to the file: "] = "Zapisywanie przyk�adowego tekstu do pliku: ";
$messages["Closing the file: "] = "Zamykanie pliku: ";
$messages["Deleting the file: "] = "Kasowanie pliku: ";

// troubleshoot_ftpserver()
$messages["Troubleshoot an FTP server"] = "Status serwera FTP";
$messages["FTP server port"] = "Port serwera FTP";
$messages["Connection settings:"] = "Connection settings:";
$messages["Password length"] = "Password length";
$messages["Language"] = "J�zyk";
$messages["Skin number"] = "Numer sk�rki";
$messages["Connecting to the FTP server: "] = "��czenie z serwerem FTP: ";
$messages["Logging into the FTP server: "] = "Logowanie na serwer FTP: ";
$messages["Setting the passive mode: "] = "Ustawianie trybu pasywnego: ";
$messages["Getting the FTP server system type: "] = "Getting the FTP server system type: ";
$messages["Changing to the directory %1\$s: "] = "Zmiana na katalog %1\$s: ";
$messages["The directory from the FTP server is: %1\$s "] = "Katalog na serwerze FTP: %1\$s ";
$messages["Getting the raw list of directories and files: "] = "Pobieranie listy plik�w i katalog�w: ";
$messages["Trying a second time to get the raw list of directories and files: "] = "Ponowna pr�ba pobrania listy plik� i katalog�w: ";
$messages["Closing the connection: "] = "Zamykanie po��czenia: ";
$messages["Raw list of directories and files:"] = "Lista plik�w i katalog�w:";
$messages["Parsed list of directories and files:"] = "Przetworzona plik�w i katalog�w:";

// printTranslationFunctions()
$messages["net2ftp translation functions"] = "Funkcje t�umacz�ce net2ftp";
$messages["A PHP application can be translated using the standard <a href=\"http://www.php.net/gettext\">gettext</a> functions, or using a self-made translation function."] = "Aplikacja PHP mo�e zosta� przet�umaczona przy u�yciu standardowych funkcji <a href=\"http://www.php.net/gettext\">gettext</a> lub przy u�yciu w�asnej funkcji t�umacz�cej.";
$messages["In both cases, the steps to take are similar."] = "W obu przypadkach, konieczne kroki s� podobne.";
$messages["Step 1: change code"] = "Krok 1: zmiana kodu";
$messages["All messages must be translated using a translation function, for example translate()."] = "Wszytkie teksty musz� zosta� przet�umaczone przy u�yciu funkcji t�umacz�cej np. translate().";
$messages["This Hello World code:"] = "Kod Hello World:";
$messages["must be changed to this:"] = "musi by� przet�umaczony na:";
$messages["Step 2: extract messages"] = "Krok 2: wyekstrahowanie tekst�w";
$messages["All messages which are used by the translate() function must be extracted from the code files, and copied to a <b>main message file</b>."] = "Wszytkie teksty u�ywane przez funkcj� translate() musz� zosta� wyekstrahowane z kod�w �r�d�owych i skopiowane do <b>g��wnego pliku t�umacz�cego</b>.";
$messages["Step 3: translate messages"] = "Krok 3: t�umaczenie tekst�w";
$messages["The main message file is given to translators, who rename the file and replace the messages in English by the translation."] = "G�owny tekst jest dostarczany t�umaczom, kt�rzy tworz� nowy plik z przet�umaczonymi tekstami.";
$messages["The translators return the <b>translated message files</b>."] = "T�umacze przesy�aj� nowy plik jako <b>przet�umaczony plik</b>.";
$messages["Step 4: check new or obsolete messages"] = "Krok 4: sprawdzenia nowych lub zmodyfikowanych tekst�w";
$messages["Each time the application is modified, a new main message file must be generated, as in step 2."] = "Za ka�dym razem gdy modyfikowana jest aplikacja konieczne jest wygenerowanie nowego pliku z t�umaczeniem (patrz Krok 2).";
$messages["In order to avoid translating everything all over again, it must then be compared to all translated message files, to check if there are new or obsolete messages."] = "Aby unikn�� c�g�ego t�umaczenia tego samego, plik musi by� por�wnany ze swoj� poprzedni� wersj�, w celu sprawdzenia zaistnia�ych zmian.";
$messages["net2ftp can help in step 2 to extract messages to translate from code files"] = "net2ftp udost�pnia plik w wersji angielskiej w celu u�atwienia t�umacze�";
$messages["net2ftp can help in step 4 to check if there are new or obsolete messages"] = "ponadto net2ftp mo�e pom�c w kroku 4, w znalezieniu nowych tekst�w do t�umaczenia";

// translate_extract()
$messages["Extract messages from code files"] = "Extract messages from code files";
$messages["Directory containing code files:"] = "Directory containing code files:";
$messages["Translation function used in the code:"] = "Translation function used in the code:";
$messages["File to generate:"] = "File to generate:";
$messages["Extracted messages:"] = "Extracted messages:";
$messages["No messages were found, so no file was put on the FTP server."] = "No messages were found, so no file was put on the FTP server.";
$messages["The main language file <b>%1\$s</b> was transferred to directory <b>%2\$s</b>."] = "The main language file <b>%1\$s</b> was transferred to directory <b>%2\$s</b>.";

// translate_check()
$messages["Main language file:"] = "Main language file:";
$messages["Directory containing translated language files:"] = "Directory containing translated language files:";
$messages["File %1\$s was skipped because it could not be read, or because it was empty."] = "File %1\$s was skipped because it could not be read, or because it was empty.";
$messages["File nr %1\$s <b>%2\$s</b>"] = "File nr %1\$s <b>%2\$s</b>";
$messages["New messages:"] = "New messages:";
$messages["Obsolete messages:"] = "Obsolete messages:";
$messages["All the files have been processed"] = "All the files have been processed";

// sendsitecommand()
$messages["Send site command"] = "Send site command";
$messages["Enter the site command"] = "Enter the site command";
$messages["The commands you can use depends on your FTP server. These commands are not standard and vary a lot from one server to the other."] = "The commands you can use depends on your FTP server. These commands are not standard and vary a lot from one server to the other.";
$messages["Note that net2ftp cannot display the output of the FTP server, it can only tell if the command returned TRUE or FALSE. This is not a limitation of net2ftp but of PHP, the language in which net2ftp is written."] = "Note that net2ftp cannot display the output of the FTP server, it can only tell if the command returned TRUE or FALSE. This is not a limitation of net2ftp but of PHP, the language in which net2ftp is written.";
$messages["The command <b>%1\$s</b> was executed successfully."] = "The command <b>%1\$s</b> was executed successfully.";

// apache(), mysqlfunctions()
// Not yet translated

} // end advanced



// -------------------------------------------------------------------------
// authorizations.inc.php
// -------------------------------------------------------------------------

// checkAuthorization()
$messages["The FTP server <b>%1\$s</b> is not in the list of allowed FTP servers."] = "Serwer <b>%1\$s</b> Nie znajduje si� na li�cie dozwolonych serwer�w.";
$messages["The FTP server <b>%1\$s</b> is in the list of banned FTP servers."] = "Serwer <b>%1\$s</b> jest na czarnej li�cie.";
$messages["Your IP address (%1\$s) is in the list of banned IP addresses."] = "Tw�j adres IP (%1\$s) jest na czarnej li�cie.";
$messages["The FTP server port %1\$s may not be used."] = "Port %1\$s nie mo�e by� u�yty.";
$messages["You don't have the authorizations to view directory <b>%1\$s</b>."] = "Nie masz uprawnie� by przegl�da� katalog <b>%1\$s</b>.";

// logAccess(), logLogin(), logError()
// Not yet translated


// -------------------------------------------------------------------------
// bookmark.inc.php
if ($state == "bookmark") {
// -------------------------------------------------------------------------
$messages["Add this link to your bookmarks:"] = "Dodaj tem link do zak�adek:";
$messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer: kliknij prawym przycikiem na linku i wybierz \"Dodaj do ulubionych...\"";
$messages["Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla, Firefox: kliknij prawym przycikiem na link i wybierz \"Dodaj stron� do zak�adek\"";
$messages["Note: when you will use this bookmark, a popup window will ask you for your username and password."] = "Uwaga: je�li u�yjesz zapami�tanej zak�adki, pojawi si� okno pytaj�ce o nazw� u�ytkownika i has�o.";

} // end bookmark


// -------------------------------------------------------------------------
// browse.inc.php
if ($state == "browse") {
// -------------------------------------------------------------------------

// browse()
$messages["Directories with names containing \' cannot be displayed correctly. They can only be deleted. Please go back and select another subdirectory."] = "Katalogi zawieraj�ce w nazwie \' nie mog� by� poprawnie wy�wietlane. Mog� zosta� jedynie skasowane. Cofnij si� i wybie� inny podkatalog.";

$messages["Consumption message"]  = "";
$messages["Consumption message"] .= "<b>Daily limit reached: you will not be able to transfer data</b><br /><br />\n";
$messages["Consumption message"] .= "In order to guarantee the fair use of the web server for everyone, the data transfer volume and script execution time are limited per user, and per day. Once this limit is reached, you can still browse the FTP server but not transfer data to/from it.<br /><br />\n";
$messages["Consumption message"] .= "If you need unlimited usage, please install net2ftp on your own web server.<br />\n";

// ftp_getlist()
$messages["The directory <b>%1\$s</b> does not exist or could not be selected, so the root directory <b>/</b> is shown instead."] = "Katalog <b>%1\$s</b> nie istnieje b�d� nie mo�e by� wybrany, wi�c wy�wietlono katalog g��wny <b>/</b>.";

// printdirfilelist()
// Keep this short, it must fit in a small button!
$messages["New dir"] = "Nowy katalog";
$messages["New file"] = "Nowy plik";
$messages["HTML templates"] = "HTML templates";
$messages["Upload"] = "Przy�lij";
$messages["Java Upload"] = "Przy�lij Java";
$messages["Advanced"] = "Zaawansowane";
$messages["Copy"] = "Kopiuj";
$messages["Move"] = "Przenie�";
$messages["Delete"] = "Kasuj";
$messages["Rename"] = "Zmie� nazw�";
$messages["Chmod"] = "Chmod";
$messages["Download"] = "Pobierz";
$messages["Zip"] = "Zip";
$messages["Size"] = "Rozmiar";
$messages["Search"] = "Szukaj";
$messages["Go to the parent directory"] = "Przejd� do katalogu macierzystego";
$messages["Transform selected entries: "] = "Zmie� zaznaczone pozycje: ";
$messages["Make a new subdirectory in directory %1\$s"] = "Utw�rz nowy katalog w katalogu %1\$s";
$messages["Create a new file in directory %1\$s"] = "Utw�rz nowy plik w katalogu %1\$s";
$messages["Upload new files in directory %1\$s"] = "Przy�lij nowe pliki do katalogu %1\$s";
$messages["Go to the advanced functions"] = "Poka� zaawansowane funkcje";
$messages["Copy the selected entries"] = "Kopiuj zaznaczone pozycjom";
$messages["Move the selected entries"] = "Przenie� zaznaczone pozycjom";
$messages["Delete the selected entries"] = "Kasuj zaznaczone pozycjom";
$messages["Rename the selected entries"] = "Zmie� nazwy zaznaczonym pozycjom";
$messages["Chmod the selected entries (only works on Unix/Linux/BSD servers)"] = "Chmod zaznaczonym pozycjom (dzia�a jedynie na serwerach Unix/Linux/BSD)";
$messages["Download a zip file containing all selected entries"] = "Pobierz plik zip zawieraj�cy wszytkie zaznaczone pozycje";
$messages["Zip the selected entries to save or email them"] = "Zipuj zaznaczone pozycje i prze�lij mailem";
$messages["Calculate the size of the selected entries"] = "Oblicz rozmiar zaznaczonych pozycji";
$messages["Find files which contain a particular word"] = "Szukaj plik�w zawieraj�cych podan� fraz�";
$messages["Click to sort by %1\$s in descending order"] = "Kliknij by sortowa� po %1\$s w porz�dku malej�cym";
$messages["Click to sort by %1\$s in ascending order"] = "Kliknij by sortowa� po %1\$s w porz�dku rosn�cym";
$messages["Ascending order"] = "Rosn�co";
$messages["Descending order"] = "Malej�co";
//$messages["Click to sort by %1\$s in ascending order"] = "Click to sort by %1\$s in ascending order";
$messages["Up"] = "Do g�ry";
$messages["Click to check or uncheck all rows"] = "Kliknij by zaznaczy�/odznaczy� wszytkie pozycje";
$messages["All"] = "+/-";
$messages["Name"] = "Nazwa";
$messages["Type"] = "Typ";
//$messages["Size"] = "Size";
$messages["Owner"] = "W�a�ciciel";
$messages["Group"] = "Grupa";
$messages["Perms"] = "Atrybuty";
$messages["Mod Time"] = "Czas mod.";
$messages["Actions"] = "Dzia�ania";
$messages["Download the file %1\$s"] = "Pobierz plik %1\$s";
$messages["View"] = "Podgl�d";
$messages["Edit"] = "Edycja";
$messages["Update"] = "Aktualizuj";
$messages["Open"] = "Otw�rz";
$messages["View the highlighted source code of file %1\$s"] = "Poka� kolorowany kod �r�d�owy pliku %1\$s";
$messages["Edit the source code of file %1\$s"] = "Edytuj kod �r�dowy pliku %1\$s";
$messages["Upload a new version of the file %1\$s and merge the changes"] = "Prze�lij now� wersj� pliku %1\$s i scal zmiany";
$messages["View image %1\$s"] = "Poka� obraz %1\$s";
$messages["View the file %1\$s from your HTTP web server"] = "Poka� plik %1\$s z Twojego swrwera HTTP";
$messages["(Note: This link may not work if you don't have your own domain name.)"] = "(Uwaga: Ten link mo�e nie dzia�a� je�li nie posiadasz w�asnej nazwy domeny.)";
$messages["This folder is empty"] = "Ten katalog jest pusty";

// printSeparatorRow()
$messages["Directories"] = "Katalogi";
$messages["Files"] = "Pliki";
$messages["Symlinks"] = "Linki symboliczne";
$messages["Unrecognized FTP output"] = "Nie rozpoznane wyj�cie FTP";
$messages["Number"] = "Number";
$messages["Size"] = "Size";
$messages["Skipped"] = "Skipped";

// printLocationActions()
$messages["Language:"] = "J�zyk:";
$messages["Skin:"] = "Sk�rka:";
$messages["View mode:"] = "Tryb podgl�du:";
$messages["Directory Tree"] = "Drzewo katalog�w";

// printURL()
$messages["Execute %1\$s in a new window"] = "Uruchom %1\$s w nowym oknie";

// printDirectorySelect()
$messages["Double-click to go to a subdirectory:"] = "Kliknij dwukrotnie by przej�� do podkatalogu:";
$messages["Choose"] = "Wybierz";
$messages["Up"] = "Do g�ry (..)";

} // end browse


// -------------------------------------------------------------------------
// consumption.inc.php
// -------------------------------------------------------------------------
$messages["Unable to determine your IP address."] = "Unable to determine your IP address.";
$messages["Table net2ftp_logConsumptionIpaddress contains duplicate rows."] = "Table net2ftp_logConsumptionIpaddress contains duplicate rows.";
$messages["Table net2ftp_logConsumptionFtpserver contains duplicate rows."] = "Table net2ftp_logConsumptionFtpserver contains duplicate rows.";
$messages["The variable <b>consumption_ipaddress_dataTransfer</b> is not numeric."] = "The variable <b>consumption_ipaddress_dataTransfer</b> is not numeric.";
$messages["Table net2ftp_logConsumptionIpaddress could not be updated."] = "Table net2ftp_logConsumptionIpaddress could not be updated.";
$messages["Table net2ftp_logConsumptionIpaddress contains duplicate entries."] = "Table net2ftp_logConsumptionIpaddress contains duplicate entries.";
$messages["Table net2ftp_logConsumptionFtpserver could not be updated."] = "Table net2ftp_logConsumptionFtpserver could not be updated.";
$messages["Table net2ftp_logConsumptionFtpserver contains duplicate entries."] = "Table net2ftp_logConsumptionFtpserver contains duplicate entries.";
$messages["Daily limit reached: the file <b>%1\$s</b> will not be transferred"] = "Daily limit reached: the file <b>%1\$s</b> will not be transferred";


// -------------------------------------------------------------------------
// database.inc.php
// -------------------------------------------------------------------------
$messages["Unable to connect to the DB"] = "Nie mo�na po��czy� si� z DB";
$messages["Unable to select the DB"] = "Nie mo�na wybra� DB";


// -------------------------------------------------------------------------
// easywebsite.inc.php
if ($state == "easyWebsite") {
// -------------------------------------------------------------------------
$messages["Create a website in 4 easy steps"] = "Create a website in 4 easy steps";
$messages["Template overview"] = "Template overview";
$messages["Template details"] = "Template details";
$messages["Files are copied"] = "Files are copied";
$messages["Edit your pages"] = "Edit your pages";

// Screen 1 - printTemplateOverview
$messages["Click on the image to view the details of a template."] = "Click on the image to view the details of a template.";
$messages["Back to the Browse screen"] = "Back to the Browse screen";
$messages["Template"] = "Template";
$messages["Copyright"] = "Copyright";
$messages["Click on the image to view the details of this template"] = "Click on the image to view the details of this template";

// Screen 2 - printTemplateDetails
$messages["The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?"] = "The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?";
$messages["Preview"] = "Preview";
$messages["Install"] = "Install";
$messages["Size"] = "Size";
$messages["Preview page"] = "Preview page";
$messages["opens in a new window"] = "opens in a new window";

// Screen 3
$messages["Please wait while the template files are being transferred to your server: "] = "Please wait while the template files are being transferred to your server: ";
$messages["Done."] = "Done.";
$messages["Continue"] = "Continue";

// Screen 4 - printEasyAdminPanel
$messages["Edit page"] = "Edit page";
$messages["Browse the FTP server"] = "Browse the FTP server";
$messages["Add this link to your favorites to return to this page later on!"] = "Add this link to your favorites to return to this page later on!";
$messages["Edit website at %1\$s"] = "Edit website at %1\$s";
$messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer: right-click on the link and choose \"Add to Favorites...\"";
$messages["Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\"";

// ftp_copy_local2ftp
$messages["WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing..."] = "WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing...";
$messages["Created target subdirectory <b>%1\$s</b>"] = "Created target subdirectory <b>%1\$s</b>";
$messages["WARNING: Unable to copy the file <b>%1\$s</b>. Continuing..."] = "WARNING: Unable to copy the file <b>%1\$s</b>. Continuing...";
$messages["Copied file <b>%1\$s</b>"] = "Copied file <b>%1\$s</b>";
}


// -------------------------------------------------------------------------
// edit.inc.php
if ($state == "manage" && ($state2 == "edit" || $state2 == "newfile")) {
// -------------------------------------------------------------------------

// edit()
$messages["Unable to open the template file"] = "Nie mo�na otworzy� pliku z szablonem";
$messages["Unable to read the template file"] = "Nie mo�na odczyta� pliku z szablonem";
$messages["Please specify a filename"] = "Podaj nazw� pliku";

// printEditForm()
$messages["Directory: "] = "Katalog: ";
$messages["File: "] = "plik: ";
$messages["New file name: "] = "Nowa nazwa pliku: ";
$messages["Note: changing the textarea type will save the changes"] = "Uwaga: zmiany w tek�cie zostan� zapisane";
$messages["Status: This file has not yet been saved"] = "Status: Ten plik nie zosta� jeszcze zapisany";
$messages["Status: Saved on <b>%1\$s</b> using mode %2\$s"] = "Status: Zapisany <b>%1\$s</b> w trybie %2\$s";
$messages["Status: <b>This file could not be saved</b>"] = "Status: <b>Nie mo�na zapisa� tego pliku</b>";

} // end if edit newfile


// -------------------------------------------------------------------------
// errorhandling.inc.php
// -------------------------------------------------------------------------
$messages["An error has occured"] = "B��d";
$messages["Go back"] = "Wstecz";
$messages["Go to the login page"] = "Przejd� do strony logowania";


// -------------------------------------------------------------------------
// filesystem.inc.php
// -------------------------------------------------------------------------

// ftp_openconnection()
$messages["The <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this FTP module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">php.net</a><br />"] = "<a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">Modu� FTP ala PHP</a> nie jest zainstalowany.<br /><br /> Administrator tej strony powinien zainstalowa� ten modu�. Instrukcja instalacji znajduje si� pod adresem <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">php.net</a><br />";
$messages["Unable to connect to FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "Nie mo�na po��czy� si� z serwerem FTP <b>%1\$s</b> na porcie <b>%2\$s</b>.<br /><br />Czy jeste� pewny �e jest to adres serwera FTP? Cz�sto serwer FTP ma inny adres ni� serwer HTTP. Skontaktuj si� z dostawc� internetu b�d� administratorem.<br />";
$messages["Unable to login to FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "Nie mo�na zalogowa� si� na serwer FTP<b>%1\$s</b> u�ytkownik <b>%2\$s</b>.<br /><br />czy jeste� pewien �e nazwa u�ytkownika i has�o s� poprawne? Skontaktuj si� z dostawc� internetu b�d� administratorem.<br />";
$messages["Unable to switch to the passive mode on FTP server <b>%1\$s</b>."] = "Nie mo�na prze��czy� si� w tryb pasywny na serwerze FTP <b>%1\$s</b>.";

// ftp_openconnection2()
$messages["Unable to connect to the second (target) FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the second (target) FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "Nie mo�na po��czy� si� z drugim serwerem FTP <b>%1\$s</b> na porcie <b>%2\$s</b>.<br /><br />Czy jeste� pewny �e jest to adres drugiego serwera FTP? Cz�sto serwer FTP ma inny adres ni� serwer HTTP. Skontaktuj si� z dostawc� internetu b�d� administratorem.<br />";
$messages["Unable to login to the second (target) FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "Nie mo�na zalogowa� si� na drugi serwer FTP<b>%1\$s</b> u�ytkownik <b>%2\$s</b>.<br /><br />czy jeste� pewien �e nazwa u�ytkownika i has�o s� poprawne? Skontaktuj si� z dostawc� internetu b�d� administratorem.<br />";
$messages["Unable to switch to the passive mode on the second (target) FTP server <b>%1\$s</b>."] = "ie mo�na prze��czy� si� w tryb pasywny na drugim serwerze FTP <b>%1\$s</b>.";

// ftp_myrename()
$messages["Unable to rename directory or file <b>%1\$s</b> into <b>%2\$s</b>"] = "Nie mo�na zmieni� nazwy katalogu lub pliku <b>%1\$s</b> na <b>%2\$s</b>";

// ftp_mychmod()
$messages["Unable to execute site command <b>%1\$s</b>. Note that the CHMOD command is only available on Unix FTP servers, not on Windows FTP servers."] = 
"Nie mo�na wykona� lokalnego polecenia <b>%1\$s</b>. Komenda CHMOD jest dost�ppna jedynie na serwerach UNIX.";
$messages["Directory <b>%1\$s</b> successfully chmodded to <b>%2\$s</b>"] = "Zmieniono atrybuty katalogu <b>%1\$s</b> na <b>%2\$s</b>";
$messages["File <b>%1\$s</b> was successfully chmodded to <b>%2\$s</b>"] = "Zmieniono atrybuty pliku <b>%1\$s</b> na <b>%2\$s</b>";
$messages["All the selected directories and files have been processed."] = "Wszystkie zaznaczone pliki i katalogi zosta�y przetworzone.";

// ftp_myrmdir()
$messages["Unable to delete the directory <b>%1\$s</b>"] = "Nie mo�na usun�� katalogu <b>%1\$s</b>";

// ftp_newdirectory()
$messages["Unable to create the directory <b>%1\$s</b>"] = "Nie mo�na utworzy� katalogu <b>%1\$s</b>";

// ftp_readfile()
$messages["Unable to create the temporary file"] = "Nie mo�na utworzy� pliku tymczasowego";
$messages["Unable to get the file <b>%1\$s</b> from the FTP server and to save it as temporary file <b>%2\$s</b>.<br />Check the permissions of the %3\$s directory.<br />"] = "Nie mo�na pobra� pliku <b>%1\$s</b> z serwera FTP i zapisa� go jako plik tymczasowy <b>%2\$s</b>.<br />Sprawd� uprawnienia dla katalogu %3\$s.<br />";
$messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "Nie mo�na otworzy� pliku tymczasowego. Sprawd� uprawnienia dla katalogu %1\$s.";
$messages["Unable to read the temporary file"] = "Nie mo�na czyta� pliku tymczasowego";
$messages["Unable to close the handle of the temporary file"] = "Nie mo�na zamkn�� pliku tymczasowego";
$messages["Unable to delete the temporary file"] = "Nie mo�na skasowa� pliku tymczasowego";

// ftp_writefile()
$messages["Unable to create the temporary file. Check the permissions of the %1\$s directory."] = "Nie mo�na utworzy� pliku tymczasowego. Sprawd� uprawnienia dla katalogu %1\$s.";
$messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "Nie mo�na otworzy� pliku tymczasowego. Sprawd� uprawnienia dla katalogu %1\$s.";
$messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "Nie mo�na zapisa� tekstu w pliku tymczasowym <b>%1\$s</b>.<br />Sprawd� uprawnienia dla katalogu %2\$s.";
$messages["Unable to close the handle of the temporary file"] = "Nie mo�na zamkn�� pliku tymczasowego";
$messages["Unable to put the file <b>%1\$s</b> on the FTP server.<br />You may not have write permissions on the directory."] = "Nie mo�na umie�ci� pliku <b>%1\$s</b> na serwerze FTP.<br />Mo�esz nie mie� uprawnie� do tego katalogu.";
$messages["Unable to delete the temporary file"] = "Nie mo�na skasowa� pliku tymczasowego";

// ftp_copymovedelete()
$messages["Processing directory <b>%1\$s</b>"] = "Przetwarzanie katalogu <b>%1\$s</b>";
$messages["The target directory <b>%1\$s</b> is the same as or a subdirectory of the source directory <b>%2\$s</b>, so this directory will be skipped"] = 
"Katalog docelowy <b>%1\$s</b> jest taki sam jak podkatalog �r�d�owy <b>%2\$s</b>, wi�c zostanie pomini�ty";
$messages["Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing the copy/move process..."] = "Nie mo�na utworzy� podkatalogu <b>%1\$s</b>. Mo�e ju� istnie�. Kontynuuj� proces kopiowania/przenoszenia...";
$messages["Created target subdirectory <b>%1\$s</b>"] = "Utworzono podkatalog docelowy <b>%1\$s</b>";
$messages["Unable to delete the subdirectory <b>%1\$s</b> - it may not be empty"] = "Nie mo�na usun�� podkatalogu <b>%1\$s</b> - mo�e nie jest pusty";
$messages["Deleted subdirectory <b>%1\$s</b>"] = "Usuni�to podkatalog <b>%1\$s</b>";
$messages["Processing of directory <b>%1\$s</b> completed"] = "Przetwarzanie katalogu <b>%1\$s</b> zako�czone";
$messages["The target for file <b>%1\$s</b> is the same as the source, so this file will be skipped"] = "Plik docelowy <b>%1\$s</b> jest taki sam jak plik �r�d�owy, wi�c zostanie pomini�ty";
$messages["Unable to copy the file <b>%1\$s</b>"] = "Nie mo�na skopiowa� pliku <b>%1\$s</b>";
$messages["Copied file <b>%1\$s</b>"] = "Skopiowano plik <b>%1\$s</b>";
$messages["Unable to move the file <b>%1\$s</b>"] = "Nie mo�a przesun�� pliku <b>%1\$s</b>";
$messages["Moved file <b>%1\$s</b>"] = "Przesuni�to plik <b>%1\$s</b>";
$messages["Unable to delete the file <b>%1\$s</b>"] = "Nie mo�na skasowa� pliku <b>%1\$s</b>";
$messages["Deleted file <b>%1\$s</b>"] = "Skasowano plik <b>%1\$s</b>";
$messages["All the selected directories and files have been processed."] = "Wszystkie zaznaczone katalogi i pliki zosta�y przetworzone.";

// ftp_processfiles()

// ftp_getfile()
$messages["Unable to copy the remote file <b>%1\$s</b> to the local file using FTP mode <b>%2\$s</b>"] = "Nie mo�na skopiowa� pliku ze zdalego systemu <b>%1\$s</b> do pliku lokalnego przy u�yciu trybu FTP <b>%2\$s</b>";
$messages["Unable to delete file <b>%1\$s</b>"] = "Nie mo�na skasowa� pliku <b>%1\$s</b>";

// ftp_putfile()
$messages["Unable to copy the local file to the remote file <b>%1\$s</b> using FTP mode <b>%2\$s</b>"] = "Nie mo�na skopiowa� pliku lokalnego do pliku zdalnego <b>%1\$s</b> przy u�yciu trybu FTP <b>%2\$s</b>";
$messages["Unable to delete the local file"] = "Nie mo�na usun�� lokalnego pliku";

// ftp_downloadfile()
$messages["Unable to delete the temporary file"] = "Nie mo�na usun�� pliku tymczasowego";
$messages["Unable to send the file to the browser"] = "Unable to send the file to the browser";

// ftp_zip()
$messages["Unable to create the temporary file"] = "Nie mo�na utworzy� pliku tymczasowego";
$messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "Nie mo�na zapisa� tekstu w pliku tymczasowym <b>%1\$s</b>.<br />Sprawd� uprawnienia dla katalogu %2\$s.";
$messages["Unable to close the handle of the temporary file"] = "Nie mo�na zamkn�� pliku tymczasowego";
$messages["The zip file has been saved on the FTP server as <b>%1\$s</b>"] = "Plik zip zosta� zapisany na serwerze FTP jako <b>%1\$s</b>";
$messages["Requested files"] = "��dane pliki";

$messages["Zip email message"]  = "";
$messages["Zip email message"] .= "Witaj, \n\n";
$messages["Zip email message"] .= "Kto� za��da� by pliki z za��cznika zosta�y przes�ane na ten email (%1\$s).\n";
$messages["Zip email message"] .= "Je�li nic o tym nie wiesz lub nie znasz tej osoby, skasuj pliki z za��cznika bez ich przegl�dania.\n";
$messages["Zip email message"] .= "Je�li nie otworzysz plik�w zip, nic nie mo�e si� sta� Twojemu komputerowi.\n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "Informacje o nadawcy:\n";
$messages["Zip email message"] .= "Adres IP : %2\$s\n";
$messages["Zip email message"] .= "Czas wys�ania: %3\$s\n";
$messages["Zip email message"] .= "Wys�ane przez net2ftp zainstalowane na tym serwerze: %4\$s \n";
$messages["Zip email message"] .= "Adres webmastera: %5\$s \n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "Wiadomo�� nadawcy:\n";
$messages["Zip email message"] .= "%6\$s \n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "net2ftp jest darmowym oprogramowaniem, na licencji GNU/GPL. Wi�cej informacji http://www.net2ftp.com\n\n\n";

$messages["The zip file has been sent to <b>%1\$s</b>."] = "Plik zip zosta� wys�any do <b>%1\$s</b>.";

// acceptFiles()
$messages["File <b>%1\$s</b> is too big. This file will not be uploaded."] = "Plik <b>%1\$s</b> jest zbyt du�y. Ten plik nie mo�e by� pobrany.";
$messages["Could not generate a temporary file."] = "Nie mo�na wygenerowa� pliku tymczasowego.";
$messages["File <b>%1\$s</b> could not be moved"] = "Plik <b>%1\$s</b> nie mo�e by� przeniesiony";
$messages["File <b>%1\$s</b> is OK"] = "Plik <b>%1\$s</b> jest OK";
$messages["Unable to move the uploaded file to the temp directory.<br /><br />The administrator of this website has to <b>chmod 777</b> the /temp directory of net2ftp."] = 
"Nie mo�na przenie�� pobranego pliku do katalogu tymczasowego.<br /><br />Administrator tej strony powinien wykona� komend� <b>chmod 777</b> na katalogu /temp.";
$messages["You did not provide any file to upload."] = "Nie wybrano �adnych plik�w do pobrania.";

// ftp_transferfiles()
$messages["File <b>%1\$s</b> could not be transferred to the FTP server"] = "Plik <b>%1\$s</b> nie mo�e by� preniesiony na serwer FTP";
$messages["File <b>%1\$s</b> has been transferred to the FTP server using FTP mode <b>%2\$s</b>"] = "Plik <b>%1\$s</b> zosta� przeniesiony na serwer FTP w trybie <b>%2\$s</b>";
$messages["Transferring files to the FTP server"] = "Transferring files to the FTP server";

// ftp_unziptransferfiles()
$messages["Processing archive nr %1\$s: <b>%2\$s</b>"] = "Przetwarzanie archiwum nr %1\$s: <b>%2\$s</b>";
$messages["Unable to open the archive <b>%1\$s</b> (file %2\$s)"] = "Nie mo�na otworzy� archiwum <b>%1\$s</b> (plik %2\$s)";
$messages["Could not create directory <b>%1\$s</b>"] = "Nie mo�na utworzy� katalogu <b>%1\$s</b>";
$messages["Created directory <b>%1\$s</b>"] = "Utworzony katalog <b>%1\$s</b>";
$messages["File Contents:"] = "Zawarto�� pliku:";
$messages["Could not put the file <b>%1\$s</b> to the directory <b>%2\$s</b>"] = "Nie mo�na umie�ci� pliku <b>%1\$s</b> w katalogu <b>%2\$s</b>";
$messages["Transferred file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "Przeniesiono plik <b>%1\$s</b> do katalogu <b>%2\$s</b>";
$messages["Unable to delete the archive <b>%1\$s</b> (file %2\$s)"] = "Nie mo�na usun�� archiwum <b>%1\$s</b> (plik %2\$s)";
$messages["Unable to get the list of the contents of the Zip archive. Error code: %1\$s"] = "Nie mo�na wylistowa� zawarto�ci pliku zip. Kod b��du: %1\$s";
$messages["Unable to get the list of the contents of the Tar archive."] = "Nie mo�na wylistowa� zawarto�ci pliku tar";
$messages["Could not create directory <b>%1\$s</b>"] = "Nie mo�na utworzy� katalogu <b>%1\$s</b>";
$messages["Created directory <b>%1\$s</b>"] = "Utworzono katalog <b>%1\$s</b>";
$messages["Unable to create the temporary file"] = "Nie mo�na utworzy� pliku tymczasowego";
$messages["Unable to extract file nr <b>%1\$s</b> from the archive."] = "Nie mo�na rozpakowa� pliku nr <b>%1\$s</b> z archiwyum.";
$messages["Could not put file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "Nie mo�na umie�ci� pliku <b>%1\$s</b> w katalogu <b>%2\$s</b>";
$messages["Transferred file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "Przeniesiony plik <b>%1\$s</b> do katalogu <b>%2\$s</b>";
$messages["Unable to delete the temporary file <b>%1\$s</b>."] = "Nie mo�na usun�� pliku tymczasowego <b>%1\$s</b>.";
$messages["Archive <b>%1\$s</b> was not processed because its filename extension was not recognized. Only zip, tar, tgz and gz archives are supported at the moment."] = "Archiwum <b>%1\$s</b> nie zosta�o przetworzone gdy� jego rozsze�enie nie zosta�o rozpoznane. Obecnie tylko archiwa zip, tar, tgz i gz s� obs�ugiwane.";
$messages["Unzipping and transferring files"] = "Unzipping and transferring files";

// ftp_mysite()
$messages["Unable to execute site command <b>%1\$s</b>"] = "Nie mo�na wykona� lokalnego polecenia <b>%1\$s</b>";

// shutdown()
$messages["Shutdown message"]  = "";
$messages["Shutdown message"] .= "<b>Twoje zadanie zosta�o zatrzymane</b><br /><br />";
$messages["Shutdown message"] .= "Zadanie, kt�re chcia�e� wykona� w net2ftp zaj�o wi�cej czasu ni� dozwolone %1\$s sekund, dlatego zosta�o zatrzymane.<br />";
$messages["Shutdown message"] .= "Taki limit czasu umo�liwia sprawiedliwe wykorzystanie serwera przez wszytkich u�ytkownik�w.<br /><br />";
$messages["Shutdown message"] .= "Spr�buj podzieli� zadanie na mniejsze cz��i: Wybierz mniej plik�w, pomi� najwi�ksze pliki.<br /><br />";
$messages["If you really need net2ftp to be able to handle big tasks which take a long time, consider installing net2ftp on your own server."] = "Je�li naprawd� potrzebujesz by net2frt wykonywa� rozbudowane zadania, rozwa� instalacj� net2ftp na swoim serwerze.";

// SendMail()
$messages["You did not provide any text to send by email!"] = "Nie wprowadzono �adnego tekstu do wys�ania emailem";
$messages["You did not supply a From address."] = "Nie wprowadzono pola OD";
$messages["You did not supply a To address."] = "Nie wprowadzono pol DO.";
$messages["Due to technical problems the email to <b>%1\$s</b> could not be sent."] = "W zwi�zku z problemami technicznymi email do <b>%1\$s</b> nie m�g� by� wys�any.";

// printFunctionTags()
$messages["Output generated by function %1\$s"] = "Wynik wygenerowany przez funkcj� %1\$s";



// -------------------------------------------------------------------------
// homepage.inc.php
if ($state == "homepage") {
// -------------------------------------------------------------------------
$messages["net2ftp features short"] ="Je�li si� zalogujesz, masz nast�puj�ce mo�liwo�ci: \n";
$messages["net2ftp features short"] .="<ul>\n";
$messages["net2ftp features short"] .="<li> Obs�uga serwera FTP</li>\n";
$messages["net2ftp features short"] .="<li> pobiera� wysy�a� <span style=\"font-size: 80%%; color: red;\">nowo��: nielimitowana liczba plik�w do wys�ania</span></li>\n";
$messages["net2ftp features short"] .="<li> kopiowa� przenosi� kasowa� zmiena� nazwy zmienia� atrybuty</li>\n";
$messages["net2ftp features short"] .="<li> kopiowa�/przenosi� na a inny serwer FTP</li>\n";
$messages["net2ftp features short"] .="<li> przegl�da� kod z opcj� kolorowania</li>\n";
$messages["net2ftp features short"] .="<li> przegl�da� obrazy <span style=\"font-size: 80%%; color: red;\">nowo��</span></li>\n";
$messages["net2ftp features short"] .="<li> edytowa� pliki tekstowe</li>\n";
$messages["net2ftp features short"] .="<li> edytowa� pliki HTML w kilku edytorach HTML <span style=\"font-size: 80%%; color: red;\">nowo��</span></li>\n";
$messages["net2ftp features short"] .="<li> edytowa� kod z kolorowaniem sk�adni <span style=\"font-size: 80%%; color: red;\">beta</span></li>\n";
$messages["net2ftp features short"] .="<li> zipowa� pliki do pobrania, wysy�a� emailem i zapisywa�</li>\n";
$messages["net2ftp features short"] .="<li> pobiera� i dekompresowa� pliki (zip, tar, tgz, gz)</li>\n";
$messages["net2ftp features short"] .="<li> szuka� s��w i fraz</li>\n";
$messages["net2ftp features short"] .="<li> otrzyma� obj�to�� plik�w i katalog�w</li>\n";
$messages["net2ftp features short"] .="</ul>\n";

} // end homepage


// -------------------------------------------------------------------------
// net2ftp_loginform.inc.php
// -------------------------------------------------------------------------
$messages["FTP server"] = "Serwer FTP";
$messages["Example"] = "Przyk�ad";
$messages["Username"] = "U�ytkownik";
$messages["Password"] = "Has�o";
$messages["Anonymous"] = "Anonimowo";
$messages["Passive mode"] = "Tryb pasywny";
$messages["Initial directory"] = "Katalog startowy";
$messages["Language"] = "J�zyk";
$messages["Skin"] = "Sk�rka";
$messages["FTP mode"] = "FTP mode";
$messages["Login"] = "Logowanie";
$messages["Clear cookies"] = "Usu� ciasteczka";
$messages["Please enter an FTP server."] = "Please enter an FTP server.";
$messages["Please enter a username."] = "Please enter a username.";
$messages["Please enter a password."] = "Please enter a password.";


// -------------------------------------------------------------------------
// html.inc.php
// -------------------------------------------------------------------------

// HtmlBegin()
$messages["Status:"] = "Status:";

// HtmlEnd()
$messages["net2ftp Help Guide"] = "Pomoc net2ftp";
$messages["net2ftp Forums"] = "Forum net2ftp";
$messages["License"] = "Licencja";
$messages["Powered by"] = "Obs�ugiwane przez";

// printJavascriptFunctions()
$messages["Choose a directory"] = "Wybierz katalog";
$messages["Please wait..."] = "Prosz� czeka�...";
$messages["Uploading... please wait..."] = "Wysy�anie... prosz� czeka�...";
$messages["If the upload takes more than the allowed <b>%1\$s seconds<\/b>, you will have to try again with less/smaller files."] = 
"Je�li wysy�anie zajmie wi�cej ni� <b>%1\$s sekund<\/b>, konieczna b�dzie kolejna pr�ba z mniejsz� liczb�/mniejszymi plikami.";
$messages["This window will close automatically in a few seconds."] = "To okno zamknie si� automatycznie w ci�gu kilku sekund.";
$messages["Close window now"] = "Zamknij okno";


// -------------------------------------------------------------------------
// httpheaders.inc.php
// -------------------------------------------------------------------------
// Nothing to translate


// -------------------------------------------------------------------------
// manage.inc.php
if ($state == "manage") {
// -------------------------------------------------------------------------

// manage()
$messages["Please select at least one directory or file!"] = "Wybierz przynajmniej jeden plik lub katalog!";
$messages["Unexpected state2 string. Exiting."] = "Nieznana wartos� zmiennej state2. Ko�czenie dzia�ania.";

// renameentry()
if ($state2 == "rename") {
$messages["Rename directories and files"] = "Przemianowywanie plik�w i katalog�w";
$messages["Old name: "] = "Stara nazwa: ";
$messages["New name: "] = "Nowa nazwa: ";
$messages["The new name may not contain any dots. This entry was not renamed to <b>%1\$s</b>"] = "Nowa nazwa nie mo�e zawiera� zadnych kropek. Ta pozycja nie zosta�a przemianowana na <b>%1\$s</b>";
$messages["<b>%1\$s</b> was successfully renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> zosta�a przemianowana na <b>%2\$s</b>";
$messages["<b>%1\$s</b> could not be renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> could not be renamed to <b>%2\$s</b>";
}

// chmodentry()
if ($state2 == "chmod") {
$messages["Chmod directories and files"] = "Zmiana atrybut�w plik�w i katalog�w";
$messages["Set all permissions"] = "Ustaw wszytkim";
$messages["Read"] = "Czytanie";
$messages["Write"] = "Pisanie";
$messages["Execute"] = "Wykonywanie";
$messages["Owner"] = "W�a�ciciel";
$messages["Group"] = "Grupa";
$messages["Everyone"] = "Wszyscy";
$messages["To set all permissions to the same values, enter those permissions above and click on the button \"Set all permissions\""] = "Aby zmieni� wszytkie uprawnienia na takie same warto�ci, wprowad� te uprawnienia i naci�nij przycisk \"Ustaw wszytkie uprawnienia\"";
$messages["Set the permissions of directory <b>%1\$s</b> to: "] = "Zmieniono uprawnienia katalogowi <b>%1\$s</b> to: ";
$messages["Set the permissions of file <b>%1\$s</b> to: "] = "Zmieniono uprawnienia plikowi <b>%1\$s</b> to: ";
$messages["Set the permissions of symlink <b>%1\$s</b> to: "] = "Zmieniono uprawnienia linkowi symbolicznemu <b>%1\$s</b> to: ";
$messages["Chmod value"] = "warto�� Chmod";
$messages["Chmod also the subdirectories within this directory"] = "Zmien uprawnienia r�wnie� podkatalogom tego katalogu";
$messages["Chmod also the files within this directory"] = "Zmien uprawnienia r�wnie� wszytkim plikom w tym katalogu";
$messages["The chmod nr <b>%1\$s</b> is out of the range 000-777. Please try again."] = "Chmod nr <b>%1\$s</b> nie jest z zakresu 000-777. Spr�buj jeszcze raz.";
}

// copymovedeleteentry()
if ($state2 == "copy" || $state2 == "move" || $state2 == "delete") {
$messages["Copy directories and files"] = "Kopiowanie plik�w i katalog�w";
$messages["Move directories and files"] = "Przenoszenie plik�w i katalog�w";
$messages["Delete directories and files"] = "Kasowanie plik�w i katalog�w";
$messages["Are you sure you want to delete these directories and files?"] = "Czy napewno chcesz usun�� te pliki i katalogi?";
$messages["All the subdirectories and files of the selected directories will also be deleted!"] = "Wszytkie podkatalogi i pliki wybrane katalogu zostan� usuni�te!";
$messages["Set all targetdirectories"] = "Ustaw dla wszytkich";
$messages["To set a common target directory, enter that target directory in the textbox above and click on the button \"Set all targetdirectories\"."] = "Aby wybra� standardow� czynno�� dla katalogu, wprowad� nazw� katalogu w powy�szym oknie i naci�nij przycisk \"Ustaw dla wszytkich wybranych katalog�w\".";
$messages["Note: the target directory must already exist before anything can be copied into it."] = "Uwaga: Katalog docelowy musi istnie� zanim bedzie mozna do niego kopiowa� pliki.";
$messages["Different target FTP server:"] = "Adres innego docelowego serwera FTP:";
$messages["Leave empty if you want to copy the files to the same FTP server."] = "Pozostaw puste, je�li chesz kopiowa� pliki na ten sam serwer FTP.";
$messages["If you want to copy the files to another FTP server, enter your login data."] = "Je�li chcesz kopiowa� pliki na inny serwer wprowad� jego adres, swoj� nazw� u�ytkownika oraz has�o.";
$messages["Leave empty if you want to move the files to the same FTP server."] = "Pozostaw puste je�li chcesz przenosi� plik na tym samym serwerze FTP.";
$messages["If you want to move the files to another FTP server, enter your login data."] = "Je�li chcesz przenosi� pliki na inny serwer FTP wprowad� jego adres, swoj� nazw� u�ytkownika oraz has�o.";
$messages["Copy directory <b>%1\$s</b> to:"] = "Kopiowanie katalogu <b>%1\$s</b> do:";
$messages["Move directory <b>%1\$s</b> to:"] = "Przenoszenie katalogu <b>%1\$s</b> do:";
$messages["Directory <b>%1\$s</b>"] = "Katalog <b>%1\$s</b>";
$messages["Copy file <b>%1\$s</b> to:"] = "Kopiowanie pliku <b>%1\$s</b> do:";
$messages["Move file <b>%1\$s</b> to:"] = "Przenoszenie pliku <b>%1\$s</b> do:";
$messages["File <b>%1\$s</b>"] = "Plik <b>%1\$s</b>";
$messages["Copy symlink <b>%1\$s</b> to:"] = "Kopiowanie linku symbolicznego <b>%1\$s</b> do:";
$messages["Move symlink <b>%1\$s</b> to:"] = "Przenoszenie linku symbolicznego <b>%1\$s</b> do:";
$messages["Symlink <b>%1\$s</b>"] = "Link symboliczny <b>%1\$s</b>";
$messages["Target directory:"] = "Katalog docelowy:";
$messages["Target name:"] = "Nazwa docelowa:";
$messages["Processing the entries:"] = "Przetwarzanie pozycji:";
}

// newdirectory()
if ($state2 == "newdirectory") {
$messages["Create new directories"] = "Tworzenie nowych katalog�w";
$messages["The new directories will be created in <b>%1\$s</b>."] = "Nowe katalogi b�d� utworzone w <b>%1\$s</b>.";
$messages["New directory name:"] = "Nazwa nowego katalogu:";
$messages["Directory <b>%1\$s</b> was successfully created."] = "Katalog <b>%1\$s</b> zosta� utworzony.";
}

// uploadfile()
if ($state2 == "uploadfile") {
$messages["Upload files and archives"] = "Wysy�anie plik�w i archiw�w";
$messages["Upload results"] = "Wyniki wysy�ania";
$messages["Checking files:"] = "Sprawdzanie plik�w:";
$messages["Transferring files to the FTP server:"] = "Transfer plik�w na serwer FTP:";
$messages["Decompressing archives and transferring files to the FTP server:"] = "Dekompresja plik�w i transfer na serwer FTP:";
$messages["Upload more files and archives"] = "Wy�lij wi�cej plik�w i archiw�w";
}

// printUploadForm() and javaupload()
if ($state2 == "uploadfile" || $state2 == "javaupload") {
$messages["Upload to directory:"] = "Wy�lij do katalogu:";
$messages["Files"] = "Pliki";
$messages["Archives"] = "Archiwa";
$messages["Files entered here will be transferred to the FTP server."] = "Wpisane tu pliki b�d� wys�ane na serwer FTP.";
$messages["Archives entered here will be decompressed, and the files inside will be transferred to the FTP server."] = "Wpisane tu archiwa b�d� wys��ne na serwer FTP.";
$messages["Add another"] = "Dodaj nast�pne";
$messages["Use folder names (creates subdirectories automatically)"] = "U�yj nazw katalog�w (automatycznie tworzy podkatalogi)";
$messages["Restrictions:"] = "Ograniczenia:";
$messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s kB</b> and by PHP to <b>%2\$s</b>"] = "Maksymalny rozmiar pliku ustawiony w  net2ftp to <b>%1\$s kB</b> i w PHP to <b>%2\$s</b>";
$messages["The maximum execution time is <b>%1\$s seconds</b>"] = "Maksymalny czas wykonywania skryptu <b>%1\$s sekund</b>";
$messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "Tryb transferu FTP (ASCII or BINARY) b�dzie ustawiony automatycznie na podstawie rozszerzenia";
$messages["If the destination file already exists, it will be overwritten"] = "Je�li plik docelowy istnieje, zostanie nadpisany";

$messages["Upload directories and files using a Java applet"] = "Upload directories and files using a Java applet";
$messages["Number of files:"] = "Number of files:";
$messages["Size of files:"] = "Size of files:";
$messages["Add"] = "Add";
$messages["Remove"] = "Remove";
$messages["Upload"] = "Upload";
$messages["Add files to the upload queue"] = "Add files to the upload queue";
$messages["Remove files from the upload queue"] = "Remove files from the upload queue";
$messages["Upload the files which are in the upload queue"] = "Upload the files which are in the upload queue";
$messages["Maximum server space exceeded. Please select less/smaller files."] = "Maximum server space exceeded. Please select less/smaller files.";
$messages["Total size of the files is too big. Please select less/smaller files."] = "Total size of the files is too big. Please select less/smaller files.";
$messages["Total number of files is too high. Please select fewer files."] = "Total number of files is too high. Please select fewer files.";
$messages["Note: to use this applet, Sun's Java plugin must be installed (version 1.4 or newer)."] = "Note: to use this applet, Sun's Java plugin must be installed (version 1.4 or newer).";

$messages["Browser does not support Java applets"] = "Your browser does not support applets, or you have disabled applets in your browser settings.\n";
$messages["Browser does not support Java applets"] .= "To use this applet, please install the newest version of Sun's java. You can get it from <a href=\"http://www.java.com/\">java.com</a>. Click on Get It Now.\n";
$messages["Browser does not support Java applets"] .= "The online installation is about 1-2 MB and the offline installation is about 13 MB. This 'end-user' java is called JRE (Java Runtime Environment).\n";
$messages["Browser does not support Java applets"] .= "Alternatively, use net2ftp's normal upload or upload-and-unzip functionality.\n";
}

// zipentry()
if ($state2 == "zip") {
$messages["Zip entries"] = "Zipowanie wybranych pozycji";
$messages["Save the zip file on the FTP server as:"] = "Zapisz plik zip na serwerze FTP jako:";
$messages["Email the zip file in attachment to:"] = "Wy�lij plik zip poczt� do:";
$messages["Note that sending files is not anonymous: your IP address as well as the time of the sending will be added to the email."] = "Wysy�anie plik�w nie jest anonimowe: Tw�j adres IP i czas wys�ania b�dzie dodany do emaila.";
$messages["Some additional comments to add in the email:"] = "Dodatkowe komentarze do emaila:";
$messages["You did not enter a filename for the zipfile. Go back and enter a filename."] = "Nie podano nazwy pliku zip. Cofnij i wprowad� nazw� pliku.";
$messages["The email address you have entered (%1\$s) does not seem to be valid.<br />Please enter an address in the format <b>username@domain.com</b>"] = "Adres, kt�ry wprowadzono (%1\$s) nie jest prawidowym adresem email.<br />Wprowad� adres w formacie <b>username@domain.com</b>";
}

// calculatesize()
if ($state2 == "calculatesize") {
$messages["Size of selected directories and files"] = "Rozmiar zaznaczonych plik�w i katalog�w";
$messages["The total size taken by the selected directories and files is:"] = "Ca�kowity rozmiar zaznaczonych plik�w i katalog�w:";
$messages["The nr of files which were skipped:"] = "Liczba pomini�tych plik�w:";
}

// findstring()
if ($state2 == "findstring") {
$messages["Search directories and files"] = "Szukaj katalog�w i plik�w";
$messages["Search results"] = "Wyniki wyszukiwania";
$messages["Please enter a valid search word or phrase."] = "Wprowad� prawid�ow� fraz� lub s�owo do wyszukania.";
$messages["Please enter a valid filename."] = "Wprowad� prawid�ow� nazw� plik�w.";
$messages["Please enter a valid file size in the \"from\" textbox, for example 0."] = "Wprowad� prawid�owy rozmiar pliku w polu \"od\" , np. 0.";
$messages["Please enter a valid file size in the \"to\" textbox, for example 500000."] = "Wprowad� prawid�owy rozmiar pliku w polu \"do\" , np. 500000.";
$messages["Please enter a valid date in Y-m-d format in the \"from\" textbox."] = "Wprowad� prawid�ow� dat� w formacie Y-m-d w polu \"od\".";
$messages["Please enter a valid date in Y-m-d format in the \"to\" textbox."] = "Wprowad� prawid�ow� dat� w formacie Y-m-d w polu \"do\".";
$messages["The word <b>%1\$s</b> was not found in the selected directories and files."] = "S�owo <b>%1\$s</b> nie zosta�o znalezione w zaznaczonych katalogach i plikach.";
$messages["The word <b>%1\$s</b> was found in the following files:"] = "S�owo <b>%1\$s</b> znaleziono w nast�puj�cych plikach:";
$messages["Search again"] = "Nowe szukanie";
}

// printFindstringForm()
if ($state2 == "findstring") {
$messages["Search for a word or phrase"] = "Szukaj s�owa lub frazy";
$messages["Case sensitive search"] = "Wa�na wielko�� liter";
$messages["Restrict the search to:"] = "Ogranicz szukanie do:";
$messages["files with a filename like"] = "nazw plik�w typu";
$messages["(wildcard character is *)"] = "(maska = *)";
$messages["files with a size"] = "plik�w o rozmiarze";
$messages["from"] = "od";
$messages["to"] = "do";
$messages["files which were last modified"] = "plik�w ostatnio modyfikowanych";
}

// updatefile()
if ($state2 == "updatefile") {
$messages["Update file"] = "Aktualizuj plik";
$messages["<b>WARNING: THIS FUNCTION IS STILL IN EARLY DEVELOPMENT. USE IT ONLY ON TEST FILES! YOU HAVE BEEN WARNED!"] = "<b>UWAGA: TA FUNKCJA JEST W STADIUM PROJEKTOWANIA. U�YWAJ JEJ NA PLIKACH TESTOWYCH! ZOSTA�E� OSTRZE�ONY!";
$messages["Known bugs: - erases tab characters - doesn't work well with big files (> 50kB) - was not tested yet on files containing non-standard characters</b>"] = "Znane b��dy: - kasuje znaki tabulacji - nie dzia�a poprawnie dla du�ych plik�w (> 50kB) - nie by�a testowana na plikach zawieraj�cych niestandardowe znaki</b>";
$messages["This function allows you to upload a new version of the selected file, to view what are the changes and to accept or reject each change. Before anything is saved, you can edit the merged files."] = "Ta funkcja pozwala na wys�anie nowej wesji pliku, przejrzenia jakie nast�pi�y zmiany, zaakceptowa� lub odrzuci� zmiany. Mo�na edutowa� i scali� pliki zanim zostan� zapisane.";
$messages["Old file:"] = "Stary plik:";
$messages["New file:"] = "Nowy plik:";
$messages["Restrictions:"] = "Ograniczenia:";
$messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s kB</b> and by PHP to <b>%2\$s</b>"] = "Maksymalny rozmiar pliku ustawiony w  net2ftp to <b>%1\$s kB</b> i w PHP to <b>%2\$s</b>";
$messages["The maximum execution time is <b>%1\$s seconds</b>"] = "Maksymalny czas wykonywania skryptu <b>%1\$s seconds</b>";
$messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "Tryb transferu FTP (ASCII or BINARY) b�dzie ustawiony automatycznie na podstawie rozszerzenia";
$messages["If the destination file already exists, it will be overwritten"] = "Je�li plik docelowy istnieje, zostanie nadpisany";
$messages["You did not provide any files or archives to upload."] = "Nie wprowadzono �adnych plik�w/archiw�w do wys�ania.";
$messages["Unable to delete the new file"] = "Nie mozna skasowa� nowego pliku";
}

// printComparisonSelect()
if ($state2 == "updatefile") {
$messages["Please wait..."] = "Prosz� czeka�...";
$messages["Select lines below, accept or reject changes and submit the form."] = "Zaznacz poni�ej linie, akceptuj lub odrzu� zmiany i wy�lij formularz.";
}

} // end manage


// -------------------------------------------------------------------------
// registerglobals.inc.php
// -------------------------------------------------------------------------
$messages["Please enter your username and password for FTP server "] = "Please enter your username and password for FTP server ";
$messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below.";
$messages["Access to the net2ftp Admin panel is disabled, because no password has been set in the file settings.inc.php. Enter a password in that file, and reload this page."] = "Access to the net2ftp Admin panel is disabled, because no password has been set in the file settings.inc.php. Enter a password in that file, and reload this page.";
$messages["Please enter your Admin username and password"] = "Please enter your Admin username and password"; 
$messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below.";
$messages["Wrong username or password for the net2ftp Admin panel. The username and password can be set in the file settings.inc.php."] = "Wrong username or password for the net2ftp Admin panel. The username and password can be set in the file settings.inc.php.";


// -------------------------------------------------------------------------
// skins.inc.php
// -------------------------------------------------------------------------
$messages["Blue"] = "Niebieska";
$messages["Grey"] = "Szara";
$messages["Black"] = "Czarna";
$messages["Yellow"] = "��ta";
$messages["Pastel"] = "Pastel";

// getMime()
$messages["Directory"] = "Katalog";
$messages["Symlink"] = "Link symboliczny";
$messages["ASP script"] = "Sktypt ASP";
$messages["Cascading Style Sheet"] = "Styl CSS";
$messages["HTML file"] = "Plik HTML";
$messages["Java source file"] = "Plik �r�d�owy Java";
$messages["JavaScript file"] = "Plik JavaScript";
$messages["PHP Source"] = "Plik �r�d�owy PHP";
$messages["PHP script"] = "Skrypt PHP";
$messages["Text file"] = "Plik tekstowy";
$messages["Bitmap file"] = "Bitmapa";
$messages["GIF file"] = "GIF";
$messages["JPEG file"] = "JPEG";
$messages["PNG file"] = "PNG";
$messages["TIF file"] = "TIF";
$messages["GIMP file"] = "GIMP";
$messages["Executable"] = "Wykonywalny";
$messages["Shell script"] = "Skrypt Shella";
$messages["MS Office - Word document"] = "MS Office - dokument Word";
$messages["MS Office - Excel spreadsheet"] = "MS Office - dokument Excel";
$messages["MS Office - PowerPoint presentation"] = "MS Office - prezentacja PowerPoint";
$messages["MS Office - Access database"] = "MS Office - baza Access";
$messages["MS Office - Visio drawing"] = "MS Office - rysunek Visio";
$messages["MS Office - Project file"] = "MS Office - plik Projecta";
$messages["OpenOffice - Writer 6.0 document"] = "OpenOffice - dokument Writer 6.0";
$messages["OpenOffice - Writer 6.0 template"] = "OpenOffice - szablon Writer 6.0";
$messages["OpenOffice - Calc 6.0 spreadsheet"] = "OpenOffice - dokument Calc 6.0";
$messages["OpenOffice - Calc 6.0 template"] = "OpenOffice - szablon Calc 6.0";
$messages["OpenOffice - Draw 6.0 document"] = "OpenOffice - dokument Draw 6.0";
$messages["OpenOffice - Draw 6.0 template"] = "OpenOffice - szablon Draw 6.0";
$messages["OpenOffice - Impress 6.0 presentation"] = "OpenOffice - prezentacja Impress 6.0";
$messages["OpenOffice - Impress 6.0 template"] = "OpenOffice - szablon Impress 6.0";
$messages["OpenOffice - Writer 6.0 global document"] = "OpenOffice - dokument Writer 6.0 global";
$messages["OpenOffice - Math 6.0 document"] = "OpenOffice - dokument Math 6.0";
$messages["StarOffice - StarWriter 5.x document"] = "StarOffice - dokument StarWriter 5.x";
$messages["StarOffice - StarWriter 5.x global document"] = "StarOffice - dokument StarWriter 5.x global";
$messages["StarOffice - StarCalc 5.x spreadsheet"] = "StarOffice - dokument StarCalc 5.x";
$messages["StarOffice - StarDraw 5.x document"] = "StarOffice - dokument StarDraw 5.x";
$messages["StarOffice - StarImpress 5.x presentation"] = "StarOffice - prezentacja StarImpress 5.x";
$messages["StarOffice - StarImpress Packed 5.x file"] = "StarOffice - plik StarImpress Packed 5.x";
$messages["StarOffice - StarMath 5.x document"] = "StarOffice - dokument StarMath 5.x";
$messages["StarOffice - StarChart 5.x document"] = "StarOffice - dokument StarChart 5.x";
$messages["StarOffice - StarMail 5.x mail file"] = "StarOffice - plik poczty StarMail 5.x";
$messages["Adobe Acrobat document"] = "dokument Adobe Acrobat";
$messages["ARC archive"] = "archiwum ARC";
$messages["ARJ archive"] = "archiwum ARJ";
$messages["RPM"] = "RPM";
$messages["GZ archive"] = "archiwum GZ";
$messages["TAR archive"] = "archiwum TAR";
$messages["Zip archive"] = "archiwum Zip";
$messages["MOV movie file"] = "film MOV";
$messages["MPEG movie file"] = "film MPEG";
$messages["Real movie file"] = "film Real";
$messages["Quicktime movie file"] = "film Quicktime";
$messages["Shockwave flash file"] = "animacja Shockwave flash";
$messages["Shockwave file"] = "plik Shockwave";
$messages["WAV sound file"] = "d�wi�k WAV";
$messages["Font file"] = "Czcionka";
$messages["%1\$s File"] = "plik %1\$s";
$messages["File"] = "Plik";

// getAction()
$messages["Back"] = "Wstecz";
$messages["Submit"] = "Wy�lij";
$messages["Refresh"] = "Od�wie�";
$messages["Details"] = "Szczeg�y";
$messages["Icons"] = "Ikony";
$messages["List"] = "Lista";
$messages["Logout"] = "Wyloguj";
$messages["Help"] = "Pomoc";
$messages["Bookmark"] = "Zak�adki";
$messages["Save"] = "Zapisz";
$messages["Default"] = "Domy�lnie";


// -------------------------------------------------------------------------
// view.inc.php
// -------------------------------------------------------------------------
$messages["Image"] = "Image";
$messages["View Macromedia ShockWave Flash movie %1\$s"] = "View Macromedia ShockWave Flash movie %1\$s";
$messages["View file %1\$s"] = "View file %1\$s";
$messages["To save the image, right-click on it and choose 'Save picture as...'"] = "Aby zapisa� obraz, kliknij na obrazie przwym przyciskiem i wybierz 'Zapisz obraz jako...'";


// ----------------------------------------------------------------------------------
// DO NOT CHANGE ANYTHING BELOW THIS LINE
// ----------------------------------------------------------------------------------

return $messages;

} // end function getMessages

?>