<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------

//   -------------------------------------------------------------------------------
//  | Language: Simplified Chinese (UTF-8)                                          |
//   -------------------------------------------------------------------------------
//  | <heenji AT sohu DOT com> 2004-10-30                       comments welcome    |
//   -------------------------------------------------------------------------------
//  |                                                                               |
//  |                              INSTRUCTIONS                                     |
//  |                                                                               |
//  |  The messages to translate are listed below.                                  |
//  |  The structure of each line is like this:                                     |
//  |     $message["Hello world!"] = "Hello world!";                                |
//  |                                                                               |
//  |  Keep the text between square brackets [] as it is.                           |
//  |  Translate the 2nd part, keeping the same punctuation and HTML tags.          |
//  |                                                                               |
//  |  The English message, for example                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is written in PHP!";    |
//  |  should become after translation:                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp est ecrit en PHP!";     |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is geschreven in PHP!"; |
//  |                                                                               |
//  |  Note that the variable starts with a dollar sign $, that the value is        |
//  |  enclosed in double quotes " and that the line ends with a semi-colon ;       |
//  |  Be careful when editing this file, do not erase those special characters.    |
//  |                                                                               |
//  |  Some messages also contain one or more variables which start with a percent  |
//  |  sign, for example %1\$s or %2\$s. The English message, for example           |
//  |     $messages[...] = ["The file %1\$s was copied to %2\$s "]                  |
//  |  should becomes after translation:                                            |
//  |     $messages[...] = ["Le fichier %1\$s a �t� copi� vers %2\$s "]             |
//  |                                                                               |
//  |  When a real percent sign % is needed in the text it is entered as %%         |
//  |  otherwise it is interpreted as a variable. So no, it's not a mistake.        |
//  |                                                                               |
//  |  Between the messages to translate there is additional PHP code, for example: |
//  |     if ($state2 == "rename") {                               // <-- PHP code  |
//  |     $messages["Rename directories"] = "Rename directories";  // <-- message   |
//  |     }                                                        // <-- PHP code  |
//  |  This code is needed to load the messages only when they are actually needed. |
//  |  There is no need to change or delete any of that PHP code; translate only    |
//  |  the message.                                                                 |
//  |                                                                               |
//  |  Thanks in advance to all the translators!                                    |
//  |  David.                                                                       |
//  |                                                                               |
//   -------------------------------------------------------------------------------

function getMessages() {
global $state, $state2;


// -------------------------------------------------------------------------
// Used encoding
// -------------------------------------------------------------------------
$messages["iso-8859-1"] = "UTF-8";


// -------------------------------------------------------------------------
// Status messages
// -------------------------------------------------------------------------
// When translating these messages, keep in mind that the text should not be too long
// It should fit in the status textbox
$messages["Connecting to the FTP server"] = "正链接到FTP服务器";
$messages["Getting the list of directories and files"] = "正获取目录和文件列表";
$messages["Printing the list of directories and files"] = "正打印目录和文件列表";
$messages["Processing the entries"] = "正处理输入中";
$messages["Checking files"] = "确认文件中";
$messages["Transferring files to the FTP server"] = "正传送文件到FTP服务器上";
$messages["Decompressing archives and transferring files"] = "解压缩文档并传送文件中";
$messages["Searching the files..."] = "正搜索文件...";
$messages["Uploading new file"] = "正上传新文件";
$messages["Reading the new file"] = "正读取新文件";
$messages["Reading the old file"] = "正读取旧文件";
$messages["Comparing the 2 files"] = "比较2个文件";
$messages["Printing the comparison"] = "打印比较的结果";
$messages["Script finished in %1\$s seconds"] = "代码执行耗时 %1\$s 秒";
$messages["Script halted"] = "代码终止";


// -------------------------------------------------------------------------
// index.php
// -------------------------------------------------------------------------
$messages["Unexpected state string. Exiting."] = "未知状态语句. 结束.";
$messages["This beta function is not activated on this server."] = "此测试功能没有被系统激活.";
$messages["This function has been disabled by the Administrator of this website."] = "This function has been disabled by the Administrator of this website.";


// -------------------------------------------------------------------------
// admin.inc.php
if ($state == "admin") {
// -------------------------------------------------------------------------
$messages["Admin functions"] = "系统管理功能";

$messages["Version information"] = "版本信息";
$messages["This version of net2ftp is up-to-date"] = "此版本net2ftp是最新的";
$messages["The latest version could not be retrieved from the net2ftp.com server. Check the security settings of your browser, which may prevent the loading of a small file from the net2ftp.com server."] = "最新版本无法从net2ftp.com服务器上获得，查看浏览器的安全设置,它可能限制了从服务器上下载更新文件.";

$messages["Logging"] = "登入中";
$messages["Date from:"] = "日期从:";
$messages["to:"] = "到:";
$messages["Empty logs"] = "为空";
$messages["View logs"] = "查看登陆信息";
$messages["No data"] = "无数据";

$messages["Setup MySQL tables"] = "安装 MySQL 数据表";
$messages["Go"] = "前往";
$messages["Create the MySQL database tables"] = "创建MySQL 数据表";
$messages["Create tables"] = "创建数据表";
$messages["The handle of file %1\$s could not be opened"] = "文件 %1\$s 无法打开";
$messages["The file %1\$s could not be opened"] = "文件 %1\$s 无法打开";
$messages["The handle of file %1\$s could not be closed"] = "文件 %1\$s 无法关闭";
$messages["MySQL username"] = "MySQL 用户名";
$messages["MySQL password"] = "MySQL 用户密码";
$messages["MySQL database"] = "MySQL 数据库名";
$messages["MySQL server"] = "MySQL 服务器名";
$messages["This SQL query is going to be executed:"] = "以下SQL语句将要被执行:";
$messages["Execute"] = "执行";
$messages["Settings used:"] = "使用以下设置:";
$messages["MySQL password length"] = "MySQL 密码长度";
$messages["Results:"] = "结果:";
$messages["The connection to the server <b>%1\$s</b> could not be set up"] = "到服务器联接 <b>%1\$s</b> 无法建立";
$messages["Unable to select the database <b>%1\$s</b>"] = "无法选择数据库 <b>%1\$s</b>";
$messages["The SQL query could not be executed"] = "SQL 语句无法被执行";
$messages["The tables were created successfully"] = "数据表创建成功";

$messages["Beta functions"] = "Beta 功能";
$messages["View logs"] = "查看登陆信息";
$messages["Empty logs"] = "清空登陆信息";
$messages["The table <b>%1\$s</b> was emptied successfully."] = "数据表 <b>%1\$s</b> 被成功清空.";
$messages["The table <b>%1\$s</b> could not be emptied."] = "数据表 <b>%1\$s</b> 无法被清空.";
$messages["The table <b>%1\$s</b> was optimized successfully."] = "数据表 <b>%1\$s</b> 优化成功.";
$messages["The table <b>%1\$s</b> could not be optimized."] = "数据表 <b>%1\$s</b> 无法被优化.";

} // end admin

// -------------------------------------------------------------------------
// advanced.inc.php
if ($state == "高级") {
// -------------------------------------------------------------------------

// advanced()
$messages["The site command functions are not available on this webserver."] = "站点命令功能无法在此web服务器上使用.";
$messages["The Apache functions are not available on this webserver."] = "Apache功能无法在此服务器上使用.";
$messages["The MySQL functions are not available on this webserver."] = "MySQL功能无法在此服务器上使用.";
$messages["Unexpected state2 string. Exiting."] = "非预知的state2 语句. 结束.";

// printAdvancedFunctions()
$messages["Advanced functions"] = "高级功能";
$messages["Go"] = "前往";
$messages["Troubleshooting functions"] = "错误诊断功能";
$messages["Troubleshoot net2ftp on this webserver"] = "此web服务器上的net2ftp 错误诊断";
$messages["Troubleshoot an FTP server"] = "FTP服务器上的错误诊断";
$messages["Translation functions"] = "错误诊断功能";
$messages["Introduction to the translation functions"] = "翻译功能的介绍";
$messages["Extract messages to translate from code files"] = "从代码文件中抽取信息翻译";
$messages["Check if there are new or obsolete messages"] = "查看是否有新语句";
$messages["Beta functions"] = "测试功能";
$messages["Send a site command to the FTP server"] = "发送站点命令到FTP服务器";
$messages["Apache: password-protect a directory, create custom error pages"] = "Apache: 密码保护目录, 创建自定义的错误页面";
$messages["MySQL: execute an SQL query"] = "MySQL: 执行SQL语句";

// troubleshoot_webserver()
$messages["Troubleshoot your net2ftp installation"] = "诊断你的net2ftp 安装";
$messages["Checking if the FTP module of PHP is installed: "] = "查看PHP的FTP模块是否已经安装: ";
$messages["yes"] = "是";
$messages["no - please install it!"] = "否 - 请安装!";
$messages["Checking the permissions of the directory on the web server: a small file will be written to the /temp folder and then deleted."] = "查看web服务器上的目录权限: 一个文件将会写入到 /temp 目录然后会被删除.";
$messages["Creating filename: "] = "创建文件名: ";
$messages["OK. Filename: %1\$s"] = "OK. 文件名: %1\$s";
$messages["not OK"] = "不 OK";
$messages["OK"] = "OK";
$messages["not OK. Check the permissions of the %1\$s directory"] = "不OK. 查看 %1\$s 目录的权限";
$messages["Opening the file in write mode: "] = "在写入模式下打开文件: ";
$messages["Writing some text to the file: "] = "给此文件写入些文字: ";
$messages["Closing the file: "] = "关闭文件: ";
$messages["Deleting the file: "] = "删除文件: ";

// troubleshoot_ftpserver()
$messages["Troubleshoot an FTP server"] = "FTP服务器上的错误诊断";
$messages["FTP server port"] = "FTP 服务器端口";
$messages["Connection settings:"] = "连接语句:";
$messages["Password length"] = "密码长度";
$messages["Language"] = "语言";
$messages["Skin number"] = "皮肤编号";
$messages["Connecting to the FTP server: "] = "正链接到FTP服务器: ";
$messages["Logging into the FTP server: "] = "正登入到FTP服务器: ";
$messages["Setting the passive mode: "] = "设置passive 模式: ";
$messages["Getting the FTP server system type: "] = "正获取FTP 服务器系统类型: ";
$messages["Changing to the directory %1\$s: "] = "正改变目录到 %1\$s: ";
$messages["The directory from the FTP server is: %1\$s "] = "FTP服务器上的目录为: %1\$s ";
$messages["Getting the raw list of directories and files: "] = "正获取原始目录和文件: ";
$messages["Trying a second time to get the raw list of directories and files: "] = "再一次尝试获取原始目录和文件: ";
$messages["Closing the connection: "] = "正关闭链接: ";
$messages["Raw list of directories and files:"] = "原始目录和文件列表:";
$messages["Parsed list of directories and files:"] = "传过来的目录和文件列表:";

// printTranslationFunctions()
$messages["net2ftp translation functions"] = "net2ftp 翻译功能";
$messages["A PHP application can be translated using the standard <a href=\"http://www.php.net/gettext\">gettext</a> functions, or using a self-made translation function."] = "一个PHP程序可以使用标准的<a href=\"http://www.php.net/gettext\">gettext</a> 功能来翻译, 或者使用自我模式来翻译.";
$messages["In both cases, the steps to take are similar."] = "这两种方式的步骤都大致相同.";
$messages["Step 1: change code"] = "步骤 1: 改变代码";
$messages["All messages must be translated using a translation function, for example translate()."] = "所有的语句都要用翻译功能翻译, 如translate().";
$messages["This Hello World code:"] = "这个 Hello World 语句:";
$messages["must be changed to this:"] = "要改成这样:";
$messages["Step 2: extract messages"] = "步骤 2: 抽出语句";
$messages["All messages which are used by the translate() function must be extracted from the code files, and copied to a <b>main message file</b>."] = "所用使用translate() 功能的语句必须从代码文件中抽取出来, 复制到 <b>主要语句文件</b>.";
$messages["Step 3: translate messages"] = "步骤 3: 翻译语句";
$messages["The main message file is given to translators, who rename the file and replace the messages in English by the translation."] = "主语句文件会给翻译者, 它们重命名文件，通过翻译用英文来覆盖语句.";
$messages["The translators return the <b>translated message files</b>."] = "此翻译会退回到 <b>被翻译的语句文件</b>.";
$messages["Each time the application is modified, a new main message file must be generated, as in step 2."] = "每次程序被修改, 一个新的主语句文件会被创建, 正如步骤2.";
$messages["In order to avoid translating everything all over again, it must then be compared to all translated message files, to check if there are new or obsolete messages."] = "为了避免重复翻译所有的内容, 需要比较所有被翻译的文件, 查看是否有新的或者绝对的语句.";
$messages["net2ftp can help in step 2 to extract messages to translate from code files"] = "在步骤2，net2ftp可以帮助从代码文件中抽取要翻译的语句";
$messages["net2ftp can help in step 4 to check if there are new or obsolete messages"] = "在步骤4，net2ftp 可以帮助查看是否有新的或绝对的语句";

// translate_extract()
$messages["Extract messages from code files"] = "从代码文件中抽取语句";
$messages["Directory containing code files:"] = "含有代码文件的目录:";
$messages["Translation function used in the code:"] = "在代码里使用的翻译功能:";
$messages["File to generate:"] = "要生成的文件:";
$messages["Extracted messages:"] = "被抽取的语句:";
$messages["No messages were found, so no file was put on the FTP server."] = "没有找到任何语句, 所以没有文件放置到FTP服务器上.";
$messages["The main language file <b>%1\$s</b> was transferred to directory <b>%2\$s</b>."] = "主语言文件 <b>%1\$s</b> 被传送到目录 <b>%2\$s</b>.";

// translate_check()
$messages["Main language file:"] = "主语言文件:";
$messages["Directory containing translated language files:"] = "含有被翻译的语言文件的目录:";
$messages["File %1\$s was skipped because it could not be read, or because it was empty."] = "文件 %1\$s 被跳过，因为它无法读取或者它为空.";
$messages["File nr %1\$s <b>%2\$s</b>"] = "文件 %1\$s <b>%2\$s</b>";
$messages["New messages:"] = "新语句:";
$messages["Obsolete messages:"] = "绝对语句:";
$messages["All the files have been processed"] = "所有文件已经被处理了";

// sendsitecommand()
$messages["Send site command"] = "发送站点命令";
$messages["Enter the site command"] = "输入站点命令";
$messages["The commands you can use depends on your FTP server. These commands are not standard and vary a lot from one server to the other."] = "你所使用的密码决定于你的FTP服务器. 这些命令并非标准化的，所以不同的服务器会有不同.";
$messages["Note that net2ftp cannot display the output of the FTP server, it can only tell if the command returned TRUE or FALSE. This is not a limitation of net2ftp but of PHP, the language in which net2ftp is written."] = "注意net2ftp 无法显示FTP 服务器输出的结果, 它只能作出真或者假的反馈。这不是net2ftp的缺陷，而是PHP, net2ftp所编程用的.";
$messages["The command <b>%1\$s</b> was executed successfully."] = "命令 <b>%1\$s</b> 被成功执行.";

// apache(), mysqlfunctions()
// Not yet translated

} // end advanced



// -------------------------------------------------------------------------
// authorizations.inc.php
// -------------------------------------------------------------------------

// checkAuthorization()
$messages["The FTP server <b>%1\$s</b> is not in the list of allowed FTP servers."] = "FTP服务器 <b>%1\$s</b> 不在被允许的FTP 服务器列表中.";
$messages["The FTP server <b>%1\$s</b> is in the list of banned FTP servers."] = "FTP服务器 <b>%1\$s</b> 在被禁的FTP服务器中.";
$messages["Your IP address (%1\$s) is in the list of banned IP addresses."] = "你的IP 地址 (%1\$s) 在被禁的IP地址列表里.";
$messages["The FTP server port %1\$s may not be used."] = "FTP 服务端口 %1\$s 可能无法被使用.";
$messages["You don't have the authorizations to view directory <b>%1\$s</b>."] = "你没有权限浏览目录 <b>%1\$s</b>.";

// logAccess(), logLogin(), logError()
// Not yet translated


// -------------------------------------------------------------------------
// bookmark.inc.php
if ($state == "bookmark") {
// -------------------------------------------------------------------------
$messages["Add this link to your bookmarks:"] = "添加此链接到你的书签:";
$messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer: 右键点击链接，然后选择 \"Add to Favorites...\"";
$messages["Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla, Firefox: 右键点击链接，然后选择 \"Bookmark This Link...\"";
$messages["Note: when you will use this bookmark, a popup window will ask you for your username and password."] = "注意: 当你使用此书签, 会弹出一个窗口，要求你的用户名和密码.";

} // end bookmark


// -------------------------------------------------------------------------
// browse.inc.php
if ($state == "browse") {
// -------------------------------------------------------------------------

// browse()
$messages["Directories with names containing \' cannot be displayed correctly. They can only be deleted. Please go back and select another subdirectory."] = "目录名含有字符 \' 无法被正常显示. 只能删除它们. 请退回然后选择其它的子目录.";

$messages["Consumption message"]  = "";
$messages["Consumption message"] .= "<b>每日限量已经达到: 你无法再传送数据了</b><br /><br />\n";
$messages["Consumption message"] .= "为了保证其他人也可以公平使用web服务, 每个用户每天传送数据的容量和代码所执行的时间是受限制的, 一旦此限制达到, 你仍然可以浏览FTP服务器，但是无法上传或者下载.<br /><br />\n";
$messages["Consumption message"] .= "如果你要无限制的使用, 请安装net2ftp 在你自己的WEB服务器上.<br />\n";

// ftp_getlist()
$messages["The directory <b>%1\$s</b> does not exist or could not be selected, so the root directory <b>/</b> is shown instead."] = "目录 <b>%1\$s</b> 不存在或者无法选取, 所以根目录 <b>/</b> 被显示.";

// printdirfilelist()
// Keep this short, it must fit in a small button!
$messages["New dir"] = "新目录";
$messages["New file"] = "新文件";
$messages["HTML templates"] = "HTML templates";
$messages["Upload"] = "上�";
$messages["Java Upload"] = "Java 上�";
$messages["Advanced"] = "高级";
$messages["Copy"] = "复制";
$messages["Move"] = "移到";
$messages["Delete"] = "删除";
$messages["Rename"] = "重命名";
$messages["Chmod"] = "修改权限";
$messages["Download"] = "下载";
$messages["Zip"] = "Zip";
$messages["Size"] = "大小";
$messages["Search"] = "搜索";
$messages["Go to the parent directory"] = "上级目录";
$messages["Transform selected entries: "] = "传送所选的: ";
$messages["Make a new subdirectory in directory %1\$s"] = "在目录 %1\$s 里创建子目录";
$messages["Create a new file in directory %1\$s"] = "在目录 %1\$s 里创建新文件";
$messages["Upload new files in directory %1\$s"] = "上传新文件到目录 %1\$s";
$messages["Go to the advanced functions"] = "前往高级功能";
$messages["Copy the selected entries"] = "复制所选";
$messages["Move the selected entries"] = "移动所选";
$messages["Delete the selected entries"] = "删除所选";
$messages["Rename the selected entries"] = "重命名所选";
$messages["Chmod the selected entries (only works on Unix/Linux/BSD servers)"] = "修改所选的权限 (只可用于 Unix/Linux/BSD 服务器)";
$messages["Download a zip file containing all selected entries"] = "下载一个zip 文件含有所有选定的内容";
$messages["Zip the selected entries to save or email them"] = "Zip 压缩所选的内容来保存或者电邮";
$messages["Calculate the size of the selected entries"] = "计算所选的内容的大小";
$messages["Find files which contain a particular word"] = "搜索含有特定单词的文件";
$messages["Click to sort by %1\$s in descending order"] = "点击按 %1\$s 分类并降序排列";
$messages["Click to sort by %1\$s in ascending order"] = "点击按 %1\$s 分类并升序排列";
$messages["Ascending order"] = "升序排列";
$messages["Descending order"] = "降序排列";
//$messages["Click to sort by %1\$s in ascending order"] = "Click to sort by %1\$s in ascending order";
$messages["Up"] = "向上";
$messages["Click to check or uncheck all rows"] = "点击对所有列复选或者取消复选";
$messages["All"] = "全部";
$messages["Name"] = "名称";
$messages["Type"] = "类型";
//$messages["Size"] = "Size";
$messages["Owner"] = "拥有者";
$messages["Group"] = "组";
$messages["Perms"] = "权限";
$messages["Mod Time"] = "修改时间";
$messages["Actions"] = "操作";
$messages["Download the file %1\$s"] = "下载文件 %1\$s";
$messages["View"] = "查看";
$messages["Edit"] = "编辑";
$messages["Update"] = "更新";
$messages["Open"] = "打开";
$messages["View the highlighted source code of file %1\$s"] = "查看有语法高亮显示的文件 %1\$s";
$messages["Edit the source code of file %1\$s"] = "编辑文件 %1\$s 的源代码";
$messages["Upload a new version of the file %1\$s and merge the changes"] = "上传文件 %1\$s 的新版本";
$messages["View image %1\$s"] = "查看图像 %1\$s";
$messages["View the file %1\$s from your HTTP web server"] = "从你的WEB服务器上查看文件 %1\$s ";
$messages["(Note: This link may not work if you don't have your own domain name.)"] = "(注意: 如果你没有域名，此链接可能无法使用.)";
$messages["This folder is empty"] = "此目录为空";

// printSeparatorRow()
$messages["Directories"] = "目录";
$messages["Files"] = "文件";
$messages["Symlinks"] = "链接";
$messages["Unrecognized FTP output"] = "无法识别FTP输出";
$messages["Number"] = "Number";
$messages["Size"] = "Size";
$messages["Skipped"] = "Skipped";

// printLocationActions()
$messages["Language:"] = "语言:";
$messages["Skin:"] = "皮肤:";
$messages["View mode:"] = "浏览模式:";
$messages["Directory Tree"] = "目录树";

// printURL()
$messages["Execute %1\$s in a new window"] = "执行 %1\$s 于新打开的窗口";

// printDirectorySelect()
$messages["Double-click to go to a subdirectory:"] = "双击打开下级目录:";
$messages["Choose"] = "选择";
$messages["Up"] = "向上";

} // end browse


// -------------------------------------------------------------------------
// consumption.inc.php
// -------------------------------------------------------------------------
$messages["Unable to determine your IP address."] = "无法确认你的	IP地址.";
$messages["Table net2ftp_logConsumptionIpaddress contains duplicate rows."] = "Table net2ftp_logConsumptionIpaddress 含有重复列.";
$messages["Table net2ftp_logConsumptionFtpserver contains duplicate rows."] = "表格 net2ftp_logConsumptionFtpserver 含有重复列.";
$messages["The variable <b>consumption_ipaddress_dataTransfer</b> is not numeric."] = "函数 <b>consumption_ipaddress_dataTransfer</b> 不是数值型.";
$messages["Table net2ftp_logConsumptionIpaddress could not be updated."] = "表格 net2ftp_logConsumptionIpaddress 无法被更新.";
$messages["Table net2ftp_logConsumptionIpaddress contains duplicate entries."] = "表格 net2ftp_logConsumptionIpaddress 含有重复内容.";
$messages["Table net2ftp_logConsumptionFtpserver could not be updated."] = "表格 net2ftp_logConsumptionFtpserver 无法被更新.";
$messages["Table net2ftp_logConsumptionFtpserver contains duplicate entries."] = "表格 net2ftp_logConsumptionFtpserver 含有重复内容.";
$messages["Daily limit reached: the file <b>%1\$s</b> will not be transferred"] = "已经达到每日限制: 文件 <b>%1\$s</b> 无法被传送";


// -------------------------------------------------------------------------
// database.inc.php
// -------------------------------------------------------------------------
$messages["Unable to connect to the DB"] = "无法链接到数据库";
$messages["Unable to select the DB"] = "无法链接到数据库";


// -------------------------------------------------------------------------
// easywebsite.inc.php
if ($state == "easyWebsite") {
// -------------------------------------------------------------------------
$messages["Create a website in 4 easy steps"] = "Create a website in 4 easy steps";
$messages["Template overview"] = "Template overview";
$messages["Template details"] = "Template details";
$messages["Files are copied"] = "Files are copied";
$messages["Edit your pages"] = "Edit your pages";


// Screen 1 - printTemplateOverview
$messages["Click on the image to view the details of a template."] = "Click on the image to view the details of a template.";
$messages["Back to the Browse screen"] = "Back to the Browse screen";
$messages["Template"] = "Template";
$messages["Copyright"] = "Copyright";
$messages["Click on the image to view the details of this template"] = "Click on the image to view the details of this template";

// Screen 2 - printTemplateDetails
$messages["The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?"] = "The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?";
$messages["Preview"] = "Preview";
$messages["Install"] = "Install";
$messages["Size"] = "Size";
$messages["Preview page"] = "Preview page";
$messages["opens in a new window"] = "opens in a new window";

// Screen 3
$messages["Please wait while the template files are being transferred to your server: "] = "Please wait while the template files are being transferred to your server: ";
$messages["Done."] = "Done.";
$messages["Continue"] = "Continue";

// Screen 4 - printEasyAdminPanel
$messages["Edit page"] = "Edit page";
$messages["Browse the FTP server"] = "Browse the FTP server";
$messages["Add this link to your favorites to return to this page later on!"] = "Add this link to your favorites to return to this page later on!";
$messages["Edit website at %1\$s"] = "Edit website at %1\$s";
$messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer: right-click on the link and choose \"Add to Favorites...\"";
$messages["Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\"";

// ftp_copy_local2ftp
$messages["WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing..."] = "WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing...";
$messages["Created target subdirectory <b>%1\$s</b>"] = "Created target subdirectory <b>%1\$s</b>";
$messages["WARNING: Unable to copy the file <b>%1\$s</b>. Continuing..."] = "WARNING: Unable to copy the file <b>%1\$s</b>. Continuing...";
$messages["Copied file <b>%1\$s</b>"] = "Copied file <b>%1\$s</b>";
}


// -------------------------------------------------------------------------
// edit.inc.php
if ($state == "manage" && ($state2 == "edit" || $state2 == "newfile")) {
// -------------------------------------------------------------------------

// edit()
$messages["Unable to open the template file"] = "无法打开暂存文件";
$messages["Unable to read the template file"] = "无法读取暂存文件";
$messages["Please specify a filename"] = "请确认一个文件名";

// printEditForm()
$messages["Directory: "] = "目录: ";
$messages["File: "] = "文件: ";
$messages["New file name: "] = "新文件名: ";
$messages["Note: changing the textarea type will save the changes"] = "注意: 改变文本输入类型将会保存改动";
$messages["Status: This file has not yet been saved"] = "状态: 此文件未保存";
$messages["Status: Saved on <b>%1\$s</b> using mode %2\$s"] = "状态: 保存在 <b>%1\$s</b> 使用模式 %2\$s";
$messages["Status: <b>This file could not be saved</b>"] = "状态: <b>此文件无法被保存</b>";

} // end if edit newfile


// -------------------------------------------------------------------------
// errorhandling.inc.php
// -------------------------------------------------------------------------
$messages["An error has occured"] = "发生一个错误";
$messages["Go back"] = "退回";
$messages["Go to the login page"] = "登陆";


// -------------------------------------------------------------------------
// filesystem.inc.php
// -------------------------------------------------------------------------

// ftp_openconnection()
$messages["The <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this FTP module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">php.net</a><br />"] = " <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">PHP的FTP模块</a> 没有被安装.<br /><br /> 此网站的系统管理员必须安装此模块，安装指南可以查看 <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">php.net</a><br />";
$messages["Unable to connect to FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "无法链接到 FTP 服务器 <b>%1\$s</b> 在端口 <b>%2\$s</b>.<br /><br />确定此FTP服务器地址没有错? 和 HTTP (web) 服务器不同. 请联系你的ISP 服务商或者系统管理员获取帮助.<br />";
$messages["Unable to login to FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "无法登入到你的FTP 服务器 <b>%1\$s</b> ，使用用户名 <b>%2\$s</b>.<br /><br />你的用户名和密码正确否? 请联系你的ISP 服务商或者系统管理员获取帮助.<br />";
$messages["Unable to switch to the passive mode on FTP server <b>%1\$s</b>."] = "无法在FTP服务器上转到passive 模式 <b>%1\$s</b>.";

// ftp_openconnection2()
$messages["Unable to connect to the second (target) FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the second (target) FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "无法链接到第二台 (target) FTP 服务器 <b>%1\$s</b> 在端口 <b>%2\$s</b>.<br /><br />确认此地址是否正确? 和 HTTP (web) 服务器不同. 请联系你的ISP 服务商或者系统管理员获取帮助.<br />";
$messages["Unable to login to the second (target) FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "无法链接到第二台 (target) FTP 服务器 <b>%1\$s</b> ，使用用户名 <b>%2\$s</b>.<br /><br />你的用户名和密码正确否? 请联系你的ISP 服务商或者系统管理员获取帮助.<br />";
$messages["Unable to switch to the passive mode on the second (target) FTP server <b>%1\$s</b>."] = "无法转到passive 模式，在第二台 (target) FTP 服务器 <b>%1\$s</b>.";

// ftp_myrename()
$messages["Unable to rename directory or file <b>%1\$s</b> into <b>%2\$s</b>"] = "无法重命名目录和文件 <b>%1\$s</b> 为 <b>%2\$s</b>";

// ftp_mychmod()
$messages["Unable to execute site command <b>%1\$s</b>. Note that the CHMOD command is only available on Unix FTP servers, not on Windows FTP servers."] = "无法执行站点命令 <b>%1\$s</b>. 注意CHMOD 命令只适用于 Unix FTP 服务器, 而不是Windows FTP 服务器.";
$messages["Directory <b>%1\$s</b> successfully chmodded to <b>%2\$s</b>"] = "目录 <b>%1\$s</b> 被成功修改权限为 <b>%2\$s</b>";
$messages["File <b>%1\$s</b> was successfully chmodded to <b>%2\$s</b>"] = "文件 <b>%1\$s</b> 被成功修改权限为 <b>%2\$s</b>";
$messages["All the selected directories and files have been processed."] = "所有选定的目录和文件被处理.";

// ftp_rmdir2()
$messages["Unable to delete the directory <b>%1\$s</b>"] = "无法删除目录 <b>%1\$s</b>";

// ftp_delete2()
$messages["Unable to delete the file <b>%1\$s</b>"] = "无法删除文件 <b>%1\$s</b>";

// ftp_newdirectory()
$messages["Unable to create the directory <b>%1\$s</b>"] = "无法创建目录 <b>%1\$s</b>";

// ftp_readfile()
$messages["Unable to create the temporary file"] = "无法创建暂时文件";
$messages["Unable to get the file <b>%1\$s</b> from the FTP server and to save it as temporary file <b>%2\$s</b>.<br />Check the permissions of the %3\$s directory.<br />"] = "无法从FTP服务器上获取文件 <b>%1\$s</b> , 并保存为暂时文件 <b>%2\$s</b>.<br />查看目录 %3\$s 的权限设置.<br />";
$messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "无法打开暂时文件. 查看目录 %1\$s 的权限设置.";
$messages["Unable to read the temporary file"] = "无法读取暂时文件";
$messages["Unable to close the handle of the temporary file"] = "无法关闭对暂时文件的处理";
$messages["Unable to delete the temporary file"] = "无法删除暂时文件";

// ftp_writefile()
$messages["Unable to create the temporary file. Check the permissions of the %1\$s directory."] = "无法创建暂时文件. 查看目录 %1\$s 的权限设置.";
$messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "无法打开暂时文件. 查看目录 %1\$s 的权限设置.";
$messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "无法写入语句到暂时文件 <b>%1\$s</b>.<br />查看目录 %2\$s 的权限设置.";
$messages["Unable to close the handle of the temporary file"] = "无法关闭对暂时文件的处理";
$messages["Unable to put the file <b>%1\$s</b> on the FTP server.<br />You may not have write permissions on the directory."] = "无法放置文件 <b>%1\$s</b> 到FTP 服务器上.<br />你也许对该目录没有写入的权限.";
$messages["Unable to delete the temporary file"] = "无法删除暂时文件";

// ftp_copymovedelete()
$messages["Processing directory <b>%1\$s</b>"] = "处理目录<b>%1\$s</b>";
$messages["The target directory <b>%1\$s</b> is the same as or a subdirectory of the source directory <b>%2\$s</b>, so this directory will be skipped"] = "目标目录 <b>%1\$s</b> 和源目录<b>%2\$s</b>相同或者是源目录<b>%2\$s</b>的子目录 , 所以此目录被跳过";
$messages["Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing the copy/move process..."] = "无法创建子目录 <b>%1\$s</b>. 可能它已经存在. 继续 复制/移动 的处理...";
$messages["Created target subdirectory <b>%1\$s</b>"] = "创建目标子目录 <b>%1\$s</b>";
$messages["Unable to delete the subdirectory <b>%1\$s</b> - it may not be empty"] = "无法删除子目录 <b>%1\$s</b> - 它可能不为空";
$messages["Deleted subdirectory <b>%1\$s</b>"] = "被删除的子目录 <b>%1\$s</b>";
$messages["Processing of directory <b>%1\$s</b> completed"] = "对目录 <b>%1\$s</b> 的处理已经完成";
$messages["The target for file <b>%1\$s</b> is the same as the source, so this file will be skipped"] = "目标文件 <b>%1\$s</b> 和源文件相同, 所以此文件被跳过";
$messages["Unable to copy the file <b>%1\$s</b>"] = "无法复制文件 <b>%1\$s</b>";
$messages["Copied file <b>%1\$s</b>"] = "复制文件 <b>%1\$s</b>";
$messages["Unable to move the file <b>%1\$s</b>"] = "无法移动文件 <b>%1\$s</b>";
$messages["Moved file <b>%1\$s</b>"] = "移动文件 <b>%1\$s</b>";
$messages["Unable to delete the file <b>%1\$s</b>"] = "无法删除文件 <b>%1\$s</b>";
$messages["Deleted file <b>%1\$s</b>"] = "删除文件 <b>%1\$s</b>";
$messages["All the selected directories and files have been processed."] = "所有选定的目录和文件已经被处理.";

// ftp_processfiles()

// ftp_getfile()
$messages["Unable to copy the remote file <b>%1\$s</b> to the local file using FTP mode <b>%2\$s</b>"] = "无法复制远端文件 <b>%1\$s</b> 到当前文件，使用FTP模式 <b>%2\$s</b>";
$messages["Unable to delete file <b>%1\$s</b>"] = "无法删除文件 <b>%1\$s</b>";

// ftp_putfile()
$messages["Unable to copy the local file to the remote file <b>%1\$s</b> using FTP mode <b>%2\$s</b>"] = "无法复制本地文件到远端文件 <b>%1\$s</b> ，使用FTP模式 <b>%2\$s</b>";
$messages["Unable to delete the local file"] = "无法删除本地文件";

// ftp_downloadfile()
$messages["Unable to delete the temporary file"] = "无法删除暂时文件";
$messages["Unable to send the file to the browser"] = "无法发送文件到浏览器";

// ftp_zip()
$messages["Unable to create the temporary file"] = "无法创建暂时文件";
$messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "无法向暂时文件写入文字 <b>%1\$s</b>.<br />查看 %2\$s 目录的权限设置.";
$messages["Unable to close the handle of the temporary file"] = "无法关闭对暂时文件的处理";
$messages["The zip file has been saved on the FTP server as <b>%1\$s</b>"] = "zip文件已经保存到FTP服务器，为 <b>%1\$s</b>";
$messages["Requested files"] = "被请求的文件";

$messages["Zip email message"]  = "";
$messages["Zip email message"] .= "你好, \n\n";
$messages["Zip email message"] .= "某人把这些文件作为附件发送到此电子邮件账号 (%1\$s).\n";
$messages["Zip email message"] .= "如果你不了解或者不信任它, 请删除此邮件，不要打开附件中的zip文件.\n";
$messages["Zip email message"] .= "注意，如果你没有打开附件, 文件是不会损害到你的电脑的.\n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "关于寄信人的信息:\n";
$messages["Zip email message"] .= "IP 地址: %2\$s\n";
$messages["Zip email message"] .= "发出日期: %3\$s\n";
$messages["Zip email message"] .= "使用net2ftp发送，该站点是: %4\$s \n";
$messages["Zip email message"] .= "网络管理员邮箱: %5\$s \n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "寄信人的说明:\n";
$messages["Zip email message"] .= "%6\$s \n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "net2ftp 是免费软件, 遵循 GNU/GPL 协议. 要了解更多信息, 请浏览http://www.net2ftp.com\n\n\n";

$messages["The zip file has been sent to <b>%1\$s</b>."] = "zip文件已经发送到 <b>%1\$s</b>.";

// acceptFiles()
$messages["File <b>%1\$s</b> is too big. This file will not be uploaded."] = "文件 <b>%1\$s</b> 太大. 无法上传该文件.";
$messages["Could not generate a temporary file."] = "无法创建暂时文件.";
$messages["File <b>%1\$s</b> could not be moved"] = "文件 <b>%1\$s</b> 无法移动";
$messages["File <b>%1\$s</b> is OK"] = "文件 <b>%1\$s</b> 是ok的";
$messages["Unable to move the uploaded file to the temp directory.<br /><br />The administrator of this website has to <b>chmod 777</b> the /temp directory of net2ftp."] = "无法移动要上传的文件到temp目录.<br /><br />系统管理员必须将net2ftp的 /temp目录的权限设置为<b> 777</b> .";
$messages["You did not provide any file to upload."] = "你没有提供要上传的文件.";

// ftp_transferfiles()
$messages["File <b>%1\$s</b> could not be transferred to the FTP server"] = "文件 <b>%1\$s</b> 无法传送到FTP服务器上";
$messages["File <b>%1\$s</b> has been transferred to the FTP server using FTP mode <b>%2\$s</b>"] = "文件<b>%1\$s</b> 传送到FTP服务器上,使用的FTP模式为 <b>%2\$s</b>";
$messages["Transferring files to the FTP server"] = "正传送到FTP服务器上";

// ftp_unziptransferfiles()
$messages["Processing archive nr %1\$s: <b>%2\$s</b>"] = "正在处理压缩文档 %1\$s: <b>%2\$s</b>";
$messages["Unable to open the archive <b>%1\$s</b> (file %2\$s)"] = "无法打开压缩文档 <b>%1\$s</b> (文件 %2\$s)";
$messages["Could not create directory <b>%1\$s</b>"] = "无法创建目录 <b>%1\$s</b>";
$messages["Created directory <b>%1\$s</b>"] = "创建目录 <b>%1\$s</b>";
$messages["File Contents:"] = "文件内容:";
$messages["Could not put the file <b>%1\$s</b> to the directory <b>%2\$s</b>"] = "无法放置文件 <b>%1\$s</b> 到目录 <b>%2\$s</b>";
$messages["Transferred file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "传送文件 <b>%1\$s</b> 到目录 <b>%2\$s</b>";
$messages["Unable to delete the archive <b>%1\$s</b> (file %2\$s)"] = "无法删除压缩文档 <b>%1\$s</b> (文件 %2\$s)";
$messages["Unable to get the list of the contents of the Zip archive. Error code: %1\$s"] = "无法获取Zip文档的内容. 错误代码: %1\$s";
$messages["Unable to get the list of the contents of the Tar archive."] = "无法获取Tar文档的内容.";
$messages["Could not create directory <b>%1\$s</b>"] = "无法创建目录 <b>%1\$s</b>";
$messages["Created directory <b>%1\$s</b>"] = "创建目录 <b>%1\$s</b>";
$messages["Unable to create the temporary file"] = "无法创建暂时文件";
$messages["Unable to extract file nr <b>%1\$s</b> from the archive."] = "无法从压缩文档中解压文件 <b>%1\$s</b> .";
$messages["Could not put file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "无法放置文件 <b>%1\$s</b> 到目录<b>%2\$s</b>";
$messages["Transferred file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "传送文件 <b>%1\$s</b> 到目录 <b>%2\$s</b>";
$messages["Unable to delete the temporary file <b>%1\$s</b>."] = "无法删除暂时文件 <b>%1\$s</b>.";
$messages["Archive <b>%1\$s</b> was not processed because its filename extension was not recognized. Only zip, tar, tgz and gz archives are supported at the moment."] = "文档 <b>%1\$s</b> 没有被处理，因为无法识别它的扩展名. 当前只有 zip, tar, tgz and gz 文档被支持.";
$messages["Unzipping and transferring files"] = "解压缩并传送文件";

// ftp_mysite()
$messages["Unable to execute site command <b>%1\$s</b>"] = "无法执行命令 <b>%1\$s</b>";

// shutdown()
$messages["Shutdown message"]  = "";
$messages["Shutdown message"] .= "<b>你的操作任务被终止</b><br /><br />";
$messages["Shutdown message"] .= "你操作的时间超过的限定时间 %1\$s 秒, 任务被终止.<br />";
$messages["Shutdown message"] .= "时间限制可以保证其它用户也可以正当使用FTP服务.<br /><br />";
$messages["Shutdown message"] .= "尝试把任务分小块: 限制所选择的文件, 清除容量最大的文件.<br /><br />";
$messages["If you really need net2ftp to be able to handle big tasks which take a long time, consider installing net2ftp on your own server."] = "如果确实需要net2ftp 来处理耗时长的任务, 请考虑安装net2ftp 到你自己的服务器上.";

// SendMail()
$messages["You did not provide any text to send by email!"] = "没有输入要电邮的文字!";
$messages["You did not supply a From address."] = "没有输入寄信人邮件地址.";
$messages["You did not supply a To address."] = "没有输入收信人邮件地址.";
$messages["Due to technical problems the email to <b>%1\$s</b> could not be sent."] = "由于技术原因，发送到地址 <b>%1\$s</b> 的邮件无法被邮寄出。";

// printFunctionTags()
$messages["Output generated by function %1\$s"] = "结果生成是使用功能 %1\$s";



// -------------------------------------------------------------------------
// homepage.inc.php
if ($state == "homepage") {
// -------------------------------------------------------------------------
$messages["net2ftp features short"] ="你登入系统后，可以: \n";
$messages["net2ftp features short"] .="<ul>\n";
$messages["net2ftp features short"] .="<li> 浏览FTP服务器</li>\n";
$messages["net2ftp features short"] .="<li> 上传 下载 <span style=\"font-size: 80%%; color: red;\">新功能: 无限制上传文件</span></li>\n";
$messages["net2ftp features short"] .="<li> 复制 移动 删除 重命名 修改权限</li>\n";
$messages["net2ftp features short"] .="<li> 复制/移动到 其它FTP 服务器</li>\n";
$messages["net2ftp features short"] .="<li> 有语法闪亮的代码显示</li>\n";
$messages["net2ftp features short"] .="<li> 查看图片 <span style=\"font-size: 80%%; color: red;\">新功能</span></li>\n";
$messages["net2ftp features short"] .="<li> 编辑文本文件</li>\n";
$messages["net2ftp features short"] .="<li> 编辑 HTML 代码在其他HTML 编辑器中 <span style=\"font-size: 80%%; color: red;\">new</span></li>\n";
$messages["net2ftp features short"] .="<li> 编辑代码有语法闪亮提示 <span style=\"font-size: 80%%; color: red;\">测试</span></li>\n";
$messages["net2ftp features short"] .="<li> zip 文件的下载, 电邮或者保存</li>\n";
$messages["net2ftp features short"] .="<li> 上传和解压 (zip, tar, tgz, gz)</li>\n";
$messages["net2ftp features short"] .="<li> 搜索词汇和词组</li>\n";
$messages["net2ftp features short"] .="<li> 计算目录和文件的容量大小</li>\n";
$messages["net2ftp features short"] .="</ul>\n";

} // end homepage


// -------------------------------------------------------------------------
// net2ftp_loginform.inc.php
// -------------------------------------------------------------------------
$messages["FTP server"] = "FTP 服务器";
$messages["Example"] = "例子";
$messages["Username"] = "用户名";
$messages["Password"] = "密码";
$messages["Anonymous"] = "匿名";
$messages["Passive mode"] = "Passive 模式";
$messages["Initial directory"] = "初始目录";
$messages["Language"] = "语言";
$messages["Skin"] = "皮肤";
$messages["FTP mode"] = "FTP 模式";
$messages["Login"] = "登入";
$messages["Clear cookies"] = "清除cookies";
$messages["Please enter an FTP server."] = "Please enter an FTP server.";
$messages["Please enter a username."] = "Please enter a username.";
$messages["Please enter a password."] = "Please enter a password.";


// -------------------------------------------------------------------------
// html.inc.php
// -------------------------------------------------------------------------

// HtmlBegin()
$messages["Status:"] = "状态:";

// HtmlEnd()
$messages["net2ftp Help Guide"] = "net2ftp 帮助文件";
$messages["net2ftp Forums"] = "net2ftp 论坛";
$messages["License"] = "协议";
$messages["Powered by"] = "使用";

// printJavascriptFunctions()
$messages["Choose a directory"] = "选择一个目录";
$messages["Please wait..."] = "请稍候...";
$messages["Uploading... please wait..."] = "上传中... 请稍候...";
$messages["If the upload takes more than the allowed <b>%1\$s seconds<\/b>, you will have to try again with less/smaller files."] = "如果上传的时间超过允许的时间 <b>%1\$s 秒<\/b>, 你可以把文件减小后再试一试.";
$messages["This window will close automatically in a few seconds."] = "此窗口将在几秒钟后自动关闭.";
$messages["Close window now"] = "现在关闭窗口";


// -------------------------------------------------------------------------
// httpheaders.inc.php
// -------------------------------------------------------------------------
// Nothing to translate


// -------------------------------------------------------------------------
// manage.inc.php
if ($state == "manage") {
// -------------------------------------------------------------------------

// manage()
$messages["Please select at least one directory or file!"] = "请选择至少的一个目录或者文件!";
$messages["Unexpected state2 string. Exiting."] = "无法预期的state2语句. 关闭中.";

// renameentry()
if ($state2 == "rename") {
$messages["Rename directories and files"] = "重命名目录和文件";
$messages["Old name: "] = "旧名称: ";
$messages["New name: "] = "新名称: ";
$messages["The new name may not contain any dots. This entry was not renamed to <b>%1\$s</b>"] = "新名称不能含有点号. 无法被重命名为 <b>%1\$s</b>";
$messages["<b>%1\$s</b> was successfully renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> 被成功重命名为 <b>%2\$s</b>";
$messages["<b>%1\$s</b> could not be renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> 无法被重命名为 <b>%2\$s</b>";
}

// chmodentry()
if ($state2 == "chmod") {
$messages["Chmod directories and files"] = "修改目录和文件权限";
$messages["Set all permissions"] = "设置所有权限";
$messages["Read"] = "读取";
$messages["Write"] = "写入";
$messages["Execute"] = "执行";
$messages["Owner"] = "拥有者";
$messages["Group"] = "组";
$messages["Everyone"] = "任何人";
$messages["To set all permissions to the same values, enter those permissions above and click on the button \"Set all permissions\""] = "设置所有的权限为相同值, 在上面中输入需要的权限，然后点击按钮 \"设置所有权限\"";
$messages["Set the permissions of directory <b>%1\$s</b> to: "] = "设置目录 <b>%1\$s</b> 的权限为: ";
$messages["Set the permissions of file <b>%1\$s</b> to: "] = "设置文件 <b>%1\$s</b> 的权限为: ";
$messages["Set the permissions of symlink <b>%1\$s</b> to: "] = "设置链接 <b>%1\$s</b> 的权限为: ";
$messages["Chmod value"] = "权限值";
$messages["Chmod also the subdirectories within this directory"] = "也设置此目录里的子目录的权限";
$messages["Chmod also the files within this directory"] = "也设置此目录里的文件的权限";
$messages["The chmod nr <b>%1\$s</b> is out of the range 000-777. Please try again."] = "输入的权限值 <b>%1\$s</b> 超出可用的范围 000-777. 请重试.";
}

// copymovedeleteentry()
if ($state2 == "copy" || $state2 == "move" || $state2 == "delete") {
$messages["Copy directories and files"] = "复制目录和文件";
$messages["Move directories and files"] = "移动目录和文件";
$messages["Delete directories and files"] = "删除目录和文件";
$messages["Are you sure you want to delete these directories and files?"] = "确定要删除这些目录和文件?";
$messages["All the subdirectories and files of the selected directories will also be deleted!"] = "所有所选的目录里的子目录和文件的内容也都将被删除!";
$messages["Set all targetdirectories"] = "设置所有的目标目录";
$messages["To set a common target directory, enter that target directory in the textbox above and click on the button \"Set all targetdirectories\"."] = "设置一个一般的目录, 在上面的输入框中输入目标目录的名称，然后点击按钮 \"设置所有的目标目录\".";
$messages["Note: the target directory must already exist before anything can be copied into it."] = "注意: 在复制任何内容之前，必须保证目标目录已经存在.";
$messages["Different target FTP server:"] = "不同的目标FTP服务器:";
$messages["Leave empty if you want to copy the files to the same FTP server."] = "如果你要复制到相同的FTP服务器上，请留空.";
$messages["If you want to copy the files to another FTP server, enter your login data."] = "如果你要复制这些文件到其他其他FTP服务器, 请输入你的登入信息.";
$messages["Leave empty if you want to move the files to the same FTP server."] = "如果你要移动到相同的FTP服务器上，请留空.";
$messages["If you want to move the files to another FTP server, enter your login data."] = "如果你要移动这些文件到其他FTP服务器,请输入你的登入信息.";
$messages["Copy directory <b>%1\$s</b> to:"] = "复制目录 <b>%1\$s</b> 到:";
$messages["Move directory <b>%1\$s</b> to:"] = "移动目录 <b>%1\$s</b> 到:";
$messages["Directory <b>%1\$s</b>"] = "目录 <b>%1\$s</b>";
$messages["Copy file <b>%1\$s</b> to:"] = "复制文件 <b>%1\$s</b> 到:";
$messages["Move file <b>%1\$s</b> to:"] = "移动文件 <b>%1\$s</b> 到:";
$messages["File <b>%1\$s</b>"] = "文件 <b>%1\$s</b>";
$messages["Copy symlink <b>%1\$s</b> to:"] = "复制链接 <b>%1\$s</b> 到:";
$messages["Move symlink <b>%1\$s</b> to:"] = "移动链接 <b>%1\$s</b> 到:";
$messages["Symlink <b>%1\$s</b>"] = "链接 <b>%1\$s</b>";
$messages["Target directory:"] = "目标目录:";
$messages["Target name:"] = "目标名称:";
$messages["Processing the entries:"] = "处理以下输入:";
}

// newdirectory()
if ($state2 == "newdirectory") {
$messages["Create new directories"] = "新建目录";
$messages["The new directories will be created in <b>%1\$s</b>."] = "新目录将创建在 <b>%1\$s</b>.";
$messages["New directory name:"] = "新目录名称:";
$messages["Directory <b>%1\$s</b> was successfully created."] = "目录 <b>%1\$s</b> 被成功创建.";
}

// uploadfile()
if ($state2 == "uploadfile") {
$messages["Upload files and archives"] = "上传文件和压缩文档";
$messages["Upload results"] = "上传的结果";
$messages["Checking files:"] = "查看文件:";
$messages["Transferring files to the FTP server:"] = "正将文件传送到服务器中:";
$messages["Decompressing archives and transferring files to the FTP server:"] = "解压缩文件并传送到FTP服务器上:";
$messages["Upload more files and archives"] = "上传更多的文件和压缩文档";
}

// printUploadForm() and javaupload()
if ($state2 == "uploadfile" || $state2 == "javaupload") {
$messages["Upload to directory:"] = "上传到目录:";
$messages["Files"] = "文件";
$messages["Archives"] = "压缩文件";
$messages["Files entered here will be transferred to the FTP server."] = "在这里输入的文件将被传送到FTP服务器.";
$messages["Archives entered here will be decompressed, and the files inside will be transferred to the FTP server."] = "在这里输入的压缩文件将被解压缩, 文档里的文件将被上传到FTP服务器.";
$messages["Add another"] = "Add another";
$messages["Use folder names (creates subdirectories automatically)"] = "使用的目录名 (子目录自动被创建)";
$messages["Restrictions:"] = "限制:";
$messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s kB</b> and by PHP to <b>%2\$s</b>"] = "文件的最大容量受net2ftp 限制为 <b>%1\$s kB</b> 和受PHP限制为 <b>%2\$s</b>";
$messages["The maximum execution time is <b>%1\$s seconds</b>"] = "最长的执行时间为 <b>%1\$s 秒</b>";
$messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "根据文件扩展名，将自动选择FTP模式 (ASCII 或者 BINARY) ";
$messages["If the destination file already exists, it will be overwritten"] = "如果目标文件已经存在，它将被覆盖";

$messages["Upload directories and files using a Java applet"] = "Upload directories and files using a Java applet";
$messages["Number of files:"] = "Number of files:";
$messages["Size of files:"] = "Size of files:";
$messages["Add"] = "Add";
$messages["Remove"] = "Remove";
$messages["Upload"] = "Upload";
$messages["Add files to the upload queue"] = "Add files to the upload queue";
$messages["Remove files from the upload queue"] = "Remove files from the upload queue";
$messages["Upload the files which are in the upload queue"] = "Upload the files which are in the upload queue";
$messages["Maximum server space exceeded. Please select less/smaller files."] = "Maximum server space exceeded. Please select less/smaller files.";
$messages["Total size of the files is too big. Please select less/smaller files."] = "Total size of the files is too big. Please select less/smaller files.";
$messages["Total number of files is too high. Please select fewer files."] = "Total number of files is too high. Please select fewer files.";
$messages["Note: to use this applet, Sun's Java plugin must be installed (version 1.4 or newer)."] = "Note: to use this applet, Sun's Java plugin must be installed (version 1.4 or newer).";

$messages["Browser does not support Java applets"] = "Your browser does not support applets, or you have disabled applets in your browser settings.\n";
$messages["Browser does not support Java applets"] .= "To use this applet, please install the newest version of Sun's java. You can get it from <a href=\"http://www.java.com/\">java.com</a>. Click on Get It Now.\n";
$messages["Browser does not support Java applets"] .= "The online installation is about 1-2 MB and the offline installation is about 13 MB. This 'end-user' java is called JRE (Java Runtime Environment).\n";
$messages["Browser does not support Java applets"] .= "Alternatively, use net2ftp's normal upload or upload-and-unzip functionality.\n";
}

// zipentry()
if ($state2 == "zip") {
$messages["Zip entries"] = "Zip 输入";
$messages["Save the zip file on the FTP server as:"] = "保存zip文件到FTP服务器中为:";
$messages["Email the zip file in attachment to:"] = "把zip文件作为邮件附件发送到:";
$messages["Note that sending files is not anonymous: your IP address as well as the time of the sending will be added to the email."] = "注意发送文件不是匿名发送: 你的IP地址和发送日期将会自动加入到邮件里.";
$messages["Some additional comments to add in the email:"] = "添加到电子邮件里的一些说明:";
$messages["You did not enter a filename for the zipfile. Go back and enter a filename."] = "没有为zip文件命名. 退回并命名.";
$messages["The email address you have entered (%1\$s) does not seem to be valid.<br />Please enter an address in the format <b>username@domain.com</b>"] = "你输入的邮件地址 (%1\$s) 格式不正确.<br />请输入类似以下格式的邮件地址 <b>username@domain.com</b>";
}

// calculatesize()
if ($state2 == "calculatesize") {
$messages["Size of selected directories and files"] = "所选的目录和文件容量大小";
$messages["The total size taken by the selected directories and files is:"] = "所选的目录和文件所占的容量大小:";
$messages["The nr of files which were skipped:"] = "被跳过未操作的文件为:";
}

// findstring()
if ($state2 == "findstring") {
$messages["Search directories and files"] = "搜索目录和文件";
$messages["Search results"] = "搜索结果为";
$messages["Please enter a valid search word or phrase."] = "请输入正确的词汇或者词组.";
$messages["Please enter a valid filename."] = "请输入正确的文件名称.";
$messages["Please enter a valid file size in the \"from\" textbox, for example 0."] = "请输入正确的文件大小在 \"从\" 输入框, 如0.";
$messages["Please enter a valid file size in the \"to\" textbox, for example 500000."] = "请输入正确的文件大小在 \"到\" 输入框, 如500000.";
$messages["Please enter a valid date in Y-m-d format in the \"from\" textbox."] = "请输入正确的日期 Y-m-d 格式在 \"从\" 输入框.";
$messages["Please enter a valid date in Y-m-d format in the \"to\" textbox."] = "请输入正确的日期 Y-m-d 格式在 \"到\" 输入框.";
$messages["The word <b>%1\$s</b> was not found in the selected directories and files."] = "词汇<b>%1\$s</b> 没有在所选的目录和文件中找到.";
$messages["The word <b>%1\$s</b> was found in the following files:"] = "词汇 <b>%1\$s</b> 出现在以下文件中:";
$messages["Search again"] = "重新搜索";
}

// printFindstringForm()
if ($state2 == "findstring") {
$messages["Search for a word or phrase"] = "查找词汇或者词组";
$messages["Case sensitive search"] = "大小写字母有区别";
$messages["Restrict the search to:"] = "限制查询范围为:";
$messages["files with a filename like"] = "文件名称类似";
$messages["(wildcard character is *)"] = "(取代 字符是 *)";
$messages["files with a size"] = "文件大小";
$messages["from"] = "从";
$messages["to"] = "到";
$messages["files which were last modified"] = "文件被最新修改";
}

// updatefile()
if ($state2 == "updatefile") {
$messages["Update file"] = "更新文件";
$messages["<b>WARNING: THIS FUNCTION IS STILL IN EARLY DEVELOPMENT. USE IT ONLY ON TEST FILES! YOU HAVE BEEN WARNED!"] = "<b>警告: 此功能仍在发展中. 仅限于测试使用! 请小心!";
$messages["Known bugs: - erases tab characters - doesn't work well with big files (> 50kB) - was not tested yet on files containing non-standard characters</b>"] = "已知错误: - 删除tab 字符 - 无法应用在大文件中 (> 50kB) - 还未测试那些含有非标准字符的文件。</b>";
$messages["This function allows you to upload a new version of the selected file, to view what are the changes and to accept or reject each change. Before anything is saved, you can edit the merged files."] = "此功能允许你上穿所选定的文件的新版本文件, 查看有哪些内容改动和接受或者拒绝改动. 在保存之前, 你可以编辑合并的文件.";
$messages["Old file:"] = "旧文件:";
$messages["New file:"] = "新文件:";
$messages["Restrictions:"] = "限制:";
$messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s kB</b> and by PHP to <b>%2\$s</b>"] = "文件最大容量被 net2ftp 系统限制为 <b>%1\$s kB</b> ，被PHP限制为 <b>%2\$s</b>";
$messages["The maximum execution time is <b>%1\$s seconds</b>"] = "最长的执行时间为 <b>%1\$s 秒</b>";
$messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "根据文件的扩展名，FTP传送模式 (ASCII or BINARY) 将被自动选用";
$messages["If the destination file already exists, it will be overwritten"] = "如果目标文件已经存在，它将被覆盖";
$messages["You did not provide any files or archives to upload."] = "你没有提交任何要上传的文件或者压缩文档.";
$messages["Unable to delete the new file"] = "无法删除新文件";
}

// printComparisonSelect()
if ($state2 == "updatefile") {
$messages["Please wait..."] = "请稍候...";
$messages["Select lines below, accept or reject changes and submit the form."] = "请选择下面的内容，接受或者拒绝改动，然后提交表单.";
}

} // end manage


// -------------------------------------------------------------------------
// registerglobals.inc.php
// -------------------------------------------------------------------------
$messages["Please enter your username and password for FTP server "] = "请输入用户名和密码 ";
$messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "弹出窗口里的登陆信息未填全.<br />点击下面的 \"登陆\" .";
$messages["Access to the net2ftp Admin panel is disabled, because no password has been set in the file settings.inc.php. Enter a password in that file, and reload this page."] = "使用net2ftp 系统管理台被禁用, 因为在settings.inc.php文件中没有设置管理员密码. 请在该文件中输入密码, 然后重新刷新此页面.";
$messages["Please enter your Admin username and password"] = "请输入系统管理员用户名和密码"; 
$messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "弹出窗口里的登陆信息未填全.<br />点击下面的 \"登陆\" .";
$messages["Wrong username or password for the net2ftp Admin panel. The username and password can be set in the file settings.inc.php."] = "错误的系统管理员用户名和密码. 用户名和密码设置在settings.inc.php里.";


// -------------------------------------------------------------------------
// skins.inc.php
// -------------------------------------------------------------------------
$messages["Blue"] = "蓝色";
$messages["Grey"] = "灰色";
$messages["Black"] = "黑色";
$messages["Yellow"] = "黄色";
$messages["Pastel"] = "浅色";

// getMime()
$messages["Directory"] = "目录";
$messages["Symlink"] = "Symlink";
$messages["ASP script"] = "ASP script";
$messages["Cascading Style Sheet"] = "Cascading Style Sheet";
$messages["HTML file"] = "HTML file";
$messages["Java source file"] = "Java source file";
$messages["JavaScript file"] = "JavaScript file";
$messages["PHP Source"] = "PHP Source";
$messages["PHP script"] = "PHP script";
$messages["Text file"] = "Text file";
$messages["Bitmap file"] = "Bitmap file";
$messages["GIF file"] = "GIF file";
$messages["JPEG file"] = "JPEG file";
$messages["PNG file"] = "PNG file";
$messages["TIF file"] = "TIF file";
$messages["GIMP file"] = "GIMP file";
$messages["Executable"] = "Executable";
$messages["Shell script"] = "Shell script";
$messages["MS Office - Word document"] = "MS Office - Word document";
$messages["MS Office - Excel spreadsheet"] = "MS Office - Excel spreadsheet";
$messages["MS Office - PowerPoint presentation"] = "MS Office - PowerPoint presentation";
$messages["MS Office - Access database"] = "MS Office - Access database";
$messages["MS Office - Visio drawing"] = "MS Office - Visio drawing";
$messages["MS Office - Project file"] = "MS Office - Project file";
$messages["OpenOffice - Writer 6.0 document"] = "OpenOffice - Writer 6.0 document";
$messages["OpenOffice - Writer 6.0 template"] = "OpenOffice - Writer 6.0 template";
$messages["OpenOffice - Calc 6.0 spreadsheet"] = "OpenOffice - Calc 6.0 spreadsheet";
$messages["OpenOffice - Calc 6.0 template"] = "OpenOffice - Calc 6.0 template";
$messages["OpenOffice - Draw 6.0 document"] = "OpenOffice - Draw 6.0 document";
$messages["OpenOffice - Draw 6.0 template"] = "OpenOffice - Draw 6.0 template";
$messages["OpenOffice - Impress 6.0 presentation"] = "OpenOffice - Impress 6.0 presentation";
$messages["OpenOffice - Impress 6.0 template"] = "OpenOffice - Impress 6.0 template";
$messages["OpenOffice - Writer 6.0 global document"] = "OpenOffice - Writer 6.0 global document";
$messages["OpenOffice - Math 6.0 document"] = "OpenOffice - Math 6.0 document";
$messages["StarOffice - StarWriter 5.x document"] = "StarOffice - StarWriter 5.x document";
$messages["StarOffice - StarWriter 5.x global document"] = "StarOffice - StarWriter 5.x global document";
$messages["StarOffice - StarCalc 5.x spreadsheet"] = "StarOffice - StarCalc 5.x spreadsheet";
$messages["StarOffice - StarDraw 5.x document"] = "StarOffice - StarDraw 5.x document";
$messages["StarOffice - StarImpress 5.x presentation"] = "StarOffice - StarImpress 5.x presentation";
$messages["StarOffice - StarImpress Packed 5.x file"] = "StarOffice - StarImpress Packed 5.x file";
$messages["StarOffice - StarMath 5.x document"] = "StarOffice - StarMath 5.x document";
$messages["StarOffice - StarChart 5.x document"] = "StarOffice - StarChart 5.x document";
$messages["StarOffice - StarMail 5.x mail file"] = "StarOffice - StarMail 5.x mail file";
$messages["Adobe Acrobat document"] = "Adobe Acrobat document";
$messages["ARC archive"] = "ARC archive";
$messages["ARJ archive"] = "ARJ archive";
$messages["RPM"] = "RPM";
$messages["GZ archive"] = "GZ archive";
$messages["TAR archive"] = "TAR archive";
$messages["Zip archive"] = "Zip archive";
$messages["MOV movie file"] = "MOV movie file";
$messages["MPEG movie file"] = "MPEG movie file";
$messages["Real movie file"] = "Real movie file";
$messages["Quicktime movie file"] = "Quicktime movie file";
$messages["Shockwave flash file"] = "Shockwave flash file";
$messages["Shockwave file"] = "Shockwave file";
$messages["WAV sound file"] = "WAV sound file";
$messages["Font file"] = "Font file";
$messages["%1\$s File"] = "%1\$s File";
$messages["File"] = "文件";

// getAction()
$messages["Back"] = "退回";
$messages["Submit"] = "提交";
$messages["Refresh"] = "刷新";
$messages["Details"] = "详细资料";
$messages["Icons"] = "图标";
$messages["List"] = "浏览";
$messages["Logout"] = "登出";
$messages["Help"] = "帮助";
$messages["Bookmark"] = "书签";
$messages["Save"] = "保存";
$messages["Default"] = "缺省";


// -------------------------------------------------------------------------
// view.inc.php
// -------------------------------------------------------------------------
$messages["Image"] = "图像";
$messages["View Macromedia ShockWave Flash movie %1\$s"] = "查看Macromedia ShockWave Flash 影片 %1\$s";
$messages["View file %1\$s"] = "查看文件 %1\$s";
$messages["To save the image, right-click on it and choose 'Save picture as...'"] = "保存图像, 右键点击它, 选择 '保存图像为...'";



// ----------------------------------------------------------------------------------
// DO NOT CHANGE ANYTHING BELOW THIS LINE
// ----------------------------------------------------------------------------------

return $messages;

} // end function getMessages

?>