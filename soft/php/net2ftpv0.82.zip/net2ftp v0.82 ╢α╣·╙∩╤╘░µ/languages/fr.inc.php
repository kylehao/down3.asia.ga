<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------

//   -------------------------------------------------------------------------------
//  | Language: French                                                              |
//   -------------------------------------------------------------------------------
//  | Sebastien KEFO thieury <email> 2004-05-24                                     |
//  | Mathieu MG             <email> 2004-11-15                                     |
//   -------------------------------------------------------------------------------
//  |                                                                               |
//  |                              INSTRUCTIONS                                     |
//  |                                                                               |
//  |  The messages to translate are listed below.                                  |
//  |  The structure of each line is like this:                                     |
//  |     $message["Hello world!"] = "Hello world!";                                |
//  |                                                                               |
//  |  Keep the text between square brackets [] as it is.                           |
//  |  Translate the 2nd part, keeping the same punctuation and HTML tags.          |
//  |                                                                               |
//  |  The English message, for example                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is written in PHP!";    |
//  |  should become after translation:                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp est �crit en PHP!";     |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is geschreven in PHP!"; |
//  |                                                                               |
//  |  Note that the variable starts with a dollar sign $, that the value is        |
//  |  enclosed in double quotes " and that the line ends with a semi-colon ;       |
//  |  Be careful when editing this file, do not erase those special characters.    |
//  |                                                                               |
//  |  Some messages also contain one or more variables which start with a percent  |
//  |  sign, for example %1\$s or %2\$s. The English message, for example           |
//  |     $messages[...] = ["The file %1\$s was copied to %2\$s "]                  |
//  |  should becomes after translation:                                            |
//  |     $messages[...] = ["Le fichier %1\$s a ete copie vers %2\$s "]             |
//  |                                                                               |
//  |  When a real percent sign % is needed in the text it is entered as %%         |
//  |  otherwise it is interpreted as a variable. So no, it's not a mistake.        |
//  |                                                                               |
//  |  Between the messages to translate there is additional PHP code, for example: |
//  |     if ($state2 == "rename") {                               // <-- PHP code  |
//  |     $messages["Rename directories"] = "Rename directories";  // <-- message   |
//  |     }                                                        // <-- PHP code  |
//  |  This code is needed to load the messages only when they are actually needed. |
//  |  There is no need to change or delete any of that PHP code; translate only    |
//  |  the message.                                                                 |
//  |                                                                               |
//  |  Thanks in advance to all the translators!                                    |
//  |  David.                                                                       |
//  |                                                                               |
//   -------------------------------------------------------------------------------

function getMessages() {
global $state, $state2;


// -------------------------------------------------------------------------
// Used encoding
// -------------------------------------------------------------------------
$messages["iso-8859-1"] = "iso-8859-1";


// -------------------------------------------------------------------------
// Status messages
// -------------------------------------------------------------------------
// When translating these messages, keep in mind that the text should not be too long
// It should fit in the status textbox
$messages["Connecting to the FTP server"] = "Connection au serveur FTP";

$messages["Getting the list of directories and files"] = "Obtention de la liste des r�pertoires et fichiers";
$messages["Printing the list of directories and files"] = "Affichage de la liste des r�pertoires et fichiers";
$messages["Processing the entries"] = "Traitements des �l�ments";
$messages["Checking files"] = "Contr�le des fichiers";
$messages["Transferring files to the FTP server"] = "Transfert des fichiers sur le serveur FTP";
$messages["Decompressing archives and transferring files"] = "D�compression des archives et transfert des fichiers";
$messages["Searching the files..."] = "Recherche des fichiers...";
$messages["Uploading new file"] = "Upload du nouveau fichier";
$messages["Reading the new file"] = "Lecture du nouveau fichier";
$messages["Reading the old file"] = "Lecture de l'ancien fichier";
$messages["Comparing the 2 files"] = "Comparaison des 2 fichiers";
$messages["Printing the comparison"] = "Affichage de la comparaison";
$messages["Script finished in %1\$s seconds"] = "Script ex�cut� en %1\$s secondes";
$messages["Script halted"] = "Script arr�t�";


// -------------------------------------------------------------------------
// index.php ok 
// -------------------------------------------------------------------------
$messages["Unexpected state string. Exiting."] = "Chaine de caract�res inattendue. Quitter.";
$messages["This beta function is not activated on this server."] = "Cette fonction est en phase de test; elle n'est pas encore activ�e sur ce serveur.";
$messages["This function has been disabled by the Administrator of this website."] = "Cette fonction a �t� desactiv�e par l'Administrateur de ce site web.";


// -------------------------------------------------------------------------
// admin.inc.php
if ($state == "admin") {
// -------------------------------------------------------------------------
$messages["Admin functions"] = "Fonctions administratives";

$messages["Version information"] = "Informations sur la version";
$messages["This version of net2ftp is up-to-date"] = "Cette version de net2ftp est � jour";
$messages["The latest version could not be retrieved from the net2ftp.com server. Check the security settings of your browser, which may prevent the loading of a small file from the net2ftp.com server."] = "La derni�re version n'a pas pu �tre t�l�charg�e � partir du site net2ftp.com. V�rifiez les param�tres de securit� de votre navigateur web, ils pourraient emp�cher le chargement d'un petit fichier � partir du serveur net2ftp.com.";

$messages["Logging"] = "Archivage";
$messages["Date from:"] = "A partir de la date:";
$messages["to:"] = "jusqu'�:";
$messages["Empty logs"] = "Archives vides";
$messages["View logs"] = "Visualiser les archives";
$messages["No data"] = "Aucune donn�es";

$messages["Setup MySQL tables"] = "Cr�er les tables MySQL";
$messages["Go"] = "Go";
$messages["Create the 3 MySQL database tables needed for logging"] = "Creer les 3 tables MySQL n�cessaires pour l'archivage";
$messages["Create tables"] = "Cr�er les tables";
$messages["The handle of file %1\$s could not be opened"] = "Le pointeur du fichier %1\$s n'a pu �tre ouvert";
$messages["The file %1\$s could not be opened"] = "Le fichier %1\$s n'a pu �tre ouvert";
$messages["The handle of file %1\$s could not be closed"] = "Le pointeur du fichier %1\$s n'a pu �tre ouvert";
$messages["MySQL username"] = "Utilisateur MySQL";
$messages["MySQL password"] = "Mot de passe MySQL";
$messages["MySQL database"] = "Nom de la base de donn�es MySQL";
$messages["MySQL server"] = "Serveur MySQL";
$messages["This SQL query is going to be executed:"] = "Cette requ�te SQL va �tre ex�cut�e:";
$messages["Settings used:"] = "Param�tres utilis�s:";
$messages["MySQL password length"] = "Longueur du mot de passe MySQL";
$messages["Results:"] = "R�sultats:";
$messages["The connection to the server <b>%1\$s</b> could not be set up"] = "La connection au serveur <b>%1\$s</b> n'a pu �tre �tablie";
$messages["Unable to select the database <b>%1\$s</b>"] = "Impossible de s�lectionner la base de donn�es <b>%1\$s</b>";
$messages["The SQL query could not be executed"] = "La requ�te SQL n'a pu �tre ex�cut�e";
$messages["The tables were created successfully"] = "Les tables ont �t� cr��es avec succ�s";

$messages["Beta functions"] = "Fonctions Beta";
$messages["View logs"] = "Afficher les archives";
$messages["Empty logs"] = "Vider les archives";
$messages["The table <b>%1\$s</b> was emptied successfully."] = "La table <b>%1\$s</b> a �t� vid�e avec succ�s.";
$messages["The table <b>%1\$s</b> could not be emptied."] = "La table <b>%1\$s</b> n'a pu �tre vid�e.";

} // end admin

// -------------------------------------------------------------------------
// advanced.inc.php
if ($state == "advanced") {
// -------------------------------------------------------------------------

// advanced()
$messages["The site command functions are not available on this webserver."] = "Les fonctions de commande ne sont pas disponibles sur ce serveur.";
$messages["The Apache functions are not available on this webserver."] = "Les fonctions d'Apache ne sont pas disponibles sur ce serveur.";
$messages["The MySQL functions are not available on this webserver."] = "Les fonctions de MySQL ne sont pas disponibles sur ce serveur.";
$messages["Unexpected state2 string. Exiting."] = "Chaine de caracteres inattendue. Quitter.";

// printAdvancedFunctions()
$messages["Advanced functions"] = "Options avanc�es";
$messages["Go"] = "Go";
$messages["Troubleshooting functions"] = "Fonctions de d�pannage";
$messages["Troubleshoot net2ftp on this webserver"] = "D�panner net2ftp sur ce serveur";
$messages["Troubleshoot an FTP server"] = "D�panner un serveur FTP";
$messages["Translation functions"] = "Fonctions de traduction";
$messages["Introduction to the translation functions"] = "Introduction aux fonctions de traduction";
$messages["Extract messages to translate from code files"] = "Extraire les messages pour traduire � partir des fichiers de code";
$messages["Check if there are new or obsolete messages"] = "V�rifier s'il y a de nouveaux ou d�suets messages";
$messages["Beta functions"] = "Fonctions Beta";
$messages["Send a site command to the FTP server"] = "Envoyer une commande site au serveur FTP";
$messages["Apache: password-protect a directory, create custom error pages"] = "Apache: prot�ger un r�pertoire par mot de passe, cr�er des pages d'erreur personnalis�es";
$messages["MySQL: execute an SQL query"] = "MySQL: ex�cuter une requ�te SQL";

// troubleshoot_webserver()
$messages["Troubleshoot your net2ftp installation"] = "D�panner votre installation net2ftp";
$messages["Checking if the FTP module of PHP is installed: "] = "V�rifier si le module PHP est pr�sent sur ce FTP: ";
$messages["yes"] = "oui";
$messages["no - please install it!"] = "non - installez-le svp!";
$messages["Checking the permissions of the directory on the web server: a small file will be written to the /temp folder and then deleted."] = "Contr�le des permissions du r�pertoire sur le serveur : un petit fichiers va �tre cr�� dans le r�pertoire /temp puis effac�.";
$messages["Creating filename: "] = "Nom du fichier: ";
$messages["OK. Filename: %1\$s"] = "Ok. Nom du fichier: %1\$s";
$messages["not OK"] = "Incorrect";
$messages["OK"] = "Correct";
$messages["not OK. Check the permissions of the %1\$s directory"] = "Incorrect. V�rifiez les permissions du r�pertoire %1\$s ";
$messages["Opening the file in write mode: "] = "Ouvrir le fichier en mode �criture: ";
$messages["Writing some text to the file: "] = "�crire du texte dans le fichier: ";
$messages["Closing the file: "] = "Fermeture du fichier: ";
$messages["Deleting the file: "] = "Suppression du fichier: ";

// troubleshoot_ftpserver()
$messages["Troubleshoot an FTP server"] = "D�panner un serveur FTP";
$messages["FTP server port"] = "Port du serveur FTP";
$messages["Connection settings:"] = "Param�tres de connection:";
$messages["Password length"] = "Longueur du mot de passe";
$messages["Language"] = "Langue";
$messages["Skin number"] = "Num�ro de l'habillement";
$messages["Connecting to the FTP server: "] = "Connection au serveur FTP: ";
$messages["Logging into the FTP server: "] = "Identification sur le serveur FTP: ";
$messages["Setting the passive mode: "] = "R�glage du mode passif: ";
$messages["Getting the FTP server system type: "] = "Obtention du type de syst�me du serveur FTP: ";
$messages["Changing to the directory %1\$s: "] = "Changement pour le r�pertoire %1\$s: ";
$messages["The directory from the FTP server is: %1\$s "] = "Le r�pertoire du serveur FTP est: %1\$s ";
$messages["Getting the raw list of directories and files: "] = "Obtention de la liste des r�pertoires et fichiers: ";
$messages["Trying a second time to get the raw list of directories and files: "] = "Seconde tentative d'obtention de la liste des r�pertoires et fichiers: ";
$messages["Closing the connection: "] = "Fermeture la connection: ";
$messages["Raw list of directories and files:"] = "Liste des r�pertoires et fichiers:";
$messages["Parsed list of directories and files:"] = "Liste des r�pertoires et fichiers analys�s:";

// printTranslationFunctions()
$messages["net2ftp translation functions"] = "Fonctions de traduction de net2ftp";
$messages["A PHP application can be translated using the standard <a href=\"http://www.php.net/gettext\">gettext</a> functions, or using a self-made translation function."] = "Une application PHP peut �tre traduite en utilisant la fonction standard <a href=\"http://www.php.net/gettext\">gettext</a> , ou en la traduisant soi-meme.";
$messages["In both cases, the steps to take are similar."] = "Dans les deux cas, les d�marches � suivre sont similaires.";
$messages["Step 1: change code"] = "1ere etape : changer le code";
$messages["All messages must be translated using a translation function, for example translate()."] = "Tous les messages doivent �tre traduits en utilisant une fonction de traduction, par exemple traduire().";
$messages["This Hello World code:"] = "Ce message de bienvenue:";
$messages["must be changed to this:"] = "doit �tre chang� en:";
$messages["Step 2: extract messages"] = "2e etape: extraire les messages";
$messages["All messages which are used by the translate() function must be extracted from the code files, and copied to a <b>main message file</b>."] = "Tous les messages qui sont utilis�s par la fonction traduire() doivent �tre extraits des fichiers de code et copi�s dans le <b>fichier des messages principaux</b>.";
$messages["Step 3: translate messages"] = "3e etape : traduction des messages";
$messages["The main message file is given to translators, who rename the file and replace the messages in English by the translation."] = "Le fichier principal des messages est donn� aux traducteurs qui le renomment et remplacent les messages en Anglais par la traduction.";
$messages["The translators return the <b>translated message files</b>."] = "Les traducteurs vous renvoient <b>le fichier des message traduits</b>.";
$messages["Each time the application is modified, a new main message file must be generated, as in step 2."] = "Chaque fois que l'application est modifi�e, un nouveau fichier des messages principaux  doit �tre g�n�r�, comme � la 2e �tape.";
$messages["In order to avoid translating everything all over again, it must then be compared to all translated message files, to check if there are new or obsolete messages."] = "Pour �viter de tout traduire � nouveau, il doit �tre compar� � tous les fichiers de messages traduits pour v�rifier si il y a des nouveaux messages, ou des d�suets.";
$messages["net2ftp can help in step 2 to extract messages to translate from code files"] = "net2ftp peut aider � la 2e �tape en extrayant les messages � traduire des fichiers de code";
$messages["net2ftp can help in step 4 to check if there are new or obsolete messages"] = "net2ftp peut aider � la 4e �tape en v�rifiant s'il y a des nouveaux messages, ou des d�suets";

// translate_extract()
$messages["Extract messages from code files"] = "Extraire les messages des fichiers de code";
$messages["Directory containing code files:"] = "R�pertoires contenant des fichiers de code:";
$messages["Translation function used in the code:"] = "Fonction de traduction utilis�e dans le code:";
$messages["File to generate:"] = "Fichier � g�n�rer:";
$messages["Extracted messages:"] = "Messages extraits:";
$messages["No messages were found, so no file was put on the FTP server."] = "Aucun message n'a �t� trouv�, donc aucun fichier n'a �t� mis sur le serveur FTP.";
$messages["The main language file <b>%1\$s</b> was transferred to directory <b>%2\$s</b>."] = "Le fichier des messages principaux a <b>%1\$s</b> a �t� transf�r� dans le r�pertoire <b>%2\$s</b>.";

// translate_check()
$messages["Main language file:"] = "Fichier principal des langues:";
$messages["Directory containing translated language files:"] = "R�pertoire contenant les fichiers de langue traduits:";
$messages["File %1\$s was skipped because it could not be read, or because it was empty."] = "Le fichier %1\$s a �t� saut� parce qu'il ne pouvait pas �tre lu ou qu'il �tait vide.";
$messages["File nr %1\$s <b>%2\$s</b>"] = "Fichier num�ro %1\$s <b>%2\$s</b>";
$messages["New messages:"] = "Nouveaux messages:";
$messages["Obsolete messages:"] = "Messages d�suets:";
$messages["All the files have been processed"] = "Tous les fichiers ont �t� trait�s";

// sendsitecommand()
$messages["Send site command"] = "Envoyer une commande de site";
$messages["Enter the site command"] = "Entrer une commande de site";
$messages["The commands you can use depends on your FTP server. These commands are not standard and vary a lot from one server to the other."] = "Les commandes que vous pouvez utiliser d�pendent de votre serveur FTP. Ces commandes ne sont pas un standard et varient beaucoup de serveurs en serveurs.";
$messages["Note that net2ftp cannot display the output of the FTP server, it can only tell if the command returned TRUE or FALSE. This is not a limitation of net2ftp but of PHP, the language in which net2ftp is written."] = "Prenez note que net2ftp ne peut pas afficher la r�ponse du serveur FTP, il peut seulement afficher si la commande a renvoy� TRUE ou FALSE. Ceci n'est pas une limite de net2ftp mais de PHP, le langage de programmation avec lequel net2ftp est �crit.";
$messages["The command <b>%1\$s</b> was executed successfully."] = "La commande <b>%1\$s</b> a �t� ex�cut�e avec succ�s.";

// apache(), mysqlfunctions()
// Not yet translated

} // end advanced



// -------------------------------------------------------------------------
// authorizations.inc.php
// -------------------------------------------------------------------------

// checkAuthorization()
$messages["The FTP server <b>%1\$s</b> is not in the list of allowed FTP servers."] = "Le serveur FTP <b>%1\$s</b> ne fait pas parti des serveur FTP autoris�s.";
$messages["The FTP server <b>%1\$s</b> is in the list of banned FTP servers."] = "Le serveur FTP <b>%1\$s</b> fait parti des serveurs FTP bannis.";
$messages["Your IP address (%1\$s) is in the list of banned IP addresses."] = "Votre adresse IP (%1\$s) a �t� bannie de ce serveur FTP.";
$messages["The FTP server port %1\$s may not be used."] = "Le port %1\$s du seveur FTP ne peut pas �tre utilis�.";
$messages["You don't have the authorizations to view directory <b>%1\$s</b>."] = "Vous n'avez pas les permissions requises pour voir le r�pertoire <b>%1\$s</b>.";

// logAccess(), logLogin(), logError()
// Not yet translated


// -------------------------------------------------------------------------
// bookmark.inc.php
if ($state == "bookmark") {
// -------------------------------------------------------------------------
$messages["Add this link to your bookmarks:"] = "Ajouter ce lien dans mes favoris:";
$messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer: clic droit sur le lien et choisir \"Ajouter aux favoris...\"";
$messages["Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla, Firefox: clic droit sur le lien et choisir \"Bookmark This Link...\"";
$messages["Note: when you will use this bookmark, a popup window will ask you for your username and password."] = "Note: quand vous cliquerez ce lien, une fen�tre pop-up vous demandera votre nom d'utilisateur et votre mot de passe.";

} // end bookmark


// -------------------------------------------------------------------------
// browse.inc.php
if ($state == "browse") {
// -------------------------------------------------------------------------

// browse()
$messages["Directories with names containing \' cannot be displayed correctly. They can only be deleted. Please go back and select another subdirectory."] = "Les r�pertoires dont le nom contient \' ne peuvent pas �tre affich�s correctement. Ils ne peuvent qu'�tre effac�s , revenez en arriere et choisissez un autre sous-r�pertoire.";

$messages["Consumption message"]  = "";
$messages["Consumption message"] .= "<b>Limite journali�re atteinte: vous ne pourrez plus transf�rer des donn�es</b><br /><br />\n";
$messages["Consumption message"] .= "Afin de garantir un usage �quitable du serveur web pour tout le monde, le volume de transfert de donn�es ainsi que le temps d'�x�cution du script sont limit�s par utilisateur, et par jour. Une fois cette limite atteinte, vous pouvez toujours naviguer le serveur FTP mais plus transf�rer de donn�es.<br /><br />\n";
$messages["Consumption message"] .= "Si vous avez besoin d'un acc�s illimit�, veuillez installer net2ftp sur votre propre serveur web.<br />\n";

// ftp_getlist()
$messages["The directory <b>%1\$s</b> does not exist or could not be selected, so the root directory <b>/</b> is shown instead."] = "Le r�pertoire <b>%1\$s</b> n'existe pas ou n'a pu �tre s�lectionn�, donc le r�partoire principal <b>/</b> est affich� � la place.";

// printdirfilelist()
// Keep this short, it must fit in a small button!
$messages["New dir"] = "Nouveau r�pertoire";
$messages["New file"] = "Nouveau fichier";
$messages["HTML templates"] = "Templates HTML";
$messages["Upload"] = "Upload";
$messages["Java Upload"] = "Upload Java";
$messages["Advanced"] = "Avanc�";
$messages["Copy"] = "Copier";
$messages["Move"] = "D�placer";
$messages["Delete"] = "Effacer";
$messages["Rename"] = "Renommer";
$messages["Chmod"] = "Chmod";
$messages["Download"] = "T�l�charger";
$messages["Zip"] = "Zip";
$messages["Size"] = "Taille";
$messages["Search"] = "Rechercher";
$messages["Go to the parent directory"] = "Aller dans le r�pertoire superieur";
$messages["Transform selected entries: "] = "Transformer l'entr�e selectionn�e: ";
$messages["Make a new subdirectory in directory %1\$s"] = "Cr�er un nouveau sous-r�pertoire dans le r�pertoire %1\$s";
$messages["Create a new file in directory %1\$s"] = "Cr�er un nouveau fichier dans le r�pertoire %1\$s";
$messages["Upload new files in directory %1\$s"] = "Upload d'un nouveau fichier dans le r�pertoire %1\$s";
$messages["Go to the advanced functions"] = "Aller dans les fonctions avanc�es";
$messages["Copy the selected entries"] = "Copier les �l�ments selectionn�s";
$messages["Move the selected entries"] = "D�placer les �l�ments selectionn�s";
$messages["Delete the selected entries"] = "Effacer les �l�ments selectionn�s";
$messages["Rename the selected entries"] = "Renommer les �l�ments selectionn�s";
$messages["Chmod the selected entries (only works on Unix/Linux/BSD servers)"] = "R�gler le CHMOD des �l�ments selectionn�s (fonctionne uniquement sur les serveurs Unix/Linux/BSD)";
$messages["Download a zip file containing all selected entries"] = "T�l�charger un fichier .ZIP contenant tous les �l�ments selectionne";
$messages["Zip the selected entries to save or email them"] = "Cr�er un fichier .ZIP pour sauvegarder les �l�ments selectionn�s ou les envoyer par courriel";
$messages["Calculate the size of the selected entries"] = "Calculer la taille des �l�ments selectionn�s";
$messages["Find files which contain a particular word"] = "Trouver les fichiers qui contiennent un mot en particulier";
$messages["Click to sort by %1\$s in descending order"] = "Cliquer pour classer par %1\$s en ordre d�croissant";
$messages["Click to sort by %1\$s in ascending order"] = "Cliquer pour classer par %1\$s en ordre croissant";
$messages["Ascending order"] = "Ordre croissant";
$messages["Descending order"] = "Ordre d�croissant";
//$messages["Click to sort by %1\$s in ascending order"] = "Cliquer pour classer par %1\$s en ordre ascendant";
$messages["Up"] = "Remonter";
$messages["Click to check or uncheck all rows"] = "Cliquer pour cocher ou decocher tous les �l�ments";
$messages["All"] = "Tous";
$messages["Name"] = "Nom";
$messages["Type"] = "Type";
//$messages["Size"] = "Taille";
$messages["Owner"] = "Propri�taire";
$messages["Group"] = "Groupe";
$messages["Perms"] = "Permissions";
$messages["Mod Time"] = "Modifi� le";
$messages["Actions"] = "Actions";
$messages["Download the file %1\$s"] = "T�l�charger le fichier %1\$s";
$messages["View"] = "Voir";
$messages["Edit"] = "�diter";
$messages["Update"] = "Mise � jour";
$messages["Open"] = "Ouvrir";
$messages["View the highlighted source code of file %1\$s"] = "Voir le code source surlign� du fichier %1\$s";
$messages["Edit the source code of file %1\$s"] = "�diter le code source du fichier %1\$s";
$messages["Upload a new version of the file %1\$s and merge the changes"] = "Uploader une nouvelle version du fichier %1\$s et fusionner les changements";
$messages["View image %1\$s"] = "Voir l'image %1\$s";
$messages["View the file %1\$s from your HTTP web server"] = "Voir le fichier %1\$s � partir de votre serveur HTTP";
$messages["(Note: This link may not work if you don't have your own domain name.)"] = "(Note: Ce lien peut ne pas fonctionner si vous n'avez pas votre propre nom de domaine.)";
$messages["This folder is empty"] = "Ce r�pertoire est vide";

// printSeparatorRow()
$messages["Directories"] = "r�pertoires";
$messages["Files"] = "Fichiers";
$messages["Symlinks"] = "Symlinks";
$messages["Unrecognized FTP output"] = "Sortie FTP non-reconnue";
$messages["Number"] = "Number";
$messages["Size"] = "Size";
$messages["Skipped"] = "Skipped";

// printLocationActions()
$messages["Language:"] = "Langue:";
$messages["Skin:"] = "Habillement:";
$messages["View mode:"] = "Mode de visualisation:";
$messages["Directory Tree"] = "Chemin actuel";

// printURL()
$messages["Execute %1\$s in a new window"] = "Ex�cuter %1\$s dans une nouvelle fen�tre";

// printDirectorySelect()
$messages["Double-click to go to a subdirectory:"] = "Double-cliquer pour acc�der � un sous-r�pertoire:";
$messages["Choose"] = "Choisir";
$messages["Up"] = "Haut";

} // end browse


// -------------------------------------------------------------------------
// consumption.inc.php
// -------------------------------------------------------------------------
$messages["Unable to determine your IP address."] = "Impossible de d�terminer votre adresse IP.";
$messages["Table net2ftp_logConsumptionIpaddress contains duplicate rows."] = "La table net2ftp_logConsumptionIpaddress contient des doubles records.";
$messages["Table net2ftp_logConsumptionFtpserver contains duplicate rows."] = "La table net2ftp_logConsumptionFtpserver contient des doubles records.";
$messages["The variable <b>consumption_ipaddress_dataTransfer</b> is not numeric."] = "La variable <b>consumption_ipaddress_dataTransfer</b> n'est pas num�rique.";
$messages["Table net2ftp_logConsumptionIpaddress could not be updated."] = "La table net2ftp_logConsumptionIpaddress n'a pas pu �tre mise � jour.";
$messages["Table net2ftp_logConsumptionIpaddress contains duplicate entries."] = "La table net2ftp_logConsumptionIpaddress contient des doubles records.";
$messages["Table net2ftp_logConsumptionFtpserver could not be updated."] = "La table net2ftp_logConsumptionFtpserver n'a pas pu �tre mise � jour.";
$messages["Table net2ftp_logConsumptionFtpserver contains duplicate entries."] = "La table net2ftp_logConsumptionFtpserver contient des doubles records.";
$messages["Daily limit reached: the file <b>%1\$s</b> will not be transferred"] = "Limite journali�re atteinte: le fichier <b>%1\$s</b> ne sera pas transf�r�";


// -------------------------------------------------------------------------
// database.inc.php ok
// -------------------------------------------------------------------------
$messages["Unable to connect to the DB"] = "Impossible de se connecter � la base de donn�es";
$messages["Unable to select the DB"] = "Impossible de choisir la base de donn�es";


// -------------------------------------------------------------------------
// easywebsite.inc.php
if ($state == "easyWebsite") {
// -------------------------------------------------------------------------
$messages["Create a website in 4 easy steps"] = "Cr�ez un site web en 4 pas";
$messages["Template overview"] = "Apper�u";
$messages["Template details"] = "D�tails";
$messages["Files are copied"] = "Fichiers sont copi�s";
$messages["Edit your pages"] = "Editez vos pages";

// Screen 1 - printTemplateOverview
$messages["Click on the image to view the details of a template."] = "Click on the image to view the details of a template.";
$messages["Back to the Browse screen"] = "Back to the Browse screen";
$messages["Template"] = "Template";
$messages["Copyright"] = "Copyright";
$messages["Click on the image to view the details of this template"] = "Click on the image to view the details of this template";

// Screen 2 - printTemplateDetails
$messages["The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?"] = "The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?";
$messages["Preview"] = "Preview";
$messages["Install"] = "Install";
$messages["Size"] = "Size";
$messages["Preview page"] = "Preview page";
$messages["opens in a new window"] = "opens in a new window";

// Screen 3
$messages["Please wait while the template files are being transferred to your server: "] = "Please wait while the template files are being transferred to your server: ";
$messages["Done."] = "Done.";
$messages["Continue"] = "Continue";

// Screen 4 - printEasyAdminPanel
$messages["Edit page"] = "Edit page";
$messages["Browse the FTP server"] = "Browse the FTP server";
$messages["Add this link to your favorites to return to this page later on!"] = "Add this link to your favorites to return to this page later on!";
$messages["Edit website at %1\$s"] = "Edit website at %1\$s";
$messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer: right-click on the link and choose \"Add to Favorites...\"";
$messages["Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\"";

// ftp_copy_local2ftp
$messages["WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing..."] = "WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing...";
$messages["Created target subdirectory <b>%1\$s</b>"] = "Created target subdirectory <b>%1\$s</b>";
$messages["WARNING: Unable to copy the file <b>%1\$s</b>. Continuing..."] = "WARNING: Unable to copy the file <b>%1\$s</b>. Continuing...";
$messages["Copied file <b>%1\$s</b>"] = "Copied file <b>%1\$s</b>";
}


// -------------------------------------------------------------------------
// edit.inc.php ok
if ($state == "manage" && ($state2 == "edit" || $state2 == "newfile")) {
// -------------------------------------------------------------------------

// edit()
$messages["Unable to open the template file"] = "Impossible d'ouvrir le fichier de description";
$messages["Unable to read the template file"] = "Impossible de lire le fichier de description";
$messages["Please specify a filename"] = "Veuillez sp�cifier un nom de fichier";

// printEditForm()
$messages["Directory: "] = "R�pertoire: ";
$messages["File: "] = "Fichier: ";
$messages["New file name: "] = "Nom du nouveau fichier: ";
$messages["Note: changing the textarea type will save the changes"] = "Note: changer le type de la zone de texte sauvegardera les changements";
$messages["Status: This file has not yet been saved"] = "Statut: Ce fichier n'a pas encore �t� sauvegard�";
$messages["Status: Saved on <b>%1\$s</b> using mode %2\$s"] = "Statut: Sauvegard� dans <b>%1\$s</b> en utilisant le mode %2\$s";
$messages["Status: <b>This file could not be saved</b>"] = "Statut: <b>Ce fichier n'a pas pu �tre sauvegard�</b>";

} // end if edit newfile


// -------------------------------------------------------------------------
// errorhandling.inc.php ok
// -------------------------------------------------------------------------
$messages["An error has occured"] = "Une erreur s'est produite";
$messages["Go back"] = "Revenir en arri�re";
$messages["Go to the login page"] = "Aller � la page de connection";


// -------------------------------------------------------------------------
// filesystem.inc.php
// -------------------------------------------------------------------------

// ftp_openconnection()
$messages["The <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this FTP module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">php.net</a><br />"] = "Le <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">module FTP de PHP</a> n'est pas install� sur ce serveur.<br /><br /> L'administrateur de ce site devrait l'installer. Vous trouverez les instructions d'installation sur <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">php.net</a><br />";
$messages["Unable to connect to FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "Impossible de se connecter au serveur FTP <b>%1\$s</b> sur le port <b>%2\$s</b>.<br /><br />�tes-vous s�r que c'est la bonne adresse du serveur FTP? Cette adresse est souvent diff�rente de celle du serveur HTTP (web). Veuillez contacter votre fournisseur internet ou l'administrateur du syst�me pour obtenir de l'aide.<br />";
$messages["Unable to login to FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "Impossible de se connecter au serveur FTP <b>%1\$s</b> avec le nom d'utilisateure <b>%2\$s</b>.<br /><br />�tes-vous s�r que votre nom d'utilisateur et mot de passe sont corrects? Veuillez contacter votre fournisseur internet ou l'administrateur du syst�me pour obtenir de l'aide.<br />";
$messages["Unable to switch to the passive mode on FTP server <b>%1\$s</b>."] = "Impossible de se mettre en mode passif sur le serveur FTP <b>%1\$s</b>.";

// ftp_openconnection2()
$messages["Unable to connect to the second (target) FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the second (target) FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "Impossible de se connecter au deuxi�me serveur FTP <b>%1\$s</b> sur le port <b>%2\$s</b>.<br /><br />�tes-vous s�r que c'est la bonne adresse du serveur FTP? Cette adresse est souvent diff�rente de celle du serveur HTTP (web). Veuillez contacter votre fournisseur internet ou l'administrateur du syst�me pour obtenir de l'aide.<br />";
$messages["Unable to login to the second (target) FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "Impossible de se connecter au deuxi�me serveur FTP <b>%1\$s</b> sur le port <b>%2\$s</b>.<br /><br />�tes-vous s�r que c'est la bonne adresse du serveur FTP? Cette adresse est souvent diff�rente de celle du serveur HTTP (web). Veuillez contacter votre fournisseur internet ou l'administrateur du syst�me pour obtenir de l'aide.<br />";
$messages["Unable to switch to the passive mode on the second (target) FTP server <b>%1\$s</b>."] = "Impossible de se mettre en mode passif sur le deuxi�me serveur FTP <b>%1\$s</b>.";

// ftp_myrename()
$messages["Unable to rename directory or file <b>%1\$s</b> into <b>%2\$s</b>"] = "Impossible de renommer le r�pertoire/fichier <b>%1\$s</b> en <b>%2\$s</b>";

// ftp_mychmod()
$messages["Unable to execute site command <b>%1\$s</b>. Note that the CHMOD command is only available on Unix FTP servers, not on Windows FTP servers."] = "Impossible d'ex�cuter la commande <b>%1\$s</b>. Note: les commandes CHMOD sont uniquement possibles sur les serveurs FTP Unix, non sur les serveurs FTP Windows.";
$messages["Directory <b>%1\$s</b> successfully chmodded to <b>%2\$s</b>"] = "Le CHMOD du r�pertoire <b>%1\$s</b> a �t� chang� avec succ�s pour <b>%2\$s</b>";
$messages["File <b>%1\$s</b> was successfully chmodded to <b>%2\$s</b>"] = "Le CHMOD du fichier <b>%1\$s</b> a �t� chang� avec succ�s pour <b>%2\$s</b>";
$messages["All the selected directories and files have been processed."] = "Tous les r�pertoires et fichiers s�lectionn�s ont �t� trait�s avec succ�s.";

// ftp_rmdir2()
$messages["Unable to delete the directory <b>%1\$s</b>"] = "Impossible de supprimer le r�pertoire <b>%1\$s</b>";

// ftp_delete2()
$messages["Unable to delete the file <b>%1\$s</b>"] = "Impossible de supprimer le fichier <b>%1\$s</b>";

// ftp_newdirectory()
$messages["Unable to create the directory <b>%1\$s</b>"] = "Impossible de cr�er le r�pertoire <b>%1\$s</b>";

// ftp_readfile()
$messages["Unable to create the temporary file"] = "Impossible de cr�er le fichier temporaire";
$messages["Unable to get the file <b>%1\$s</b> from the FTP server and to save it as temporary file <b>%2\$s</b>.<br />Check the permissions of the %3\$s directory.<br />"] = "Impossible d'acc�der au fichier <b>%1\$s</b> sur le serveur FTP et de le sauvegarder comme le fichier temporaire <b>%2\$s</b>.<br />Verifiez les permissions du r�pertoire %3\$s .<br />";
$messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "Impossible d'ouvrir le fichier temporaire. Verifiez les permissions du r�pertoire %1\$s .";
$messages["Unable to read the temporary file"] = "Impossible de lire le fichier temporaire";
$messages["Unable to close the handle of the temporary file"] = "Impossible de fermer le pointeur du fichier temporaire.";
$messages["Unable to delete the temporary file"] = "Impossible de supprimer le fichier temporaire";

// ftp_writefile()
$messages["Unable to create the temporary file. Check the permissions of the %1\$s directory."] = "Impossible de cr�er le fichier temporaire. Verifiez les permissions du r�pertoire %1\$s .";
$messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "Impossible d'ouvrir le fichier temporaire. Verifiez les permissions du r�pertoire %1\$s .";
$messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "Impossible d'�crire la cha�ne de caract�res dans le fichier temporaire <b>%1\$s</b>.<br />Verifiez les permissions du r�pertoire %2\$s .";
$messages["Unable to close the handle of the temporary file"] = "Impossible de fermer le pointeur du fichier temporaire.";
$messages["Unable to put the file <b>%1\$s</b> on the FTP server.<br />You may not have write permissions on the directory."] = "Impossible de mettre le fichier <b>%1\$s</b> sur le serveur FTP.<br />Vous pourriez ne pas avoir la permission d'�crire dans ce r�pertoire.";
$messages["Unable to delete the temporary file"] = "Impossible de supprimer le fichier temporaire";

// ftp_copymovedelete()
$messages["Processing directory <b>%1\$s</b>"] = "Traitement du r�petoire <b>%1\$s</b>";
$messages["The target directory <b>%1\$s</b> is the same as or a subdirectory of the source directory <b>%2\$s</b>, so this directory will be skipped"] = "Le r�pertoire de destination <b>%1\$s</b> est identique ou est un sous-r�pertoire du r�pertoire source <b>%2\$s</b>, et donc ce r�pertoire va �tre omis";
$messages["Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing the copy/move process..."] = "Impossible de cr�er le sous-r�pertoire <b>%1\$s</b>. Il existe peut-�tre d�j�. Le processus de copie/d�placement continue...";
$messages["Created target subdirectory <b>%1\$s</b>"] = "Sous-r�pertoire de destination <b>%1\$s</b> cr��";
$messages["Unable to delete the subdirectory <b>%1\$s</b> - it may not be empty"] = "Impossible de supprimer le sous-r�pertoire <b>%1\$s</b> - il n'est peut-�tre pas vide";
$messages["Deleted subdirectory <b>%1\$s</b>"] = "Sous-r�pertoire <b>%1\$s</b> �ffac�";
$messages["Processing of directory <b>%1\$s</b> completed"] = "Traitement du r�pertoire <b>%1\$s</b> achev�";
$messages["The target for file <b>%1\$s</b> is the same as the source, so this file will be skipped"] = "La destination du fichier <b>%1\$s</b> est la m�me que la source, donc ce fichier sera omis";
$messages["Unable to copy the file <b>%1\$s</b>"] = "Impossible de copier le fichier <b>%1\$s</b>";
$messages["Copied file <b>%1\$s</b>"] = "Fichier <b>%1\$s</b> copi�";
$messages["Unable to move the file <b>%1\$s</b>"] = "Impossible de d�placer le fichier <b>%1\$s</b>";
$messages["Moved file <b>%1\$s</b>"] = "Fichier <b>%1\$s</b> d�plac�";
$messages["Unable to delete the file <b>%1\$s</b>"] = "Impossible d'effacer le fichier <b>%1\$s</b>";
$messages["Deleted file <b>%1\$s</b>"] = "Fichier <b>%1\$s</b> supprim�";
$messages["All the selected directories and files have been processed."] = "Tous les r�pertoires et fichiers s�lectionn�s ont �t� trait�s.";

// ftp_processfiles()

// ftp_getfile()
$messages["Unable to copy the remote file <b>%1\$s</b> to the local file using FTP mode <b>%2\$s</b>"] = "Impossible de copier le fichier distant <b>%1\$s</b> vers le fichier local en utilisant le mode FTP <b>%2\$s</b>";
$messages["Unable to delete file <b>%1\$s</b>"] = "Impossible de supprimer le fichier <b>%1\$s</b>";

// ftp_putfile()
$messages["Unable to copy the local file to the remote file <b>%1\$s</b> using FTP mode <b>%2\$s</b>"] = "Impossible de copier le fichier local vers le fichier distant <b>%1\$s</b> en utilisant le mode FTP<b>%2\$s</b>";
$messages["Unable to delete the local file"] = "Impossible de supprimer le fichier local";

// ftp_downloadfile()
$messages["Unable to delete the temporary file"] = "Impossible de supprimer le fichier temporaire";
$messages["Unable to send the file to the browser"] = "Impossible d'envoyer le fichier au fureteur";

// ftp_zip()
$messages["Unable to create the temporary file"] = "Impossible de cr�er le fichier temporaire";
$messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "Impossible d'�crire la cha�ne vers le fichier temporaire <b>%1\$s</b>.<br />V�rifiez les permissions du r�pertoire %2\$s.";
$messages["Unable to close the handle of the temporary file"] = "Impossible de fermer le pointeur du fichier temporaire";
$messages["The zip file has been saved on the FTP server as <b>%1\$s</b>"] = "Le fichier zip a �t� sauvegard� sur le serveur FTP en tant que <b>%1\$s</b>";
$messages["Requested files"] = "Fichiers r�quisitionn�s";

$messages["Zip email message"]  = "";
$messages["Zip email message"] .= "Cher, \n\n";
$messages["Zip email message"] .= "Quelqu'un a exig� que les fichiers joints soient envoy�s � ce cette adresse �lectronique (%1\$s).\n";
$messages["Zip email message"] .= "Si vous n'avez aucune id�e de ce que c'est ou vous ne faites pas confiance � cette personne, veuillez supprimer ce courriel sans ouvrir le fichier zip attach�.\n";
$messages["Zip email message"] .= "Notez que si nous n'ouvrez pas le fichier zip, les fichiers � l'int�rieur de celui-ci ne peuvent pas endommager votre ordinateur.\n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "Informatios � propos de l'exp�diteur:\n";
$messages["Zip email message"] .= "Adresse IP: %2\$s\n";
$messages["Zip email message"] .= "Heure de l'envoi: %3\$s\n";
$messages["Zip email message"] .= "Envoy� via le programme net2ftp install� sur ce serveur: %4\$s \n";
$messages["Zip email message"] .= "Webmaster's email: %5\$s \n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "Message de l'exp�diteur:\n";
$messages["Zip email message"] .= "%6\$s \n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "net2ftp est un logiciel gratuit, publi� sous la licence GNU/GPL. Pour plus d'informations allez � http://www.net2ftp.com\n\n\n";

$messages["The zip file has been sent to <b>%1\$s</b>."] = "Le fichier zip a bien �t� envoy� � <b>%1\$s</b>.";

// acceptFiles()
$messages["File <b>%1\$s</b> is too big. This file will not be uploaded."] = "Le fichier <b>%1\$s</b> est trop gros: il n'a donc pas �t� upload�";
$messages["Could not generate a temporary file."] = "Impossible de g�n�rer le fichier temporaire.";
$messages["File <b>%1\$s</b> could not be moved"] = "Le fichier <b>%1\$s</b> ne peut �tre d�plac�";
$messages["File <b>%1\$s</b> is OK"] = "Le fichier <b>%1\$s</b> est correct";
$messages["Unable to move the uploaded file to the temp directory.<br /><br />The administrator of this website has to <b>chmod 777</b> the /temp directory of net2ftp."] = "Impossible de d�placer le fichier upload� vers le r�pertoire /temp.<br /><br />L'administrateur de ce site doit mettre le <b>chmod</b> du r�pertoire /temp de net2ftp � <b>777</b>.";
$messages["You did not provide any file to upload."] = "Vous n'avez fourni aucun fichier � uploader.";

// ftp_transferfiles()
$messages["File <b>%1\$s</b> could not be transferred to the FTP server"] = "Le fichier <b>%1\$s</b> n'a pu �tre transf�r� vers le serveur FTP";
$messages["File <b>%1\$s</b> has been transferred to the FTP server using FTP mode <b>%2\$s</b>"] = "Le fichier <b>%1\$s</b> a �t� transf�r� vers le serveur FTP en utilisant le mode FTP <b>%2\$s</b>";
$messages["Transferring files to the FTP server"] = "Transfer des fichiers vers le serveur FTP en cours";

// ftp_unziptransferfiles()
$messages["Processing archive nr %1\$s: <b>%2\$s</b>"] = "Traitement de l'archive num�ro %1\$s: <b>%2\$s</b>";
$messages["Unable to open the archive <b>%1\$s</b> (file %2\$s)"] = "Impossible d'ouvrir l'archive <b>%1\$s</b> (fichier %2\$s)";
$messages["Could not create directory <b>%1\$s</b>"] = "Impossible de cr�er le r�pertoire <b>%1\$s</b>";
$messages["Created directory <b>%1\$s</b>"] = "Le r�pertoire <b>%1\$s</b> a �t� cr��";
$messages["File Contents:"] = "FContenu du fichier:";
$messages["Could not put the file <b>%1\$s</b> to the directory <b>%2\$s</b>"] = "Impossible de mettre le fichier <b>%1\$s</b> dans le r�pertoire <b>%2\$s</b>";
$messages["Transferred file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "Le fichier <b>%1\$s</b> a �t� transf�r� dans le r�pertoire <b>%2\$s</b>";
$messages["Unable to delete the archive <b>%1\$s</b> (file %2\$s)"] = "Impossible de supprimer l'archive <b>%1\$s</b> (fichier %2\$s)";
$messages["Unable to get the list of the contents of the Zip archive. Error code: %1\$s"] = "Impossible d'acqu�rir la liste du contenu de l'archive Zip. Code d'erreur: %1\$s";
$messages["Unable to get the list of the contents of the Tar archive."] = "Impossible d'acqu�rir la liste du contenu de l'archive Tar.";
$messages["Could not create directory <b>%1\$s</b>"] = "Impossible de cr�er le r�pertoire <b>%1\$s</b>";
$messages["Created directory <b>%1\$s</b>"] = "Le r�pertoire <b>%1\$s</b> a �t� cr��";
$messages["Unable to create the temporary file"] = "Impossible de cr�er le fichier temporaire";
$messages["Unable to extract file nr <b>%1\$s</b> from the archive."] = "Impossible d'extraite le fichier num�ro <b>%1\$s</b> de l'archive.";
$messages["Could not put file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "Impossible de mettre le fichier <b>%1\$s</b> dans le r�pertoire <b>%2\$s</b>";
$messages["Transferred file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "Le fichier <b>%1\$s</b> a �t� transf�r� dans le r�pertoire <b>%2\$s</b>";
$messages["Unable to delete the temporary file <b>%1\$s</b>."] = "Impossible de supprimer le fichier temporaire <b>%1\$s</b>.";
$messages["Archive <b>%1\$s</b> was not processed because its filename extension was not recognized. Only zip, tar, tgz and gz archives are supported at the moment."] = "L'archive <b>%1\$s</b> n'a pas �t� trait�e parce que son extension n'a pas �t� reconnue. Seulement les archives zip, tar, tgz et gz sont support�es pour le moment.";
$messages["Unzipping and transferring files"] = "Extraction et transfer des fichiers";

// ftp_mysite()
$messages["Unable to execute site command <b>%1\$s</b>"] = "Impossible d'ex�cuter la commande de site <b>%1\$s</b>";

// shutdown()
$messages["Shutdown message"]  = "";
$messages["Shutdown message"] .= "<b>Votre t�che a �t� interrompue</b><br /><br />";
$messages["Shutdown message"] .= "La t�che que vous avez tent� d'ex�cuter avec net2ftp a pris plus de temps que les %1\$s secondes permises, ce pourquoi cette t�che a �t� interrompue.<br />";
$messages["Shutdown message"] .= "Cette limite de temps garantie un usage ad�quat du serveur pour tout le monde.<br /><br />";
$messages["Shutdown message"] .= "Essayez de s�parer votre t�che en des t�ches plus petites: restreignez votre s�lection de fichiers et d�s�lectionnez les plus gros.<br /><br />";
$messages["If you really need net2ftp to be able to handle big tasks which take a long time, consider installing net2ftp on your own server."] = "Si vous avez vraiment besoin que netftp puisse g�rer des t�ches plus lourdes, veuillez consid�rez d'installer net2ftp sur votre propre serveur.";

// SendMail()
$messages["You did not provide any text to send by email!"] = "Vous n'avez sp�cifi� aucun texte � envoyer par courriel!";
$messages["You did not supply a From address."] = "Vous n'avez pas sp�cifi� un adresse d'exp�diteur.";
$messages["You did not supply a To address."] = "Vous n'avez pas sp�cifi� un adresse de destinataire.";
$messages["Due to technical problems the email to <b>%1\$s</b> could not be sent."] = "Du � des probl�mes techniques, le courriel allant � <b>%1\$s</b> n'a pu �tre envoy�.";

// printFunctionTags()
$messages["Output generated by function %1\$s"] = "R�sultat g�n�r� par la fonction %1\$s";



// -------------------------------------------------------------------------
// homepage.inc.php ok
if ($state == "homepage") {
// -------------------------------------------------------------------------
$messages["net2ftp features short"] ="Une fois entr�, vous serez en mesure de: \n";
$messages["net2ftp features short"] .="<ul>\n";
$messages["net2ftp features short"] .="<li> naviguer le serveur FTP</li>\n";
$messages["net2ftp features short"] .="<li> t�l�charger (download et upload) <span style=\"font-size: 80%%; color: red;\">nouveau: nombre illimit� d'uploads</span></li>\n";
$messages["net2ftp features short"] .="<li> copier, d�placer, effacer, renommer et regler les permissions</li>\n";
$messages["net2ftp features short"] .="<li> copier/d�placer vers un 2e serveur FTP</li>\n";
$messages["net2ftp features short"] .="<li> voir les codes source</li>\n";
$messages["net2ftp features short"] .="<li> voir les images <span style=\"font-size: 80%%; color: red;\">nouveau</span></li>\n";
$messages["net2ftp features short"] .="<li> �diter les fichiers textes</li>\n";
$messages["net2ftp features short"] .="<li> �diter le code HTML dans differents �diteurs HTML <span style=\"font-size: 80%%; color: red;\">nouveau</span></li>\n";
$messages["net2ftp features short"] .="<li> �diter le code avec la mise en page syntaxique <span style=\"font-size: 80%%; color: red;\">beta</span></li>\n";
$messages["net2ftp features short"] .="<li> zipper les fichiers a t�l�charger, les envoyer par mail ou les sauvegarder</li>\n";
$messages["net2ftp features short"] .="<li> upload-et-d�zip sur le serveur FTP (zip, tar, tgz, gz)</li>\n";
$messages["net2ftp features short"] .="<li> rechercher des mots ou phrases</li>\n";
$messages["net2ftp features short"] .="<li> calculer la taille des r�pertoires et fichiers</li>\n";
$messages["net2ftp features short"] .="</ul>\n";

} // end homepage


// -------------------------------------------------------------------------
// net2ftp_loginform.inc.php ok
// -------------------------------------------------------------------------
$messages["FTP server"] = "Serveur FTP";
$messages["Example"] = "Exemple";
$messages["Username"] = "Nom d'utilisateur";
$messages["Password"] = "Mot de passe";
$messages["Anonymous"] = "Anonyme";
$messages["Passive mode"] = "Mode passif";
$messages["Initial directory"] = "R�pertoire de depart";
$messages["Language"] = "Langue";
$messages["Skin"] = "Habillement";
$messages["FTP mode"] = "Mode FTP";
$messages["Login"] = "Soumettre";
$messages["Clear cookies"] = "Effacer les cookies";
$messages["Please enter an FTP server."] = "Veuillez entrer un serveur FTP.";
$messages["Please enter a username."] = "Veuillez entrer un nom d'utilisateur.";
$messages["Please enter a password."] = "Veuillez entrer un mot de passe.";


// -------------------------------------------------------------------------
// html.inc.php ok
// -------------------------------------------------------------------------

// HtmlBegin()
$messages["Status:"] = "Statut:";

// HtmlEnd()
$messages["net2ftp Help Guide"] = "Guide d'Aide net2ftp";
$messages["net2ftp Forums"] = "Forums net2ftp";
$messages["License"] = "Licence";
$messages["Powered by"] = "Soutenu par";

// printJavascriptFunctions()
$messages["Choose a directory"] = "Choisir un r�pertoire";
$messages["Please wait..."] = "Merci de patienter...";
$messages["Uploading... please wait..."] = "Upload en cours... Merci de patienter...";
$messages["If the upload takes more than the allowed <b>%1\$s seconds<\/b>, you will have to try again with less/smaller files."] = "Si l'upload prend plus que les <b>%1\$s secondes<\/b> permises, vous devrez reessayer avec moins de fichiers ou avec des fichiers plus petits.";
$messages["This window will close automatically in a few seconds."] = "Cette fen�tre se fermera automatiquement dans quelques secondes.";
$messages["Close window now"] = "Fermer la fen�tre maintenant";


// -------------------------------------------------------------------------
// httpheaders.inc.php ok
// -------------------------------------------------------------------------
// Nothing to translate


// -------------------------------------------------------------------------
// manage.inc.php
if ($state == "manage") {
// -------------------------------------------------------------------------

// manage()
$messages["Please select at least one directory or file!"] = "Veuillez s�l�ctioner au moins un r�pertoire ou un fichier!";
$messages["Unexpected state2 string. Exiting."] = "Cha�ne state2 innatendue. Fermeture.";

// renameentry()
if ($state2 == "rename") {
$messages["Rename directories and files"] = "Renommer des r�pertoires et des fichiers";
$messages["Old name: "] = "Ancien nom: ";
$messages["New name: "] = "Nouveau nom: ";
$messages["The new name may not contain any dots. This entry was not renamed to <b>%1\$s</b>"] = "Le nouveau nom ne doit contenir aucun points. Cette entr�e n'a pas �t� renomm�e en <b>%1\$s</b>";
$messages["<b>%1\$s</b> was successfully renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> a �t� renomm� avec succ�s en <b>%2\$s</b>";
$messages["<b>%1\$s</b> could not be renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> n'a pu �tre renomm� en <b>%2\$s</b>";
}

// chmodentry()
if ($state2 == "chmod") {
$messages["Chmod directories and files"] = "Changer le chmod des r�pertoires et des fichiers";
$messages["Set all permissions"] = "�tablir toutes les permissions";
$messages["Read"] = "Lire";
$messages["Write"] = "�crire";
$messages["Execute"] = "Ex�cuter";
$messages["Owner"] = "Propri�taire";
$messages["Group"] = "Groupe";
$messages["Everyone"] = "Tous";
$messages["To set all permissions to the same values, enter those permissions above and click on the button \"Set all permissions\""] = "Pour r�gler toutes les permissions aux m�mes valeurs, entrez ces permissions ci-haut et cliquez sur le bouton \"�tablir toutes les permissions\"";
$messages["Set the permissions of directory <b>%1\$s</b> to: "] = "�tablir les permissions du r�pertoire <b>%1\$s</b> �: ";
$messages["Set the permissions of file <b>%1\$s</b> to: "] = "�tablir les permissions du fichier <b>%1\$s</b> �: ";
$messages["Set the permissions of symlink <b>%1\$s</b> to: "] = "�tablir les permissions du symlink <b>%1\$s</b> �: ";
$messages["Chmod value"] = "Valeur chmod";
$messages["Chmod also the subdirectories within this directory"] = "�tablir le chmod sur les sous-r�pertoires dans ce r�pertoire �galement";
$messages["Chmod also the files within this directory"] = "�tablir le chmod sur les fichiers dans ce r�pertoire �galement";
$messages["The chmod nr <b>%1\$s</b> is out of the range 000-777. Please try again."] = "Le chmod <b>%1\$s</b> est � l'ext�rieur de l'intervalle 000-777. Veuillez essayer � nouveau.";
}

// copymovedeleteentry()
if ($state2 == "copy" || $state2 == "move" || $state2 == "delete") {
$messages["Copy directories and files"] = "Copier les r�pertoires et les fichiers";
$messages["Move directories and files"] = "D�placer les r�pertoires et les fichiers";
$messages["Delete directories and files"] = "Supprimer les r�pertoires et les fichiers";
$messages["Are you sure you want to delete these directories and files?"] = "�tes-vous sur de vouloir supprimer ces r�pertoires et fichiers?";
$messages["All the subdirectories and files of the selected directories will also be deleted!"] = "Tous les sous-r�pertoires et fichiers des r�pertoires s�lectionn�s vont aussi �tre supprim�s";
$messages["Set all targetdirectories"] = "�tablir tous les r�pertoires cible";
$messages["To set a common target directory, enter that target directory in the textbox above and click on the button \"Set all targetdirectories\"."] = "Pour �tablir un r�pertoire cible commun, entrer le r�pertoire cible dans la bo�te de texte ci-dessus et cliquez sur \"�tablir tous les r�pertoires cible\".";
$messages["Note: the target directory must already exist before anything can be copied into it."] = "Note: le r�pertoire cible doit d�ja exister avant que quelque chose y soit copi�.";
$messages["Different target FTP server:"] = "Diff�rent serveur FTP comme cible:";
$messages["Leave empty if you want to copy the files to the same FTP server."] = "Laisser vide si vous copiez les fichiers vers le m�me serveur FTP.";
$messages["If you want to copy the files to another FTP server, enter your login data."] = "Si vous voulez copier les fichiers vers un autre serveur FTP, veuillez entrer vos informations de connexion.";
$messages["Copy directory <b>%1\$s</b> to:"] = "Copier le r�pertoire <b>%1\$s</b> vers:";
$messages["Move directory <b>%1\$s</b> to:"] = "D�placer le r�pertoire <b>%1\$s</b> vers:";
$messages["Directory <b>%1\$s</b>"] = "R�pertoire <b>%1\$s</b>";
$messages["Copy file <b>%1\$s</b> to:"] = "Copier le fichier <b>%1\$s</b> vers:";
$messages["Move file <b>%1\$s</b> to:"] = "D�placer le fichier <b>%1\$s</b> vers:";
$messages["File <b>%1\$s</b>"] = "Fichier <b>%1\$s</b>";
$messages["Copy symlink <b>%1\$s</b> to:"] = "Copier le symlink <b>%1\$s</b> vers:";
$messages["Move symlink <b>%1\$s</b> to:"] = "D�placer le symlink <b>%1\$s</b> vers:";
$messages["Symlink <b>%1\$s</b>"] = "Symlink <b>%1\$s</b>";
$messages["Target directory:"] = "R�pertoire cible:";
$messages["Target name:"] = "Nom de la cible:";
$messages["Processing the entries:"] = "Traitement des entr�es:";
}

// newdirectory()
if ($state2 == "newdirectory") {
$messages["Create new directories"] = "Cr�er des nouveaux r�pertoires";
$messages["The new directories will be created in <b>%1\$s</b>."] = "Les nouveaux r�pertoires seront cr��s dans <b>%1\$s</b>.";
$messages["New directory name:"] = "Nom du nouveau r�pertoire:";
$messages["Directory <b>%1\$s</b> was successfully created."] = "Le r�pertoire <b>%1\$s</b> a �t� cr�� avec succ�s.";
}

// uploadfile()
if ($state2 == "uploadfile") {
$messages["Upload files and archives"] = "Uploader des fichiers et des archives";
$messages["Upload results"] = "R�sultats de l'upload";
$messages["Checking files:"] = "V�rification des fichiers:";
$messages["Transferring files to the FTP server:"] = "Transfer des fichiers vers le serveur FTP:";
$messages["Decompressing archives and transferring files to the FTP server:"] = "Decompression des archives et transfer des fichiers vers le serveur FTP:";
$messages["Upload more files and archives"] = "Uploader plus de fichiers et d'archives";
}

// printUploadForm() and javaupload()
if ($state2 == "uploadfile" || $state2 == "javaupload") {
$messages["Upload to directory:"] = "Uploader vers le r�pertoire:";
$messages["Files"] = "Fichiers";
$messages["Archives"] = "Archives";
$messages["Files entered here will be transferred to the FTP server."] = "Les fichiers entr�s ici seront transf�r�s vers le serveur FTP.";
$messages["Archives entered here will be decompressed, and the files inside will be transferred to the FTP server."] = "Les archives entr�es ici vont �tre d�compress�es et les fichiers � l'int�rieur de celles-ci vont �tre transf�r�s vers le serveur FTP.";
$messages["Add another"] = "Ajouter un autre";
$messages["Use folder names (creates subdirectories automatically)"] = "Utiliser les noms des r�pertoires (cr�er les sous-r�pertoires automatiquement)";
$messages["Restrictions:"] = "Restrictions:";
$messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s kB</b> and by PHP to <b>%2\$s</b>"] = "La grosseur maximale d'un fichier est restreinte � <b>%1\$s kB</b> par net2ftp et � <b>%2\$s</b> par PHP";
$messages["The maximum execution time is <b>%1\$s seconds</b>"] = "Le temps d'ex�cution maximum est de <b>%1\$s secondes</b>";
$messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "Le mode de transfer FTP (ASCII ou BINARY) sera automatiquement d�termin� selon l'extension du fichier";
$messages["If the destination file already exists, it will be overwritten"] = "Si le fichier de destination existe d�ja il sera remplac� par celui-ci";

$messages["Upload directories and files using a Java applet"] = "Upload directories and files using a Java applet";
$messages["Number of files:"] = "Number of files:";
$messages["Size of files:"] = "Size of files:";
$messages["Add"] = "Add";
$messages["Remove"] = "Remove";
$messages["Upload"] = "Upload";
$messages["Add files to the upload queue"] = "Add files to the upload queue";
$messages["Remove files from the upload queue"] = "Remove files from the upload queue";
$messages["Upload the files which are in the upload queue"] = "Upload the files which are in the upload queue";
$messages["Maximum server space exceeded. Please select less/smaller files."] = "Maximum server space exceeded. Please select less/smaller files.";
$messages["Total size of the files is too big. Please select less/smaller files."] = "Total size of the files is too big. Please select less/smaller files.";
$messages["Total number of files is too high. Please select fewer files."] = "Total number of files is too high. Please select fewer files.";
$messages["Note: to use this applet, Sun's Java plugin must be installed (version 1.4 or newer)."] = "Note: to use this applet, Sun's Java plugin must be installed (version 1.4 or newer).";

$messages["Browser does not support Java applets"] = "Your browser does not support applets, or you have disabled applets in your browser settings.\n";
$messages["Browser does not support Java applets"] .= "To use this applet, please install the newest version of Sun's java. You can get it from <a href=\"http://www.java.com/\">java.com</a>. Click on Get It Now.\n";
$messages["Browser does not support Java applets"] .= "The online installation is about 1-2 MB and the offline installation is about 13 MB. This 'end-user' java is called JRE (Java Runtime Environment).\n";
$messages["Browser does not support Java applets"] .= "Alternatively, use net2ftp's normal upload or upload-and-unzip functionality.\n";
}

// zipentry()
if ($state2 == "zip") {
$messages["Zip entries"] = "Entr�es zip";
$messages["Save the zip file on the FTP server as:"] = "Sauvegarder le fichier zip sur le serveur comme:";
$messages["Email the zip file in attachment to:"] = "Envoyer le fichier zip comme attachement par courriel �:";
$messages["Note that sending files is not anonymous: your IP address as well as the time of the sending will be added to the email."] = "Prendre note qu'envoyer des fichiers n'est pas anonyme: votre adresse IP ainsi que le temps et la date d'envoie seront ajout�s au courriel.";
$messages["Some additional comments to add in the email:"] = "Quelques commentaires additionnels � ajouter au courriel:";
$messages["You did not enter a filename for the zipfile. Go back and enter a filename."] = "Vous n'avez pas entr� un nom de fichier pour le fichier zip. Retournez en arri�re et entrez un nom de fichier.";
$messages["The email address you have entered (%1\$s) does not seem to be valid.<br />Please enter an address in the format <b>username@domain.com</b>"] = "L'adresse de courriel que vous avez entr� (%1\$s) ne semble pas �tre valide.<br />Veuillez entrer une adresse du type <b>utilisateur@domaine.com</b>";
}

// calculatesize()
if ($state2 == "calculatesize") {
$messages["Size of selected directories and files"] = "Taille des r�pertoires et fichiers s�lectionn�s";
$messages["The total size taken by the selected directories and files is:"] = "La taille totale des r�pertoires et fichiers s�lectionn�s est de:";
$messages["The nr of files which were skipped:"] = "Le nombre de fichiers omis est:";
}

// findstring()
if ($state2 == "findstring") {
$messages["Search directories and files"] = "Rechercher dans des r�pertoires et fichiers";
$messages["Search results"] = "R�sultats de la recherche";
$messages["Please enter a valid search word or phrase."] = "Veuillez entrer un mot ou une phrase de recherche valide.";
$messages["Please enter a valid filename."] = "Veuillez entrer un nom de fichier valide.";
$messages["Please enter a valid file size in the \"from\" textbox, for example 0."] = "Veuillez entrer une taille de fichier valide dans le champ de saisie \"de\", comme par exemple 0.";
$messages["Please enter a valid file size in the \"to\" textbox, for example 500000."] = "Veuillez entrer une taille de fichier valide dans le champ de saisie \"�\", comme par exemple 500000.";
$messages["Please enter a valid date in Y-m-d format in the \"from\" textbox."] = "Veuillez entrer la date en utilisant le format A-m-j dans le champ de saisie \"de\".";
$messages["Please enter a valid date in Y-m-d format in the \"to\" textbox."] = "Veuillez entrer la date en utilisant le format A-m-j dans le champ de saisie \"�\".";
$messages["The word <b>%1\$s</b> was not found in the selected directories and files."] = "Le mot <b>%1\$s</b> n'a pas �t� trouv� dans les r�pertoires et fichiers s�lectionn�s.";
$messages["The word <b>%1\$s</b> was found in the following files:"] = "Le mot <b>%1\$s</b> a �t� trouv� dans les fichiers suivants:";
$messages["Search again"] = "R�p�ter la recherche";
}

// printFindstringForm()
if ($state2 == "findstring") {
$messages["Search for a word or phrase"] = "Rechercher un mot ou une phrase";
$messages["Case sensitive search"] = "Recherche sensible � la casse";
$messages["Restrict the search to:"] = "Restreindre la recherche �:";
$messages["files with a filename like"] = "fichiers avec un nom de fichier comme";
$messages["(wildcard character is *)"] = "(caract�re wildcard est *)";
$messages["files with a size"] = "fichiers avec une taille";
$messages["from"] = "de";
$messages["to"] = "�";
$messages["files which were last modified"] = "fichiers modifi�s derni�rement";
}

// updatefile()
if ($state2 == "updatefile") {
$messages["Update file"] = "Mettre � jour le fichier";
$messages["<b>WARNING: THIS FUNCTION IS STILL IN EARLY DEVELOPMENT. USE IT ONLY ON TEST FILES! YOU HAVE BEEN WARNED!"] = "<b>ATTENTION: CETTE FONCTION EN EST ENCORE � SON STADE PRIMAIRE. NE L'UTILISEZ QU'AVEC DES FICHIERS TEST VOUS AUREZ �T� PR�VENUS!";
$messages["Known bugs: - erases tab characters - doesn't work well with big files (> 50kB) - was not tested yet on files containing non-standard characters</b>"] = "Bugs connus: - Effacer les tabulations - ne fonctionne pas bien avec les gros fichiers(> 50kB) - n'a pas encore �t� test� sur des fichiers contenant des caract�res non-standard</b>";
$messages["This function allows you to upload a new version of the selected file, to view what are the changes and to accept or reject each change. Before anything is saved, you can edit the merged files."] = "Cette fonction vous permet d'uploader une nouvelle version du fichier s�lectionn�, pour voir quels sont les changements puis pour les accepter ou les refuser. Avant que le tout soit enregistr� vous pouvez modifier les fichiers fusionn�s.";
$messages["Old file:"] = "Ancien fichier:";
$messages["New file:"] = "Nouveau fichier:";
$messages["Restrictions:"] = "Restrictions:";
$messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s kB</b> and by PHP to <b>%2\$s</b>"] = "La grosseur maximale d'un fichier est restreinte � <b>%1\$s kB</b> par net2ftp et � <b>%2\$s</b> par PHP";
$messages["The maximum execution time is <b>%1\$s seconds</b>"] = "Le temps d'ex�cution maximum est <b>%1\$s secondes</b>";
$messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "Le mode de transfer FTP (ASCII ou BINARY) sera automatiquement d�termin� selon l'extension du fichier";
$messages["If the destination file already exists, it will be overwritten"] = "Si le fichier de destination existe d�ja il sera remplac� par celui-ci";
$messages["You did not provide any files or archives to upload."] = "Vous n'avez fourni aucun fichier ou archive � uploader.";
$messages["Unable to delete the new file"] = "Impossible de supprimer le nouveau fichier";
}

// printComparisonSelect()
if ($state2 == "updatefile") {
$messages["Please wait..."] = "Veuillez patienter...";
$messages["Select lines below, accept or reject changes and submit the form."] = "S�lectionner les lignes ci-dessous, acceptez ou refusez les changements et soumettez le formulaire.";
}

} // end manage


// -------------------------------------------------------------------------
// registerglobals.inc.php ok
// -------------------------------------------------------------------------
$messages["Please enter your username and password for FTP server "] = "Veuillez entrer votre nom d'utilisateur et votre mot de passe du serveur FTP ";
$messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "Vous n'avez pas entr� correctement vos information de connexion dans la fen�tre pop-up.<br />Cliquez sur \"Aller � la page de connecxion\" ci-dessous.";
$messages["Access to the net2ftp Admin panel is disabled, because no password has been set in the file settings.inc.php. Enter a password in that file, and reload this page."] = "L'acc�s au panneau d'administration a �t� d�sactiv� parce qu'aucun mot de passe n'a �t� pr�cis� dans le fichier settings.inc.php. Pr�cisez un mot de passe dans ce fichier, et rechargez cette page.";
$messages["Please enter your Admin username and password"] = "Veuillez entrer votre nom d'utilisateur et votre mot de passe administrateur";
$messages["Wrong username or password for the net2ftp Admin panel. The username and password can be set in the file settings.inc.php."] = "Mauvais nom d'utilisateur ou mot de passe pour le panneau d'administration de net2ftp. Le nom d'utilisateur et le mot de passe peuvent �tre configur�s dans le fichier settings.inc.php.";


// -------------------------------------------------------------------------
// skins.inc.php ok
// -------------------------------------------------------------------------
$messages["Blue"] = "Bleu";
$messages["Grey"] = "Gris";
$messages["Black"] = "Noir";
$messages["Yellow"] = "Jaune";
$messages["Pastel"] = "Pastel";

// getMime()
$messages["Directory"] = "R�pertoire";
$messages["Symlink"] = "Symlink";
$messages["ASP script"] = "Script ASP";
$messages["Cascading Style Sheet"] = "Feuille de style CSS";
$messages["HTML file"] = "Fichier HTML";
$messages["Java source file"] = "Fichier source Java";
$messages["JavaScript file"] = "Fichier JavaScript";
$messages["PHP Source"] = "Source PHP";
$messages["PHP script"] = "Script PHP";
$messages["Text file"] = "Fichier Texte";
$messages["Bitmap file"] = "Fichier bitmap";
$messages["GIF file"] = "Fichier GIF";
$messages["JPEG file"] = "Fichier JPEG";
$messages["PNG file"] = "Fichier PNG";
$messages["TIF file"] = "Fichier TIFF";
$messages["GIMP file"] = "Fichier GIMP";
$messages["Executable"] = "Ex�cutable";
$messages["Shell script"] = "Script shell";
$messages["MS Office - Word document"] = "MS Office - Document Word";
$messages["MS Office - Excel spreadsheet"] = "MS Office - Tableur Excel";
$messages["MS Office - PowerPoint presentation"] = "MS Office - Pr�sentation PowerPoint ";
$messages["MS Office - Access database"] = "MS Office - Base de donn�es Access";
$messages["MS Office - Visio drawing"] = "MS Office - Document Visio";
$messages["MS Office - Project file"] = "MS Office - Fichier de projet";
$messages["OpenOffice - Writer 6.0 document"] = "OpenOffice - Document Writer 6.0";
$messages["OpenOffice - Writer 6.0 template"] = "OpenOffice - Fichier de description Writer 6.0";
$messages["OpenOffice - Calc 6.0 spreadsheet"] = "OpenOffice - Tableur Calc 6.0";
$messages["OpenOffice - Calc 6.0 template"] = "OpenOffice - Fichier de description Calc 6.0";
$messages["OpenOffice - Draw 6.0 document"] = "OpenOffice - Document Draw 6.0";
$messages["OpenOffice - Draw 6.0 template"] = "OpenOffice - Fichier de description Draw 6.0";
$messages["OpenOffice - Impress 6.0 presentation"] = "OpenOffice - Pr�sentation Impress 6.0";
$messages["OpenOffice - Impress 6.0 template"] = "OpenOffice - Fichier de description Impress 6.0";
$messages["OpenOffice - Writer 6.0 global document"] = "OpenOffice - Document global Writer 6.0";
$messages["OpenOffice - Math 6.0 document"] = "OpenOffice - Document Math 6.0";
$messages["StarOffice - StarWriter 5.x document"] = "StarOffice - Document StarWriter 5.x";
$messages["StarOffice - StarWriter 5.x global document"] = "StarOffice - Document global StarWriter 5.x";
$messages["StarOffice - StarCalc 5.x spreadsheet"] = "StarOffice - Tableur StarCalc 5.x";
$messages["StarOffice - StarDraw 5.x document"] = "StarOffice - Document StarDraw 5.x";
$messages["StarOffice - StarImpress 5.x presentation"] = "StarOffice - Pr�sentation StarImpress 5.x";
$messages["StarOffice - StarImpress Packed 5.x file"] = "StarOffice - Fichier StarImpress 5.x paquet�";
$messages["StarOffice - StarMath 5.x document"] = "StarOffice - Document StarMath 5.x";
$messages["StarOffice - StarChart 5.x document"] = "StarOffice - Document StarChart 5.x";
$messages["StarOffice - StarMail 5.x mail file"] = "StarOffice - Fichier mail StarMail 5.x";
$messages["Adobe Acrobat document"] = "Document Adobe Acrobat";
$messages["ARC archive"] = "Archive ARC";
$messages["ARJ archive"] = "Archive ARJ";
$messages["RPM"] = "RPM";
$messages["GZ archive"] = "Archive GZ";
$messages["TAR archive"] = "Archive TAR";
$messages["Zip archive"] = "Archive ZIP";
$messages["MOV movie file"] = "Fichier film MOV";
$messages["MPEG movie file"] = "Fichier film MPEG";
$messages["Real movie file"] = "Fichier film Real";
$messages["Quicktime movie file"] = "Fichier film Quicktime";
$messages["Shockwave flash file"] = "Fichier shockwave flash";
$messages["Shockwave file"] = "Fichier shockwave";
$messages["WAV sound file"] = "Fichier son WAV";
$messages["Font file"] = "Fichier de police";
$messages["%1\$s File"] = "Fichier %1\$s";
$messages["File"] = "Fichier";

// getAction()
$messages["Back"] = "Retour";
$messages["Submit"] = "Soumettre";
$messages["Refresh"] = "Actualiser";
$messages["Details"] = "D�tails";
$messages["Icons"] = "Ic�nes";
$messages["List"] = "Liste";
$messages["Logout"] = "D�connexion";
$messages["Help"] = "Aide";
$messages["Bookmark"] = "Favoris";
$messages["Save"] = "Sauvegarder";
$messages["Default"] = "D�faut";


// -------------------------------------------------------------------------
// view.inc.php
// -------------------------------------------------------------------------
$messages["Image"] = "Image";
$messages["View Macromedia ShockWave Flash movie %1\$s"] = "Visualiser le film Macromedia ShockWave Flash %1\$s";
$messages["View file %1\$s"] = "Visualiser le fichier %1\$s";
$messages["To save the image, right-click on it and choose 'Save picture as...'"] = "Pour sauvegarder l'image, faites un click droit sur l'image et choisissez 'Save picture as...'";


// ----------------------------------------------------------------------------------
// DO NOT CHANGE ANYTHING BELOW THIS LINE
// ----------------------------------------------------------------------------------

return $messages;

} // end function getMessages

?>
