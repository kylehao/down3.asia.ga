<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2004 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------

//   -------------------------------------------------------------------------------
//  | Language: Dutch (Nederlands)                                                  |
//   -------------------------------------------------------------------------------
//  | Pierre Aronnax <pierre AT trionax.com> 2004-12-22                             |
//   -------------------------------------------------------------------------------
//  |                                                                               |
//  |                              INSTRUCTIONS                                     |
//  |                                                                               |
//  |  The messages to translate are listed below.                                  |
//  |  The structure of each line is like this:                                     |
//  |     $message["Hello world!"] = "Hello world!";                                |
//  |                                                                               |
//  |  Keep the text between square brackets [] as it is.                           |
//  |  Translate the 2nd part, keeping the same punctuation and HTML tags.          |
//  |                                                                               |
//  |  The English message, for example                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is written in PHP!";    |
//  |  should become after translation:                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp est ecrit en PHP!";     |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is geschreven in PHP!"; |
//  |                                                                               |
//  |  Note that the variable starts with a dollar sign $, that the value is        |
//  |  enclosed in double quotes " and that the line ends with a semi-colon ;       |
//  |  Be careful when editing this file, do not erase those special characters.    |
//  |                                                                               |
//  |  Some messages also contain one or more variables which start with a percent  |
//  |  sign, for example %1\$s or %2\$s. The English message, for example           |
//  |     $messages[...] = ["The file %1\$s was copied to %2\$s "]                  |
//  |  should becomes after translation:                                            |
//  |     $messages[...] = ["Le fichier %1\$s a �t� copi� vers %2\$s "]             |
//  |                                                                               |
//  |  When a real percent sign % is needed in the text it is entered as %%         |
//  |  otherwise it is interpreted as a variable. So no, it's not a mistake.        |
//  |                                                                               |
//  |  Between the messages to translate there is additional PHP code, for example: |
//  |     if ($state2 == "rename") {                               // <-- PHP code  |
//  |     $messages["Rename directories"] = "Rename directories";  // <-- message   |
//  |     }                                                        // <-- PHP code  |
//  |  This code is needed to load the messages only when they are actually needed. |
//  |  There is no need to change or delete any of that PHP code; translate only    |
//  |  the message.                                                                 |
//  |                                                                               |
//  |  Thanks in advance to all the translators!                                    |
//  |  David.                                                                       |
//  |                                                                               |
//   -------------------------------------------------------------------------------

function getMessages() {
global $state, $state2;


// -------------------------------------------------------------------------
// Used encoding
// -------------------------------------------------------------------------
$messages["iso-8859-1"] = "iso-8859-1";


// -------------------------------------------------------------------------
// Status messages
// -------------------------------------------------------------------------
// When translating these messages, keep in mind that the text should not be too long
// It should fit in the status textbox
$messages["Connecting to the FTP server"] = "Verbinding maken met de FTP server";
$messages["Getting the list of directories and files"] = "Lijst van mappen en bestanden wordt opgevraagd";
$messages["Printing the list of directories and files"] = "Lijst van mappen en bestanden wordt afgebeeld";
$messages["Processing the entries"] = "Reeks wordt verwerkt";
$messages["Checking files"] = "Bestanden worden nagekeken";
$messages["Transferring files to the FTP server"] = "Bestanden worden naar de FTP server verzonden";
$messages["Decompressing archives and transferring files"] = "Archieven worden uitgepakt en verzonden";
$messages["Searching the files..."] = "Bestanden worden doorzocht...";
$messages["Uploading new file"] = "Nieuw bestand wordt verzonden";
$messages["Reading the new file"] = "Nieuw bestand wordt gelezen";
$messages["Reading the old file"] = "Oud bestand wordt gelezen";
$messages["Comparing the 2 files"] = "Bestanden worden vergeleken";
$messages["Printing the comparison"] = "Vergelijking wordt afgebeeld";
$messages["Script finished in %1\$s seconds"] = "Script be�indigd in %1\$s seconden";
$messages["Script halted"] = "Script werd onderbroken";


// -------------------------------------------------------------------------
// index.php
// -------------------------------------------------------------------------
$messages["Unexpected state string. Exiting."] = "Onverwachte state string. De applicatie wordt onderbroken.";
$messages["This beta function is not activated on this server."] = "Deze test functie is niet geactiveerd op deze server.";
$messages["This function has been disabled by the Administrator of this website."] = "Deze functie is gedeactiveerd door de Administrator van deze website.";


// -------------------------------------------------------------------------
// admin.inc.php
if ($state == "admin") {
// -------------------------------------------------------------------------
$messages["Admin functions"] = "Admin functies";

$messages["Version information"] = "Versie informatie";
$messages["This version of net2ftp is up-to-date"] = "Deze versie van net2ftp is up-to-date";
$messages["The latest version could not be retrieved from the net2ftp.com server. Check the security settings of your browser, which may prevent the loading of a small file from the net2ftp.com server."] = "Het opzoeken van de laatste versie informatie op net2ftp.com is mislukt. Kijk de veiligheidsinstellingen van Uw browser na; deze zouden het downloaden van een file van op net2ftp.com kunnen verhinderen.";

$messages["Logging"] = "Logging";
$messages["Date from:"] = "Date from:";
$messages["to:"] = "to:";
$messages["Empty logs"] = "Leeg logs";
$messages["View logs"] = "Bekijk logs";
$messages["No data"] = "Geen data";

$messages["Setup MySQL tables"] = "Stel de MySQL tabellen in";
$messages["Go"] = "Ga";
$messages["Create the MySQL database tables"] = "Maak de MySQL tabellen aan";
$messages["Create tables"] = "Maak tabellen aan";
$messages["The handle of file %1\$s could not be opened"] = "Het openen van de handle van het bestand %1\$s is mislukt";
$messages["The file %1\$s could not be opened"] = "Het openen van het bestand %1\$s is mislukt";
$messages["The handle of file %1\$s could not be closed"] = "Het sluiten van de handle van het bestand %1\$s is mislukt";
$messages["MySQL username"] = "MySQL gebruikersnaam";
$messages["MySQL password"] = "MySQL wachtwoord";
$messages["MySQL database"] = "MySQL database";
$messages["MySQL server"] = "MySQL server";
$messages["This SQL query is going to be executed:"] = "Deze SQL query zal worden uitgevoerd:";
$messages["Execute"] = "Uitvoeren";
$messages["Settings used:"] = "Gebruikte parameters:";
$messages["MySQL password length"] = "MySQL wachtwoord lengte";
$messages["Results:"] = "Resultaten:";
$messages["The connection to the server <b>%1\$s</b> could not be set up"] = "De connectie met de server <b>%1\$s</b> kon niet worden opgezet";
$messages["Unable to select the database <b>%1\$s</b>"] = "De database <b>%1\$s</b> kon niet worden geselecteerd";
$messages["The SQL query could not be executed"] = "De SQL query kon niet worden uitgevoerd";
$messages["The tables were created successfully"] = "De tabellen werden succesvol aangemaakt";

$messages["Beta functions"] = "Beta functies";
$messages["Send a site command to the FTP server"] = "Verstuur een site commando naar de FTP server";
$messages["View logs"] = "Bekijk de logs";
$messages["Empty logs"] = "Leeg de logs";
$messages["The table <b>%1\$s</b> was emptied successfully."] = "De tabel <b>%1\$s</b> werd succesvol geleegd.";
$messages["The table <b>%1\$s</b> could not be emptied."] = "De tabel <b>%1\$s</b> kon niet worden geleegd.";

} // end admin

// -------------------------------------------------------------------------
// advanced.inc.php
if ($state == "advanced") {
// -------------------------------------------------------------------------

// advanced()
$messages["The site command functions are not available on this webserver."] = "De site commando functies zijn niet beschikbaar op deze webserver.";
$messages["The Apache functions are not available on this webserver."] = "De Apache functies zijn niet beschikbaar op deze webserver.";
$messages["The MySQL functions are not available on this webserver."] = "De MySQL functies zijn niet beschikbaar op deze webserver.";
$messages["Unexpected state2 string. Exiting."] = "Onverwachte state2 string. De applicatie wordt onderbroken.";

// printAdvancedFunctions()
$messages["Advanced functions"] = "Geavanceerde functies";
$messages["Go"] = "Ga";
$messages["Troubleshooting functions"] = "Probleemoplossing functies";
$messages["Troubleshoot net2ftp on this webserver"] = "Test de installatie van net2ftp op deze webserver";
$messages["Troubleshoot an FTP server"] = "Test net2ftp op een FTP server";
$messages["Translation functions"] = "Vertaal functies";
$messages["Introduction to the translation functions"] = "Inleiding tot de vertaal functies";
$messages["Extract messages to translate from code files"] = "Verkrijg de te vertalen berichten uit de code bestanden";
$messages["Check if there are new or obsolete messages"] = "Kijk na of er nieuwe of verouderde berichten zijn";
$messages["Beta functions"] = "Beta functies";
$messages["Send a site command to the FTP server"] = "Stuur een site commando naar de FTP server";
$messages["Apache: password-protect a directory, create custom error pages"] = "Apache: bescherm een map met een wachtwoord, maak speciale foutpagina's aan";
$messages["MySQL: execute an SQL query"] = "MySQL: voer een SQL query uit";

// troubleshoot_webserver()
$messages["Troubleshoot your net2ftp installation"] = "Test de installatie van net2ftp op deze webserver";
$messages["Checking if the FTP module of PHP is installed: "] = "Er wordt gecontroleerd of de FTP module van PHP is ge�nstalleerd: ";
$messages["yes"] = "ja";
$messages["no - please install it!"] = "nee - installeer de module!";
$messages["Checking the permissions of the directory on the web server: a small file will be written to the /temp folder and then deleted."] = "De rechten van de map op de webserver zullen worden nagekeken: een klein bestand zal worden weggeschreven naar de /temp directory en zal daarna worden verwijderd.";
$messages["Creating filename: "] = "Bestand wordt aangemaakt met naam: ";
$messages["OK. Filename: %1\$s"] = "OK. Naam van het bestand: %1\$s";
$messages["not OK"] = "niet OK";
$messages["OK"] = "OK";
$messages["not OK. Check the permissions of the %1\$s directory"] = "niet OK. Controleer de rechten van de map %1\$s";
$messages["Opening the file in write mode: "] = "Bestand wordt in schrijf-mode geopend: ";
$messages["Writing some text to the file: "] = "Er wordt wat tekst weggeschreven naar het bestand: ";
$messages["Closing the file: "] = "Bestand wordt gesloten: ";
$messages["Deleting the file: "] = "Bestand wordt verwijderd: ";

// troubleshoot_ftpserver()
$messages["Troubleshoot an FTP server"] = "Test net2ftp op een FTP server";
$messages["FTP server port"] = "FTP server poort";
$messages["Connection settings:"] = "Verbinding instellingen:";
$messages["Password length"] = "Wachtwoord lengte";
$messages["Language"] = "Taal";
$messages["Skin number"] = "Uiterlijk nummer";
$messages["Connecting to the FTP server: "] = "Verbinding met FTP server wordt aangemaakt: ";
$messages["Logging into the FTP server: "] = "Aan het inloggen: ";
$messages["Setting the passive mode: "] = "De passieve mode wordt gekozen: ";
$messages["Getting the FTP server system type: "] = "Het FTP server system type wordt opgevraagd: ";
$messages["Changing to the directory %1\$s: "] = "Huidige map wordt veranderd naar %1\$s: ";
$messages["The directory from the FTP server is: %1\$s "] = "De map van de FTP server is: %1\$s ";
$messages["Getting the raw list of directories and files: "] = "Ruwe lijst van mappen en bestanden wordt aangevraagd: ";
$messages["Trying a second time to get the raw list of directories and files: "] = "Er wordt een tweede keer geprobeerd om een ruwe lijst van mappen en bestanden te krijgen: ";
$messages["Closing the connection: "] = "Verbinding wordt gesloten: ";
$messages["Raw list of directories and files:"] = "Ruwe lijst van mappen en bestanden:";
$messages["Parsed list of directories and files:"] = "Verkregen lijst van mappen en bestanden:";

// printTranslationFunctions()
$messages["net2ftp translation functions"] = "net2ftp vertaal functies";
$messages["A PHP application can be translated using the standard <a href=\"http://www.php.net/gettext\">gettext</a> functions, or using a self-made translation function."] = "Een PHP applicatie kan worden vertaald door gebruik te maken van de standaard <a href=\"http://www.php.net/gettext\">gettext</a> functies, of door gebruik te maken van een zelfgemaakte vertaalfunctie.";
$messages["In both cases, the steps to take are similar."] = "In beide gevallen zijn de stappen dezelfde.";
$messages["Step 1: change code"] = "Stap 1: wijzig de code";
$messages["All messages must be translated using a translation function, for example translate()."] = "Alle berichten moeten worden vertaald m.b.v. een vertaalfunctie, bijvoorbeeld translate().";
$messages["This Hello World code:"] = "Deze Hello World code:";
$messages["must be changed to this:"] = "moet worden veranderd tot dit:";
$messages["Step 2: extract messages"] = "Stap 2: extraheer de berichten";
$messages["All messages which are used by the translate() function must be extracted from the code files, and copied to a <b>main message file</b>."] = "Alle berichten die worden gebruikt door de translate() functie moeten worden ge�xtraheerd uit de code bestanden, en worden gecopi�erd naar een <b>hoofd-berichtenbestand</b>.";
$messages["Step 3: translate messages"] = "Stap 3: vertaal de berichten";
$messages["The main message file is given to translators, who rename the file and replace the messages in English by the translation."] = "Het hoofd-berichtenbestand wordt aan vertalers gegeven, die het bestand hernoemen en alle berichten in het Engels vertalen naar een andere taal.";
$messages["The translators return the <b>translated message files</b>."] = "De vertalers geven <b>vertaalde-berichtenbestanden</b> terug.";
$messages["Each time the application is modified, a new main message file must be generated, as in step 2."] = "Telkens wanneer de applicatie wordt gewijzigd, moet een nieuw hoofd-berichtenbestand worden aangemaakt, zoals in stap 2.";
$messages["In order to avoid translating everything all over again, it must then be compared to all translated message files, to check if there are new or obsolete messages."] = "Om te vermijden dat alles opnieuw zou moeten worden vertaald, moet het vergeleken worden met alle bestaande vertaalde-berichtenbestanden, om na te gaan of er nieuwe of verouderde berichten zijn.";
$messages["net2ftp can help in step 2 to extract messages to translate from code files"] = "net2ftp kan helpen in stap 2 om berichten te extraheren uit code bestanden";
$messages["net2ftp can help in step 4 to check if there are new or obsolete messages"] = "net2ftp kan helpen in stap 4 om na te kijken of er nieuwe of verouderde berichten zijn";

// translate_extract()
$messages["Extract messages from code files"] = "Extraheer berichten van code bestanden";
$messages["Directory containing code files:"] = "Map die de code bestanden bevat:";
$messages["Translation function used in the code:"] = "Vertaalfunctie die in de code wordt gebruikt:";
$messages["File to generate:"] = "Te genereren bestand:";
$messages["Extracted messages:"] = "Ge�xtraheerde berichten:";
$messages["No messages were found, so no file was put on the FTP server."] = "Er werden geen berichten gevonden, dus er is geen bestand geplaatst op de FTP server.";
$messages["The main language file <b>%1\$s</b> was transferred to directory <b>%2\$s</b>."] = "Het hoofd-berichtenbestand <b>%1\$s</b> is verplaatst naar de map <b>%2\$s</b>.";

// translate_check()
$messages["Main language file:"] = "Hoofd-berichtenbestand:";
$messages["Directory containing translated language files:"] = "Map die vertaalde-berichtenbestanden bevat:";
$messages["File %1\$s was skipped because it could not be read, or because it was empty."] = "Bestand %1\$s was overgeslagen omdat het niet kon worden gelezen, of omdat het leeg was.";
$messages["File nr %1\$s <b>%2\$s</b>"] = "Bestand nr %1\$s <b>%2\$s</b>";
$messages["New messages:"] = "Nieuwe berichten:";
$messages["Obsolete messages:"] = "Verouderde berichten:";
$messages["All the files have been processed"] = "Alle bestanden zijn verwerkt";

// sendsitecommand()
$messages["Send site command"] = "Verstuur een site commando";
$messages["Enter the site command"] = "Geef het site commando op";
$messages["The commands you can use depends on your FTP server. These commands are not standard and vary a lot from one server to the other."] = "Welke commando's gebruikt kunnen worden hangt af van de FTP server. Deze commando's zijn niet standaard en wijken af van server tot server.";
$messages["Note that net2ftp cannot display the output of the FTP server, it can only tell if the command returned TRUE or FALSE. This is not a limitation of net2ftp but of PHP, the language in which net2ftp is written."] = "Let op: net2ftp kan geen gedetailleerd resultaat weergeven, net2ftp kan enkel aangeven of het commando succesvol was. Dit is geen beperking van net2ftp zelf maar van PHP, de programmeertaal waarin net2ftp is geschreven.";
$messages["The command <b>%1\$s</b> was executed successfully."] = "Het commando <b>%1\$s</b> is succesvol uitgevoerd.";

// apache(), mysqlfunctions()
// Not yet translated

} // end advanced



// -------------------------------------------------------------------------
// authorizations.inc.php
// -------------------------------------------------------------------------

// checkAuthorization()
$messages["The FTP server <b>%1\$s</b> is not in the list of allowed FTP servers."] = "De FTP server <b>%1\$s</b> staat niet in de lijst met toegestane FTP servers.";
$messages["The FTP server <b>%1\$s</b> is in the list of banned FTP servers."] = "De FTP server <b>%1\$s</b> staat in de lijst met verboden FTP servers.";
$messages["Your IP address (%1\$s) is in the list of banned IP addresses."] = "Uw IP adres (%1\$s) staat in de lijst met verboden IP adressen.";
$messages["The FTP server port %1\$s may not be used."] = "De FTP server poort %1\$s mag niet worden gebruikt.";
$messages["You don't have the authorizations to view directory <b>%1\$s</b>."] = "U heeft geen rechten om de map <b>%1\$s</b> te bekijken.";

// logAccess(), logLogin(), logError()
// Not yet translated


// -------------------------------------------------------------------------
// bookmark.inc.php
if ($state == "bookmark") {
// -------------------------------------------------------------------------
$messages["Add this link to your bookmarks:"] = "Voeg deze link toe aan uw favorieten:";
$messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer: rechter muisklik op de link, en kies \"Toevoegen aan Favorieten...\"";
$messages["Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla, Firefox: rechter muisklik op de link, en kies \"Bladwijzer van deze pagina maken...\"";
$messages["Note: when you will use this bookmark, a popup window will ask you for your username and password."] = "Opmerking: als u deze link gebruikt, vraagt een extra venster naar uw gebruikersnaam en wachtwoord.";

} // end bookmark


// -------------------------------------------------------------------------
// browse.inc.php
if ($state == "browse") {
// -------------------------------------------------------------------------

// browse()
$messages["Directories with names containing \' cannot be displayed correctly. They can only be deleted. Please go back and select another subdirectory."] = "Mappen die het teken \' in hun naam hebben kunnen niet correct worden afgebeeld. Ze kunnen alleen worden verwijderd. Kiest u a.u.b. een andere map.";

$messages["Consumption message"]  = "";
$messages["Consumption message"] .= "<b>De dagelijkse limiet is bereikt: hierdoor kunt u geen gegevens versturen</b><br /><br />\n";
$messages["Consumption message"] .= "Om iedereen een eerlijk gebruik van deze webserver te garanderen, zijn de hoeveelheid data en script verwerkingstijd dagelijks beperkt. Zodra deze limiet is bereikt, kunt u nog wel door de FTP server bladeren, maar er geen bestanden vanaf/naartoe sturen.<br /><br />\n";
$messages["Consumption message"] .= "Als u onbeperkt gebruik wil, overweeg dan om net2ftp op uw eigen server te installeren.<br />\n";

// ftp_getlist()
$messages["The directory <b>%1\$s</b> does not exist or could not be selected, so the root directory <b>/</b> is shown instead."] = "De map <b>%1\$s</b> bestaat niet of kon niet worden geselecteerd, in plaats daarvan is de hoofd map <b>/</b> afgebeeld.";

// printdirfilelist()
// Keep this short, it must fit in a small button!
$messages["New dir"] = "Nieuwe map";
$messages["New file"] = "Nieuw bestand";
$messages["HTML templates"] = "HTML templates";
$messages["Upload"] = "Upload";
$messages["Java Upload"] = "Java Upload";
$messages["Advanced"] = "Geavanceerd";
$messages["Copy"] = "Kopi�ren";
$messages["Move"] = "Verplaatsen";
$messages["Delete"] = "Verwijderen";
$messages["Rename"] = "Hernoemen";
$messages["Chmod"] = "Chmod";
$messages["Download"] = "Download";
$messages["Zip"] = "Inpakken";
$messages["Size"] = "Grootte";
$messages["Search"] = "Zoeken";
$messages["Go to the parent directory"] = "Ga naar de bovenliggende map";
$messages["Transform selected entries: "] = "Verwerk de geselecteerde reeks: ";
$messages["Make a new subdirectory in directory %1\$s"] = "Maak een nieuwe onderliggende map aan in de map %1\$s";
$messages["Create a new file in directory %1\$s"] = "Maak een nieuw bestand aan in de map %1\$s";
$messages["Upload new files in directory %1\$s"] = "Upload een nieuw bestand in de map %1\$s";
$messages["Go to the advanced functions"] = "Ga naar de geavanceerde functies";
$messages["Copy the selected entries"] = "Kopieer de geselecteerde reeksen";
$messages["Move the selected entries"] = "Verplaats de geselecteerde reeksen";
$messages["Delete the selected entries"] = "Verwijder de geselecteerde reeksen";
$messages["Rename the selected entries"] = "Hernoem de geselecteerde reeksen";
$messages["Chmod the selected entries (only works on Unix/Linux/BSD servers)"] = "Chmod de geselecteerde reeks (werkt alleen op Unix/Linux/BSD servers)";
$messages["Download a zip file containing all selected entries"] = "Download een zip bestand die alle geselecteerde reeksen bevat";
$messages["Zip the selected entries to save or email them"] = "Zip de geselecteerde reeks en sla deze op, of email deze";
$messages["Calculate the size of the selected entries"] = "Bereken de grootte van de geselecteerde reeks";
$messages["Find files which contain a particular word"] = "Vind bestanden die een bepaald woord bevatten";
$messages["Click to sort by %1\$s in descending order"] = "Klik om op %1\$s te sorteren in omgekeerde volgorde";
$messages["Click to sort by %1\$s in ascending order"] = "Klik om op %1\$s te sorteren in alfabetische volgorde";
$messages["Ascending order"] = "Alfabetische volgorde";
$messages["Descending order"] = "Omgekeerde volgorde";
//$messages["Click to sort by %1\$s in ascending order"] = "Klik om op %1\$s te sorteren in alfabetische volgorde";
$messages["Up"] = "Omhoog";
$messages["Click to check or uncheck all rows"] = "Klik hier om alle rijen te selecteren of deselecteren";
$messages["All"] = "Alles";
$messages["Name"] = "Naam";
$messages["Type"] = "Type";
//$messages["Size"] = "Grootte";
$messages["Owner"] = "Eigenaar";
$messages["Group"] = "Groep";
$messages["Perms"] = "Rechten";
$messages["Mod Time"] = "Gewijzigd Op";
$messages["Actions"] = "Acties";
$messages["Download the file %1\$s"] = "Download het bestand %1\$s";
$messages["View"] = "Bekijk";
$messages["Edit"] = "Bewerk";
$messages["Update"] = "Vernieuw";
$messages["Open"] = "Open";
$messages["View the highlighted source code of file %1\$s"] = "Bekijk de geaccentueerde bron van het bestand %1\$s";
$messages["Edit the source code of file %1\$s"] = "Bewerk de bron van het bestand %1\$s";
$messages["Upload a new version of the file %1\$s and merge the changes"] = "Upload een nieuwere versie van het bestand %1\$s en voeg de wijzigingen samen";
$messages["View image %1\$s"] = "Bekijk afbeelding %1\$s";
$messages["View the file %1\$s from your HTTP web server"] = "Bekijk het bestand %1\$s vanaf uw HTTP web server";
$messages["(Note: This link may not work if you don't have your own domain name.)"] = "(Opmerking: Deze link werkt mogelijk niet als u geen eigen domeinnaam heeft.)";
$messages["This folder is empty"] = "Deze map is leeg";

// printSeparatorRow()
$messages["Directories"] = "Mappen";
$messages["Files"] = "Bestanden";
$messages["Symlinks"] = "Symlinks";
$messages["Unrecognized FTP output"] = "Niet herkende FTP uitvoer";
$messages["Number"] = "Aantal";
$messages["Size"] = "Grootte";
$messages["Skipped"] = "Overgeslagen";

// printLocationActions()
$messages["Language:"] = "Taal:";
$messages["Skin:"] = "Uiterlijk:";
$messages["View mode:"] = "Bekijk mode:";
$messages["Directory Tree"] = "Mappen volgorde";

// printURL()
$messages["Execute %1\$s in a new window"] = "Voer %1\$s uit in een nieuw venster";

// printDirectorySelect()
$messages["Double-click to go to a subdirectory:"] = "Dubbel klik om naar een onderliggende map te gaan:";
$messages["Choose"] = "Kies";
$messages["Up"] = "Omhoog";

} // end browse


// -------------------------------------------------------------------------
// consumption.inc.php
// -------------------------------------------------------------------------
$messages["Unable to determine your IP address."] = "Het achterhalen van uw IP adres is mislukt.";
$messages["Table net2ftp_logConsumptionIpaddress contains duplicate rows."] = "Tabel net2ftp_logConsumptionIpaddress bevat gelijke rijen.";
$messages["Table net2ftp_logConsumptionFtpserver contains duplicate rows."] = "Tabel net2ftp_logConsumptionFtpserver bevat gelijke rijen.";
$messages["The variable <b>consumption_ipaddress_dataTransfer</b> is not numeric."] = "De variabele <b>consumption_ipaddress_dataTransfer</b> is geen cijfer.";
$messages["Table net2ftp_logConsumptionIpaddress could not be updated."] = "Tabel net2ftp_logConsumptionIpaddress kan niet worden vernieuwd.";
$messages["Table net2ftp_logConsumptionIpaddress contains duplicate entries."] = "Tabel net2ftp_logConsumptionIpaddress bevat gelijke gegevens.";
$messages["Table net2ftp_logConsumptionFtpserver could not be updated."] = "Tabel net2ftp_logConsumptionFtpserver kan niet worden vernieuwd.";
$messages["Table net2ftp_logConsumptionFtpserver contains duplicate entries."] = "Tabel net2ftp_logConsumptionFtpserver bevat gelijke gegevens.";
$messages["Daily limit reached: the file <b>%1\$s</b> will not be transferred"] = "Dagelijkse limiet bereikt: het bestand <b>%1\$s</b> wordt niet verstuurd";


// -------------------------------------------------------------------------
// database.inc.php
// -------------------------------------------------------------------------
$messages["Unable to connect to the DB"] = "Verbinding maken met de DB is mislukt";
$messages["Unable to select the DB"] = "Selecteren van de DB is mislukt";


// -------------------------------------------------------------------------
// easywebsite.inc.php
if ($state == "easyWebsite") {
// -------------------------------------------------------------------------
$messages["Create a website in 4 easy steps"] = "Create a website in 4 easy steps";
$messages["Template overview"] = "Template overview";
$messages["Template details"] = "Template details";
$messages["Files are copied"] = "Files are copied";
$messages["Edit your pages"] = "Edit your pages";

// Screen 1 - printTemplateOverview
$messages["Click on the image to view the details of a template."] = "Klik op de afbeelding om de details te bekijken van een template.";
$messages["Back to the Browse screen"] = "Terug naar het Browse scherm";
$messages["Template"] = "Template";
$messages["Copyright"] = "Copyright";
$messages["Click on the image to view the details of this template"] = "Klik op deze afbeelding om de details te bekijken van deze template";

// Screen 2 - printTemplateDetails
$messages["The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?"] = "De template bestanden zullen worden gecopieerd naar de FTP server. Bestaande bestanden met dezelfde naam zullen worden overschreven. Wil u verdergaan?";
$messages["Preview"] = "Bekijk";
$messages["Install"] = "Installeer";
$messages["Size"] = "Grootte";
$messages["Preview page"] = "Bekijk pagina";
$messages["opens in a new window"] = "wordt in een nieuw venster geopend";

// Screen 3
$messages["Please wait while the template files are being transferred to your server: "] = "Een ogenblikje geduld; de template bestanden worden getransfereerd naar uw server: ";
$messages["Done."] = "Klaar.";
$messages["Continue"] = "Ga verder";

// Screen 4 - printEasyAdminPanel
$messages["Edit page"] = "Bewerk pagina";
$messages["Browse the FTP server"] = "Blader doorheen de FTP server";
$messages["Add this link to your favorites to return to this page later on!"] = "Voeg deze link toe aan uw Favorieten om terug te kunnen komen naar deze pagina!";
$messages["Edit website at %1\$s"] = "Bewerk website op %1\$s";
$messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer: rechter muisklik op de link, en kies \"Toevoegen aan Favorieten...\"";
$messages["Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla, Firefox: rechter muisklik op de link, en kies \"Bladwijzer van deze pagina maken...\"";

// ftp_copy_local2ftp
$messages["WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing..."] = "WAARSCHUWING: Het aanmaken van de map <b>%1\$s</b> is mislukt. Deze bestaat mogelijk al. Het programma wordt voortgezet...";
$messages["Created target subdirectory <b>%1\$s</b>"] = "Doelmap <b>%1\$s</b> is aangemaakt";
$messages["WARNING: Unable to copy the file <b>%1\$s</b>. Continuing..."] = "WAARSCHUWING: Het kopi�ren van het bestand <b>%1\$s</b> is mislukt. Het programma wordt voortgezet...";
$messages["Copied file <b>%1\$s</b>"] = "Bestand <b>%1\$s</b> gekopieerd";
}


// -------------------------------------------------------------------------
// edit.inc.php
if ($state == "manage" && ($state2 == "edit" || $state2 == "newfile")) {
// -------------------------------------------------------------------------

// edit()
$messages["Unable to open the template file"] = "Het openen van het template bestand is mislukt";
$messages["Unable to read the template file"] = "Het lezen van het template bestand is mislukt";
$messages["Please specify a filename"] = "Kiest u a.u.b. een bestandsnaam";

// printEditForm()
$messages["Directory: "] = "Map: ";
$messages["File: "] = "Bestand: ";
$messages["New file name: "] = "Nieuwe bestandsnaam: ";
$messages["Note: changing the textarea type will save the changes"] = "Opmerking: als u veranderd van textarea worden de wijzigingen opgeslagen";
$messages["Status: This file has not yet been saved"] = "Status: Dit bestand is nog niet opgeslagen";
$messages["Status: Saved on <b>%1\$s</b> using mode %2\$s"] = "Status: Opgeslagen om <b>%1\$s</b> met de mode %2\$s";
$messages["Status: <b>This file could not be saved</b>"] = "Status: <b>Dit bestand kon niet worden opgeslagen</b>";

} // end if edit newfile


// -------------------------------------------------------------------------
// errorhandling.inc.php
// -------------------------------------------------------------------------
$messages["An error has occured"] = "Er heeft zich een fout voorgedaan";
$messages["Go back"] = "Ga terug";
$messages["Go to the login page"] = "Ga naar de login pagina";


// -------------------------------------------------------------------------
// filesystem.inc.php
// -------------------------------------------------------------------------

// ftp_openconnection()
$messages["The <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this FTP module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">php.net</a><br />"] = "De <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module van PHP</a> is niet ge�nstalleerd.<br /><br /> De systeembeheerder van deze site zou de FTP module moeten installeren. Installatie instructies zijn gegeven op <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">php.net</a><br />";
$messages["Unable to connect to FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "Verbinding maken met de FTP server <b>%1\$s</b> op poort <b>%2\$s</b> is mislukt.<br /><br />Weet u zeker dat dit het correcte adres is van de FTP server? Deze is vaak verschillend van de HTTP (web) server. Neem a.u.b. contact op met uw ISP helpdesk of systeembeheerder voor hulp.<br />";
$messages["Unable to login to FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "Inloggen op FTP server <b>%1\$s</b> met gebruikersnaam <b>%2\$s</b> is mislukt.<br /><br />Weet u zeker dat uw gebruikersnaam en wachtwoord correct zijn? Neem a.u.b. contact op met uw ISP helpdesk of systeembeheerder voor hulp.<br />";
$messages["Unable to switch to the passive mode on FTP server <b>%1\$s</b>."] = "Het overschakelen naar passieve mode op de FTP server <b>%1\$s</b> is mislukt.";

// ftp_openconnection2()
$messages["Unable to connect to the second (target) FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the second (target) FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "Verbinding met de tweede (doel) FTP server <b>%1\$s</b> op poort <b>%2\$s</b> is mislukt.<br /><br />Weet u zeker dat dit het correcte adres is van de FTP server? Deze is vaak verschillend van de HTTP (web) server. Neem a.u.b. contact op met uw ISP helpdesk of systeembeheerder voor hulp.<br />";
$messages["Unable to login to the second (target) FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "Inloggen op tweede (doel) FTP server <b>%1\$s</b> met gebruikersnaam <b>%2\$s</b> is mislukt.<br /><br />Weet u zeker dat uw gebruikersnaam en wachtwoord correct zijn? Neem a.u.b. contact op met uw ISP helpdesk of systeembeheerder voor hulp.<br />";
$messages["Unable to switch to the passive mode on the second (target) FTP server <b>%1\$s</b>."] = "Het overschakelen naar passieve mode op de tweede (doel) FTP server <b>%1\$s</b> is mislukt.";

// ftp_myrename()
$messages["Unable to rename directory or file <b>%1\$s</b> into <b>%2\$s</b>"] = "Het hernoemen van de map of bestand <b>%1\$s</b> in <b>%2\$s</b> is mislukt";

// ftp_mychmod()
$messages["Unable to execute site command <b>%1\$s</b>. Note that the CHMOD command is only available on Unix FTP servers, not on Windows FTP servers."] = "Het uitvoeren van het commando <b>%1\$s</b> is mislukt. Let op dat het CHMOD commando alleen beschikbaar is op Unix FTP servers, niet op Windows FTP servers.";
$messages["Directory <b>%1\$s</b> successfully chmodded to <b>%2\$s</b>"] = "Map <b>%1\$s</b> is successvol ge-chmod naar <b>%2\$s</b>";
$messages["File <b>%1\$s</b> was successfully chmodded to <b>%2\$s</b>"] = "Bestand <b>%1\$s</b> is successvol ge-chmod naar <b>%2\$s</b>";
$messages["All the selected directories and files have been processed."] = "Alle geselecteerde mappen en bestanden zijn verwerkt.";

// ftp_rmdir2()
$messages["Unable to delete the directory <b>%1\$s</b>"] = "Het verwijderen van de map <b>%1\$s</b> is mislukt.";

// ftp_delete2()
$messages["Unable to delete the file <b>%1\$s</b>"] = "Het verwijderen van het bestand <b>%1\$s</b> is mislukt";

// ftp_newdirectory()
$messages["Unable to create the directory <b>%1\$s</b>"] = "Het cre�ren van de map <b>%1\$s</b> is mislukt";

// ftp_readfile()
$messages["Unable to create the temporary file"] = "Het cre�ren van het tijdelijke bestand is mislukt";
$messages["Unable to get the file <b>%1\$s</b> from the FTP server and to save it as temporary file <b>%2\$s</b>.<br />Check the permissions of the %3\$s directory.<br />"] = "Het openen van bestand <b>%1\$s</b> van de FTP server, en op te slaan als tijdelijk bestand <b>%2\$s</b> is mislukt.<br />Controleer de rechten van de map %3\$s.<br />";
$messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "Het openen van het tijdelijke bestand is mislukt. Controleer de rechten van de map %1\$s.";
$messages["Unable to read the temporary file"] = "Het lezen van het tijdelijke bestand is mislukt";
$messages["Unable to close the handle of the temporary file"] = "Het sluiten van het tijdelijke bestand is mislukt";
$messages["Unable to delete the temporary file"] = "Het verwijderen van het tijdelijke bestand is mislukt";

// ftp_writefile()
$messages["Unable to create the temporary file. Check the permissions of the %1\$s directory."] = "Het cre�ren van het tijdelijke bestand is mislukt. Controleer de rechten van de map %1\$s.";
$messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "Het openen van het tijdelijke bestand is mislukt. Controleer de rechten van de map %1\$s.";
$messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "Het schrijven van de regel naar het bestand <b>%1\$s</b> is mislukt.<br />Controleer de rechten van de map %2\$s.";
$messages["Unable to close the handle of the temporary file"] = "Het sluiten van het tijdelijke bestand is mislukt";
$messages["Unable to put the file <b>%1\$s</b> on the FTP server.<br />You may not have write permissions on the directory."] = "Het opslaan van de bestand <b>%1\$s</b> op de FTP server is mislukt.<br />U heeft mogelijk geen schrijf rechten in deze map.";
$messages["Unable to delete the temporary file"] = "Het verwijderen van het tijdelijke bestand is mislukt";

// ftp_copymovedelete()
$messages["Processing directory <b>%1\$s</b>"] = "Map <b>%1\$s</b> wordt verwerkt";
$messages["The target directory <b>%1\$s</b> is the same as or a subdirectory of the source directory <b>%2\$s</b>, so this directory will be skipped"] = "De doel map <b>%1\$s</b> is de zelfde als, of is een onderliggende map van de bron map <b>%2\$s</b>, daarom wordt deze map overgeslagen";
$messages["Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing the copy/move process..."] = "Het aanmaken van de map <b>%1\$s</b> is mislukt. Deze bestaat mogelijk al. De kopi�ren/verplaatsen procedure wordt voortgezet...";
$messages["Created target subdirectory <b>%1\$s</b>"] = "Onderliggende doel map <b>%1\$s</b> aangemaakt";
$messages["Unable to delete the subdirectory <b>%1\$s</b> - it may not be empty"] = "Het verwijderen van de onderliggende map <b>%1\$s</b> is mislukt - deze is mogelijk niet leeg";
$messages["Deleted subdirectory <b>%1\$s</b>"] = "Onderliggende map <b>%1\$s</b> verwijderd";
$messages["Processing of directory <b>%1\$s</b> completed"] = "Verwerken van map <b>%1\$s</b> voltooid";
$messages["The target for file <b>%1\$s</b> is the same as the source, so this file will be skipped"] = "Het doel van het bestand <b>%1\$s</b> is het zelfde als de bron, daarom wordt dit bestand overgeslagen";
$messages["Unable to copy the file <b>%1\$s</b>"] = "Het kopi�ren van het bestand <b>%1\$s</b> is mislukt";
$messages["Copied file <b>%1\$s</b>"] = "Bestand <b>%1\$s</b> gekopieerd";
$messages["Unable to move the file <b>%1\$s</b>"] = "Het verplaatsen van het bestand <b>%1\$s</b> is mislukt";
$messages["Moved file <b>%1\$s</b>"] = "Bestand <b>%1\$s</b> verplaatst";
$messages["Unable to delete the file <b>%1\$s</b>"] = "Het verwijderen van het bestand <b>%1\$s</b> is mislukt";
$messages["Deleted file <b>%1\$s</b>"] = "Bestand <b>%1\$s</b> verwijderd";
$messages["All the selected directories and files have been processed."] = "Alle geselecteerde mappen en bestanden zijn verwerkt.";

// ftp_processfiles()

// ftp_getfile()
$messages["Unable to copy the remote file <b>%1\$s</b> to the local file using FTP mode <b>%2\$s</b>"] = "Het kopi�ren van het externe bestand <b>%1\$s</b> naar het locale bestand via FTP mode <b>%2\$s</b> is mislukt";
$messages["Unable to delete file <b>%1\$s</b>"] = "Het verwijderen van het bestand <b>%1\$s</b> is mislukt";

// ftp_putfile()
$messages["Unable to copy the local file to the remote file <b>%1\$s</b> using FTP mode <b>%2\$s</b>"] = "Het kopi�ren van het locale bestand naar het externe bestand <b>%1\$s</b> via FTP mode <b>%2\$s</b> is mislukt";
$messages["Unable to delete the local file"] = "Het verwijderen van het locale bestand is mislukt";

// ftp_downloadfile()
$messages["Unable to delete the temporary file"] = "Het verwijderen van de tijdelijke bestand is mislukt";
$messages["Unable to send the file to the browser"] = "Het verzenden van het bestand naar de browser is mislukt";

// ftp_zip()
$messages["Unable to create the temporary file"] = "Het cre�ren van het tijdelijke bestand is mislukt";
$messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "Het schrijven van de regel naar het tijdelijke bestand <b>%1\$s</b> is mislukt.<br />Controleer de rechten van de map %2\$s.";
$messages["Unable to close the handle of the temporary file"] = "Het sluiten van het tijdelijke bestand is mislukt";
$messages["The zip file has been saved on the FTP server as <b>%1\$s</b>"] = "Het zip bestand is opgeslagen op de FTP server als <b>%1\$s</b>";
$messages["Requested files"] = "Aangevraagde bestanden";

$messages["Zip email message"]  = "";
$messages["Zip email message"] .= "Geachte, \n\n";
$messages["Zip email message"] .= "Iemand heeft gevraagd om het bestand dat als bijlage is toegevoegd naar account (%1\$s) te versturen.\n";
$messages["Zip email message"] .= "Als u hier niks van af weet, of als u de afzender niet vertrouwd, verwijder dan a.u.b. deze email zonder de bijlage te openen.\n";
$messages["Zip email message"] .= "Als u de bijlage niet opent, kan uw computer niet worden beschadigd.\n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "Informatie over de afzender:\n";
$messages["Zip email message"] .= "IP adres: %2\$s\n";
$messages["Zip email message"] .= "Tijdstip van verzending: %3\$s\n";
$messages["Zip email message"] .= "Verstuurd met het net2ftp programma vanaf de website: %4\$s \n";
$messages["Zip email message"] .= "Webmaster's email: %5\$s \n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "Bericht van de afzender:\n";
$messages["Zip email message"] .= "%6\$s \n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "net2ftp is vrije software, uitgebracht onder de GNU/GPL licentie. Ga voor meer informatie naar http://www.net2ftp.com\n\n\n";

$messages["The zip file has been sent to <b>%1\$s</b>."] = "Het zip bestand is verzonden naar <b>%1\$s</b>.";

// acceptFiles()
$messages["File <b>%1\$s</b> is too big. This file will not be uploaded."] = "Het bestand <b>%1\$s</b> is te groot. Dit bestand zal niet worden geupload.";
$messages["Could not generate a temporary file."] = "Het cre�ren van het tijdelijke bestand is mislukt.";
$messages["File <b>%1\$s</b> could not be moved"] = "Het bestand <b>%1\$s</b> kon niet worden verplaatst";
$messages["File <b>%1\$s</b> is OK"] = "Het bestand <b>%1\$s</b> is OK";
$messages["Unable to move the uploaded file to the temp directory.<br /><br />The administrator of this website has to <b>chmod 777</b> the /temp directory of net2ftp."] = "Het verplaatsen van het geuploade bestand naar de tijdelijke map is mislukt.<br /><br />De systeembeheerder van deze website moet de /temp map van net2ftp <b>chmod-den naar 777</b>.";
$messages["You did not provide any file to upload."] = "U heeft geen bestand opgegeven dat moet worden geupload.";

// ftp_transferfiles()
$messages["File <b>%1\$s</b> could not be transferred to the FTP server"] = "Het bestand <b>%1\$s</b> kon niet worden verzonden naar de FTP server";
$messages["File <b>%1\$s</b> has been transferred to the FTP server using FTP mode <b>%2\$s</b>"] = "Het bestand <b>%1\$s</b> is verzonden naar de FTP server via FTP mode <b>%2\$s</b>";
$messages["Transferring files to the FTP server"] = "De bestanden worden verzonden naar de FTP server";

// ftp_unziptransferfiles()
$messages["Processing archive nr %1\$s: <b>%2\$s</b>"] = "Het archief nummer %1\$s: <b>%2\$s</b> wordt verwerkt";
$messages["Unable to open the archive <b>%1\$s</b> (file %2\$s)"] = "Het openen van het archief <b>%1\$s</b> (file %2\$s) is mislukt";
$messages["Could not create directory <b>%1\$s</b>"] = "Het aanmaken van de map <b>%1\$s</b> is mislukt";
$messages["Created directory <b>%1\$s</b>"] = "Map <b>%1\$s</b> aangemaakt";
$messages["File Contents:"] = "Bestand Inhoud:";
$messages["Could not put the file <b>%1\$s</b> to the directory <b>%2\$s</b>"] = "Het plaatsen van het bestand <b>%1\$s</b> in de map <b>%2\$s</b> is mislukt";
$messages["Transferred file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "Verzonden van bestand <b>%1\$s</b> naar map <b>%2\$s</b>";
$messages["Unable to delete the archive <b>%1\$s</b> (file %2\$s)"] = "Het verwijderen van het archief <b>%1\$s</b> (file %2\$s) is mislukt";
$messages["Unable to get the list of the contents of the Zip archive. Error code: %1\$s"] = "Het verkrijgen van de lijst met inhoud van het Zip archief is mislukt. Foutmelding: %1\$s";
$messages["Unable to get the list of the contents of the Tar archive."] = "Het verkrijgen van de lijst met inhoud van het Tar archief is mislukt.";
$messages["Could not create directory <b>%1\$s</b>"] = "Het cre�ren van de map <b>%1\$s</b> is mislukt";
$messages["Created directory <b>%1\$s</b>"] = "Gecre�erde map <b>%1\$s</b>";
$messages["Unable to create the temporary file"] = "Het cre�ren van het tijdelijke bestand is mislukt";
$messages["Unable to extract file nr <b>%1\$s</b> from the archive."] = "Het uitpakken van bestand nummer <b>%1\$s</b> uit het archief is mislukt.";
$messages["Could not put file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "Het plaatsen van bestand <b>%1\$s</b> in map <b>%2\$s</b> is mislukt";
$messages["Transferred file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "Verzonden van bestand <b>%1\$s</b> naar map <b>%2\$s</b>";
$messages["Unable to delete the temporary file <b>%1\$s</b>."] = "Het verwijderen van het tijdelijke bestand <b>%1\$s</b> is mislukt.";
$messages["Archive <b>%1\$s</b> was not processed because its filename extension was not recognized. Only zip, tar, tgz and gz archives are supported at the moment."] = "Archief <b>%1\$s</b> is niet verwerkt omdat de extensie niet is herkent. Op dit moment worden alleen zip, tar, tgz and gz archieven ondersteund.";
$messages["Unzipping and transferring files"] = "Bezig met uitpakken en versturen van bestanden";

// ftp_mysite()
$messages["Unable to execute site command <b>%1\$s</b>"] = "Het uitvoeren van het commando <b>%1\$s</b> is mislukt";

// shutdown()
$messages["Shutdown message"]  = "";
$messages["Shutdown message"] .= "<b>Uw opdracht is gestopt</b><br /><br />";
$messages["Shutdown message"] .= "De opdracht die u probeerde uit te voeren met net2ftp duurde langer dan de toegestane %1\$s seconden, en is daarom gestopt.<br />";
$messages["Shutdown message"] .= "Deze tijd limiet garandeert een eerlijk gebruik van de web server voor iedereen.<br /><br />";
$messages["Shutdown message"] .= "Probeer uw opdracht op te splitsen in een kleiner aantal bestanden.<br /><br />";
$messages["If you really need net2ftp to be able to handle big tasks which take a long time, consider installing net2ftp on your own server."] = "Als u wil dat net2ftp grote opdrachten kan uitvoeren, overweeg dan om net2ftp op uw eigen server te installeren.";

// SendMail()
$messages["You did not provide any text to send by email!"] = "U heeft geen tekst opgegeven om te worden verzonden met de email!";
$messages["You did not supply a From address."] = "U heeft geen afzender adres opgegeven.";
$messages["You did not supply a To address."] = "U heeft geen ontvangst adres opgegeven.";
$messages["Due to technical problems the email to <b>%1\$s</b> could not be sent."] = "In verband met technische problemen kon de email naar <b>%1\$s</b> niet worden verzonden.";

// printFunctionTags()
$messages["Output generated by function %1\$s"] = "Resultaat gegenereerd door de functie %1\$s";




// -------------------------------------------------------------------------
// homepage.inc.php
if ($state == "homepage") {
// -------------------------------------------------------------------------
$messages["net2ftp features short"] ="Zodra u bent ingelogd, bent u in staat tot: \n";
$messages["net2ftp features short"] .="<ul>\n";
$messages["net2ftp features short"] .="<li> door de FTP server te navigeren</li>\n";
$messages["net2ftp features short"] .="<li> uploaden downloaden <span style=\"font-size: 80%%; color: red;\">nieuw: ongelimiteerd aantal upload bestanden</span></li>\n";
$messages["net2ftp features short"] .="<li> kopi�ren verplaatsen verwijderen hernoemen chmod-en</li>\n";
$messages["net2ftp features short"] .="<li> kopi�ren/verplaatsen naar een tweede FTP server</li>\n";
$messages["net2ftp features short"] .="<li> bekijken van de bron met syntax highlighting</li>\n";
$messages["net2ftp features short"] .="<li> bekijken van afbeeldingen <span style=\"font-size: 80%%; color: red;\">nieuw</span></li>\n";
$messages["net2ftp features short"] .="<li> bewerken van tekst bestanden</li>\n";
$messages["net2ftp features short"] .="<li> bewerken van HTML in verschillende HTML editors <span style=\"font-size: 80%%; color: red;\">nieuw</span></li>\n";
$messages["net2ftp features short"] .="<li> bewerken van HTML en PHP met syntax accent <span style=\"font-size: 80%%; color: red;\">beta</span></li>\n";
$messages["net2ftp features short"] .="<li> zip bestanden om te downloaden, emailen en op te slaan</li>\n";
$messages["net2ftp features short"] .="<li> uploaden-en-uitpakken (zip, tar, tgz, gz)</li>\n";
$messages["net2ftp features short"] .="<li> zoeken naar woorden en uitdrukkingen</li>\n";
$messages["net2ftp features short"] .="<li> berekenen van de grootte van mappen en bestanden</li>\n";
$messages["net2ftp features short"] .="</ul>\n";

} // end homepage


// -------------------------------------------------------------------------
// net2ftp_loginform.inc.php
// -------------------------------------------------------------------------
$messages["FTP server"] = "FTP server";
$messages["Example"] = "Voorbeeld";
$messages["Username"] = "Gebruikersnaam";
$messages["Password"] = "Wachtwoord";
$messages["Anonymous"] = "Anoniem";
$messages["Passive mode"] = "Passieve mode";
$messages["Initial directory"] = "Begin map";
$messages["Language"] = "Taal";
$messages["Skin"] = "Uiterlijk";
$messages["FTP mode"] = "FTP mode";
$messages["Login"] = "Inloggen";
$messages["Clear cookies"] = "Verwijder cookies";
$messages["Please enter an FTP server."] = "Gelieve een FTP server in te vullen.";
$messages["Please enter a username."] = "Gelieve een gebruikersnaam in te vullen.";
$messages["Please enter a password."] = "Gelieve een paswoord in te vullen.";


// -------------------------------------------------------------------------
// html.inc.php
// -------------------------------------------------------------------------

// HtmlBegin()
$messages["Status:"] = "Status:";

// HtmlEnd()
$messages["net2ftp Help Guide"] = "net2ftp Handleiding";
$messages["net2ftp Forums"] = "net2ftp Forums";
$messages["License"] = "Licentie";
$messages["Powered by"] = "Aangedreven door";

// printJavascriptFunctions()
$messages["Choose a directory"] = "Kies een map";
$messages["Please wait..."] = "Even wachten...";
$messages["Uploading... please wait..."] = "Aan het uploaden... even wachten...";
$messages["If the upload takes more than the allowed <b>%1\$s seconds<\/b>, you will have to try again with less/smaller files."] = "Als het uploaden langer duurt dan de toegestane <b>%1\$s<\/b> seconden, moet u het opnieuw proberen met minder/kleinere bestanden.";
$messages["This window will close automatically in a few seconds."] = "Dit venster wordt automatisch gesloten in enkele seconden.";
$messages["Close window now"] = "Sluit dit venster";


// -------------------------------------------------------------------------
// httpheaders.inc.php
// -------------------------------------------------------------------------
// Nothing to translate


// -------------------------------------------------------------------------
// manage.inc.php
if ($state == "manage") {
// -------------------------------------------------------------------------

// manage()
$messages["Please select at least one directory or file!"] = "Kies minimaal ��n map of bestand!";
$messages["Unexpected state2 string. Exiting."] = "Onverwachte state2 string. De applicatie wordt onderbroken.";

// renameentry()
if ($state2 == "rename") {
$messages["Rename directories and files"] = "Hernoem mappen en bestanden";
$messages["Old name: "] = "Oude naam: ";
$messages["New name: "] = "Nieuwe naam: ";
$messages["The new name may not contain any dots. This entry was not renamed to <b>%1\$s</b>"] = "De nieuwe naam mag geen punten bevatten. Deze reeks is niet hernoemt naar <b>%1\$s</b>";
$messages["<b>%1\$s</b> was successfully renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> is succesvol hernoemd naar <b>%2\$s</b>";
$messages["<b>%1\$s</b> could not be renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> is niet hernoemd naar <b>%2\$s</b>";
}

// chmodentry()
if ($state2 == "chmod") {
$messages["Chmod directories and files"] = "Chmod mappen en bestanden";
$messages["Set all permissions"] = "Wijzig alle rechten";
$messages["Read"] = "Lezen";
$messages["Write"] = "Schrijven";
$messages["Execute"] = "Uitvoeren";
$messages["Owner"] = "Eigenaar";
$messages["Group"] = "Groep";
$messages["Everyone"] = "Iedereen";
$messages["To set all permissions to the same values, enter those permissions above and click on the button \"Set all permissions\""] = "Om alle rechten gelijk te maken, specificeer deze rechten hierboven en klik op de knop \"Wijzig alle rechten\"";
$messages["Set the permissions of directory <b>%1\$s</b> to: "] = "Stel de rechten van me map <b>%1\$s</b> in op: ";
$messages["Set the permissions of file <b>%1\$s</b> to: "] = "Stel de rechten van het bestand <b>%1\$s</b> in op: ";
$messages["Set the permissions of symlink <b>%1\$s</b> to: "] = "Stel de rechten van de symlink <b>%1\$s</b> in op: ";
$messages["Chmod value"] = "Chmod waarde";
$messages["Chmod also the subdirectories within this directory"] = "Chmod ook de onderliggende mappen van deze map";
$messages["Chmod also the files within this directory"] = "Chmod ook alle bestanden in deze map";
$messages["The chmod nr <b>%1\$s</b> is out of the range 000-777. Please try again."] = "Het chmod nummer <b>%1\$s</b> is buiten het limiet van 000-777. Probeert u het a.u.b. opnieuw.";
}

// copymovedeleteentry()
if ($state2 == "copy" || $state2 == "move" || $state2 == "delete") {
$messages["Copy directories and files"] = "Kopieer mappen en bestanden";
$messages["Move directories and files"] = "Verplaats mappen en bestanden";
$messages["Delete directories and files"] = "Verwijder mappen en bestanden";
$messages["Are you sure you want to delete these directories and files?"] = "Weet u zeker dat u deze mappen en bestanden wilt verwijderen?";
$messages["All the subdirectories and files of the selected directories will also be deleted!"] = "Alle onderliggende mappen zullen ook worden verwijderd!";
$messages["Set all targetdirectories"] = "Stel alle doel mappen in";
$messages["To set a common target directory, enter that target directory in the textbox above and click on the button \"Set all targetdirectories\"."] = "Om een gemeenschappelijke doel map op te geven, voer die doel map in in de bovenstaande textbox, en klik op de knop \"Stel alle doel mappen in\".";
$messages["Note: the target directory must already exist before anything can be copied into it."] = "Opmerking: deze doel map moet reeds bestaan voordat er iets naar toe kan worden gekopieerd.";
$messages["Different target FTP server:"] = "Andere doel FTP server:";
$messages["Leave empty if you want to copy the files to the same FTP server."] = "Laat leeg als u de bestanden naar de zelfde FTP server wilt kopi�ren.";
$messages["If you want to copy the files to another FTP server, enter your login data."] = "Als u de bestanden naar een andere FTP server wilt kopi�ren, voert u dan de login gegevens in.";
$messages["Leave empty if you want to move the files to the same FTP server."] = "Laat leeg als u de bestanden naar de zelfde FTP server wilt kopi�ren.";
$messages["If you want to move the files to another FTP server, enter your login data."] = "Als u de bestanden naar een andere FTP server wilt kopi�ren, voert u dan de login gegevens in.";
$messages["Copy directory <b>%1\$s</b> to:"] = "Kopieer map <b>%1\$s</b> naar:";
$messages["Move directory <b>%1\$s</b> to:"] = "Verplaats map <b>%1\$s</b> naar:";
$messages["Directory <b>%1\$s</b>"] = "Map <b>%1\$s</b>";
$messages["Copy file <b>%1\$s</b> to:"] = "Kopieer bestand <b>%1\$s</b> naar:";
$messages["Move file <b>%1\$s</b> to:"] = "Verplaats bestand <b>%1\$s</b> naar:";
$messages["File <b>%1\$s</b>"] = "Bestand <b>%1\$s</b>";
$messages["Copy symlink <b>%1\$s</b> to:"] = "Kopieer symlink <b>%1\$s</b> naar:";
$messages["Move symlink <b>%1\$s</b> to:"] = "Verplaats symlink <b>%1\$s</b> naar:";
$messages["Symlink <b>%1\$s</b>"] = "Symlink <b>%1\$s</b>";
$messages["Target directory:"] = "Doel map:";
$messages["Target name:"] = "Doel naam:";
$messages["Processing the entries:"] = "Verwerk de reeks:";
}

// newdirectory()
if ($state2 == "newdirectory") {
$messages["Create new directories"] = "Cre�er nieuwe map";
$messages["The new directories will be created in <b>%1\$s</b>."] = "De nieuwe map wordt gecre�erd in <b>%1\$s</b>.";
$messages["New directory name:"] = "Nieuwe map naam:";
$messages["Directory <b>%1\$s</b> was successfully created."] = "De map <b>%1\$s</b> is succesvol gecre�erd.";
}

// uploadfile()
if ($state2 == "uploadfile") {
$messages["Upload files and archives"] = "Upload bestanden en archieven";
$messages["Upload results"] = "Upload resultaten";
$messages["Checking files:"] = "Controleren van bestanden:";
$messages["Transferring files to the FTP server:"] = "Bestanden worden naar de FTP server verzonden:";
$messages["Decompressing archives and transferring files to the FTP server:"] = "Archieven worden uitgepakt en verzonden naar de FTP server:";
$messages["Upload more files and archives"] = "Upload meer bestanden en archieven";
}

// printUploadForm() and javaupload()
if ($state2 == "uploadfile" || $state2 == "javaupload") {
$messages["Upload to directory:"] = "Upload naar map:";
$messages["Files"] = "Bestanden";
$messages["Archives"] = "Archieven";
$messages["Files entered here will be transferred to the FTP server."] = "Deze opgegeven bestanden worden naar de FTP server verzonden.";
$messages["Archives entered here will be decompressed, and the files inside will be transferred to the FTP server."] = "Deze opgegeven archieven zullen worden uitgepakt, en de inhoud zal naar de FTP server worden verzonden";
$messages["Add another"] = "Voeg nog een toe";
$messages["Use folder names (creates subdirectories automatically)"] = "Gebruik map structuur (cre�ert onderliggende mappen automatisch)";
$messages["Restrictions:"] = "Beperkingen:";
$messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s kB</b> and by PHP to <b>%2\$s</b>"] = "De maximale grootte van de bestanden zijn beperkt door net2ftp tot <b>%1\$s kB</b> en door PHP tot <b>%2\$s</b>";
$messages["The maximum execution time is <b>%1\$s seconds</b>"] = "De maximale uitvoeringstijd is <b>%1\$s seconden</b>";
$messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "De FTP verzend mode (ASCII of BINARY) wordt automatisch gedetecteerd, afhankelijk van de bestandsnaam extensie";
$messages["If the destination file already exists, it will be overwritten"] = "Als het doel bestand al bestaat, wordt deze overschreven";

$messages["Upload directories and files using a Java applet"] = "Upload mappen en bestanden met een Java applet";
$messages["Number of files:"] = "Aantal bestanden:";
$messages["Size of files:"] = "Grootte van bestanden:";
$messages["Add"] = "Voeg toe";
$messages["Remove"] = "Verwijder";
$messages["Upload"] = "Upload";
$messages["Add files to the upload queue"] = "Voeg bestanden toe aan de upload wachtrij";
$messages["Remove files from the upload queue"] = "Verwijder bestanden uit de upload wachtrij";
$messages["Upload the files which are in the upload queue"] = "Upload de bestanden die in de wachtrij staan";
$messages["Maximum server space exceeded. Please select less/smaller files."] = "Maximum ruimte op server overschreden. Selecteer a.u.b. minder/kleinere bestanden.";
$messages["Total size of the files is too big. Please select less/smaller files."] = "De totale grootte van de bestanden is te groot. Selecteer a.u.b. minder/kleinere bestanden.";
$messages["Total number of files is too high. Please select fewer files."] = "Er zijn teveel bestanden opgegeven. Selecteer a.u.b. minder bestanden.";
$messages["Note: to use this applet, Sun's Java plugin must be installed (version 1.4 or newer)."] = "Opmerking: om van deze applet gebruik te maken moet Sun's Java plugin zijn geinstalleerd (versie 1.4 of nieuwer).";

$messages["Browser does not support Java applets"] = "Uw browser ondersteund geen applets, of u heeft applets uitgeschakeld in de instellingen van uw browser.\n";
$messages["Browser does not support Java applets"] .= "Installeer a.u.b. de nieuwste versie van Sun's java om van deze applet gebruik te maken. Deze kunt u vinden op <a href=\"http://www.java.com/\">java.com</a>. Klik op Get It Now.\n";
$messages["Browser does not support Java applets"] .= "De online installatie is ongeveer 1-2 MB groot, en de offline installatie ongeveer 13 MB. De 'end-user' java wordt JRE genoemd (Java Runtime Environment).\n";
$messages["Browser does not support Java applets"] .= "Gebruik anders net2ftp's normale upload of upload-en-uitpak functionaliteit.\n";
}

// zipentry()
if ($state2 == "zip") {
$messages["Zip entries"] = "Zip reeks";
$messages["Save the zip file on the FTP server as:"] = "Sla het zip bestand op de FTP server op als:";
$messages["Email the zip file in attachment to:"] = "Email het zip bestand als bijlage naar:";
$messages["Note that sending files is not anonymous: your IP address as well as the time of the sending will be added to the email."] = "Let op dat dit niet anoniem gebeurd: uw IP adres, en de tijd waarop deze is verzonden wordt toegevoegd aan de email.";
$messages["Some additional comments to add in the email:"] = "Voeg een opmerking toe aan deze email:";
$messages["You did not enter a filename for the zipfile. Go back and enter a filename."] = "U heeft geen bestandsnaam opgegeven voor het zip bestand. Ga terug, en geef deze op.";
$messages["The email address you have entered (%1\$s) does not seem to be valid.<br />Please enter an address in the format <b>username@domain.com</b>"] = "Het door u opgegeven email adres (%1\$s) is ongeldig.<br />Gebruik het formaat <b>gebruikersnaam@domein.com</b>";
}

// calculatesize()
if ($state2 == "calculatesize") {
$messages["Size of selected directories and files"] = "Grootte van de geselecteerde mappen en bestanden";
$messages["The total size taken by the selected directories and files is:"] = "De totale grootte van de geselecteerde mappen en bestanden is:";
$messages["The nr of files which were skipped:"] = "Het aantal overgeslagen bestanden:";
}

// findstring()
if ($state2 == "findstring") {
$messages["Search directories and files"] = "Doorzoek mappen en bestanden";
$messages["Search results"] = "Zoek resultaten";
$messages["Please enter a valid search word or phrase."] = "Kies a.u.b. een geldig zoek woord of uitdrukking.";
$messages["Please enter a valid filename."] = "Kies a.u.b. een geldig bestandsnaam.";
$messages["Please enter a valid file size in the \"from\" textbox, for example 0."] = "Kies a.u.b. een geldig bestands grootte in de \"van\" textbox, bijvoorbeeld 0.";
$messages["Please enter a valid file size in the \"to\" textbox, for example 500000."] = "Kies a.u.b. een geldig bestands grootte in de \"tot\" textbox, bijvoorbeeld 500000.";
$messages["Please enter a valid date in Y-m-d format in the \"from\" textbox."] = "Kies a.u.b. een geldige datum in het Y-m-d formaat in de \"van\" textbox.";
$messages["Please enter a valid date in Y-m-d format in the \"to\" textbox."] = "Kies a.u.b. een geldige datum in het Y-m-d formaat in de \"tot\" textbox.";
$messages["The word <b>%1\$s</b> was not found in the selected directories and files."] = "Het woord <b>%1\$s</b> is niet gevonden in de geselecteerde mappen en bestanden.";
$messages["The word <b>%1\$s</b> was found in the following files:"] = "Het woord <b>%1\$s</b> is gevonden in de volgende bestanden:";
$messages["Search again"] = "Zoek opnieuw";
}

// printFindstringForm()
if ($state2 == "findstring") {
$messages["Search for a word or phrase"] = "Zoek naar een woord of uitdrukking";
$messages["Case sensitive search"] = "Zoek hoofdletter gevoelig";
$messages["Restrict the search to:"] = "Beperk het zoeken tot:";
$messages["files with a filename like"] = "bestanden met een bestandsnaam die lijken op";
$messages["(wildcard character is *)"] = "(wildcard karakter is *)";
$messages["files with a size"] = "bestand met een grootte";
$messages["from"] = "van";
$messages["to"] = "tot";
$messages["files which were last modified"] = "bestanden die als laatst zijn gewijzigd";
}

// updatefile()
if ($state2 == "updatefile") {
$messages["Update file"] = "Update bestanden";
$messages["<b>WARNING: THIS FUNCTION IS STILL IN EARLY DEVELOPMENT. USE IT ONLY ON TEST FILES! YOU HAVE BEEN WARNED!"] = "<b>WAARSCHUWING: DEZE FUNCTIE IS PAS IN EEN VROEGE ONTWERPFASE. GEBRUIK HET ALLEEN OP TEST BESTANDEN! U BENT GEWAARSCHUWD!";
$messages["Known bugs: - erases tab characters - doesn't work well with big files (> 50kB) - was not tested yet on files containing non-standard characters</b>"] = "Bekende fouten: - verwijderd tab karakters - werkt niet goed op grootte bestanden (> 50kB) - is niet getest op bestanden die niet-standaard karakters bevatten</b>";
$messages["This function allows you to upload a new version of the selected file, to view what are the changes and to accept or reject each change. Before anything is saved, you can edit the merged files."] = "Deze functie stelt u in staat om een nieuwere versie van een bestand te uploaden, om de wijzigingen te bekijken, en om deze wijzigingen te accepteren of af te wijzen. Voordat er iets wordt opgeslagen kunt u wijzigingen in de samengevoegde bestanden toebrengen.";
$messages["Old file:"] = "Oud bestand:";
$messages["New file:"] = "Nieuw bestand:";
$messages["Restrictions:"] = "Beperkingen:";
$messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s kB</b> and by PHP to <b>%2\$s</b>"] = "De maximale bestandsgrootte van een bestand is beperkt door net2ftp tot <b>%1\$s kB</b> en door PHP tot <b>%2\$s</b>";
$messages["The maximum execution time is <b>%1\$s seconds</b>"] = "De maximale uitvoeringstijd is <b>%1\$s seconden</b>";
$messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "De FTP verzend mode (ASCII of BINARY) wordt automatisch gedetecteerd, afhankelijk van de bestandsnaam extensie";
$messages["If the destination file already exists, it will be overwritten"] = "Als het doel bestand al bestaat, wordt deze overschreven";
$messages["You did not provide any files or archives to upload."] = "U heeft geen bestanden of archieven opgegeven om te worden geupload.";
$messages["Unable to delete the new file"] = "Het verwijderen van het nieuwe bestand is mislukt";
}

// printComparisonSelect()
if ($state2 == "updatefile") {
$messages["Please wait..."] = "Even wachten...";
$messages["Select lines below, accept or reject changes and submit the form."] = "Selecteer onderstaande lijnen, accepteer of verwerp wijzigingen in het formulier.";
}

} // end manage


// -------------------------------------------------------------------------
// registerglobals.inc.php
// -------------------------------------------------------------------------
$messages["Please enter your username and password for FTP server "] = "Geef uw gebruikersnaam en wachtwoord op voor FTP server ";
$messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "U heeft geen inlog gegevens opgegeven.<br />Klik hieronder op \"Ga naar de login pagina\" om in te loggen.";
$messages["Access to the net2ftp Admin panel is disabled, because no password has been set in the file settings.inc.php. Enter a password in that file, and reload this page."] = "De toegang tot de net2ftp Admin panel is uitgeschakeld, omdat er geen wachtwoord is opgegeven in het bestand settings.inc.php. Voeg een wachtwoord toe in dat bestand, en vernieuw deze pagina.";
$messages["Please enter your Admin username and password"] = "Geef a.u.b. uw Admin gebruikersnaam en wachtwoord op"; 
$messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "U heeft geen inlog gegevens opgegeven in het popup venster.<br />Klik hieronder op \"Ga naar de login pagina\".";
$messages["Wrong username or password for the net2ftp Admin panel. The username and password can be set in the file settings.inc.php."] = "De gebruikersnaam en wachtwoord voor de Admin panel is ongeldig. De gebruikersnaam en wachtwoord kan worden ingesteld in het bestand settings.inc.php.";


// -------------------------------------------------------------------------
// skins.inc.php
// -------------------------------------------------------------------------
$messages["Blue"] = "Blauw";
$messages["Grey"] = "Grijs";
$messages["Black"] = "Zwart";
$messages["Yellow"] = "Geel";
$messages["Pastel"] = "Pastel";

// getMime()
$messages["Directory"] = "Map";
$messages["Symlink"] = "Symlink";
$messages["ASP script"] = "ASP script";
$messages["Cascading Style Sheet"] = "Cascading Style Sheet";
$messages["HTML file"] = "HTML bestand";
$messages["Java source file"] = "Java source bestand";
$messages["JavaScript file"] = "JavaScript bestand";
$messages["PHP Source"] = "PHP Source";
$messages["PHP script"] = "PHP script";
$messages["Text file"] = "Tekst bestand";
$messages["Bitmap file"] = "Bitmap bestand";
$messages["GIF file"] = "GIF bestand";
$messages["JPEG file"] = "JPEG bestand";
$messages["PNG file"] = "PNG bestand";
$messages["TIF file"] = "TIF bestand";
$messages["GIMP file"] = "GIMP bestand";
$messages["Executable"] = "Uitvoerbaar bestand";
$messages["Shell script"] = "Shell script";
$messages["MS Office - Word document"] = "MS Office - Word document";
$messages["MS Office - Excel spreadsheet"] = "MS Office - Excel spreadsheet";
$messages["MS Office - PowerPoint presentation"] = "MS Office - PowerPoint presentatie";
$messages["MS Office - Access database"] = "MS Office - Access database";
$messages["MS Office - Visio drawing"] = "MS Office - Visio afbeelding";
$messages["MS Office - Project file"] = "MS Office - Project bestand";
$messages["OpenOffice - Writer 6.0 document"] = "OpenOffice - Writer 6.0 document";
$messages["OpenOffice - Writer 6.0 template"] = "OpenOffice - Writer 6.0 template";
$messages["OpenOffice - Calc 6.0 spreadsheet"] = "OpenOffice - Calc 6.0 spreadsheet";
$messages["OpenOffice - Calc 6.0 template"] = "OpenOffice - Calc 6.0 template";
$messages["OpenOffice - Draw 6.0 document"] = "OpenOffice - Draw 6.0 document";
$messages["OpenOffice - Draw 6.0 template"] = "OpenOffice - Draw 6.0 template";
$messages["OpenOffice - Impress 6.0 presentation"] = "OpenOffice - Impress 6.0 presentatie";
$messages["OpenOffice - Impress 6.0 template"] = "OpenOffice - Impress 6.0 template";
$messages["OpenOffice - Writer 6.0 global document"] = "OpenOffice - Writer 6.0 global document";
$messages["OpenOffice - Math 6.0 document"] = "OpenOffice - Math 6.0 document";
$messages["StarOffice - StarWriter 5.x document"] = "StarOffice - StarWriter 5.x document";
$messages["StarOffice - StarWriter 5.x global document"] = "StarOffice - StarWriter 5.x global document";
$messages["StarOffice - StarCalc 5.x spreadsheet"] = "StarOffice - StarCalc 5.x spreadsheet";
$messages["StarOffice - StarDraw 5.x document"] = "StarOffice - StarDraw 5.x document";
$messages["StarOffice - StarImpress 5.x presentation"] = "StarOffice - StarImpress 5.x presentatie";
$messages["StarOffice - StarImpress Packed 5.x file"] = "StarOffice - StarImpress Packed 5.x bestand";
$messages["StarOffice - StarMath 5.x document"] = "StarOffice - StarMath 5.x document";
$messages["StarOffice - StarChart 5.x document"] = "StarOffice - StarChart 5.x document";
$messages["StarOffice - StarMail 5.x mail file"] = "StarOffice - StarMail 5.x mail bestand";
$messages["Adobe Acrobat document"] = "Adobe Acrobat document";
$messages["ARC archive"] = "ARC archief";
$messages["ARJ archive"] = "ARJ archief";
$messages["RPM"] = "RPM";
$messages["GZ archive"] = "GZ archief";
$messages["TAR archive"] = "TAR archief";
$messages["Zip archive"] = "Zip archief";
$messages["MOV movie file"] = "MOV film bestand";
$messages["MPEG movie file"] = "MPEG film bestand";
$messages["Real movie file"] = "Real film bestand";
$messages["Quicktime movie file"] = "Quicktime film bestand";
$messages["Shockwave flash file"] = "Shockwave flash bestand";
$messages["Shockwave file"] = "Shockwave bestand";
$messages["WAV sound file"] = "WAV geluids bestand";
$messages["Font file"] = "Font bestand";
$messages["%1\$s File"] = "%1\$s Bestand";
$messages["File"] = "Bestand";

// getAction()
$messages["Back"] = "Terug";
$messages["Submit"] = "Verzenden";
$messages["Refresh"] = "Vernieuwen";
$messages["Details"] = "Details";
$messages["Icons"] = "Iconen";
$messages["List"] = "Lijst";
$messages["Logout"] = "Uitloggen";
$messages["Help"] = "Help";
$messages["Bookmark"] = "Favoriet";
$messages["Save"] = "Opslaan";
$messages["Default"] = "Standaard";


// -------------------------------------------------------------------------
// view.inc.php
// -------------------------------------------------------------------------
$messages["Image"] = "Image";
$messages["View Macromedia ShockWave Flash movie %1\$s"] = "Bekijk Macromedia ShockWave Flash video %1\$s";
$messages["View file %1\$s"] = "View file %1\$s";
$messages["To save the image, right-click on it and choose 'Save picture as...'"] = "Voor het opslaan van deze afbeelding: rechter muisklik op de afbeelding, en kies 'Afbeelding opslaan als...'";


// ----------------------------------------------------------------------------------
// DO NOT CHANGE ANYTHING BELOW THIS LINE
// ----------------------------------------------------------------------------------

return $messages;


} // end function getMessages

?>