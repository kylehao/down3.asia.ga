<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------

//   -------------------------------------------------------------------------------
//  | Language: German (Deutsch)                                                    |
//   -------------------------------------------------------------------------------
//  | Danny       <email>            2004-04-05                                     |
//  | Mike Haller <info@jupload.biz> 2004-12-05                                     |
//   -------------------------------------------------------------------------------
//  |                                                                               |
//  |                              INSTRUCTIONS                                     |
//  |                                                                               |
//  |  The messages to translate are listed below.                                  |
//  |  The structure of each line is like this:                                     |
//  |     $message["Hello world!"] = "Hello world!";                                |
//  |                                                                               |
//  |  Keep the text between square brackets [] as it is.                           |
//  |  Translate the 2nd part, keeping the same punctuation and HTML tags.          |
//  |                                                                               |
//  |  The English message, for example                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is written in PHP!";    |
//  |  should become after translation:                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp est ecrit en PHP!";     |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is geschreven in PHP!"; |
//  |                                                                               |
//  |  Note that the variable starts with a dollar sign $, that the value is        |
//  |  enclosed in double quotes " and that the line ends with a semi-colon ;       |
//  |  Be careful when editing this file, do not erase those special characters.    |
//  |                                                                               |
//  |  Some messages also contain one or more variables which start with a percent  |
//  |  sign, for example %1\$s or %2\$s. The English message, for example           |
//  |     $messages[...] = ["The file %1\$s was copied to %2\$s "]                  |
//  |  should becomes after translation:                                            |
//  |     $messages[...] = ["Le fichier %1\$s a �t� copi� vers %2\$s "]             |
//  |                                                                               |
//  |  When a real percent sign % is needed in the text it is entered as %%         |
//  |  otherwise it is interpreted as a variable. So no, it's not a mistake.        |
//  |                                                                               |
//  |  Between the messages to translate there is additional PHP code, for example: |
//  |     if ($state2 == "rename") {                               // <-- PHP code  |
//  |     $messages["Rename directories"] = "Rename directories";  // <-- message   |
//  |     }                                                        // <-- PHP code  |
//  |  This code is needed to load the messages only when they are actually needed. |
//  |  There is no need to change or delete any of that PHP code; translate only    |
//  |  the message.                                                                 |
//  |                                                                               |
//  |  Thanks in advance to all the translators!                                    |
//  |  David.                                                                       |
//  |                                                                               |
//   -------------------------------------------------------------------------------

function getMessages() {
global $state, $state2;


// -------------------------------------------------------------------------
// Used encoding
// -------------------------------------------------------------------------
$messages["iso-8859-1"] = "iso-8859-1";


// -------------------------------------------------------------------------
// Status messages
// -------------------------------------------------------------------------
// When translating these messages, keep in mind that the text should not be too long
// It should fit in the status textbox
$messages["Connecting to the FTP server"] = "Verbindung zum FTP-Server wird hergestellt";
$messages["Getting the list of directories and files"] = "Ordner- und Dateiliste wird empfangen";
$messages["Printing the list of directories and files"] = "Ordner- und Dateiliste wird erstellt";
$messages["Processing the entries"] = "Verarbeiten der Eintr�ge";
$messages["Checking files"] = "Verarbeiten der Dateien";
$messages["Transferring files to the FTP server"] = "Dateien werden zum FTP-Server geschickt";
$messages["Decompressing archives and transferring files"] = "Archive werden entpackt und die Dateien transferriert";
$messages["Searching the files..."] = "Dateien werden gesucht...";
$messages["Uploading new file"] = "Upload der neuen Datei";
$messages["Reading the new file"] = "Lesen der neuen Datei";
$messages["Reading the old file"] = "Lesen der alten Datei";
$messages["Comparing the 2 files"] = "Vergleich der 2 Dateien";
$messages["Printing the comparison"] = "Ausgabe des Vergleichs";
$messages["Script finished in %1\$s seconds"] = "Script beendet in %1\$s Sekunden";
$messages["Script halted"] = "Script angehalten";


// -------------------------------------------------------------------------
// index.php
// -------------------------------------------------------------------------
$messages["Unexpected state string. Exiting."] = "Unerwartete Zeichenkette. Beende.";
$messages["This beta function is not activated on this server."] = "Dies Beta-Funktion ist auf Ihrem Server nicht aktiviert.";
$messages["This function has been disabled by the Administrator of this website."] = "This function has been disabled by the Administrator of this website.";


// -------------------------------------------------------------------------
// admin.inc.php
if ($state == "admin") {
// -------------------------------------------------------------------------
$messages["Admin functions"] = "Administrationsfunktionen";

$messages["Version information"] = "Versionsinformationen";
$messages["This version of net2ftp is up-to-date"] = "Diese Version von net2ftp ist aktuell.";
$messages["The latest version could not be retrieved from the net2ftp.com server. Check the security settings of your browser, which may prevent the loading of a small file from the net2ftp.com server."] = "Die aktuellste Version konnte nicht vom net2ftp.com Server geladen werden. Bitte pr&uuml;fen Sie die Sicherheitseinstellungen Ihres Webbrowsers, die m�glicherweise den Download einer kleinen Datei vom net2ftp.com Server verhindern.";

$messages["Logging"] = "Logging";
$messages["Date from:"] = "Datum ab:";
$messages["to:"] = "bis:";
$messages["Empty logs"] = "Leer";
$messages["View logs"] = "Logs betrachten";
$messages["No data"] = "Keine Daten";

$messages["Setup MySQL tables"] = "MySQL-Tabellen einrichten";
$messages["Go"] = "Weiter";
$messages["Create the MySQL database tables"] = "Anlegen der MySQL-Datenbanktabellen";
$messages["Create tables"] = "Tabellen anlegen";
$messages["The handle of file %1\$s could not be opened"] = "Die Referenz zur Datei %1\$s konnte nicht ge&ouml;ffnet werden";
$messages["The file %1\$s could not be opened"] = "Die Datei %1\$s konnte nicht ge&ouml;ffnet werden";
$messages["The handle of file %1\$s could not be closed"] = "Die Referenz zur Datei %1\$s konnte nicht geschlossen werden";
$messages["MySQL username"] = "MySQL Benutzername";
$messages["MySQL password"] = "MySQL Kennwort";
$messages["MySQL database"] = "MySQL Datenbankname";
$messages["MySQL server"] = "MySQL Server";
$messages["This SQL query is going to be executed:"] = "Folgende SQL-Anfrage wird ausgef&uuml;hrt:";
$messages["Execute"] = "Ausf�hren";
$messages["Settings used:"] = "Verwendete Einstellungen:";
$messages["MySQL password length"] = "MySQL Kennwortl&auml;nge";
$messages["Results:"] = "Ergebnisse:";
$messages["The connection to the server <b>%1\$s</b> could not be set up"] = "Die Verbindung zum Server <b>%1\$s</b> konnte nicht aufgebaut werden";
$messages["Unable to select the database <b>%1\$s</b>"] = "Die Datenbank <b>%1\$s</b> konnte nicht selektiert werden";
$messages["The SQL query could not be executed"] = "Die SQL-Anfrage konnte nicht ausgef&uuml;hrt werden";
$messages["The tables were created successfully"] = "Die Tabellen wurden erfolgreich angelegt";

$messages["Beta functions"] = "Betafunktionen";
$messages["View logs"] = "Logs betrachten";
$messages["Empty logs"] = "Logs leeren";
$messages["The table <b>%1\$s</b> was emptied successfully."] = "Die Tabelle <b>%1\$s</b> wurde erfolgreich geleert.";
$messages["The table <b>%1\$s</b> could not be emptied."] = "Die Tabelle <b>%1\$s</b> konnte nicht geleert werden.";

} // end admin

// -------------------------------------------------------------------------
// advanced.inc.php
if ($state == "Erweitert") {
// -------------------------------------------------------------------------

// advanced()
$messages["The site command functions are not available on this webserver."] = "Die Navigations Funktionen sind auf diesem Webserver nicht verf�gbar.";
$messages["The Apache functions are not available on this webserver."] = "Die Apache Funktionen sind auf diesem Webserver nicht verf�gbar.";
$messages["The MySQL functions are not available on this webserver."] = "Die MySQL Funktionen sind auf diesem Webserver nicht verf�gbar.";
$messages["Unexpected state2 string. Exiting."] = "Unerwartete state2-Zeichenkette. Beende.";

// printAdvancedFunctions()
$messages["Advanced functions"] = "Erweiterte Funktionen";
$messages["Go"] = "Weiter";
$messages["Troubleshooting functions"] = "Fehlersuchfunktionen";
$messages["Troubleshoot net2ftp on this webserver"] = "Fehlersuche bei net2ftp auf diesem Webserver";
$messages["Troubleshoot an FTP server"] = "Fehlersuche bei einem FTP Server";
$messages["Translation functions"] = "&Uuml;bersetzungsfunktionen";
$messages["Introduction to the translation functions"] = "Einf&uuml;hrung in die &Uuml;bersetzungsfunktionen";
$messages["Extract messages to translate from code files"] = "Extrahiere zu &uuml;bersetzende Zeichenketten aus dem Quelltext";
$messages["Check if there are new or obsolete messages"] = "Suche nach neuen oder veralteten Zeichenketten";
$messages["Beta functions"] = "Betafunktionen";
$messages["Send a site command to the FTP server"] = "Ein SITE-Kommando auf dem FTP Server absetzen";
$messages["Apache: password-protect a directory, create custom error pages"] = "Apache: Verzeichnis passwortsch&uuml;tzen, eine eigene Error-Seite anlegen";
$messages["MySQL: execute an SQL query"] = "MySQL: eine SQL-Anfrage ausf&uuml;hren";

// troubleshoot_webserver()
$messages["Troubleshoot your net2ftp installation"] = "Fehlersuche bei der net2ftp Installation";
$messages["Checking if the FTP module of PHP is installed: "] = "�berpr�fen ob das FTP Modul von PHP installiert ist";
$messages["yes"] = "Ja";
$messages["no - please install it!"] = "Nein - bitte installieren!";
$messages["Checking the permissions of the directory on the web server: a small file will be written to the /temp folder and then deleted."] = "�berpr�fung der Berechtigungen des Verzeichnisses auf dem Webserver: eine kleine Datei wird in den /temp Ordner geschrieben und anschlie�end gel�scht.";
$messages["Creating filename: "] = "Dateiname wird erstellt: ";
$messages["OK. Filename: %1\$s"] = "OK. Dateiname: %tempfilename";
$messages["not OK"] = "nicht OK";
$messages["OK"] = "OK";
$messages["not OK. Check the permissions of the %1\$s directory"] = "nicht OK. Bitte die Berechtigung des Ordners %1\$s �berpr�fen";
$messages["Opening the file in write mode: "] = "&Ouml;ffnen der Datei im Schreib-Modus: ";
$messages["Writing some text to the file: "] = "Schreiben von Text in die Datei: ";
$messages["Closing the file: "] = "Schlie�en der Datei: ";
$messages["Deleting the file: "] = "L�schen der Datei: ";

// troubleshoot_ftpserver()
$messages["Troubleshoot an FTP server"] = "Fehlersuche bei einem FTP Server";
$messages["FTP server port"] = "FTP Server Port";
$messages["Connection settings:"] = "Verbindungseigenschaften:";
$messages["Password length"] = "Passwortl�nge";
$messages["Language"] = "Sprache";
$messages["Skin number"] = "Skin Nummer";
$messages["Connecting to the FTP server: "] = "Verbinden mit dem FTP Server: ";
$messages["Logging into the FTP server: "] = "Anmelden am FTP Server: ";
$messages["Setting the passive mode: "] = "Setzen des passiven Modus:";
$messages["Getting the FTP server system type: "] = "Pr�fe Systemtyp des FTP-Servers: ";
$messages["Changing to the directory %1\$s: "] = "Wechseln in das Verzeichniss %1\$s: ";
$messages["The directory from the FTP server is: %1\$s "] = "Das Verzeichniss des FTP Server ist: %1\$s ";
$messages["Getting the raw list of directories and files: "] = "Empfang einer Rohliste der Dateien und Ordnern: ";
$messages["Trying a second time to get the raw list of directories and files: "] = "Erneuter Empfangsversuch einer Rohliste der Dateien und Ordnern: ";
$messages["Closing the connection: "] = "Verbindung wird geschlossen: ";
$messages["Raw list of directories and files:"] = "Rohliste der Dateien und Ordner:";
$messages["Parsed list of directories and files:"] = "Zergliederte Liste der Dateien und Ordner:";

// printTranslationFunctions()
$messages["net2ftp translation functions"] = "net2ftp &Uuml;bersetzungsfunktionen";
$messages["A PHP application can be translated using the standard <a href=\"http://www.php.net/gettext\">gettext</a> functions, or using a self-made translation function."] = "Eine PHP Anwendung kann mit der Standard-Funktion <a href=\"http://www.php.net/gettext\">gettext</a> &uuml;bersetzt werden, oder mit Hilfe einer selbst geschriebenen Funktion.";
$messages["In both cases, the steps to take are similar."] = "In beiden F&auml;llen sind die Schritte &auml;hnlich.";
$messages["Step 1: change code"] = "Schritt 1: Quelltext &auml;ndern";
$messages["All messages must be translated using a translation function, for example translate()."] = "Alle Zeichenketten m&uuml;ssen mit einer &Uuml;bersetzungsfunktion &uuml;bersetzt werden, zum Beispiel translate().";
$messages["This Hello World code:"] = "Dieser Hello-World Quelltext:";
$messages["must be changed to this:"] = "muss folgenderma&szlig;en abge&auml;ndert werden:";
$messages["Step 2: extract messages"] = "Schritt 2: Zeichenketten extrahieren";
$messages["All messages which are used by the translate() function must be extracted from the code files, and copied to a <b>main message file</b>."] = "Alle Zeichenketten, die von der translate()-Funktion genutzt werden, m&uuml;ssen aus dem Quelltext extrahiert werden und in eine <b>main message Datei</b> kopiert werden.";
$messages["Step 3: translate messages"] = "Schritt 3: &Uuml;bersetzen der Zeichenketten";
$messages["The main message file is given to translators, who rename the file and replace the messages in English by the translation."] = "Diese main message Datei wird an einen &Uuml;bersetzer gegeben, der die Datei umbenennt und die englischen Zeichenketten durch die &Uuml;bersetzungen ersetzt.";
$messages["The translators return the <b>translated message files</b>."] = "Der &Uuml;bersetzer liefert die <b>&uuml;bersetzte message Datei</b> zur&uuml;ck.";
$messages["Each time the application is modified, a new main message file must be generated, as in step 2."] = "Bei jeder &Auml;nderung der Anwendung muss eine neue main message Datei, wie in Schritt 2, erzeugt werden.";
$messages["In order to avoid translating everything all over again, it must then be compared to all translated message files, to check if there are new or obsolete messages."] = "Um unn&ouml;tige Arbeit zu verhindern, muss die erzeugte message Datei mit allen &uuml;bersetzten message Dateien verglichen werden, um nach neuen oder veralteten Zeichenketten zu pr&uuml;fen.";
$messages["net2ftp can help in step 2 to extract messages to translate from code files"] = "net2ftp unterst&uuml;tzt den Schritt 2 beim Extrahieren der zu &uuml;bersetzenden Zeichenketten";
$messages["net2ftp can help in step 4 to check if there are new or obsolete messages"] = "net2ftp unterst&uuml;tzt Schritt 4 bei der Pr&uuml;fung nach neuen oder veralteten Zeichenketten.";

// translate_extract()
$messages["Extract messages from code files"] = "Zeichenketten aus Quelltextdateien extrahieren";
$messages["Directory containing code files:"] = "Verzeichnis, welches die Quelltexte enth�lt:";
$messages["Translation function used in the code:"] = "Verwendete &Uuml;bersetzungsfunktion im Quelltext:";
$messages["File to generate:"] = "Zu erzeugende Datei:";
$messages["Extracted messages:"] = "Extrahierte Zeichenketten:";
$messages["No messages were found, so no file was put on the FTP server."] = "Es wurden keine Zeichenketten gefunden, demnach auch keine Dateien auf den FTP Server hochgeladen.";
$messages["The main language file <b>%1\$s</b> was transferred to directory <b>%2\$s</b>."] = "Die Haupt-Sprachdatei <b>%1\$s</b> wurde in das Verzeichnis <b>%2\$s</b> kopiert.";

// translate_check()
$messages["Main language file:"] = "Haupt-Sprachdatei:";
$messages["Directory containing translated language files:"] = "Verzeichnis, welches die &uuml;bersetzten Sprachdateien enth&auml;lt:";
$messages["File %1\$s was skipped because it could not be read, or because it was empty."] = "Datei %1\$s wurde &uuml;bersprungen, da Sie entweder nicht geladen werden konnte, oder leer ist.";
$messages["File nr %1\$s <b>%2\$s</b>"] = "Datei Nr. %1\$s <b>%2\$s</b>";
$messages["New messages:"] = "Neue Zeichenketten:";
$messages["Obsolete messages:"] = "Veraltete Zeichenketten:";
$messages["All the files have been processed"] = "Alle Sprachdateien wurden verarbeitet";

// sendsitecommand()
$messages["Send site command"] = "SITE-Kommando absetzen";
$messages["Enter the site command"] = "Geben Sie das SITE-Kommando ein";
$messages["The commands you can use depends on your FTP server. These commands are not standard and vary a lot from one server to the other."] = "Die g�ltigen Kommandos h�ngen vom verwendeten FTP-Server ab. Diese Kommandos sind nicht standardisiert und unterscheiden sich stark von einem Server zu einem Anderen.";
$messages["Note that net2ftp cannot display the output of the FTP server, it can only tell if the command returned TRUE or FALSE. This is not a limitation of net2ftp but of PHP, the language in which net2ftp is written."] = "Beachten Sie, dass net2ftp die Ausgabe des FTP-Servers nicht anzeigen kann, es kann lediglich anzeigen, ob das Kommando TRUE oder FALSE zur�ckgeliefert hat. Dies ist keine Beschr�nkung von net2ftp, sondern von PHP (der Programmiersprache, in der net2ftp geschrieben ist).";
$messages["The command <b>%1\$s</b> was executed successfully."] = "Das Kommando <b>%1\$s</b> wurde erfolgreich ausgef&uuml;hrt.";

// apache(), mysqlfunctions()
// Not yet translated

} // end advanced



// -------------------------------------------------------------------------
// authorizations.inc.php
// -------------------------------------------------------------------------

// checkAuthorization()
$messages["The FTP server <b>%1\$s</b> is not in the list of allowed FTP servers."] = "Der FTP Server <b>%1\$s</b> ist nicht in der Liste der erlaubten FTP Server.";
$messages["The FTP server <b>%1\$s</b> is in the list of banned FTP servers."] = "Der FTP Server <b>%1\$s</b> ist in der Liste der verbotenen FTP Server.";
$messages["Your IP address (%1\$s) is in the list of banned IP addresses."] = "Ihre IP address (%1\$s) ist in der Liste der verbotenen IP Addressen.";
$messages["The FTP server port %1\$s may not be used."] = "Der FTP Server Port %1\$s darf nicht genutzt werden.";
$messages["You don't have the authorizations to view directory <b>%1\$s</b>."] = "Sie haben nicht die Berechtigung um das Verzeichniss <b>%1\$s</b> anzuschauen.";

// logAccess(), logLogin(), logError()
// Not yet translated


// -------------------------------------------------------------------------
// bookmark.inc.php
if ($state == "bookmark") {
// -------------------------------------------------------------------------
$messages["Add this link to your bookmarks:"] = "Diesen Link zu Ihren Favoriten hinzuf�gen:";
$messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer: Rechtsklick auf den Link und \"Zu Favoriten hinzuf�gen ...\" ausw�hlen";
$messages["Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla, Firefox: Rechtsklick auf den Link und \"Bookmark This Link...\" ausw�hlen";
$messages["Note: when you will use this bookmark, a popup window will ask you for your username and password."] = "Achtung: Wenn Sie dieses Lesezeichen benutzen, werden Sie in einem Popup Fenster nach dem Usernamen und Passwort gefragt.";

} // end bookmark


// -------------------------------------------------------------------------
// browse.inc.php
if ($state == "browse") {
// -------------------------------------------------------------------------

// browse()
$messages["Directories with names containing \' cannot be displayed correctly. They can only be deleted. Please go back and select another subdirectory."] = "Verzeichnisse, die  \' enthalten, k�nnen nicht korrekt dargestellt werden. Diese k�nnen nur gel�scht werden. Bitte gehen Sie zur�ck und w�hlen Sie ein anderes Verzeichniss.";

$messages["Consumption message"]  = "";
$messages["Consumption message"] .= "<b>Tages-Beschr�nkung erreicht: Sie k�nnen keine Daten mehr transferieren.</b><br /><br />\n";
$messages["Consumption message"] .= "Um die faire Nutzung des Webservers f�r alle Nutzer zu gew�hrleisten, ist das Transfervolumen und die Laufzeit von Skripten pro Nutzer und Tag beschr�nkt. Wird die Beschr�nkung erreicht, k�nnen Sie immernoch den FTP Server durchsuchen, allerdings k�nnen keine Daten mehr hoch- oder runtergeladen werden.<br /><br />\n";
$messages["Consumption message"] .= "Wenn Sie unbeschr�nkten Zugang ben�tigen, installieren Sie net2ftp bitte auf Ihrem eigenen Webserver.<br />\n";

// ftp_getlist()
$messages["The directory <b>%1\$s</b> does not exist or could not be selected, so the root directory <b>/</b> is shown instead."] = "Das Verzeichniss <b>%1\$s</b> existiert nicht oder kann nicht ausgew�hlt werden, stattdessen wird das Root-Verzeichniss <b>/</b> dargestellt.";

// printdirfilelist()
// Keep this short, it must fit in a small button!
$messages["New dir"] = "Neuer Ordner";
$messages["New file"] = "Neue Datei";
$messages["HTML templates"] = "HTML templates";
$messages["Upload"] = "Upload";
$messages["Java Upload"] = "Java Upload";
$messages["Advanced"] = "Erweitert";
$messages["Copy"] = "Kopieren";
$messages["Move"] = "Verschieben";
$messages["Delete"] = "L�schen";
$messages["Rename"] = "Umbenennen";
$messages["Chmod"] = "Zugriffsrechte";
$messages["Download"] = "Download";
$messages["Zip"] = "Zip";
$messages["Size"] = "Gr��e";
$messages["Search"] = "Suchen";
$messages["Go to the parent directory"] = "�bergeordneter Ordner";
$messages["Transform selected entries: "] = "Ausgew�hlte Eintr�ge transformieren: ";
$messages["Make a new subdirectory in directory %1\$s"] = "Erstellen eines neuen Unterverzeichnisses im Ordner %1\$s";
$messages["Create a new file in directory %1\$s"] = "Erstellen einer neuen Datein im Ordner %1\$s";
$messages["Upload new files in directory %1\$s"] = "Upload neuer Dateien in Verzeichniss %1\$s";
$messages["Go to the advanced functions"] = "Wechseln zu erweiterten Funktionen";
$messages["Copy the selected entries"] = "Kopieren der ausgew�hlten Eintr�ge";
$messages["Move the selected entries"] = "Verschieben der ausgew�hlten Eintr�ge";
$messages["Delete the selected entries"] = "L�schen der ausgew�hlten Eintr�ge";
$messages["Rename the selected entries"] = "Umbenennen der ausgew�hlten Eintr�ge";
$messages["Chmod the selected entries (only works on Unix/Linux/BSD servers)"] = "Zugriffsrechte der ausgew�hlten Eintr�ge �ndern (funktioniert nur auf Unix/Linux/BSD Servern)";
$messages["Download a zip file containing all selected entries"] = "Download eine ZIP Datei mit allen ausgew�hlten Elementen";
$messages["Zip the selected entries to save or email them"] = "Zippen der ausgew�lten Elemente zum speichern oder versenden per Mail";
$messages["Calculate the size of the selected entries"] = "Kalkulieren der Gr��e ausgew�hlter Eintr�ge";
$messages["Find files which contain a particular word"] = "Suchen von Dateien mit einem bestimmten Wort im Text";
$messages["Click to sort by %1\$s in descending order"] = "Absteigend nach %1\$s sortieren";
$messages["Click to sort by %1\$s in ascending order"] = "Aufsteigend nach %1\$s sortieren";
$messages["Ascending order"] = "Aufsteigend";
$messages["Descending order"] = "Absteigend";
//$messages["Click to sort by %1\$s in ascending order"] = "Aufsteigend nach %1\$s sortieren";
$messages["Up"] = "Aufw�rts";
$messages["Click to check or uncheck all rows"] = "Alle Zeilen an- bzw. abw�hlen";
$messages["All"] = "Alle";
$messages["Name"] = "Name";
$messages["Type"] = "Typ";
//$messages["Size"] = "Gr��e";
$messages["Owner"] = "Besitzer";
$messages["Group"] = "Gruppe";
$messages["Perms"] = "Berechtigungen";
$messages["Mod Time"] = "�nderungs-Datum/Zeit";
$messages["Actions"] = "Aktionen";
$messages["Download the file %1\$s"] = "Datei %1\$s herunterladen";
$messages["View"] = "Anzeigen";
$messages["Edit"] = "Bearbeiten";
$messages["Update"] = "Aktualisieren";
$messages["Open"] = "�ffnen";
$messages["View the highlighted source code of file %1\$s"] = "Den Quellcode der Datei %1\$s ansehen";
$messages["Edit the source code of file %1\$s"] = "Den Quellcode der Datei %1\$s bearbeiten";
$messages["Upload a new version of the file %1\$s and merge the changes"] = "Hochladen einer neuen Version der Datei %1\$s und zusammenf�gen der �nderungen";
$messages["View image %1\$s"] = "View image %1\$s";
$messages["View the file %1\$s from your HTTP web server"] = "Die Datei %1\$s von Ihrem Webserver ansehen";
$messages["(Note: This link may not work if you don't have your own domain name.)"] = "(Achtung: Dieser Link wird nicht funktionieren, wenn Sie keinen eigene Dom�ne haben.)";
$messages["This folder is empty"] = "Dieser Ordner ist leer";

// printSeparatorRow()
$messages["Directories"] = "Ordner";
$messages["Files"] = "Dateien";
$messages["Symlinks"] = "Symlinks";
$messages["Unrecognized FTP output"] = "Unerkannter FTP Output";
$messages["Number"] = "Nummer";
$messages["Size"] = "Gr��e";
$messages["Skipped"] = "Skipped";

// printLocationActions()
$messages["Language:"] = "Sprache:";
$messages["Skin:"] = "Skin:";
$messages["View mode:"] = "Ansichts-Modus:";
$messages["Directory Tree"] = "Verzeichnissbaum";

// printURL()
$messages["Execute %1\$s in a new window"] = "In einem neuen Fenster %1\$s ausf�hren";

// printDirectorySelect()
$messages["Double-click to go to a subdirectory:"] = "Doppleklick um in ein Unterverzeichniss zu wechseln:";
$messages["Choose"] = "Auswahl";
$messages["Up"] = "Runter";

} // end browse


// -------------------------------------------------------------------------
// consumption.inc.php
// -------------------------------------------------------------------------
$messages["Unable to determine your IP address."] = "Kann Ihre IP-Adresse nicht aufl�sen.";
$messages["Table net2ftp_logConsumptionIpaddress contains duplicate rows."] = "Tabelle net2ftp_logConsumptionIpaddress enth�lt doppelte Eintr�ge.";
$messages["Table net2ftp_logConsumptionFtpserver contains duplicate rows."] = "Tabelle net2ftp_logConsumptionFtpserver enth�lt doppelte Eintr�ge.";
$messages["The variable <b>consumption_ipaddress_dataTransfer</b> is not numeric."] = "Die Variable <b>consumption_ipaddress_dataTransfer</b> ist nicht numerisch.";
$messages["Table net2ftp_logConsumptionIpaddress could not be updated."] = "Tabelle net2ftp_logConsumptionIpaddress konnte nicht aktualisiert werden.";
$messages["Table net2ftp_logConsumptionIpaddress contains duplicate entries."] = "Tabelle net2ftp_logConsumptionIpaddress enth�lt doppelte Eintr�ge.";
$messages["Table net2ftp_logConsumptionFtpserver could not be updated."] = "Tabelle net2ftp_logConsumptionFtpserver konnte nicht aktualisiert werden.";
$messages["Table net2ftp_logConsumptionFtpserver contains duplicate entries."] = "Tabelle net2ftp_logConsumptionFtpserver enth�lt doppelte Eintr�ge.";
$messages["Daily limit reached: the file <b>%1\$s</b> will not be transferred"] = "Tages-Beschr�nkung erreicht: die Datei <b>%1\$s</b> wird nicht transferiert";


// -------------------------------------------------------------------------
// database.inc.php
// -------------------------------------------------------------------------
$messages["Unable to connect to the DB"] = "Verbindung zur DB kann nicht hergestellt werden";
$messages["Unable to select the DB"] = "DB kann nicht ausgew�hlt werden";


// -------------------------------------------------------------------------
// easywebsite.inc.php
if ($state == "easyWebsite") {
// -------------------------------------------------------------------------
$messages["Create a website in 4 easy steps"] = "Create a website in 4 easy steps";
$messages["Template overview"] = "Template overview";
$messages["Template details"] = "Template details";
$messages["Files are copied"] = "Files are copied";
$messages["Edit your pages"] = "Edit your pages";

// Screen 1 - printTemplateOverview
$messages["Click on the image to view the details of a template."] = "Click on the image to view the details of a template.";
$messages["Back to the Browse screen"] = "Back to the Browse screen";
$messages["Template"] = "Template";
$messages["Copyright"] = "Copyright";
$messages["Click on the image to view the details of this template"] = "Click on the image to view the details of this template";

// Screen 2 - printTemplateDetails
$messages["The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?"] = "The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?";
$messages["Preview"] = "Preview";
$messages["Install"] = "Install";
$messages["Size"] = "Size";
$messages["Preview page"] = "Preview page";
$messages["opens in a new window"] = "opens in a new window";

// Screen 3
$messages["Please wait while the template files are being transferred to your server: "] = "Please wait while the template files are being transferred to your server: ";
$messages["Done."] = "Done.";
$messages["Continue"] = "Continue";

// Screen 4 - printEasyAdminPanel
$messages["Edit page"] = "Edit page";
$messages["Browse the FTP server"] = "Browse the FTP server";
$messages["Add this link to your favorites to return to this page later on!"] = "Add this link to your favorites to return to this page later on!";
$messages["Edit website at %1\$s"] = "Edit website at %1\$s";
$messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer: right-click on the link and choose \"Add to Favorites...\"";
$messages["Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\"";

// ftp_copy_local2ftp
$messages["WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing..."] = "WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing...";
$messages["Created target subdirectory <b>%1\$s</b>"] = "Created target subdirectory <b>%1\$s</b>";
$messages["WARNING: Unable to copy the file <b>%1\$s</b>. Continuing..."] = "WARNING: Unable to copy the file <b>%1\$s</b>. Continuing...";
$messages["Copied file <b>%1\$s</b>"] = "Copied file <b>%1\$s</b>";
}


// -------------------------------------------------------------------------
// edit.inc.php
if ($state == "manage" && ($state2 == "edit" || $state2 == "newfile")) {
// -------------------------------------------------------------------------

// edit()
$messages["Unable to open the template file"] = "Die Vorlage kann nicht ge�ffnet werden";
$messages["Unable to read the template file"] = "Die Vorlage kann nicht gelesen werden";
$messages["Please specify a filename"] = "Bitte geben Sie einen Dateinamen an";

// printEditForm()
$messages["Directory: "] = "Verzeichniss: ";
$messages["File: "] = "Datei: ";
$messages["New file name: "] = "Dateiname: ";
$messages["Note: changing the textarea type will save the changes"] = "Hinweis: �ndern des Textarea-Typs speichert die �nderungen";
$messages["Status: This file has not yet been saved"] = "Status: Diese Datei wurde noch nicht gespeichert";
$messages["Status: Saved on <b>%1\$s</b> using mode %2\$s"] = "Status: Speichern auf <b>%1\$s</b> im Modus %2\$s";
$messages["Status: <b>This file could not be saved</b>"] = "Status: <b>Die Datei konnte nicht gespeichert werden</b>";

} // end if edit newfile


// -------------------------------------------------------------------------
// errorhandling.inc.php
// -------------------------------------------------------------------------
$messages["An error has occured"] = "Ein Fehler ist aufgetreten";
$messages["Go back"] = "Zur�ck";
$messages["Go to the login page"] = "Zur�ck zur Anmeldeseite";


// -------------------------------------------------------------------------
// filesystem.inc.php
// -------------------------------------------------------------------------

// ftp_openconnection()
$messages["The <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this FTP module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">php.net</a><br />"] = "Das <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP-Modul von PHP</a> ist nicht installiert.<br /><br /> Der Administrator dieser Webseite sollte das FTP-Modul installieren. Hinweise zur Installation stehen auf <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">php.net</a><br />";
$messages["Unable to connect to FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "Konnte keine Verbindung zum FTP Server <b>%1\$s</b> auf Port <b>%2\$s</b> herstellen.<br /><br />Bitte Pr�fen Sie die Adresse des FTP-Servers - diese unterscheidet sich oft von der Adresse des HTTP (Web) Servers. Bitte kontaktieren Sie die Hotline Ihres Providers oder Ihren Systemadministrator.<br />";
$messages["Unable to login to FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "Anmeldung am FTP Server  <b>%1\$s</b> mit Benutzername <b>%2\$s</b> fehlgeschlagen.<br /><br />Bitte pr�fen Sie Ihren Benutzernamen und das Kennwort. Kontaktieren Sie die Hotline Ihres Providers oder Fragen Sie Ihren Systemadministrator.<br />";
$messages["Unable to switch to the passive mode on FTP server <b>%1\$s</b>."] = "Konnte nicht in den passiven Modus auf dem FTP-Server <b>%1\$s</b> wechseln.";

// ftp_openconnection2()
$messages["Unable to connect to the second (target) FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the second (target) FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "Konnte nicht zum zweiten (Ziel-) FTP-Server <b>%1\$s</b> auf Port <b>%2\$s</b> verbinden.<br /><br />Bitte Pr�fen Sie die Adresse des FTP-Servers - diese unterscheidet sich oft von der Adresse des HTTP (Web) Servers. Bitte kontaktieren Sie die Hotline Ihres Providers oder Ihren Systemadministrator.<br />";
$messages["Unable to login to the second (target) FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "Anmeldung am zweiten (Ziel-) FTP Server <b>%1\$s</b> mit Benutzername <b>%2\$s</b> fehlgeschlagen.<br /><br />Bitte pr�fen Sie Ihren Benutzernamen und das Kennwort. Kontaktieren Sie die Hotline Ihres Providers oder Fragen Sie Ihren Systemadministrator.<br />";
$messages["Unable to switch to the passive mode on the second (target) FTP server <b>%1\$s</b>."] = "Konnte nicht in den passiven Modus auf dem zweiten (Ziel-) FTP-Server <b>%1\$s</b> wechseln.";

// ftp_myrename()
$messages["Unable to rename directory or file <b>%1\$s</b> into <b>%2\$s</b>"] = "Umbenennen der Datei oder des Verzeichnisses <b>%1\$s</b> in <b>%2\$s</b> fehlgeschlagen";

// ftp_mychmod()
$messages["Unable to execute site command <b>%1\$s</b>. Note that the CHMOD command is only available on Unix FTP servers, not on Windows FTP servers."] = "Ausf�hrung des SITE-Kommandos <b>%1\$s</b> fehlgeschlagen. Hinweis: Das CHMOD Kommando ist nur auf Unix-FTP-Servern verf�gbar, nicht auf Windows-FTP-Servern.";
$messages["Directory <b>%1\$s</b> successfully chmodded to <b>%2\$s</b>"] = "Zugriffsrechte des Verzeichnisses <b>%1\$s</b> erfolgreich in <b>%2\$s</b> ge�ndert";
$messages["File <b>%1\$s</b> was successfully chmodded to <b>%2\$s</b>"] = "Zugriffsrechte der Datei <b>%1\$s</b> erfolgreich in <b>%2\$s</b> ge�ndert";
$messages["All the selected directories and files have been processed."] = "Alle ausgew�hlten Verzeichnisse und Dateien wurden verarbeitet.";

// ftp_rmdir2()
$messages["Unable to delete the directory <b>%1\$s</b>"] = "L�schen des Verzeichnisses <b>%1\$s</b> fehlgeschlagen";

// ftp_delete2()
$messages["Unable to delete the file <b>%1\$s</b>"] = "L�schen der Datei <b>%1\$s</b> fehlgeschlagen";

// ftp_newdirectory()
$messages["Unable to create the directory <b>%1\$s</b>"] = "Der neue Ordner <b>%1\$s</b> kann nicht angelegt werden";

// ftp_readfile()
$messages["Unable to create the temporary file"] = "Die tempor�re Datei kann nicht erstellt werden";
$messages["Unable to get the file <b>%1\$s</b> from the FTP server and to save it as temporary file <b>%2\$s</b>.<br />Check the permissions of the %3\$s directory.<br />"] = "Laden der Datei <b>%1\$s</b> vom FTP Server und Zwischenspeichern als <b>%2\$s</b> fehlgeschlagen.<br />Bitte pr�fen Sie die Zugriffsrechte des Ordners %3\$s.<br />";
$messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "�ffnen der zwischengespeicherten Datei fehlgeschlagen. Bitte pr�fen Sie die Zugriffsrechte des Ordners %1\$s.";
$messages["Unable to read the temporary file"] = "Lesen der tempor�ren Datei fehlgeschlagen.";
$messages["Unable to close the handle of the temporary file"] = "Die Verarbeitung der tempor�ren Datei konnte nicht beendet werden";
$messages["Unable to delete the temporary file"] = "Die tempor�re Datei kann nicht gel�scht werden";

// ftp_writefile()
$messages["Unable to create the temporary file. Check the permissions of the %1\$s directory."] = "Die tempor�re Datei kann nicht erstellt werden. Bitte Berechtigung des Verzeichnisses %1\$s �berpr�fen.";
$messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "Die tempor�re Datei kann nicht ge�ffnet werden. Bitte Berechtigung des Verzeichnisses %1\$s �berpr�fen.";
$messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "Speichern der Zeichenkette in die tempor�re Datei <b>%1\$s</b> fehlgeschlagen.<br />Bitte pr�fen Sie die Zugriffsrechte des Ordners %2\$s.";
$messages["Unable to close the handle of the temporary file"] = "Schliessen der tempor�ren Datei fehlgeschlagen.";
$messages["Unable to put the file <b>%1\$s</b> on the FTP server.<br />You may not have write permissions on the directory."] = "Konnte Datei <b>%1\$s</b> nicht auf dem FTP Server ablegen.<br />Bitte pr�fen Sie Ihre Schreibrechte in diesem Verzeichnis.";
$messages["Unable to delete the temporary file"] = "Tempor�re Datei kann nicht gel�scht werden";

// ftp_copymovedelete()
$messages["Processing directory <b>%1\$s</b>"] = "Verarbeiten des Ordners <b>%1\$s</b>";
$messages["The target directory <b>%1\$s</b> is the same as or a subdirectory of the source directory <b>%2\$s</b>, so this directory will be skipped"] = "Das Ziel-Verzeichnis <b>%1\$s</b> ist das Gleiche als der Quellordner <b>%2\$s</b>, oder ein Unterordner davon, Ordner wird �bersprungen";
$messages["Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing the copy/move process..."] = "Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing the copy/move process...";
$messages["Created target subdirectory <b>%1\$s</b>"] = "Erzeuge Unterordner <b>%1\$s</b>";
$messages["Unable to delete the subdirectory <b>%1\$s</b> - it may not be empty"] = "Das Unterverzeichniss <b>%1\$s</b> konnte nicht gel�scht werden - es ist nicht leer";
$messages["Deleted subdirectory <b>%1\$s</b>"] = "Gel�schtes Verzeichniss <b>%1\$s</b>";
$messages["Processing of directory <b>%1\$s</b> completed"] = "Verarbeitung des Verzeichnisses <b>%1\$s</b> beendet";
$messages["The target for file <b>%1\$s</b> is the same as the source, so this file will be skipped"] = "Das Ziel f�r die Datei <b>%1\$s</b> ist die selbe wie die Quelle, diese Datei wird �bersprungen";
$messages["Unable to copy the file <b>%1\$s</b>"] = "Die Datei <b>%1\$s</b> kann nicht kopiert werden";
$messages["Copied file <b>%1\$s</b>"] = "Copied file <b>%1\$s</b>";
$messages["Unable to move the file <b>%1\$s</b>"] = "Die Datei <b>%1\$s</b> kann nicht verschoben werden";
$messages["Moved file <b>%1\$s</b>"] = "Moved file <b>%1\$s</b>";
$messages["Unable to delete the file <b>%1\$s</b>"] = "Die Datei <b>%1\$s</b> kann nicht gel�scht werden";
$messages["Deleted file <b>%1\$s</b>"] = "Gel�schte Datei <b>%1\$s</b>";
$messages["All the selected directories and files have been processed."] = "Alle ausgw�hlten Dateien und Verzeichnisse wurden verarbeitet.";

// ftp_processfiles()

// ftp_getfile()
$messages["Unable to copy the remote file <b>%1\$s</b> to the local file using FTP mode <b>%2\$s</b>"] = "Die Remote Datei <b>%1\$s</b> konnte nicht lokal per FTP Modus <b>%2\$s</b> kopiert werden";
$messages["Unable to delete file <b>%1\$s</b>"] = "Die Datei <b>%1\$s</b> kann nicht gel�scht werden";

// ftp_putfile()
$messages["Unable to copy the local file to the remote file <b>%1\$s</b> using FTP mode <b>%2\$s</b>"] = "Unable to copy the local file to the remote file <b>%1\$s</b> using FTP mode <b>%2\$s</b>";
$messages["Unable to delete the local file"] = "Lokale Datei kann nicht gel�scht werden";

// ftp_downloadfile()
$messages["Unable to delete the temporary file"] = "Tempor�re Datei kann nicht gel�scht werden";
$messages["Unable to send the file to the browser"] = "Konnte Datei nicht an Browser senden";

// ftp_zip()
$messages["Unable to create the temporary file"] = "Tempor�re Datei kann nicht erstellt werden";
$messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "Schreiben der Zeichenkette in tempor�re Datei <b>%1\$s</b> fehlgeschlagen.<br />Bitte pr�fen Sie die Zugriffsrechte des Ordners %2\$s.";
$messages["Unable to close the handle of the temporary file"] = "Schliessen der tempor�ren Datei fehlgeschlagen";
$messages["The zip file has been saved on the FTP server as <b>%1\$s</b>"] = "Das ZIP-Archiv wurde auf dem FTP-Server als <b>%1\$s</b> gespeichert";
$messages["Requested files"] = "Angeforderte Dateien";

$messages["Zip email message"]  = "";
$messages["Zip email message"] .= "Sehr geehrte(r), \n\n";
$messages["Zip email message"] .= "Jemand hat veranlasst, da� diese Datei an Ihre E-Mail Adresse (%1\$s) gesendet wird.\n";
$messages["Zip email message"] .= "Wenn Sie nichts davon Wissen oder der Person nicht trauen, l�schen Sie bitte diese E-Mail und den Anhang, ohne Sie zu �ffnen.\n";
$messages["Zip email message"] .= "Beachten Sie bitte, da� die Dateien im Anhang Ihrem Computer nicht schaden k�nnen, wenn Sie die Datei nicht �ffnen.\n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "Informationen �ber den Absender:\n";
$messages["Zip email message"] .= "IP Addresse: %2\$s\n";
$messages["Zip email message"] .= "Gesendet: %3\$s\n";
$messages["Zip email message"] .= "Versendet durch den net2ftp Dienst der Webseite: %4\$s \n";
$messages["Zip email message"] .= "E-Mail Adresse des Webmaster: %5\$s \n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "Nachricht des Absenders:\n";
$messages["Zip email message"] .= "%6\$s \n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "net2ftp ist freie Software, freigegeben unter der GNU/GPL Lizenz. F�r mehr Information, gehen Sie zu http://www.net2ftp.com\n\n\n";

$messages["The zip file has been sent to <b>%1\$s</b>."] = "Die Zip Datei wurde versand an <b>%1\$s</b>.";

// acceptFiles()
$messages["File <b>%1\$s</b> is too big. This file will not be uploaded."] = "Datei <b>%1\$s</b> ist zu gro�. Diese Datei wird nicht hochgeladen.";
$messages["Could not generate a temporary file."] = "Tempor�re Datei kann nicht erstellt werden.";
$messages["File <b>%1\$s</b> could not be moved"] = "Datei <b>%1\$s</b> konnte nicht verschoben werden";
$messages["File <b>%1\$s</b> is OK"] = "Datei <b>%1\$s</b> ist OK";
$messages["Unable to move the uploaded file to the temp directory.<br /><br />The administrator of this website has to <b>chmod 777</b> the /temp directory of net2ftp."] = "Unable to move the uploaded file to the temp directory.<br /><br />The administrator of this website has to <b>chmod 777</b> the /temp directory of net2ftp.";
$messages["You did not provide any file to upload."] = "Sie haben keine Datei zum Upload ausgew�hlt.";

// ftp_transferfiles()
$messages["File <b>%1\$s</b> could not be transferred to the FTP server"] = "Datei <b>%1\$s</b> konnte nicht auf den FTP-Server geladen werden";
$messages["File <b>%1\$s</b> has been transferred to the FTP server using FTP mode <b>%2\$s</b>"] = "Datei <b>%1\$s</b> wurde erfolgreich auf den FTP-Server im Modus <b>%2\$s</b> �bertragen";
$messages["Transferring files to the FTP server"] = "�bertrage Dateien auf den FTP Server";

// ftp_unziptransferfiles()
$messages["Processing archive nr %1\$s: <b>%2\$s</b>"] = "Verarbeitung von Archiv Nr. %1\$s: <b>%2\$s</b>";
$messages["Unable to open the archive <b>%1\$s</b> (file %2\$s)"] = "�ffnen des Archivs <b>%1\$s</b> fehlgeschlagen (Datei %2\$s)";
$messages["Could not create directory <b>%1\$s</b>"] = "Anlegen des Ordners <b>%1\$s</b> fehlgeschlagen";
$messages["Created directory <b>%1\$s</b>"] = "Ordner <b>%1\$s</b> angelegt";
$messages["File Contents:"] = "Dateiinhalte:";
$messages["Could not put the file <b>%1\$s</b> to the directory <b>%2\$s</b>"] = "�bertragen der Datei <b>%1\$s</b> in den Ordner <b>%2\$s</b> fehlgeschlagen";
$messages["Transferred file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "�bertragen der Datei <b>%1\$s</b> in den Ordner <b>%2\$s</b> erfolgreich";
$messages["Unable to delete the archive <b>%1\$s</b> (file %2\$s)"] = "L�schen des Archivs <b>%1\$s</b> fehlgeschlagen. (Datei %2\$s)";
$messages["Unable to get the list of the contents of the Zip archive. Error code: %1\$s"] = "Konnte Archiv-Inhaltsverzeichnis nicht auslesen: Fehler-Nummer %1\$s";
$messages["Unable to get the list of the contents of the Tar archive."] = "Konnte Archiv-Inhaltsverzeichnis der TAR-Datei nicht auslesen.";
$messages["Could not create directory <b>%1\$s</b>"] = "Konnte Ordner <b>%1\$s</b> nicht anlegen";
$messages["Created directory <b>%1\$s</b>"] = "Ordner <b>%1\$s</b> angelegt";
$messages["Unable to create the temporary file"] = "Konnte tempor�re Datei nicht erzeugen";
$messages["Unable to extract file nr <b>%1\$s</b> from the archive."] = "Konnte Datei Nummer <b>%1\$s</b> nicht vom Archiv extrahieren.";
$messages["Could not put file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "Konnte Datei <b>%1\$s</b> nicht im Ordner <b>%2\$s</b> ablegen";
$messages["Transferred file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "Datei <b>%1\$s</b> in Ordner <b>%2\$s</b> �bertragen";
$messages["Unable to delete the temporary file <b>%1\$s</b>."] = "L�schen der tempor�ren Datei <b>%1\$s</b> fehlgeschlagen.";
$messages["Archive <b>%1\$s</b> was not processed because its filename extension was not recognized. Only zip, tar, tgz and gz archives are supported at the moment."] = "Archiv <b>%1\$s</b> wurde nicht verarbeitet, das Format ist unbekannt. Zur Zeit unterst�tzte Archiv-Formate: zip, tar, tgz (tar-gzip), gz (gzip).";
$messages["Unzipping and transferring files"] = "Entpacke und �bertrage Dateien";

// ftp_mysite()
$messages["Unable to execute site command <b>%1\$s</b>"] = "SITE-Kommando <b>%1\$s</b> fehlgeschlagen";

// shutdown()
$messages["Shutdown message"]  = "";
$messages["Shutdown message"] .= "<b>Ihr Auftrag wurde angehalten.</b><br /><br />";
$messages["Shutdown message"] .= "Ihr Arbeitsauftrag den Sie mit net2ftp ausf�hren wollten, hat mehr Zeit als die erlaubten  %1\$s Sekunden in Anspruch genommen, und wurde deswegen angehalten.<br />";
$messages["Shutdown message"] .= "Diese Zeitbeschr�nkung gew�hrleistet den Betrieb des Webservers f�r andere Nutzer.<br /><br />";
$messages["Shutdown message"] .= "Versuchen Sie, Ihren Auftrag in kleinere Schritte aufzutrennen: schr�nken Sie die Auswahl an Dateien ein, und/oder �berspringen sie die gr��ten Dateien.<br /><br />";
$messages["If you really need net2ftp to be able to handle big tasks which take a long time, consider installing net2ftp on your own server."] = "Sollten Sie net2ftp ben�tigen, um gr��ere Arbeitsauftr�ge auszuf�hren, k�nnen Sie net2ftp auf Ihrem eigenen Webserver installieren.";

// SendMail()
$messages["You did not provide any text to send by email!"] = "Sie haben keinen Text f�r den EMail-Versand angegeben!";
$messages["You did not supply a From address."] = "Sie haben keine Absenderadresse eingegeben.";
$messages["You did not supply a To address."] = "Sie haben keine Empf�ngeradresse eingegeben.";
$messages["Due to technical problems the email to <b>%1\$s</b> could not be sent."] = "Aus technischen Gr�nden konnte die EMail an <b>%1\$s</b> nicht versendet werden.";

// printFunctionTags()
$messages["Output generated by function %1\$s"] = "Output wurde generiert von der Funktion %1\$s";



// -------------------------------------------------------------------------
// homepage.inc.php
if ($state == "homepage") {
// -------------------------------------------------------------------------
$messages["net2ftp features short"] ="Wenn Sie angemeldet sind k�nnen Sie: \n";
$messages["net2ftp features short"] .="<ul>\n";
$messages["net2ftp features short"] .="<li> auf dem FTP-Server navigieren</li>\n";
$messages["net2ftp features short"] .="<li> upload download <span style=\"font-size: 80%%; color: red;\">neu: unbegrenzte Anzahl Dateien hochladen</span></li>\n";
$messages["net2ftp features short"] .="<li> kopieren verschieben l�schen umbenennen chmod</li>\n";
$messages["net2ftp features short"] .="<li> kopieren/verschieben auf  einen 2ten FTP Server</li>\n";
$messages["net2ftp features short"] .="<li> view code with syntax highlighting</li>\n";
$messages["net2ftp features short"] .="<li> Bilder ansehen <span style=\"font-size: 80%%; color: red;\">neu</span></li>\n";
$messages["net2ftp features short"] .="<li> Text Dateien editieren</li>\n";
$messages["net2ftp features short"] .="<li> HTML in mehreren zur Auswahl stehenden HTML-Editoren editieren <span style=\"font-size: 80%%; color: red;\">neu</span></li>\n";
$messages["net2ftp features short"] .="<li> HTML und PHP-Quelltexte mit Syntax Highlighting (farbliche Hervorhebung der Sprachelemente) <span style=\"font-size: 80%%; color: red;\">neu</span></li>\n";
$messages["net2ftp features short"] .="<li> ZIP-Archive herunterladen, per EMail versenden und speichern</li>\n";
$messages["net2ftp features short"] .="<li> Upload-and-Unzip (zip, tar, tgz, gz) - Hochladen von gepachten Archiven und automatisch Auspacken</li>\n";
$messages["net2ftp features short"] .="<li> Suche nach W�rtern oder Satzteilen</li>\n";
$messages["net2ftp features short"] .="<li> Berechnen von Datei- und Ordnergr��en</li>\n";
$messages["net2ftp features short"] .="</ul>\n";

} // end homepage


// -------------------------------------------------------------------------
// net2ftp_loginform.inc.php
// -------------------------------------------------------------------------
$messages["FTP server"] = "FTP Server";
$messages["Example"] = "Beispiel";
$messages["Username"] = "Username";
$messages["Password"] = "Passwort";
$messages["Anonymous"] = "Anonym";
$messages["Passive mode"] = "Passiver Modus";
$messages["Initial directory"] = "Anfangsverzeichniss";
$messages["Language"] = "Sprache";
$messages["Skin"] = "Skin";
$messages["FTP mode"] = "FTP mode";
$messages["Login"] = "Anmeldung";
$messages["Clear cookies"] = "Cookies l�schen";
$messages["Please enter an FTP server."] = "Please enter an FTP server.";
$messages["Please enter a username."] = "Please enter a username.";
$messages["Please enter a password."] = "Please enter a password.";


// -------------------------------------------------------------------------
// html.inc.php
// -------------------------------------------------------------------------

// HtmlBegin()
$messages["Status:"] = "Status:";

// HtmlEnd()
$messages["net2ftp Help Guide"] = "net2ftp Hilfe";
$messages["net2ftp Forums"] = "net2ftp Forum";
$messages["License"] = "Lizenz";
$messages["Powered by"] = "Powered by";

// printJavascriptFunctions()
$messages["Choose a directory"] = "Verzeichniss ausw�hlen";
$messages["Please wait..."] = "Bitte warten...";
$messages["Uploading... please wait..."] = "Upload... Bitte warten...";
$messages["If the upload takes more than the allowed <b>%1\$s seconds<\/b>, you will have to try again with less/smaller files."] = "If the upload takes more than the allowed <b>%1\$s<\/b>, you will have to try again with less/smaller files.";
$messages["This window will close automatically in a few seconds."] = "Dieses Fenster schlie�t sich in wenigen Sekunden selber.";
$messages["Close window now"] = "Alle Fenster schlie�en";


// -------------------------------------------------------------------------
// httpheaders.inc.php
// -------------------------------------------------------------------------
// Nothing to translate


// -------------------------------------------------------------------------
// manage.inc.php
if ($state == "manage") {
// -------------------------------------------------------------------------

// manage()
$messages["Please select at least one directory or file!"] = "Bitte mindestens eine Datei oder ein Verzeichniss ausw�hlen!";
$messages["Unexpected state2 string. Exiting."] = "Unerwartete state2-Zeichenkette. Beende.";

// renameentry()
if ($state2 == "rename") {
$messages["Rename directories and files"] = "Umbenennen von Ordnern und Dateien";
$messages["Old name: "] = "Alter Name: ";
$messages["New name: "] = "Neuer Name: ";
$messages["The new name may not contain any dots. This entry was not renamed to <b>%1\$s</b>"] = "Der neue Name darf kein Punkte beinhalten. Dieser Eintrag wurde nicht umbenannt in <b>%1\$s</b>";
$messages["<b>%1\$s</b> was successfully renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> wurde erfolgreich umbenannt in <b>%2\$s</b>";
$messages["<b>%1\$s</b> could not be renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> konnte nicht in <b>%2\$s</b> umbenannt werden";
}

// chmodentry()
if ($state2 == "chmod") {
$messages["Chmod directories and files"] = "Berechtigungen von Ordnern und Dateien �ndern";
$messages["Set all permissions"] = "Setzen aller Berechtigungen";
$messages["Read"] = "Lesen";
$messages["Write"] = "Schreiben";
$messages["Execute"] = "Ausf�hren";
$messages["Owner"] = "Besitzer";
$messages["Group"] = "Gruppe";
$messages["Everyone"] = "Jeder";
$messages["To set all permissions to the same values, enter those permissions above and click on the button \"Set all permissions\""] = "Um alle Zugriffsrechte gemeinsam zu ver�ndern, setzen Sie die Zugriffsrechte und klicken auf den Schalter \"Set all permissions\" bzw. \"Alle Zugriffsrechte setzen\"";
$messages["Set the permissions of directory <b>%1\$s</b> to: "] = "Setze Zugriffsrechte des Ordners <b>%1\$s</b> auf: ";
$messages["Set the permissions of file <b>%1\$s</b> to: "] = "Setze Zugriffsrechte der Datei<b>%1\$s</b> auf: ";
$messages["Set the permissions of symlink <b>%1\$s</b> to: "] = "Setze Zugriffsrechte des Symlinks <b>%1\$s</b> auf: ";
$messages["Chmod value"] = "Zugriffsrecht";
$messages["Chmod also the subdirectories within this directory"] = "Zugriffsrechte auch in Unterordnern dieses Ordners setzen";
$messages["Chmod also the files within this directory"] = "Zugriffsrechte auch f�r Dateien in diesem Ordner setzen";
$messages["The chmod nr <b>%1\$s</b> is out of the range 000-777. Please try again."] = "Das Zugriffsrecht <b>%1\$s</b> ist nicht innerhalb des erlaubten Bereichs 000-777. Bitte versuchen Sie es erneut.";
}

// copymovedeleteentry()
if ($state2 == "copy" || $state2 == "move" || $state2 == "delete") {
$messages["Copy directories and files"] = "Dateien und Verzeichnisse kopieren";
$messages["Move directories and files"] = "Dateien und Verzeichnisse verschieben";
$messages["Delete directories and files"] = "Dateien und Verzeichnisse l�schen";
$messages["Are you sure you want to delete these directories and files?"] = "Sind Sie sicher, da� Sie diese Dateien und Verzeichnisse l�schen wollen?";
$messages["All the subdirectories and files of the selected directories will also be deleted!"] = "Alle Unterordner und Dateien der ausgew�hlten Verzeichnisse werden ebenfalls gel�scht!";
$messages["Set all targetdirectories"] = "Setzen als Zielverzeichniss f�r alle";
$messages["To set a common target directory, enter that target directory in the textbox above and click on the button \"Set all targetdirectories\"."] = "Um einen gemeinsamen Zielordner anzugeben, tragen Sie das Zielverzeichnis in das obere Eingabefeld ein, und klicken auf \"Set all targetdirectories\" bzw \"Alle Zielordner setzen\".";
$messages["Note: the target directory must already exist before anything can be copied into it."] = "Hinweis: der Zielordner muss bereits existieren, bevor Dateien hineinkopiert werden k�nnen.";
$messages["Different target FTP server:"] = "Anderer Ziel FTP Server:";
$messages["Leave empty if you want to copy the files to the same FTP server."] = "Leer lassen, um Dateien auf den gleichen FTP Server zu �bertragen";
$messages["If you want to copy the files to another FTP server, enter your login data."] = "Um Dateien auf einen anderen FTP-Server zu �bertragen, geben Sie Ihre Login-Daten ein.";
$messages["Leave empty if you want to move the files to the same FTP server."] = "Leer lassen, um Dateien auf dem gleichen FTP-Server zu verschieben.";
$messages["If you want to move the files to another FTP server, enter your login data."] = "Um Dateien auf einen anderen FTP-Server zu verschieben, geben Sie Ihre Login-Daten ein.";
$messages["Copy directory <b>%1\$s</b> to:"] = "Kopiere Verzeichniss <b>%1\$s</b> nach:";
$messages["Move directory <b>%1\$s</b> to:"] = "Verschiebe Verzeichniss <b>%1\$s</b> nach:";
$messages["Directory <b>%1\$s</b>"] = "Verzeichniss <b>%1\$s</b>";
$messages["Copy file <b>%1\$s</b> to:"] = "Kopiere Datei <b>%1\$s</b> nach:";
$messages["Move file <b>%1\$s</b> to:"] = "Verschiebe Datei <b>%1\$s</b> nach:";
$messages["File <b>%1\$s</b>"] = "File <b>%1\$s</b>";
$messages["Copy symlink <b>%1\$s</b> to:"] = "Kopiere Symlink <b>%1\$s</b> nach:";
$messages["Move symlink <b>%1\$s</b> to:"] = "Verschiebe Symlink <b>%1\$s</b> nach:";
$messages["Symlink <b>%1\$s</b>"] = "Symlink <b>%1\$s</b>";
$messages["Target directory:"] = "Ziel Verzeichniss:";
$messages["Target name:"] = "Ziel Name:";
$messages["Processing the entries:"] = "Verarbeiten der Eintr�ge:";
}

// newdirectory()
if ($state2 == "newdirectory") {
$messages["Create new directories"] = "Erstellen neuer Verzeichnisse";
$messages["The new directories will be created in <b>%1\$s</b>."] = "Die neuen Verzeichnisse werden erstellt in <b>%1\$s</b>.";
$messages["New directory name:"] = "Neuer Verzeichniss Name:";
$messages["Directory <b>%1\$s</b> was successfully created."] = "Verzeichniss <b>%1\$s</b> wurde erfolgreich angelegt.";
}

// uploadfile()
if ($state2 == "uploadfile") {
$messages["Upload files and archives"] = "Dateien und Archive hochladen";
$messages["Upload results"] = "Ergebnisse des Hochladens";
$messages["Checking files:"] = "�berpr�fe Dateien:";
$messages["Transferring files to the FTP server:"] = "�bertragen der Dateien an den FTP-Server:";
$messages["Decompressing archives and transferring files to the FTP server:"] = "Entpacke Archiv und �bertrage Dateien auf den FTP-Server:";
$messages["Upload more files and archives"] = "Weitere Dateien und Ordner hochladen";
}

// printUploadForm() and javaupload()
if ($state2 == "uploadfile" || $state2 == "javaupload") {
$messages["Upload to directory:"] = "In Ordner hochladen:";
$messages["Files"] = "Dateien";
$messages["Archives"] = "Archives";
$messages["Files entered here will be transferred to the FTP server."] = "Hier angegebene Dateien werden zum FTP Server �bertragen.";
$messages["Archives entered here will be decompressed, and the files inside will be transferred to the FTP server."] = "Hier angegebene Archive werden dekomprimiert und die Dateien werden an den FTP Server �bermittelt.";
$messages["Add another"] = "Weitere hinzuf�gen";
$messages["Use folder names (creates subdirectories automatically)"] = "Benutze Ordner Namen (Erstellt Unterordner automatisch)";
$messages["Restrictions:"] = "Einschr�nkungen:";
$messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s kB</b> and by PHP to <b>%2\$s</b>"] = "Die maximale Gr��e einer Datei ist von net2ftp auf <b>%1\$s kB</b> und von PHP auf <b>%2\$s</b> begrenzt";
$messages["The maximum execution time is <b>%1\$s seconds</b>"] = "Die maximale Zeit zum ausf�hren ist <b>%1\$s Sekunden</b>";
$messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "Der FTP Transfer Modus (ASCII oder BINARY) wird automatisch gew�hlt, basierend auf der Dateierweiterung";
$messages["If the destination file already exists, it will be overwritten"] = "Wenn die Zieldatei bereits existiert wird sie �berschrieben";

$messages["Upload directories and files using a Java applet"] = "Upload directories and files using a Java applet";
$messages["Number of files:"] = "Number of files:";
$messages["Size of files:"] = "Size of files:";
$messages["Add"] = "Add";
$messages["Remove"] = "Remove";
$messages["Upload"] = "Upload";
$messages["Add files to the upload queue"] = "Add files to the upload queue";
$messages["Remove files from the upload queue"] = "Remove files from the upload queue";
$messages["Upload the files which are in the upload queue"] = "Upload the files which are in the upload queue";
$messages["Maximum server space exceeded. Please select less/smaller files."] = "Maximum server space exceeded. Please select less/smaller files.";
$messages["Total size of the files is too big. Please select less/smaller files."] = "Total size of the files is too big. Please select less/smaller files.";
$messages["Total number of files is too high. Please select fewer files."] = "Total number of files is too high. Please select fewer files.";
$messages["Note: to use this applet, Sun's Java plugin must be installed (version 1.4 or newer)."] = "Note: to use this applet, Sun's Java plugin must be installed (version 1.4 or newer).";

$messages["Browser does not support Java applets"] = "Your browser does not support applets, or you have disabled applets in your browser settings.\n";
$messages["Browser does not support Java applets"] .= "To use this applet, please install the newest version of Sun's java. You can get it from <a href=\"http://www.java.com/\">java.com</a>. Click on Get It Now.\n";
$messages["Browser does not support Java applets"] .= "The online installation is about 1-2 MB and the offline installation is about 13 MB. This 'end-user' java is called JRE (Java Runtime Environment).\n";
$messages["Browser does not support Java applets"] .= "Alternatively, use net2ftp's normal upload or upload-and-unzip functionality.\n";
}

// zipentry()
if ($state2 == "zip") {
$messages["Zip entries"] = "Zip Eintr�ge";
$messages["Save the zip file on the FTP server as:"] = "Datei als ZIP-File auf dem FTP Server speichern als:";
$messages["Email the zip file in attachment to:"] = "ZIP-Archiv im EMail-Anhang versenden an::";
$messages["Note that sending files is not anonymous: your IP address as well as the time of the sending will be added to the email."] = "Hinweis: Das Versenden von Dateien ist nicht anonym: Ihre IP-Addresse und die aktuelle Zeit werden an die EMail angeh�ngt.";
$messages["Some additional comments to add in the email:"] = "Weitere Kommentare an die EMail anh�ngen::";
$messages["You did not enter a filename for the zipfile. Go back and enter a filename."] = "Sie haben keinen Dateinamen f�r das ZIP-Archiv spezifiziert. Gehen Sie zur�ck und geben Sie einen Dateinamen an.";
$messages["The email address you have entered (%1\$s) does not seem to be valid.<br />Please enter an address in the format <b>username@domain.com</b>"] = "Die von Ihnen eingegebene EMail-Adresse (%1\$s) scheint ung�ltig zu sein.<br />Bitte geben Sie die Adresse in der Form <b>benutzername@domain.de</b> ein";
}

// calculatesize()
if ($state2 == "calculatesize") {
$messages["Size of selected directories and files"] = "Gr��e der ausgew�hlten Ordner und Dateien";
$messages["The total size taken by the selected directories and files is:"] = "Die verbrauchte Gesamtgr��e der ausgew�hlten Ordner und Dateien ist::";
$messages["The nr of files which were skipped:"] = "Anzahl der �bersprungenen Dateien:";
}

// findstring()
if ($state2 == "findstring") {
$messages["Search directories and files"] = "Suche Ordner und Dateien";
$messages["Search results"] = "Suchergebnisse";
$messages["Please enter a valid search word or phrase."] = "Bitte geben Sie ein g�ltiges Suchwort oder Satzteil ein.";
$messages["Please enter a valid filename."] = "Bitte geben Sie einen g�ltigen Dateinamen an.";
$messages["Please enter a valid file size in the \"from\" textbox, for example 0."] = "Bitte geben Sie eine g�ltige Dateigr��e im \"von\" Textfeld ein, zum Beispiel 0.";
$messages["Please enter a valid file size in the \"to\" textbox, for example 500000."] = "Bitte geben Sie eine g�ltige Dateigr��e im \"bis\" Textfeld ein, zum Beispiel 500000.";
$messages["Please enter a valid date in Y-m-d format in the \"from\" textbox."] = "Bitte geben Sie ein g�ltiges Datum in der Form J-m-t in das \"von\" Textfeld ein.";
$messages["Please enter a valid date in Y-m-d format in the \"to\" textbox."] = "Bitte geben Sie ein g�ltiges Datum in der Form J-m-t in das \"bis\" Textfeld ein.";
$messages["The word <b>%1\$s</b> was not found in the selected directories and files."] = "Das Suchwort <b>%1\$s</b> konnte in den ausgew�hlten Dateien und Ordnern nicht gefunden werden.";
$messages["The word <b>%1\$s</b> was found in the following files:"] = "Das Suchwort <b>%1\$s</b> wurde in folgenden Dateien gefunden:";
$messages["Search again"] = "Erneute Suche";
}

// printFindstringForm()
if ($state2 == "findstring") {
$messages["Search for a word or phrase"] = "Suche nach einem Wort oder Satzteil";
$messages["Case sensitive search"] = "Gro�- und Kleinschreibung bei Suche beachten";
$messages["Restrict the search to:"] = "Einschr�nken der Suche nach:";
$messages["files with a filename like"] = "Dateien mit einem Namen wie";
$messages["(wildcard character is *)"] = "(wildcard character is *)";
$messages["files with a size"] = "Dateien mit einer Gr��e";
$messages["from"] = "von";
$messages["to"] = "bis";
$messages["files which were last modified"] = "Dateien die zuletzt ge�ndert wurden am";
}

// updatefile()
if ($state2 == "updatefile") {
$messages["Update file"] = "Datei aktualisieren";
$messages["<b>WARNING: THIS FUNCTION IS STILL IN EARLY DEVELOPMENT. USE IT ONLY ON TEST FILES! YOU HAVE BEEN WARNED!"] = "<b>ACHTUNG: DIESE FUNKTION IST NOCH IM FR�HEN TESTBETRIEB. BENUTZEN SIE ES NUR MIT TESTDATEIEN! SIE WURDEN GEWARNT!";
$messages["Known bugs: - erases tab characters - doesn't work well with big files (> 50kB) - was not tested yet on files containing non-standard characters</b>"] = "Bekannte Programmfehler: - l�scht Tabulatoren - arbeitet nicht zuverl�ssig mit gro�en Dateien (> 50kB) - konnte noch nicht mit Dateien getestet werden, die einen anderen Zeichensatz verwenden</b>";
$messages["This function allows you to upload a new version of the selected file, to view what are the changes and to accept or reject each change. Before anything is saved, you can edit the merged files."] = "Diese Funktion erlaubt, eine neue Version der ausgew�hlten Datei hochzuladen, die �nderungen zu betrachten und f�r jede �nderung eine Auswahl zwischen Annehmen und Ablehnen. Vor dem Speichern k�nnen Sie die zusammengef�hrte Datei editieren.";
$messages["Old file:"] = "Alte Datei:";
$messages["New file:"] = "Neue Datei:";
$messages["Restrictions:"] = "Einschr�nkungen:";
$messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s kB</b> and by PHP to <b>%2\$s</b>"] = "Die maximale Dateigr��e ist beschr�nkt, und zwar von net2ftp auf <b>%1\$s kB</b> und von PHP auf <b>%2\$s</b>";
$messages["The maximum execution time is <b>%1\$s seconds</b>"] = "Die maximale Laufzeit betr�gt <b>%1\$s Sekunden</b>";
$messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "Der Modus des FTP-Transfers (ASCII oder BINARY) wird automatisch anhand der Dateierweiterung festgestellt.";
$messages["If the destination file already exists, it will be overwritten"] = "Wenn die Zieldatei bereits existiert, wird sie �berschrieben.";
$messages["You did not provide any files or archives to upload."] = "Sie haben keine Dateien oder Ordner zum Hochladen ausgew�hlt.";
$messages["Unable to delete the new file"] = "L�schen der neuen Datei fehlgeschlagen";
}

// printComparisonSelect()
if ($state2 == "updatefile") {
$messages["Please wait..."] = "Bitte warten...";
$messages["Select lines below, accept or reject changes and submit the form."] = "W�hlen Sie unten die Zeilen aus, w�hlen zwischen Annehmen und Ablehnen und schicken Sie das Formular ab.";
}

} // end manage


// -------------------------------------------------------------------------
// registerglobals.inc.php
// -------------------------------------------------------------------------
$messages["Please enter your username and password for FTP server "] = "Bitte geben Sie Ihren Benutzernamen und das Kennwort ein, f�r den FTP Server ";
$messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "Sie haben keine Zugangsdaten im Popup-Fenster ausgef�llt.<br />Klicken Sie unten auf \"Go to the login page\".";
$messages["Access to the net2ftp Admin panel is disabled, because no password has been set in the file settings.inc.php. Enter a password in that file, and reload this page."] = "Der Zugang zum net2ftp Administrationsbereich wurde deaktiviert, da kein Kennwort in der Datei settings.inc.php eingetragen wurde. Tragen Sie dort ein Kennwort ein, und laden diese Seite neu.";
$messages["Please enter your Admin username and password"] = "Bitte geben Sie Ihren Administrations-Benutzernamen und das entsprechende Kennwort ein"; 
$messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "Sie haben keine Zugangsdaten im Popup-Fenster ausgef�llt.<br />Klicken Sie unten auf \"Go to the login page\".";
$messages["Wrong username or password for the net2ftp Admin panel. The username and password can be set in the file settings.inc.php."] = "Falscher Benutzername oder falsches Kennwort f�r net2ftp Administrationsbereich. Bitte pr�fen Sie Ihre Eingabe bzw. die Einstellungen in der Datei settings.inc.php.";


// -------------------------------------------------------------------------
// skins.inc.php
// -------------------------------------------------------------------------
$messages["Blue"] = "Blau";
$messages["Grey"] = "Grau";
$messages["Black"] = "Schwarz";
$messages["Yellow"] = "Gelb";
$messages["Pastel"] = "Pastel";

// getMime()
$messages["Directory"] = "Verzeichnis";
$messages["Symlink"] = "Symlink";
$messages["ASP script"] = "ASP Script";
$messages["Cascading Style Sheet"] = "Cascading Style Sheet";
$messages["HTML file"] = "HTML Datei";
$messages["Java source file"] = "Java source Datei";
$messages["JavaScript file"] = "JavaScript Datei";
$messages["PHP Source"] = "PHP Source";
$messages["PHP script"] = "PHP Skript";
$messages["Text file"] = "Text Datei";
$messages["Bitmap file"] = "Bitmap Datei";
$messages["GIF file"] = "GIF Datei";
$messages["JPEG file"] = "JPEG Datei";
$messages["PNG file"] = "PNG Datei";
$messages["TIF file"] = "TIF Datei";
$messages["GIMP file"] = "GIMP Datei";
$messages["Executable"] = "Ausf�hrbare Datei";
$messages["Shell script"] = "Shell script";
$messages["MS Office - Word document"] = "MS Office - Word Dokument";
$messages["MS Office - Excel spreadsheet"] = "MS Office - Excel spreadsheet";
$messages["MS Office - PowerPoint presentation"] = "MS Office - PowerPoint Presentation";
$messages["MS Office - Access database"] = "MS Office - Access Datenbank";
$messages["MS Office - Visio drawing"] = "MS Office - Visio drawing";
$messages["MS Office - Project file"] = "MS Office - Project Datei";
$messages["OpenOffice - Writer 6.0 document"] = "OpenOffice - Writer 6.0 Dokument";
$messages["OpenOffice - Writer 6.0 template"] = "OpenOffice - Writer 6.0 Vorlage";
$messages["OpenOffice - Calc 6.0 spreadsheet"] = "OpenOffice - Calc 6.0 Tabellemndokument";
$messages["OpenOffice - Calc 6.0 template"] = "OpenOffice - Calc 6.0 Vorlage";
$messages["OpenOffice - Draw 6.0 document"] = "OpenOffice - Draw 6.0 Dokument";
$messages["OpenOffice - Draw 6.0 template"] = "OpenOffice - Draw 6.0 Vorlage";
$messages["OpenOffice - Impress 6.0 presentation"] = "OpenOffice - Impress 6.0 Pr�sentation";
$messages["OpenOffice - Impress 6.0 template"] = "OpenOffice - Impress 6.0 Vorlage";
$messages["OpenOffice - Writer 6.0 global document"] = "OpenOffice - Writer 6.0 Globaldokument";
$messages["OpenOffice - Math 6.0 document"] = "OpenOffice - Math 6.0 Dokument";
$messages["StarOffice - StarWriter 5.x document"] = "StarOffice - StarWriter 5.x document";
$messages["StarOffice - StarWriter 5.x global document"] = "StarOffice - StarWriter 5.x global Dokument";
$messages["StarOffice - StarCalc 5.x spreadsheet"] = "StarOffice - StarCalc 5.x Tabellendokument";
$messages["StarOffice - StarDraw 5.x document"] = "StarOffice - StarDraw 5.x Dokument";
$messages["StarOffice - StarImpress 5.x presentation"] = "StarOffice - StarImpress 5.x Pr�sentation";
$messages["StarOffice - StarImpress Packed 5.x file"] = "StarOffice - StarImpress gepackte 5.x Datei";
$messages["StarOffice - StarMath 5.x document"] = "StarOffice - StarMath 5.x Dokument";
$messages["StarOffice - StarChart 5.x document"] = "StarOffice - StarChart 5.x Dokument";
$messages["StarOffice - StarMail 5.x mail file"] = "StarOffice - StarMail 5.x Maildatei";
$messages["Adobe Acrobat document"] = "Adobe Acrobat Dokument";
$messages["ARC archive"] = "ARC Archiv";
$messages["ARJ archive"] = "ARJ Archiv";
$messages["RPM"] = "RPM";
$messages["GZ archive"] = "GZ Archiv";
$messages["TAR archive"] = "TAR Archiv";
$messages["Zip archive"] = "Zip Archiv";
$messages["MOV movie file"] = "MOV Videodatei";
$messages["MPEG movie file"] = "MPEG Videodatei";
$messages["Real movie file"] = "Real Videodatei";
$messages["Quicktime movie file"] = "Quicktime Datei";
$messages["Shockwave flash file"] = "Shockwave Flash Datei";
$messages["Shockwave file"] = "Shockwave Datei";
$messages["WAV sound file"] = "WAV Audiodatei";
$messages["Font file"] = "Font Datei";
$messages["%1\$s File"] = "%1\$s Datei";
$messages["File"] = "Datei";

// getAction()
$messages["Back"] = "Zur�ck";
$messages["Submit"] = "Senden";
$messages["Refresh"] = "Aktualisieren";
$messages["Details"] = "Details";
$messages["Icons"] = "Icons";
$messages["List"] = "List";
$messages["Logout"] = "Abmelden";
$messages["Help"] = "Hilfe";
$messages["Bookmark"] = "Lesezeichen";
$messages["Save"] = "Speichern";
$messages["Default"] = "Standard";


// -------------------------------------------------------------------------
// view.inc.php
// -------------------------------------------------------------------------
$messages["Image"] = "Bild";
$messages["View Macromedia ShockWave Flash movie %1\$s"] = "Macromedia ShockWave Flash Film %1\$s betrachten";
$messages["View file %1\$s"] = "Datei %1\$s anzeigen";
$messages["To save the image, right-click on it and choose 'Save picture as...'"] = "Um Bilder abzuspeichern, klicken Sie mit der rechten Maustaste darauf und w�hlen 'Bild speichern unter ...' im Kontextmen�";


// ----------------------------------------------------------------------------------
// DO NOT CHANGE ANYTHING BELOW THIS LINE
// ----------------------------------------------------------------------------------

return $messages;

} // end function getMessages

?>