<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------

//   -------------------------------------------------------------------------------
//  | Language: Italian                                                             |
//   -------------------------------------------------------------------------------
//  | www.codetown.net <email>                                                      |
//  | www.fiorotto.com <email> 2004-09-20                                           |
//   -------------------------------------------------------------------------------
//  |                                                                               |
//  |                              INSTRUCTIONS                                     |
//  |                                                                               |
//  |  The messages to translate are listed below.                                  |
//  |  The structure of each line is like this:                                     |
//  |     $message["Hello world!"] = "Hello world!";                                |
//  |                                                                               |
//  |  Keep the text between square brackets [] as it is.                           |
//  |  Translate the 2nd part, keeping the same punctuation and HTML tags.          |
//  |                                                                               |
//  |  The English message, for example                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is written in PHP!";    |
//  |  should become after translation:                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp est ecrit en PHP!";     |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is geschreven in PHP!"; |
//  |                                                                               |
//  |  Note that the variable starts with a dollar sign $, that the value is        |
//  |  enclosed in double quotes " and that the line ends with a semi-colon ;       |
//  |  Be careful when editing this file, do not erase those special characters.    |
//  |                                                                               |
//  |  Some messages also contain one or more variables which start with a percent  |
//  |  sign, for example %1\$s or %2\$s. The English message, for example           |
//  |     $messages[...] = ["The file %1\$s was copied to %2\$s "]                  |
//  |  should becomes after translation:                                            |
//  |     $messages[...] = ["Le fichier %1\$s a �t� copi� vers %2\$s "]             |
//  |                                                                               |
//  |  When a real percent sign % is needed in the text it is entered as %%         |
//  |  otherwise it is interpreted as a variable. So no, it's not a mistake.        |
//  |                                                                               |
//  |  Between the messages to translate there is additional PHP code, for example: |
//  |     if ($state2 == "rename") {                               // <-- PHP code  |
//  |     $messages["Rename directories"] = "Rename directories";  // <-- message   |
//  |     }                                                        // <-- PHP code  |
//  |  This code is needed to load the messages only when they are actually needed. |
//  |  There is no need to change or delete any of that PHP code; translate only    |
//  |  the message.                                                                 |
//  |                                                                               |
//  |  Thanks in advance to all the translators!                                    |
//  |  David.                                                                       |
//  |                                                                               |
//   -------------------------------------------------------------------------------

function getMessages() {
global $state, $state2;


// -------------------------------------------------------------------------
// Used encoding
// -------------------------------------------------------------------------
$messages["iso-8859-1"] = "iso-8859-1";


// -------------------------------------------------------------------------
// Status messages
// -------------------------------------------------------------------------
// When translating these messages, keep in mind that the text should not be too long
// It should fit in the status textbox
$messages["Connecting to the FTP server"] = "Connessione al server FTP";
$messages["Getting the list of directories and files"] = "Sto rilevando l&acute;elenco delle cartelle e dei file";
$messages["Printing the list of directories and files"] = "Stampa l&acute;elenco delle cartelle e dei file";
$messages["Processing the entries"] = "Analisi dei dati";
$messages["Checking files"] = "Controllo dei file";
$messages["Transferring files to the FTP server"] = "Trasferimento dei file verso il server FTP";
$messages["Decompressing archives and transferring files"] = "Decompressione degli archivi e trasferimento dei file";
$messages["Searching the files..."] = "Ricerca file...";
$messages["Uploading new file"] = "Carica (Upload) un nuovo file";
$messages["Reading the new file"] = "Lettura del nuovo file";
$messages["Reading the old file"] = "Lettura del vecchio file";
$messages["Comparing the 2 files"] = "Confronto fra i due file";
$messages["Printing the comparison"] = "Stampa il risultato del confronto";
$messages["Script finished in %1\$s seconds"] = "Esecuzione finita in %1\$s secondi";
$messages["Script halted"] = "Esecuzione arrestata";


// -------------------------------------------------------------------------
// index.php
// -------------------------------------------------------------------------
$messages["Unexpected state string. Exiting."] = "Stringa di stato inattesa. Interrompo l&acute;esecuzione.";
$messages["This beta function is not activated on this server."] = "Questa funzione beta non e&acute; attiva su questo server.";
$messages["This function has been disabled by the Administrator of this website."] = "This function has been disabled by the Administrator of this website.";

 
// -------------------------------------------------------------------------
// admin.inc.php
if ($state == "admin") {
// -------------------------------------------------------------------------
$messages["Admin functions"] = "Funzioni di amministrazione";

$messages["Version information"] = "Info versione";
$messages["This version of net2ftp is up-to-date"] = "Questa versione di net2ftp e&acute; aggiornata";
$messages["The latest version could not be retrieved from the net2ftp.com server. Check the security settings of your browser, which may prevent the loading of a small file from the net2ftp.com server."] = "L&acute;ultima versione non puo&acute; essere scaricata dal server net2ftp.com. Controlla le impostazioni di sicurezza del tuo browser, le quali possono impedire di scaricare un piccolo file dal sito net2ftp.com.";

$messages["Logging"] = "Accesso in corso";
$messages["Date from:"] = "Dal :";
$messages["to:"] = "al:";
$messages["Empty logs"] = "Vuoto";
$messages["View logs"] = "Vedi log";
$messages["No data"] = "Nessun dato";

$messages["Setup MySQL tables"] = "Imposta tabelle MySQL";
$messages["Go"] = "Esegui";
$messages["Create the MySQL database tables"] = "Crea le tabelle MySQL";
$messages["Create tables"] = "Crea tabelle";
$messages["The handle of file %1\$s could not be opened"] = "Problemi in apertura del file %1\$s";
$messages["The file %1\$s could not be opened"] = "Non riesco ad aprire il file %1\$s";
$messages["The handle of file %1\$s could not be closed"] = "Problemi in chiusura del file %1\$s";
$messages["MySQL username"] = "MySQL username";
$messages["MySQL password"] = "MySQL password";
$messages["MySQL database"] = "MySQL database";
$messages["MySQL server"] = "MySQL server";
$messages["This SQL query is going to be executed:"] = "Verra&acute; eseguita questa query SQL:";
$messages["Execute"] = "Esegui";
$messages["Settings used:"] = "Impostazioni utilizzate:";
$messages["MySQL password length"] = "Lunghezza password MySQL";
$messages["Results:"] = "Risultati:";
$messages["The connection to the server <b>%1\$s</b> could not be set up"] = "La connessione al server <b>%1\$s</b> non puo&acute; essere impostata";
$messages["Unable to select the database <b>%1\$s</b>"] = "Database <b>%1\$s</b> non trovato";
$messages["The SQL query could not be executed"] = "La query SQL non puo&acute; essere eseguita";
$messages["The tables were created successfully"] = "Le tabelle sono state create con successo";

$messages["Beta functions"] = "Funzioni BETA";
$messages["View logs"] = "Vedi i log";
$messages["Empty logs"] = "Azzera i log";
$messages["The table <b>%1\$s</b> was emptied successfully."] = "La tabella <b>%1\$s</b> e&acute; stata svuotata correttamente.";
$messages["The table <b>%1\$s</b> could not be emptied."] = "La tabella <b>%1\$s</b> non puo&acute; essere svuotata.";

} // end admin

// -------------------------------------------------------------------------
// advanced.inc.php
if ($state == "advanced") {
// -------------------------------------------------------------------------

// advanced()
$messages["The site command functions are not available on this webserver."] = "Le funzioni di comando del sito non sono disponibili su questo server web.";
$messages["The Apache functions are not available on this webserver."] = "Le funzioni Apache non sono disponibili su questo server web.";
$messages["The MySQL functions are not available on this webserver."] = "Le funzioni MySQL non sono disponibili su questo server web.";
$messages["Unexpected state2 string. Exiting."] = "Stringa di stato2 inattesa. Interrompo l&acute;esecuzione.";
// printAdvancedFunctions()
$messages["Advanced functions"] = "Funzioni Avanzate";
$messages["Go"] = "Esegui";
$messages["Troubleshooting functions"] = "Funzioni di controllo";
$messages["Troubleshoot net2ftp on this webserver"] = "Controlla net2ftp su questo server web";
$messages["Troubleshoot an FTP server"] = "Controlla un server FTP";
$messages["Translation functions"] = "Funzioni di traduzione";
$messages["Introduction to the translation functions"] = "Introduzione alle funzionalita&acute; di traduzione";
$messages["Extract messages to translate from code files"] = "Estrai i messaggi da tradurre dai file sorgente";
$messages["Check if there are new or obsolete messages"] = "Controlla se ci sono vecchi o nuovi messaggi";
$messages["Beta functions"] = "Funzione beta";
$messages["Send a site command to the FTP server"] = "Invia un comando FTP al server";
$messages["Apache: password-protect a directory, create custom error pages"] = "Apache: proteggi una cartella, crea pagine di errore personali";
$messages["MySQL: execute an SQL query"] = "MySQL: esegui una query SQL";

// troubleshoot_webserver()
$messages["Troubleshoot your net2ftp installation"] = "Controlla la tua installazione di net2ftp";
$messages["Checking if the FTP module of PHP is installed: "] = "Controlla se il modulo FTP di PHP e&acute; installato: ";
$messages["yes"] = "si";
$messages["no - please install it!"] = "no - per favore installalo!";
$messages["Checking the permissions of the directory on the web server: a small file will be written to the /temp folder and then deleted."] = "Controlla i permessi della cartella sul server web: un piccolo file di prova verra&acute; scritto nella cartella /temp e poi verra&acute; eliminato.";
$messages["Creating filename: "] = "Crea il file: ";
$messages["OK. Filename: %1\$s"] = "OK. Nome del file: %1\$s";
$messages["not OK"] = "non va bene";
$messages["OK"] = "OK";
$messages["not OK. Check the permissions of the %1\$s directory"] = "non va bene. Controlla i permessi della cartella %1\$s";
$messages["Opening the file in write mode: "] = "Apre il file in scrittura: ";
$messages["Writing some text to the file: "] = "Inserimento di testo nel file: ";
$messages["Closing the file: "] = "Chiusura del file: ";
$messages["Deleting the file: "] = "Eliminazione del file: ";

// troubleshoot_ftpserver()
$messages["Troubleshoot an FTP server"] = "Controlla un server FTP";
$messages["FTP server port"] = "Porta del server FTP";
$messages["Connection settings:"] = "Settaggi di connessione:";
$messages["Password length"] = "Lunghezza della password";
$messages["Language"] = "Lingua";
$messages["Skin number"] = "Skin numero";
$messages["Connecting to the FTP server: "] = "Connessione al server FTP: ";
$messages["Logging into the FTP server: "] = "Accesso al server FTP: ";
$messages["Setting the passive mode: "] = "Setto la modalita&acute; passive mode: ";
$messages["Getting the FTP server system type: "] = "Tipo di server FTP: ";
$messages["Changing to the directory %1\$s: "] = "Cambio alla cartella %1\$s: ";
$messages["The directory from the FTP server is: %1\$s "] = "La cartella del server FTP e&acute;: %1\$s ";
$messages["Getting the raw list of directories and files: "] = "Rilevamento dell&acute;elenco cartelle e file: ";
$messages["Trying a second time to get the raw list of directories and files: "] = "Secondo tentativo di rilevamento dell&acute;elenco cartelle e file: ";
$messages["Closing the connection: "] = "Chiusura della connessione: ";
$messages["Raw list of directories and files:"] = "Elenco delle cartelle e dei file:";
$messages["Parsed list of directories and files:"] = "Elenco ordinato delle cartelle e dei file:";

// printTranslationFunctions()
$messages["net2ftp translation functions"] = "Funzionalita&acute; di traduzione net2ftp";
$messages["A PHP application can be translated using the standard <a href=\"http://www.php.net/gettext\">gettext</a> functions, or using a self-made translation function."] = "Un&acute;applicazione PHP puo&acute; essere tradotta usando la funzione standard <a href=\"http://www.php.net/gettext\">gettext</a>, oppure utilizzando una funzione costruita appositamente.";
$messages["In both cases, the steps to take are similar."] = "In ambedue i casi, i passi da seguire sono simili.";
$messages["Step 1: change code"] = "Passo 1: cambiare codice";
$messages["All messages must be translated using a translation function, for example translate()."] = "Tutti i messaggi devono essere tradotti usando la funzione di traduzione, per esempio translate().";
$messages["This Hello World code:"] = "Questo codice Hello World:";
$messages["must be changed to this:"] = "sara&acute; cambiato in questo:";
$messages["Step 2: extract messages"] = "Passo 2: estrai i messaggi";
$messages["All messages which are used by the translate() function must be extracted from the code files, and copied to a <b>main message file</b>."] = "Tutti i messaggi utilizzati dalla funzione translate() saranno estratti dai file sorgente, e copiati in un <b>file dei messaggi principale</b>.";
$messages["Step 3: translate messages"] = "Passo 3: tradurre i messaggi";
$messages["The main message file is given to translators, who rename the file and replace the messages in English by the translation."] = "Il file principale dei messaggi sara&acute; consegnato al traduttore, che rinominera&acute; il file e cambiera&acute; i messaggi con la lingua traduzione.";
$messages["The translators return the <b>translated message files</b>."] = "The translators return the <b>translated message files</b>.";
$messages["Each time the application is modified, a new main message file must be generated, as in step 2."] = "Ogni volta che l&acute;applicazione sara&acute; modificata, deve essere generato un file principale dei messaggi (vedi passo 2).";
$messages["In order to avoid translating everything all over again, it must then be compared to all translated message files, to check if there are new or obsolete messages."] = "Per effettuare una traduzione corretta di tutto, tale file va comparato con il file tradotto, cosi&acute; da rilevare le differenze (messaggi obsoleti e/o aggiunti).";
$messages["net2ftp can help in step 2 to extract messages to translate from code files"] = "net2ftp puo&acute; aiutarti nel passo 2 di estrazione dei messaggi dal codice sorgente";
$messages["net2ftp can help in step 4 to check if there are new or obsolete messages"] = "net2ftp puo&acute; aiutarti nel passo 4 di controllo sui messaggi obsoleti o nuovi";

// translate_extract()
$messages["Extract messages from code files"] = "Estrai messaggi dai file sorgente";
$messages["Directory containing code files:"] = "Cartella contente i file sorgente:";
$messages["Translation function used in the code:"] = "Funzioni di traduzione usate nel codice:";
$messages["File to generate:"] = "File da generare:";
$messages["Extracted messages:"] = "Messaggi estratti:";
$messages["No messages were found, so no file was put on the FTP server."] = "Non sono stati trovati messaggi, nessun file inserito nel serve FTP.";
$messages["The main language file <b>%1\$s</b> was transferred to directory <b>%2\$s</b>."] = "Il file di linguaggio principale <b>%1\$s</b> e&acute; stato trasferito nella cartella <b>%2\$s</b>.";

// translate_check()
$messages["Main language file:"] = "Linguaggio file principale:";
$messages["Directory containing translated language files:"] = "Cartella contenente i file di linguaggio tradotti:";
$messages["File %1\$s was skipped because it could not be read, or because it was empty."] = "Il file %1\$s e&acute; stato saltato perche&acute; non puo&acute; essere letto, oppure e&acute; vuoto..";
$messages["File nr %1\$s <b>%2\$s</b>"] = "File n. %1\$s <b>%2\$s</b>";
$messages["New messages:"] = "Messaggi nuovi/aggiunti:";
$messages["Obsolete messages:"] = "Messaggi vecchi/obsoleti:";
$messages["All the files have been processed"] = "Tutti i file sono stati analizzati";

// sendsitecommand()
$messages["Send site command"] = "Invia comando FTP";
$messages["Enter the site command"] = "Inserisci un comando FTP";
$messages["The commands you can use depends on your FTP server. These commands are not standard and vary a lot from one server to the other."] = "La disponibilita&acute; dei comandi dipende dal tipo di server FTP. Non tutti i server FTP sono uguali.";
$messages["Note that net2ftp cannot display the output of the FTP server, it can only tell if the command returned TRUE or FALSE. This is not a limitation of net2ftp but of PHP, the language in which net2ftp is written."] = "Net2ftp non puo&acute; visualizzare l&acute;output del server FTP, puo&acute; solo confermare la corretta esecuzione o meno del comando inviato (limitazione dovuta a PHP).";
$messages["The command <b>%1\$s</b> was executed successfully."] = "Il comando <b>%1\$s</b> e&acute; stato eseguito con successo.";

// apache(), mysqlfunctions()
// Not yet translated

} // end advanced



// -------------------------------------------------------------------------
// authorizations.inc.php
// -------------------------------------------------------------------------

// checkAuthorization()
$messages["The FTP server <b>%1\$s</b> is not in the list of allowed FTP servers."] = "Il server FTP <b>%1\$s</b> non e&acute; nell&acute;elenco dei server FTP permessi.";
$messages["The FTP server <b>%1\$s</b> is in the list of banned FTP servers."] = "Il server FTP <b>%1\$s</b> e&acute; nell&acute;elenco dei server FTP proibiti.";
$messages["Your IP address (%1\$s) is in the list of banned IP addresses."] = "Il tuo indirizzo IP (%1\$s) e&acute; nell&acute;elenco degli indirizzi IP banditi.";
$messages["The FTP server port %1\$s may not be used."] = "La porta %1\$s del server FTP non puo&acute; essere usata.";
$messages["You don't have the authorizations to view directory <b>%1\$s</b>."] = "Non ha sufficienti autorizzazioni per vedere la cartella <b>%1\$s</b>.";

// logAccess(), logLogin(), logError()
// Not yet translated


// -------------------------------------------------------------------------
// bookmark.inc.php
if ($state == "bookmark") {
// -------------------------------------------------------------------------
$messages["Add this link to your bookmarks:"] = "Aggiungi questo link ai tuoi Favoriti:";
$messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer: clicca col tasto destro sul link e scegli \"Aggiungi ai Favoriti...\"";
$messages["Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla, Firefox: clicca col tasto destro sul link e scegli \"Metti questo link nei Bookmark...\"";
$messages["Note: when you will use this bookmark, a popup window will ask you for your username and password."] = "Nota: quando userai questo bookmark, una finestra popup ti chiedera&acute; il tuo username e la tua password.";

} // end bookmark


// -------------------------------------------------------------------------
// browse.inc.php
if ($state == "browse") {
// -------------------------------------------------------------------------

// browse()
$messages["Directories with names containing \' cannot be displayed correctly. They can only be deleted. Please go back and select another subdirectory."] = "Le cartelle con i nomi che contengono \' non possono essere mostrate correttamente. Possono solo essere eliminate. Per favore torna indietro e seleziona una sotto-cartella diversa.";

$messages["Consumption message"]  = "";
$messages["Consumption message"] .= "<b>Limite giornaliero raggiunto: non e&acute; possibile trasferire ulteriori file</b><br /><br />\n";
$messages["Consumption message"] .= "per garantire a tutti un uso efficente del sistema net2ftp, sono impostati un limite di trasferimento e un timeout di esecuzione per ugni utente. A limite raggiunto sara&acute; possibile effettuare solo un browse dei file senza nessun tipo di trasferimento.<br /><br />\n";
$messages["Consumption message"] .= "Se desideri un utilizzo senza limiti, installa net2ftp nel tuo proprio sito web.<br />\n";

// ftp_getlist()
$messages["The directory <b>%1\$s</b> does not exist or could not be selected, so the root directory <b>/</b> is shown instead."] = "La cartella <b>%1\$s</b> non esiste o non puo&acute; essere selezionata, quindi verra&acute; mostrata la cartella radice <b>/</b> al suo posto.";

// printdirfilelist()
// Keep this short, it must fit in a small button!
$messages["New dir"] = "Nuova cartella";
$messages["New file"] = "Nuovo file";
$messages["HTML templates"] = "HTML templates";
$messages["Upload"] = "Carica";
$messages["Java Upload"] = "Carica Java";
$messages["Advanced"] = "Funzioni avanzate";
$messages["Copy"] = "Copia";
$messages["Move"] = "Sposta";
$messages["Delete"] = "Elimina";
$messages["Rename"] = "Rinomina";
$messages["Chmod"] = "CHMOD";
$messages["Download"] = "Scarica";
$messages["Zip"] = "Zip";
$messages["Size"] = "Dimensione";
$messages["Search"] = "Cerca";
$messages["Go to the parent directory"] = "Vai alla cartella di livello superiore";
$messages["Transform selected entries: "] = "Trasforma gli elementi selezionati: ";
$messages["Make a new subdirectory in directory %1\$s"] = "Crea una nuova sotto-cartella nella cartella %1\$s";
$messages["Create a new file in directory %1\$s"] = "Crea un nuovo file nella cartella %1\$s";
$messages["Upload new files in directory %1\$s"] = "Caricamento nuovi file nella cartella %1\$s";
$messages["Go to the advanced functions"] = "Vai alle funzioni avanzate";
$messages["Copy the selected entries"] = "Copia gli elementi selezionati";
$messages["Move the selected entries"] = "Sposta gli elementi selezionati";
$messages["Delete the selected entries"] = "Elimina gli elementi selezionati";
$messages["Rename the selected entries"] = "Renonima gli elementi selezionati";
$messages["Chmod the selected entries (only works on Unix/Linux/BSD servers)"] = "CHMOD sugli elementi selezionati (solo per servers Unix/Linux/BSD)";
$messages["Download a zip file containing all selected entries"] = "Scarica un archivio zip che contiene gli elementi selezionati";
$messages["Zip the selected entries to save or email them"] = "Crea un archivio zip con gli elementi selezionati da salvare o mandare via e-mail";
$messages["Calculate the size of the selected entries"] = "Calcola le dimensioni degli elementi selezionati";
$messages["Find files which contain a particular word"] = "Trova i file che contengono una determinata parola";
$messages["Click to sort by %1\$s in descending order"] = "Clicca per ordinare per %1\$s in ordine descrescente";
$messages["Click to sort by %1\$s in ascending order"] = "Clicca per ordinare per %1\$s in ordine crescente";
$messages["Ascending order"] = "Ordine crescente";
$messages["Descending order"] = "Ordine descrescente";
$messages["Up"] = "Su";
$messages["Click to check or uncheck all rows"] = "Clicca per selezionare/deselezionare tutte le righe";
$messages["All"] = "Tutto";
$messages["Name"] = "Nome";
$messages["Type"] = "Tipo";
$messages["Owner"] = "Utente";
$messages["Group"] = "Gruppo";
$messages["Perms"] = "Permessi";
$messages["Mod Time"] = "Ora modifica";
$messages["Actions"] = "Azioni";
$messages["Download the file %1\$s"] = "Scarica il file %1\$s";
$messages["View"] = "Vedi";
$messages["Edit"] = "Modifica";
$messages["Update"] = "Aggiorna";
$messages["Open"] = "Apri";
$messages["View the highlighted source code of file %1\$s"] = "Vedi il codice sorgente selezionato del file %1\$s";
$messages["Edit the source code of file %1\$s"] = "Modifica il codice sorgente del file %1\$s";
$messages["Upload a new version of the file %1\$s and merge the changes"] = "Carica una nuova versione del file %1\$s e sincronizza i cambiamenti";
$messages["View image %1\$s"] = "Guarda l&acute;immagine %1\$s";
$messages["View the file %1\$s from your HTTP web server"] = "Guarda il file %1\$s dal tuo web server HTTP";
$messages["(Note: This link may not work if you don't have your own domain name.)"] = "(Nota: Questo link puo&acute; non funzionare se non hai un tuo dominio personale.)";
$messages["This folder is empty"] = "Questa cartella e&acute; vuota";

// printSeparatorRow()
$messages["Directories"] = "Cartelle";
$messages["Files"] = "File";
$messages["Symlinks"] = "Link simbolici";
$messages["Unrecognized FTP output"] = "Risultato FTP non riconosciuto";
$messages["Number"] = "Number";
$messages["Size"] = "Size";
$messages["Skipped"] = "Skipped";

// printLocationActions()
$messages["Language:"] = "Lingua:";
$messages["Skin:"] = "Skin:";
$messages["View mode:"] = "Modalita&acute; visione:";
$messages["Directory Tree"] = "Struttura cartelle";

// printURL()
$messages["Execute %1\$s in a new window"] = "Esegui %1\$s in una nuova finestra";

// printDirectorySelect()
$messages["Double-click to go to a subdirectory:"] = "Clicca due volte per andare in una sotto-cartella:";
$messages["Choose"] = "Scegli";
$messages["Up"] = ".. (livello superiore)";

} // end browse


// -------------------------------------------------------------------------
// consumption.inc.php
// -------------------------------------------------------------------------
$messages["Unable to determine your IP address."] = "Non riesco a determinare il tuo indirizzo IP.";
$messages["Table net2ftp_logConsumptionIpaddress contains duplicate rows."] = "La tabella net2ftp_logConsumptionIpaddress contiene una riga doppia.";
$messages["Table net2ftp_logConsumptionFtpserver contains duplicate rows."] = "La tabella net2ftp_logConsumptionFtpserver contiene una riga doppia.";
$messages["The variable <b>consumption_ipaddress_dataTransfer</b> is not numeric."] = "La variabile <b>consumption_ipaddress_dataTransfer</b> non � numerica.";
$messages["Table net2ftp_logConsumptionIpaddress could not be updated."] = "La tabella net2ftp_logConsumptionIpaddress non puo&acute; essere aggiornata.";
$messages["Table net2ftp_logConsumptionIpaddress contains duplicate entries."] = "La tabella net2ftp_logConsumptionIpaddress contiene dati doppi.";
$messages["Table net2ftp_logConsumptionFtpserver could not be updated."] = "La tabella net2ftp_logConsumptionFtpserver non puo&acute; essere aggiornata.";
$messages["Table net2ftp_logConsumptionFtpserver contains duplicate entries."] = "La tabella net2ftp_logConsumptionFtpserver contiente dati doppi.";
$messages["Daily limit reached: the file <b>%1\$s</b> will not be transferred"] = "Limite giornaliero raggiunto: il file <b>%1\$s</b> non sara&acute; trasferito";


// -------------------------------------------------------------------------
// database.inc.php
// -------------------------------------------------------------------------
$messages["Unable to connect to the DB"] = "Collegamento al DB fallito";
$messages["Unable to select the DB"] = "Selezione DB non riuscita";


// -------------------------------------------------------------------------
// easywebsite.inc.php
if ($state == "easyWebsite") {
// -------------------------------------------------------------------------
$messages["Create a website in 4 easy steps"] = "Create a website in 4 easy steps";
$messages["Template overview"] = "Template overview";
$messages["Template details"] = "Template details";
$messages["Files are copied"] = "Files are copied";
$messages["Edit your pages"] = "Edit your pages";

// Screen 1 - printTemplateOverview
$messages["Click on the image to view the details of a template."] = "Click on the image to view the details of a template.";
$messages["Back to the Browse screen"] = "Back to the Browse screen";
$messages["Template"] = "Template";
$messages["Copyright"] = "Copyright";
$messages["Click on the image to view the details of this template"] = "Click on the image to view the details of this template";

// Screen 2 - printTemplateDetails
$messages["The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?"] = "The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?";
$messages["Preview"] = "Preview";
$messages["Install"] = "Install";
$messages["Size"] = "Size";
$messages["Preview page"] = "Preview page";
$messages["opens in a new window"] = "opens in a new window";

// Screen 3
$messages["Please wait while the template files are being transferred to your server: "] = "Please wait while the template files are being transferred to your server: ";
$messages["Done."] = "Done.";
$messages["Continue"] = "Continue";

// Screen 4 - printEasyAdminPanel
$messages["Edit page"] = "Edit page";
$messages["Browse the FTP server"] = "Browse the FTP server";
$messages["Add this link to your favorites to return to this page later on!"] = "Add this link to your favorites to return to this page later on!";
$messages["Edit website at %1\$s"] = "Edit website at %1\$s";
$messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer: right-click on the link and choose \"Add to Favorites...\"";
$messages["Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\"";

// ftp_copy_local2ftp
$messages["WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing..."] = "WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing...";
$messages["Created target subdirectory <b>%1\$s</b>"] = "Created target subdirectory <b>%1\$s</b>";
$messages["WARNING: Unable to copy the file <b>%1\$s</b>. Continuing..."] = "WARNING: Unable to copy the file <b>%1\$s</b>. Continuing...";
$messages["Copied file <b>%1\$s</b>"] = "Copied file <b>%1\$s</b>";
}


// -------------------------------------------------------------------------
// edit.inc.php
if ($state == "manage" && ($state2 == "edit" || $state2 == "newfile")) {
// -------------------------------------------------------------------------

// edit()
$messages["Unable to open the template file"] = "Non e&acute; possibile aprire il file template";
$messages["Unable to read the template file"] = "Non e&acute; possibile leggere il file template";
$messages["Please specify a filename"] = "Per favore specifica un nome per il file";

// printEditForm()
$messages["Directory: "] = "Cartella: ";
$messages["File: "] = "File: ";
$messages["New file name: "] = "Nuovo nome per il file: ";
$messages["Note: changing the textarea type will save the changes"] = "Nota: cambiando il tipo di area testuale salvera&acute; le modifiche fatte finora";
$messages["Status: This file has not yet been saved"] = "Stato: Questo file non e&acute; stato ancora salvato";
$messages["Status: Saved on <b>%1\$s</b> using mode %2\$s"] = "Stato: Salvato il <b>%1\$s</b> usando la modalita&acute; %2\$s";
$messages["Status: <b>This file could not be saved</b>"] = "Stato: <b>Questo file non puo&acute; essere salvato</b>";

} // end if edit newfile


// -------------------------------------------------------------------------
// errorhandling.inc.php
// -------------------------------------------------------------------------
$messages["An error has occured"] = "Si e&acute; verificato un errore";
$messages["Go back"] = "Torna indietro";
$messages["Go to the login page"] = "Torna alla pagina di accesso";


// -------------------------------------------------------------------------
// filesystem.inc.php
// -------------------------------------------------------------------------

// ftp_openconnection()
$messages["The <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this FTP module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">php.net</a><br />"] = "Il <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">modulo FTP del PHP</a> non e&acute; installato.<br /><br /> l&acute;amministratore di questo sito dovrebbe installare questo modulo FTP. Istruzioni sull&acute;istallazione sono date su <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">php.net</a><br />";
$messages["Unable to connect to FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "Non e&acute; possibile connettersi al server FTP <b>%1\$s</b> sulla porta <b>%2\$s</b>.<br /><br />Sei sicuro che questo sia l&acute;indirizzo del server FTP? Spesso tale indirizzo e&acute; diverso da quello del server web HTTP. Per favore contatta il tuo provider ISP o l&acute;amministratore di sistema per aiuto.<br />";
$messages["Unable to login to FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "Non e&acute; possibile effettuare l&acute;accesso al server FTP <b>%1\$s</b> con username <b>%2\$s</b>.<br /><br />Sei sicuro che il tuo username e la password sono corrette? Per favore contatta il tuo provider ISP o l&acute;amministratore di sistema per aiuto.<br />";
$messages["Unable to switch to the passive mode on FTP server <b>%1\$s</b>."] = "Non e&acute; possibile passare in modalita&acute; -passive mode- sul server FTP <b>%1\$s</b>.";

// ftp_openconnection2()
$messages["Unable to connect to the second (target) FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the second (target) FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "Non e&acute; possibile connettersi al server FTP di destinazione <b>%1\$s</b> sulla porta <b>%2\$s</b>.<br /><br />Sei sicuro che dell&acute;indirizzo del server FTP di destinazione? Spesso tale indirizzo e&acute; diverso da quello del server web HTTP. Per favore contatta il tuo provider ISP o l&acute;amministratore di sistema per aiuto.<br />";
$messages["Unable to login to the second (target) FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "Non e&acute; possibile effettuare l&acute;accesso al server FTP di destinazione <b>%1\$s</b> con username <b>%2\$s</b>.<br /><br />Sei sicuro che il tuo username e la password sono corrette? Per favore contatta il tuo provider ISP o l&acute;amministratore di sistema per aiuto.<br />";
$messages["Unable to switch to the passive mode on the second (target) FTP server <b>%1\$s</b>."] = "Non e&acute; possibile passare in modalita&acute; passive mode sul server FTP di destinazione <b>%1\$s</b>.";

// ftp_myrename()
$messages["Unable to rename directory or file <b>%1\$s</b> into <b>%2\$s</b>"] = "Non e&acute; possibile rinominare la cartella o il file <b>%1\$s</b> in <b>%2\$s</b>";

// ftp_mychmod()
$messages["Unable to execute site command <b>%1\$s</b>. Note that the CHMOD command is only available on Unix FTP servers, not on Windows FTP servers."] = "Non e&acute; possibile i comandi del sito <b>%1\$s</b>. Nota che il comando CHMOD e&acute; disponibile solo su server FTP Unix/Linux, non su server FTP Windows.";
$messages["Directory <b>%1\$s</b> successfully chmodded to <b>%2\$s</b>"] = "E&acute; stato eseguito con successo un CHMOD <b>%2\$s</b> sulla cartella <b>%1\$s</b>";
$messages["File <b>%1\$s</b> was successfully chmodded to <b>%2\$s</b>"] = "E&acute; stato eseguito con successo un CHMOD <b>%2\$s</b> sul file <b>%1\$s</b>";
$messages["All the selected directories and files have been processed."] = "I file e le cartelle selezionati sono stati elaborati.";

// ftp_rmdir2()
$messages["Unable to delete the directory <b>%1\$s</b>"] = "Non e&acute; possibile eliminare la cartella <b>%1\$s</b>";

// ftp_delete2()
$messages["Unable to delete the file <b>%1\$s</b>"] = "Non e&acute; possibile eliminare il file <b>%1\$s</b>";

// ftp_newdirectory()
$messages["Unable to create the directory <b>%1\$s</b>"] = "Non e&acute; possibile creare la cartella <b>%1\$s</b>";

// ftp_readfile()
$messages["Unable to create the temporary file"] = "Non e&acute; possibile creare il file temporaneo";
$messages["Unable to get the file <b>%1\$s</b> from the FTP server and to save it as temporary file <b>%2\$s</b>.<br />Check the permissions of the %3\$s directory.<br />"] = "Non e&acute; possibile ottenere il file <b>%1\$s</b> dal server FTP e salvarlo come file temporaneo <b>%2\$s</b>.<br />Controlla i permessi della cartella %3\$s.<br />";
$messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "Non e&acute; possibile aprire il file temporaneo. Controlla i permessi della cartella %1\$s.";
$messages["Unable to read the temporary file"] = "Non e&acute; possibile leggere i file temporanei";
$messages["Unable to close the handle of the temporary file"] = "Non e&acute; possibile chiudere il file temporaneo";
$messages["Unable to delete the temporary file"] = "Non e&acute; possibile eliminare il file temporaneo";

// ftp_writefile()
$messages["Unable to create the temporary file. Check the permissions of the %1\$s directory."] = "Non e&acute; possibile creare il file temporaneo. Controlla i permessi della cartella %1\$s.";
$messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "Non e&acute; possibile aprire il file temporaneo. Controlla i permessi della cartella %1\$s.";
$messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "Non e&acute; possibile ascrivere la stringa nel file temporaneo <b>%1\$s</b>.<br />Controlla i permessi della cartella %2\$s.";
$messages["Unable to close the handle of the temporary file"] = "Non e&acute; possibile a chiudere il file temporaneo";
$messages["Unable to put the file <b>%1\$s</b> on the FTP server.<br />You may not have write permissions on the directory."] = "Non e&acute; possibile inserire il file <b>%1\$s</b> sul server FTP.<br />Forse non hai permessi in scrittura su quella cartella.";
$messages["Unable to delete the temporary file"] = "non e&acute; possibile eliminare il file temporaneo";

// ftp_copymovedelete()
$messages["Processing directory <b>%1\$s</b>"] = "Sto elaborando la cartella<b>%1\$s</b>";
$messages["The target directory <b>%1\$s</b> is the same as or a subdirectory of the source directory <b>%2\$s</b>, so this directory will be skipped"] = "La cartella di destinazione <b>%1\$s</b> e&acute; identica o e&acute; una sotto-cartella della cartella di origine <b>%2\$s</b>, quindi questa cartella verra&acute; saltata";
$messages["Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing the copy/move process..."] = "Non e&acute; possibile creare la sotto-cartella <b>%1\$s</b>. Forse esiste gia&acute;. Continuo l&acute;esecuzione di copia/spostamento...";
$messages["Created target subdirectory <b>%1\$s</b>"] = "E&acute; stata creata la sotto-cartella di destinazione <b>%1\$s</b>";
$messages["Unable to delete the subdirectory <b>%1\$s</b> - it may not be empty"] = "Non e&acute; possibile eliminare la sotto-cartella <b>%1\$s</b> - forse non e&acute; vuota";
$messages["Deleted subdirectory <b>%1\$s</b>"] = "E&acute; stata eliminata la sotto-cartella <b>%1\$s</b>";
$messages["Processing of directory <b>%1\$s</b> completed"] = "Completata l&acute;analisi della cartella <b>%1\$s</b>";
$messages["The target for file <b>%1\$s</b> is the same as the source, so this file will be skipped"] = "La destinazione per il file <b>%1\$s</b> e&acute; identica all&acute;origine, quindi questo file verra&acute; saltato";
$messages["Unable to copy the file <b>%1\$s</b>"] = "Non e&acute; possibile copiare il file <b>%1\$s</b>";
$messages["Copied file <b>%1\$s</b>"] = "Copiato il file <b>%1\$s</b>";
$messages["Unable to move the file <b>%1\$s</b>"] = "Non riesco a spostare il file <b>%1\$s</b>";
$messages["Moved file <b>%1\$s</b>"] = "Spostato il file <b>%1\$s</b>";
$messages["Unable to delete the file <b>%1\$s</b>"] = "Non e&acute; possibile eliminare il file<b>%1\$s</b>";
$messages["Deleted file <b>%1\$s</b>"] = "E&acute; stato eliminato il file <b>%1\$s</b>";
$messages["All the selected directories and files have been processed."] = "Tutte le cartelle e i file selezionati sono stati elaborati.";

// ftp_processfiles()

// ftp_getfile()
$messages["Unable to copy the remote file <b>%1\$s</b> to the local file using FTP mode <b>%2\$s</b>"] = "Non e&acute; possibile copiare il file remoto <b>%1\$s</b> in un file locale usando la modalita&acute; FTP <b>%2\$s</b>";
$messages["Unable to delete file <b>%1\$s</b>"] = "Non e&acute; possibile eliminare il file <b>%1\$s</b>";

// ftp_putfile()
$messages["Unable to copy the local file to the remote file <b>%1\$s</b> using FTP mode <b>%2\$s</b>"] = "Non e&acute; possibile copiare il file locale nel file remoto <b>%1\$s</b> usando la modalita&acute; FTP <b>%2\$s</b>";
$messages["Unable to delete the local file"] = "Non riesco a eliminare il file locale";

// ftp_downloadfile()
$messages["Unable to delete the temporary file"] = "Non e&acute; possibile eliminare il file temporaneo";
$messages["Unable to send the file to the browser"] = "Non e&acute; possibile inviare il file al browser";

// ftp_zip()
$messages["Unable to create the temporary file"] = "Non e&acute; possibile creare il file temporaneo";
$messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "Non e&acute; possibile scrivere la stringa nel file temporaneo <b>%1\$s</b>.<br />Controlla i permessi della cartella %2\$s.";
$messages["Unable to close the handle of the temporary file"] = "Non e&acute; possibile chiudere il file temporaneo";
$messages["The zip file has been saved on the FTP server as <b>%1\$s</b>"] = "Il file zip e&acute; stato salvato sul server FTP come <b>%1\$s</b>";
$messages["Requested files"] = "Files richiesti";

$messages["Zip email message"]  = "";
$messages["Zip email message"] .= "Gentile, \n\n";
$messages["Zip email message"] .= "Qualcuno ha pensato che i file allegati a questo messaggio siano mandati al suo account e-mail (%1\$s).\n";
$messages["Zip email message"] .= "Se non sai nulla di cio&acute; o non ti fidi di questa persona, per favore elimina questa e-mail senza aprire il file zip in allegato.\n";
$messages["Zip email message"] .= "Nota che se non apri il file zip, i files al suo interno non possono danneggiare il tuo computer.\n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "Informationi sul mittente:\n";
$messages["Zip email message"] .= "Indirizzo IP: %2\$s\n";
$messages["Zip email message"] .= "Ora dell&acute;invio: %3\$s\n";
$messages["Zip email message"] .= "Inviato tramite il programma net2ftp installato sul sito web: %4\$s \n";
$messages["Zip email message"] .= "Email del webmaster: %5\$s \n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "Messaggio dal mittente:\n";
$messages["Zip email message"] .= "%6\$s \n";
$messages["Zip email message"] .= "\n\n---------------------------------------\n";
$messages["Zip email message"] .= "net2ftp e&acute; software gratuito, rilasciato sotto la licenza GNU/GPL. Per ulteriori informazioni, vai al sito http://www.net2ftp.com\n\n\n";

$messages["The zip file has been sent to <b>%1\$s</b>."] = "Il file zip e&acute; stato inviato a <b>%1\$s</b>.";

// acceptFiles()
$messages["File <b>%1\$s</b> is too big. This file will not be uploaded."] = "Il file <b>%1\$s</b> e&acute; troppo grande. Questo file non sara&acute; caricato sul sito.";
$messages["Could not generate a temporary file."] = "Non e&acute; possibile generare un file temporaneo.";
$messages["File <b>%1\$s</b> could not be moved"] = "Il file <b>%1\$s</b> non puo&acute; esser spostato";
$messages["File <b>%1\$s</b> is OK"] = "Il file <b>%1\$s</b> e&acute; OK";
$messages["Unable to move the uploaded file to the temp directory.<br /><br />The administrator of this website has to <b>chmod 777</b> the /temp directory of net2ftp."] = "Non e&acute; possibile spostare nella cartella temporanea il file caricato.<br /><br />L&acute;amministratore di questo sito web deve cambiare il permesso della cartella /temp di net2ftp con <b>chmod 777</b>.";
$messages["You did not provide any file to upload."] = "Non hai specificato nessun file da caricare.";

// ftp_transferfiles()
$messages["File <b>%1\$s</b> could not be transferred to the FTP server"] = "Il file <b>%1\$s</b> non puo&acute; esser trasferito al server FTP";
$messages["File <b>%1\$s</b> has been transferred to the FTP server using FTP mode <b>%2\$s</b>"] = "Il file <b>%1\$s</b> e&acute; stato trasferito al server FTP usando la modalita&acute; FTP <b>%2\$s</b>";
$messages["Transferring files to the FTP server"] = "Transferimento file al server FTP";

// ftp_unziptransferfiles()
$messages["Processing archive nr %1\$s: <b>%2\$s</b>"] = "Sto elaborando l&acute;archivio numero %1\$s: <b>%2\$s</b>";
$messages["Unable to open the archive <b>%1\$s</b> (file %2\$s)"] = "Non e&acute; possibile aprire l&acute;archivio <b>%1\$s</b> (file %2\$s)";
$messages["Could not create directory <b>%1\$s</b>"] = "Non e&acute; possibile creare la cartella <b>%1\$s</b>";
$messages["Created directory <b>%1\$s</b>"] = "E&acute; stata creata la cartella <b>%1\$s</b>";
$messages["File Contents:"] = "Contenuto del File:";
$messages["Could not put the file <b>%1\$s</b> to the directory <b>%2\$s</b>"] = "Non e&acute; possibile mettere il file <b>%1\$s</b> nella cartella <b>%2\$s</b>";
$messages["Transferred file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "Trasferito il file <b>%1\$s</b> nella cartella <b>%2\$s</b>";
$messages["Unable to delete the archive <b>%1\$s</b> (file %2\$s)"] = "non e&acute; possibile eliminare l&acute;archivio <b>%1\$s</b> (file %2\$s)";
$messages["Unable to get the list of the contents of the Zip archive. Error code: %1\$s"] = "Non e&acute; possibile ricavare la lista col contenuto dell&acute;archivio Zip. Codice d&acute;errore: %1\$s";
$messages["Unable to get the list of the contents of the Tar archive."] = "Non e&acute; possibile ricavare la lista col contenuto dell&acute;archivio Tar.";
$messages["Could not create directory <b>%1\$s</b>"] = "Non e&acute; possibile creare la cartella <b>%1\$s</b>";
$messages["Created directory <b>%1\$s</b>"] = "E&acute; stata creata la cartella <b>%1\$s</b>";
$messages["Unable to create the temporary file"] = "Non e&acute; possibile creare il file temporaneo";
$messages["Unable to extract file nr <b>%1\$s</b> from the archive."] = "Non e&acute; possibile estrarre il file numero <b>%1\$s</b> dall&acute;archivio.";
$messages["Could not put file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "Non e&acute; possibile mettere il file <b>%1\$s</b> nella cartella <b>%2\$s</b>";
$messages["Transferred file <b>%1\$s</b> to directory <b>%2\$s</b>"] = "E&acute; stato trasferito il file <b>%1\$s</b> nella cartella <b>%2\$s</b>";
$messages["Unable to delete the temporary file <b>%1\$s</b>."] = "Non e&acute; possibile eliminare il file temporaneo <b>%1\$s</b>.";
$messages["Archive <b>%1\$s</b> was not processed because its filename extension was not recognized. Only zip, tar, tgz and gz archives are supported at the moment."] = "L&acute;archivio <b>%1\$s</b> non e&acute; stato elaborato perche&acute; la sua estensione di filename non e&acute; stata riconosciuta. Al momento sono supportati solo archivio zip, tar, tgz e gz.";
$messages["Unzipping and transferring files"] = "Estrazione e trasferimento dei file";

// ftp_mysite()
$messages["Unable to execute site command <b>%1\$s</b>"] = "Non e&acute; possibile eseguire il comando del sito <b>%1\$s</b>";

// shutdown()
$messages["Shutdown message"]  = "";
$messages["Shutdown message"] .= "<b>La tua richiesta e&acute; stata annullata</b><br /><br />";
$messages["Shutdown message"] .= "Il compito che hai chiesto di fare con net2ftp richiede piu&acute; tempo dei %1\$s secondi permessi, e quindi la tua richiesta e&acute; stata fermata.<br />";
$messages["Shutdown message"] .= "Questo limite sul tempo di esecuzione garantisce un uso corretto del server web per tutti.<br /><br />";
$messages["Shutdown message"] .= "Cerca di dividere il tuo compito in passi piu&acute; piccoli: restringi la tua selezione di files ed ometti i files piu&acute; grandi.<br /><br />";
$messages["If you really need net2ftp to be able to handle big tasks which take a long time, consider installing net2ftp on your own server."] = "Se davvero hai bisogno di net2ftp per risolvere compiti che richiedono un lungo tempo, condiera la possibilita&acute; di installare net2ftp sul tuo server personale.";

// SendMail()
$messages["You did not provide any text to send by email!"] = "Non hai inserito alcun messaggio da mandare via e-mail!";
$messages["You did not supply a From address."] = "Non hai inserito l&acute;indirizzo From.";
$messages["You did not supply a To address."] = "Non hai inserito l&acute;indirizzo To.";
$messages["Due to technical problems the email to <b>%1\$s</b> could not be sent."] = "A causa di problemi tecnici il messaggio e-mail a <b>%1\$s</b> non e&acute; stato inviato.";

// printFunctionTags()
$messages["Output generated by function %1\$s"] = "Risultato generato dalla funzione %1\$s";



// -------------------------------------------------------------------------
// homepage.inc.php
if ($state == "homepage") {
// -------------------------------------------------------------------------
$messages["net2ftp features short"] ="Dopo esserti loggato, potrai: \n";
$messages["net2ftp features short"] .="<ul>\n";
$messages["net2ftp features short"] .="<li> navigare sul server FTP</li>\n";
$messages["net2ftp features short"] .="<li> caricare o scaricare <span style=\"font-size: 80%%; color: red;\">nuovo: un numero illimitato di files</span></li>\n";
$messages["net2ftp features short"] .="<li> copiare spostare eliminare rinomiare o eseguire CHMOD</li>\n";
$messages["net2ftp features short"] .="<li> copiare/spostare ad un secondo server FTP</li>\n";
$messages["net2ftp features short"] .="<li> vedere il codice con l&acute;evidenziatore di sintassi</li>\n";
$messages["net2ftp features short"] .="<li> vedere le immagini <span style=\"font-size: 80%%; color: red;\">nuovo</span></li>\n";
$messages["net2ftp features short"] .="<li> modifica i file di testo</li>\n";
$messages["net2ftp features short"] .="<li> modifica il codice HTML con vari editor HTML <span style=\"font-size: 80%%; color: red;\">nuovo</span></li>\n";
$messages["net2ftp features short"] .="<li> modifica il codice HTML e PHP con syntax highlighting <span style=\"font-size: 80%%; color: red;\">beta</span></li>\n";
$messages["net2ftp features short"] .="<li> zippare i files per scaricarli, mandarli via e-mail o salvarli</li>\n";
$messages["net2ftp features short"] .="<li> carica-ed-estrai (zip, tar, tgz, gz)</li>\n";
$messages["net2ftp features short"] .="<li> cercare parole o frasi</li>\n";
$messages["net2ftp features short"] .="<li> calcolare la dimensione delle cartelle e dei file</li>\n";
$messages["net2ftp features short"] .="</ul>\n";

} // end homepage


// -------------------------------------------------------------------------
// net2ftp_loginform.inc.php
// -------------------------------------------------------------------------
$messages["FTP server"] = "Server FTP";
$messages["Example"] = "Esempio";
$messages["Username"] = "Username";
$messages["Password"] = "Password";
$messages["Anonymous"] = "Anonimo";
$messages["Passive mode"] = "Modo passivo";
$messages["Initial directory"] = "Cartella iniziale";
$messages["Language"] = "Lingua";
$messages["Skin"] = "Skin";
$messages["FTP mode"] = "modalita&acute; FTP";
$messages["Login"] = "Accesso";
$messages["Clear cookies"] = "Elimina i cookie";
$messages["Please enter an FTP server."] = "Please enter an FTP server.";
$messages["Please enter a username."] = "Please enter a username.";
$messages["Please enter a password."] = "Please enter a password.";


// -------------------------------------------------------------------------
// html.inc.php
// -------------------------------------------------------------------------

// HtmlBegin()
$messages["Status:"] = "Stato:";

// HtmlEnd()
$messages["net2ftp Help Guide"] = "Guida d&acute;aiuto net2ftp";
$messages["net2ftp Forums"] = "Forum net2ftp";
$messages["License"] = "Licenza";
$messages["Powered by"] = "Powered by";

// printJavascriptFunctions()
$messages["Choose a directory"] = "Scegli una cartella";
$messages["Please wait..."] = "Per favore attendi...";
$messages["Uploading... please wait..."] = "Sto caricando dei file... per favore attendi...";
$messages["If the upload takes more than the allowed <b>%1\$s seconds<\/b>, you will have to try again with less/smaller files."] = "Se il caricamento supera i <b>%1\$s secondi<\/b> permessi, dovrai riprovare con meno files alla volta o file piu&acute; piccoli.";
$messages["This window will close automatically in a few seconds."] = "Questa finestra si chiudera&acute; automaticamente fra pochi secondi.";
$messages["Close window now"] = "Chiudi la finestra ora";


// -------------------------------------------------------------------------
// httpheaders.inc.php
// -------------------------------------------------------------------------
// Nothing to translate


// -------------------------------------------------------------------------
// manage.inc.php
if ($state == "manage") {
// -------------------------------------------------------------------------

// manage()
$messages["Please select at least one directory or file!"] = "Per favore seleziona almeno una cartella o file!";
$messages["Unexpected state2 string. Exiting."] = "Stringa di stato2 inaspettata. Esecuzione interrotta.";

// renameentry()
if ($state2 == "rename") {
$messages["Rename directories and files"] = "Rinonima cartelle e file";
$messages["Old name: "] = "Vecchio nome: ";
$messages["New name: "] = "Nuovo nome: ";
$messages["The new name may not contain any dots. This entry was not renamed to <b>%1\$s</b>"] = "Il nuovo nome non puo&acute; contenere alcun punto. Questa selezione non e&acute; stata rinominata in <b>%1\$s</b>";
$messages["<b>%1\$s</b> was successfully renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> e&acute; stato rinominato con successo in <b>%2\$s</b>";
$messages["<b>%1\$s</b> could not be renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> non puo&acute; essere rinominato in <b>%2\$s</b>";
}

// chmodentry()
if ($state2 == "chmod") {
$messages["Chmod directories and files"] = "CHMOD cartelle e file";
$messages["Set all permissions"] = "Imposta a tutti i permessi";
$messages["Read"] = "Leggi";
$messages["Write"] = "Scrivi";
$messages["Execute"] = "Esegui";
$messages["Owner"] = "Utente";
$messages["Group"] = "Gruppo";
$messages["Everyone"] = "Qualsiasi";
$messages["To set all permissions to the same values, enter those permissions above and click on the button \"Set all permissions\""] = "Per settare tutti i permessi, inserisci i permessi indicati su e clicca sul tasto \"Imposta a tutti i permessi\"";
$messages["Set the permissions of directory <b>%1\$s</b> to: "] = "Setta i permessi per la cartella <b>%1\$s</b>: ";
$messages["Set the permissions of file <b>%1\$s</b> to: "] = "Setta i permessi per il file <b>%1\$s</b>: ";
$messages["Set the permissions of symlink <b>%1\$s</b> to: "] = "Setta i permessi per il link simblico <b>%1\$s</b> to: ";
$messages["Chmod value"] = "Valore CHMOD";
$messages["Chmod also the subdirectories within this directory"] = "Esegui CHMOD anche sulle sotto-cartelle all&acute;interno di questa cartella";
$messages["Chmod also the files within this directory"] = "Esegui CHMOD anche sui files all&acute;interno di questa cartella";
$messages["The chmod nr <b>%1\$s</b> is out of the range 000-777. Please try again."] = "Il valore CHMOD <b>%1\$s</b> non e&acute; nell&acute;intervallo consentito 000-777. Per favore riprova.";
}

// copymovedeleteentry()
if ($state2 == "copy" || $state2 == "move" || $state2 == "delete") {
$messages["Copy directories and files"] = "Copia cartelle e file";
$messages["Move directories and files"] = "Sposta cartelle e file";
$messages["Delete directories and files"] = "Elimina cartelle e file";
$messages["Are you sure you want to delete these directories and files?"] = "Sei sicuro di voler eliminare queste cartelle e file?";
$messages["All the subdirectories and files of the selected directories will also be deleted!"] = "Tutte le sotto-cartelle delle cartelle selezionate e i relativi file saranno eliminati!";
$messages["Set all targetdirectories"] = "Imposta a tutti come cartella di destinazione";
$messages["To set a common target directory, enter that target directory in the textbox above and click on the button \"Set all targetdirectories\"."] = "Per selezionare una cartella destinazione comune, inserisci quella cartella destinazione nella casella di testo su e clicca sul tasto \"Imposta a tutti come cartella di destinazione\".";
$messages["Note: the target directory must already exist before anything can be copied into it."] = "Nota: la cartella di destinazione deve essere esistente prima che qualunque cosa possa essere copiata al suo interno.";
$messages["Different target FTP server:"] = "Server FTP di destinazione esterno:";
$messages["Leave empty if you want to copy the files to the same FTP server."] = "Lascia vuoto se vuoi copiare i files nello stesso server FTP.";
$messages["If you want to copy the files to another FTP server, enter your login data."] = "Se vuoi copiare i files su un altro server FTP, inserisci i relativi dati di accesso.";
$messages["Leave empty if you want to move the files to the same FTP server."] = "Lascia vuoto se vuoi spostare i files sullo stesso server FTP.";
$messages["If you want to move the files to another FTP server, enter your login data."] = "Se vuoi spostare i fiels su un altro server FTP, inserisi i relativi dati di accesso.";
$messages["Copy directory <b>%1\$s</b> to:"] = "Copia cartella <b>%1\$s</b> in:";
$messages["Move directory <b>%1\$s</b> to:"] = "Sposta cartella <b>%1\$s</b> in:";
$messages["Directory <b>%1\$s</b>"] = "cartella <b>%1\$s</b>";
$messages["Copy file <b>%1\$s</b> to:"] = "Copia file <b>%1\$s</b> in:";
$messages["Move file <b>%1\$s</b> to:"] = "Sposta file <b>%1\$s</b> in:";
$messages["File <b>%1\$s</b>"] = "File <b>%1\$s</b>";
$messages["Copy symlink <b>%1\$s</b> to:"] = "Copia link simbolico <b>%1\$s</b> in:";
$messages["Move symlink <b>%1\$s</b> to:"] = "Sposta link simbolico <b>%1\$s</b> in:";
$messages["Symlink <b>%1\$s</b>"] = "Link simbolico <b>%1\$s</b>";
$messages["Target directory:"] = "Cartella di destinazione:";
$messages["Target name:"] = "Nome destinazione:";
$messages["Processing the entries:"] = "Elaborazione dati:";
}

// newdirectory()
if ($state2 == "newdirectory") {
$messages["Create new directories"] = "Crea nuove cartelle";
$messages["The new directories will be created in <b>%1\$s</b>."] = "Le nuove cartelle saranno create in <b>%1\$s</b>.";
$messages["New directory name:"] = "Nome della nuova cartella:";
$messages["Directory <b>%1\$s</b> was successfully created."] = "La cartella <b>%1\$s</b> e&acute; stata creata con successo.";
}

// uploadfile()
if ($state2 == "uploadfile") {
$messages["Upload files and archives"] = "Carica file e archivi";
$messages["Upload results"] = "Risultati del caricamento";
$messages["Checking files:"] = "Controllo file:";
$messages["Transferring files to the FTP server:"] = "Trasferimento dei file sul server FTP:";
$messages["Decompressing archives and transferring files to the FTP server:"] = "Estrazione file dagli archivi e trasferimento dei file sul server FTP:";
$messages["Upload more files and archives"] = "Carica altri file e archivi";
}

// printUploadForm() and javaupload()
if ($state2 == "uploadfile" || $state2 == "javaupload") {
$messages["Upload to directory:"] = "Carica nella cartella:";
$messages["Files"] = "File";
$messages["Archives"] = "Archivi";
$messages["Files entered here will be transferred to the FTP server."] = "I file inseriti qui saranno trasferiti sul server FTP.";
$messages["Archives entered here will be decompressed, and the files inside will be transferred to the FTP server."] = "Gli archivi inseriti qui saranno decompressi, e i file al loro interno saranno trasferiti sul server FTP.";
$messages["Add another"] = "Aggiungi un altro";
$messages["Use folder names (creates subdirectories automatically)"] = "Usa i nomi delle cartelle (crea le sotto-cartelle automaticamente)";
$messages["Restrictions:"] = "Restrizioni:";
$messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s kB</b> and by PHP to <b>%2\$s</b>"] = "La massima dimensione di un file e&acute; settata da net2ftp a <b>%1\$s kB</b> e dal PHP a <b>%2\$s</b>";
$messages["The maximum execution time is <b>%1\$s seconds</b>"] = "Il tempo di esecuzione massimo e&acute; di <b>%1\$s secondi</b>";
$messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "La modalita&acute; di trasferimento FTP (ASCII o BINARY) sara&acute; determinata automaticamente, basandosi sull&acute;estensione del file";
$messages["If the destination file already exists, it will be overwritten"] = "Se la destinazione esiste gia&acute;, sara&acute; sovrascritta";

$messages["Upload directories and files using a Java applet"] = "Upload directories and files using a Java applet";
$messages["Number of files:"] = "Number of files:";
$messages["Size of files:"] = "Size of files:";
$messages["Add"] = "Add";
$messages["Remove"] = "Remove";
$messages["Upload"] = "Upload";
$messages["Add files to the upload queue"] = "Add files to the upload queue";
$messages["Remove files from the upload queue"] = "Remove files from the upload queue";
$messages["Upload the files which are in the upload queue"] = "Upload the files which are in the upload queue";
$messages["Maximum server space exceeded. Please select less/smaller files."] = "Maximum server space exceeded. Please select less/smaller files.";
$messages["Total size of the files is too big. Please select less/smaller files."] = "Total size of the files is too big. Please select less/smaller files.";
$messages["Total number of files is too high. Please select fewer files."] = "Total number of files is too high. Please select fewer files.";
$messages["Note: to use this applet, Sun's Java plugin must be installed (version 1.4 or newer)."] = "Note: to use this applet, Sun's Java plugin must be installed (version 1.4 or newer).";

$messages["Browser does not support Java applets"] = "Your browser does not support applets, or you have disabled applets in your browser settings.\n";
$messages["Browser does not support Java applets"] .= "To use this applet, please install the newest version of Sun's java. You can get it from <a href=\"http://www.java.com/\">java.com</a>. Click on Get It Now.\n";
$messages["Browser does not support Java applets"] .= "The online installation is about 1-2 MB and the offline installation is about 13 MB. This 'end-user' java is called JRE (Java Runtime Environment).\n";
$messages["Browser does not support Java applets"] .= "Alternatively, use net2ftp's normal upload or upload-and-unzip functionality.\n";
}

// zipentry()
if ($state2 == "zip") {
$messages["Zip entries"] = "Archivi Zip";
$messages["Save the zip file on the FTP server as:"] = "Salva il file zip sul server FTP come:";
$messages["Email the zip file in attachment to:"] = "Manda il file zip in e-mail come allegato a:";
$messages["Note that sending files is not anonymous: your IP address as well as the time of the sending will be added to the email."] = "Nota che mandare i files non e&acute; anonimo: il tuo indirizzo IP cosi&acute; come l&acute;ora di invio saranno aggiunti al messaggio e-mail.";
$messages["Some additional comments to add in the email:"] = "Qualche commento aggiuntivo da inserire nell&acute;e-mail:";
$messages["You did not enter a filename for the zipfile. Go back and enter a filename."] = "Non hai inserito un nome del file per l&acute;archivio zip. Torna indietro ed inserisci un nome.";
$messages["The email address you have entered (%1\$s) does not seem to be valid.<br />Please enter an address in the format <b>username@domain.com</b>"] = "L&acute;indirizzo e-mail che hai inserito (%1\$s) non sembra esser valido.<br />Per favore inserisci un indirizzo nel formato <b>username@domain.com</b>";
}

// calculatesize()
if ($state2 == "calculatesize") {
$messages["Size of selected directories and files"] = "Dimensione delle cartelle e dei files selezionati";
$messages["The total size taken by the selected directories and files is:"] = "La dimensione totale occupata dalle cartelle e files selezionati e&acute;:";
$messages["The nr of files which were skipped:"] = "Il numero di file che sono stati saltati:";
}

// findstring()
if ($state2 == "findstring") {
$messages["Search directories and files"] = "Cerca cartelle e file";
$messages["Search results"] = "Cerca fra i risultati";
$messages["Please enter a valid search word or phrase."] = "Per favore inserisci una valida parola o frase da ricercare.";
$messages["Please enter a valid filename."] = "Per favore inserisci un nome file valido.";
$messages["Please enter a valid file size in the \"from\" textbox, for example 0."] = "Per favore inserisci una dimensione file valida nella casella \"da\", per esempio 0.";
$messages["Please enter a valid file size in the \"to\" textbox, for example 500000."] = "Per favore inserisci una dimensione file valida nella casella \"a\", per esempio 500000.";
$messages["Please enter a valid date in Y-m-d format in the \"from\" textbox."] = "Per favore inserisci una data valida nel formato Anno-mese-giorno nella casella \"da\".";
$messages["Please enter a valid date in Y-m-d format in the \"to\" textbox."] = "Per favore inserisci una data valida nel formato Anno-mese-giorno nella casella \"a\".";
$messages["The word <b>%1\$s</b> was not found in the selected directories and files."] = "La parola <b>%1\$s</b> non e&acute; stata trovata nelle cartelle e file selezionati.";
$messages["The word <b>%1\$s</b> was found in the following files:"] = "La parola <b>%1\$s</b> e&acute; stata trovata nei seguenti files:";
$messages["Search again"] = "Cerca ancora";
}

// printFindstringForm()
if ($state2 == "findstring") {
$messages["Search for a word or phrase"] = "Cerca una parola o frase";
$messages["Case sensitive search"] = "Ricerca Case sensitive";
$messages["Restrict the search to:"] = "Restringi la ricerca a:";
$messages["files with a filename like"] = "files con un nome tipo";
$messages["(wildcard character is *)"] = "(il carattere jolly e&acute; *)";
$messages["files with a size"] = "files con una dimensione";
$messages["from"] = "da";
$messages["to"] = "a";
$messages["files which were last modified"] = "files modificati per l&acute;ultima volta";
}

// updatefile()
if ($state2 == "updatefile") {
$messages["Update file"] = "Aggiorna file";
$messages["<b>WARNING: THIS FUNCTION IS STILL IN EARLY DEVELOPMENT. USE IT ONLY ON TEST FILES! YOU HAVE BEEN WARNED!"] = "<b>ATTENZIONE: QUESTA FUNZIONE E&acute; ANCORA IN FASE DI SVILUPPO. USALA SOLO SU FILES DI TEST! SEI STATO AVVERTITO	!";
$messages["Known bugs: - erases tab characters - doesn&acute;t work well with big files (> 50kB) - was not tested yet on files containing non-standard characters</b>"] = "Bugs noti: - elimina i caratteri tab - non funziona bene con files grandi (> 50kB) - non e&acute; stata testata con files che contengono caratteri non standard</b>";
$messages["This function allows you to upload a new version of the selected file, to view what are the changes and to accept or reject each change. Before anything is saved, you can edit the merged files."] = "Questa funzione ti permette di caricare una nuova versione del file selezionato, di vedere quali sono le differenze e di accettare o annullare la sostituzione. Prima di salvare qualunque cosa, puoi sempre modificare i files risultanti dall&acute;unione.";
$messages["Old file:"] = "Vecchio file:";
$messages["New file:"] = "Nuovo file:";
$messages["Restrictions:"] = "Restrizioni:";
$messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s kB</b> and by PHP to <b>%2\$s</b>"] = "La massima dimensione di un file e&acute; settata da net2ftp a <b>%1\$s kB</b> e dal PHP a <b>%2\$s</b>";
$messages["The maximum execution time is <b>%1\$s seconds</b>"] = "Il tempo di esecuzione massimo e&acute; <b>%1\$s secondi</b>";
$messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "La modalita&acute; di trasferimento FTP (ASCII o BINARY) sara&acute; determinata automaticamente, basandosi sull&acute;estensione del file";
$messages["If the destination file already exists, it will be overwritten"] = "Se il file destinazione esiste gia&acute;, sara&acute; sovrascritto";
$messages["You did not provide any files or archives to upload."] = "Non hai specificato alcun file o archivio da caricare.";
$messages["Unable to delete the new file"] = "Non e&acute; possibile eliminare il nuovo file";
}

// printComparisonSelect()
if ($state2 == "updatefile") {
$messages["Please wait..."] = "Per favore attendi...";
$messages["Select lines below, accept or reject changes and submit the form."] = "Seleziona le linee sottostanti, accetta o respingi i cambi e inserisci il modulo.";
}

} // end manage


// -------------------------------------------------------------------------
// registerglobals.inc.php
// -------------------------------------------------------------------------
$messages["Please enter your username and password for FTP server "] = "Inserire username e password per il server FTP ";
$messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "Non sono stati inseriti i dati di accesso nella finestra popup.<br />Clicca su \"Vai alla pagina di accesso\" sopra.";
$messages["Access to the net2ftp Admin panel is disabled, because no password has been set in the file settings.inc.php. Enter a password in that file, and reload this page."] = "L&acute;accesso al pannello di amministrazione net2ftp e&acute; disabilitato, perche&acute; non e&acute; stata specificata la password nel file settings.inc.php. Inserire una password in quel file e riprovare.";
$messages["Please enter your Admin username and password"] = "Inserire username e password di amministrazione"; 
$messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "Non sono stati inseriti i dati di accesso nella finestra popup.<br />Clicca su \"Vai alla pagina di accesso\" sopra.";
$messages["Wrong username or password for the net2ftp Admin panel. The username and password can be set in the file settings.inc.php."] = "Username e password di amministrazione errati. Username e password possono essere impostati nel file settings.inc.php.";


// -------------------------------------------------------------------------
// skins.inc.php
// -------------------------------------------------------------------------
$messages["Blue"] = "Blu";
$messages["Pastel"] = "Pastello";
$messages["Grey"] = "Grigio";
$messages["Black"] = "Nero";
$messages["Yellow"] = "Giallo";

// getMime()
$messages["Directory"] = "Cartella";
$messages["Symlink"] = "Link simbolico";
$messages["ASP script"] = "Script ASP";
$messages["Cascading Style Sheet"] = "Cascading Style Sheet";
$messages["HTML file"] = "File HTML";
$messages["Java source file"] = "File sorgente Java";
$messages["JavaScript file"] = "File JavaScript";
$messages["PHP Source"] = "Sorgente PHP";
$messages["PHP script"] = "Script PHP";
$messages["Text file"] = "File di testo";
$messages["Bitmap file"] = "File bitmap";
$messages["GIF file"] = "File GIF";
$messages["JPEG file"] = "File JPEG";
$messages["PNG file"] = "File PNG";
$messages["TIF file"] = "File TIF";
$messages["GIMP file"] = "File GIMP";
$messages["Executable"] = "Eseguibile";
$messages["Shell script"] = "Script shell";
$messages["MS Office - Word document"] = "MS Office - documento Word";
$messages["MS Office - Excel foglio di calcolo"] = "MS Office - foglio di calcolo Excel";
$messages["MS Office - PowerPoint presentation"] = "MS Office - presentatione PowerPoint";
$messages["MS Office - Access database"] = "MS Office - database Access";
$messages["MS Office - Visio drawing"] = "MS Office - disegno Visio";
$messages["MS Office - Project file"] = "MS Office - file di Project";
$messages["OpenOffice - Writer 6.0 document"] = "OpenOffice - Writer 6.0 documento";
$messages["OpenOffice - Writer 6.0 template"] = "OpenOffice - Writer 6.0 template";
$messages["OpenOffice - Calc 6.0 foglio di calcolo"] = "OpenOffice - Calc 6.0 foglio di calcolo";
$messages["OpenOffice - Calc 6.0 template"] = "OpenOffice - Calc 6.0 template";
$messages["OpenOffice - Draw 6.0 document"] = "OpenOffice - Draw 6.0 documento";
$messages["OpenOffice - Draw 6.0 template"] = "OpenOffice - Draw 6.0 template";
$messages["OpenOffice - Impress 6.0 presentation"] = "OpenOffice - Impress 6.0 presentatione";
$messages["OpenOffice - Impress 6.0 template"] = "OpenOffice - Impress 6.0 template";
$messages["OpenOffice - Writer 6.0 global document"] = "OpenOffice - Writer 6.0 documento globale";
$messages["OpenOffice - Math 6.0 document"] = "OpenOffice - Math 6.0 documento";
$messages["StarOffice - StarWriter 5.x document"] = "StarOffice - StarWriter 5.x documento";
$messages["StarOffice - StarWriter 5.x global document"] = "StarOffice - StarWriter 5.x  documento globale";
$messages["StarOffice - StarCalc 5.x foglio di calcolo"] = "StarOffice - StarCalc 5.x foglio di calcolo";
$messages["StarOffice - StarDraw 5.x document"] = "StarOffice - StarDraw 5.x documento";
$messages["StarOffice - StarImpress 5.x presentation"] = "StarOffice - StarImpress 5.x presentatione";
$messages["StarOffice - StarImpress Packed 5.x file"] = "StarOffice - StarImpress Packed 5.x file";
$messages["StarOffice - StarMath 5.x document"] = "StarOffice - StarMath 5.x documento";
$messages["StarOffice - StarChart 5.x document"] = "StarOffice - StarChart 5.x documento";
$messages["StarOffice - StarMail 5.x mail file"] = "StarOffice - StarMail 5.x file di mail";
$messages["Adobe Acrobat document"] = "Documento Adobe Acrobat";
$messages["ARC archive"] = "Archivio ARC";
$messages["ARJ archive"] = "Archivio ARJ";
$messages["RPM"] = "RPM";
$messages["GZ archive"] = "Archivio GZ";
$messages["TAR archive"] = "Archivio TAR";
$messages["Zip archive"] = "Archivio Zip";
$messages["MOV movie file"] = "Filmato MOV";
$messages["MPEG movie file"] = "Filmato MPEG";
$messages["Real movie file"] = "Filmato Real";
$messages["Quicktime movie file"] = "Filmato Quicktime";
$messages["Shockwave flash file"] = "File Shockwave flash";
$messages["Shockwave file"] = "File Shockwave";
$messages["WAV sound file"] = "File di suono WAV";
$messages["Font file"] = "File di Font";
$messages["%1\$s File"] = "%1\$s File";
$messages["File"] = "File";

// getAction()
$messages["Back"] = "Indietro";
$messages["Submit"] = "Invia";
$messages["Refresh"] = "Aggiorna";
$messages["Details"] = "Dettagli";
$messages["Icons"] = "Icone";
$messages["List"] = "Elenco";
$messages["Logout"] = "Uscita";
$messages["Help"] = "Aiuto";
$messages["Bookmark"] = "Preferiti";
$messages["Save"] = "Salva";
$messages["Default"] = "Default";


// -------------------------------------------------------------------------
// view.inc.php
// -------------------------------------------------------------------------
$messages["Image"] = "Immagine";
$messages["View Macromedia ShockWave Flash movie %1\$s"] = "Visualizza filmato Macromedia ShockWave %1\$s";
$messages["View file %1\$s"] = "Visualizza file %1\$s";
$messages["To save the image, right-click on it and choose 'Save picture as...'"] = "Per salvare l&acute;immagine, click con tasto destro e scegliere \"Salva immagine come...\"";


// ----------------------------------------------------------------------------------
// DO NOT CHANGE ANYTHING BELOW THIS LINE
// ----------------------------------------------------------------------------------

return $messages;

} // end function getMessages

?>