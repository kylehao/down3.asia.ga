<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------


// The $templateList array contains the properties of the templates

// Elated templates
$templateList[1]["name"]       = "Driftwood";       // Template name
$templateList[1]["directory"]  = "driftwood";       // Template directory within /html_templates
$templateList[1]["size"]       = "102 kB";          // Template size (text)
$templateList[1]["copyright"]  = "<a href=\"http://www.elated.com/pagekits\">Elated PageKits</a>"; // Template copyright
$templateList[1]["pages"][1]   = "index.html";      // List of HTML pages that can be previewed by the user
$templateList[1]["pages"][2]   = "about.html";
$templateList[1]["pages"][3]   = "news.html";
$templateList[1]["pages"][4]   = "downloads.html";
$templateList[1]["pages"][5]   = "blog.html";
$templateList[1]["pages"][6]   = "contact.html";

$templateList[2]["name"]       = "Glass";
$templateList[2]["directory"]  = "glass";
$templateList[2]["size"]       = "128 kB";
$templateList[2]["copyright"]  = "<a href=\"http://www.elated.com/pagekits\">Elated PageKits</a>"; // Template copyright
$templateList[2]["pages"][1]   = "index.html";
$templateList[2]["pages"][2]   = "about.html";
$templateList[2]["pages"][3]   = "guest.html";
$templateList[2]["pages"][4]   = "links.html";
$templateList[2]["pages"][5]   = "news.html";
$templateList[2]["pages"][6]   = "services.html";

$templateList[3]["name"]       = "Hi";
$templateList[3]["directory"]  = "hi";
$templateList[3]["size"]       = "53 kB";
$templateList[3]["copyright"]  = "<a href=\"http://www.elated.com/pagekits\">Elated PageKits</a>"; // Template copyright
$templateList[3]["pages"][1]   = "index.html";
$templateList[3]["pages"][2]   = "about.html";
$templateList[3]["pages"][3]   = "news.html";
$templateList[3]["pages"][4]   = "contact.html";
$templateList[3]["pages"][5]   = "guestbook.html";
$templateList[3]["pages"][6]   = "links.html";

$templateList[4]["name"]       = "The Doors";
$templateList[4]["directory"]  = "thedoors";
$templateList[4]["size"]       = "73 kB";
$templateList[4]["copyright"]  = "<a href=\"http://www.elated.com/pagekits\">Elated PageKits</a>"; // Template copyright
$templateList[4]["pages"][1]   = "index.html";
$templateList[4]["pages"][2]   = "mainpage.html";
$templateList[4]["pages"][3]   = "about.html";
$templateList[4]["pages"][4]   = "news.html";
$templateList[4]["pages"][5]   = "material.html";
$templateList[4]["pages"][6]   = "downloads.html";
$templateList[4]["pages"][7]   = "subpage.html";

$templateList[5]["name"]       = "Tune";
$templateList[5]["directory"]  = "tune";
$templateList[5]["size"]       = "46 kB";
$templateList[5]["copyright"]  = "<a href=\"http://www.elated.com/pagekits\">Elated PageKits</a>"; // Template copyright
$templateList[5]["pages"][1]   = "index.html";
$templateList[5]["pages"][2]   = "about.html";
$templateList[5]["pages"][3]   = "music.html";
$templateList[5]["pages"][4]   = "chat.html";
$templateList[5]["pages"][5]   = "stuff.html";
$templateList[5]["pages"][6]   = "low.html";

?>