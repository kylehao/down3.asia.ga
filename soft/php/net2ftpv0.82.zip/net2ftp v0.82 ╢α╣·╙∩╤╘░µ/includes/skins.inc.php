<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **
function getSkinArray() {


// --------------
// This function returns an array of skin names, file names, ...
// --------------

	$skinArray[1]['name'] = __("Blue");
	$skinArray[1]['css'] = "skin1-blue.css";
	$skinArray[1]['iconset'] = "nuvola";

	$skinArray[2]['name'] = __("Pastel");
	$skinArray[2]['css'] = "skin2-pastel.css";
	$skinArray[2]['iconset'] = "nuvola";
	
	$skinArray[3]['name'] = __("Black");
	$skinArray[3]['css'] = "skin3-black.css";
	$skinArray[3]['iconset'] = "noia";

	$skinArray[4]['name'] = __("Grey");
	$skinArray[4]['css'] = "skin4-grey.css";
	$skinArray[4]['iconset'] = "nuvola";
	
	$skinArray[5]['name'] = __("Yellow");
	$skinArray[5]['css'] = "skin5-yellow.css";
	$skinArray[5]['iconset'] = "noia";

	return $skinArray;

} // End function getSkinArray

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **
function printSkinSelect($fieldname, $onchange) {


// --------------
// This function prints a select with the available skins
// Skin nr 1 is the default skin
// --------------

// -------------------------------------------------------------------------
// Global variables and settings
// -------------------------------------------------------------------------
	global $net2ftpcookie_skin;
	global $net2ftp_skin;

	$skinArray = getSkinArray();

	if ($net2ftp_skin != "")           { $currentskin = $net2ftp_skin; }
	elseif ($net2ftpcookie_skin != "") { $currentskin = $net2ftpcookie_skin; }
	else                               { $currentskin = 1; }

	echo "<select name=\"$fieldname\" id=\"$fieldname\" onChange=\"$onchange\">\n";

	for ($i=1; $i<=sizeof($skinArray); $i=$i+1) {
		if ($i == $currentskin) { $selected = "selected"; }
		else { $selected = ""; }
		echo "<option value=\"$i\" $selected>" . $skinArray[$i]['name'] . "</option>\n";
	} // end for

	echo "</select>\n";

} // End function printSkinSelect

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************







// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function getSkinColors($what) {

	global $net2ftp_skin;
	$skin = $net2ftp_skin;

	if ($skin == "1") { // 1-blue
		if     ($what == "heading_fontcolor")   { return "#000000"; }
		elseif ($what == "heading_bgcolor")     { return "#CCCCFF"; }
		elseif ($what == "rows_fontcolor_odd")  { return "#000000"; }
		elseif ($what == "rows_bgcolor_odd")    { return "#FFFFFF"; }
		elseif ($what == "rows_fontcolor_even") { return "#000000"; }
		elseif ($what == "rows_bgcolor_even")   { return "#EFEFEF"; }
		elseif ($what == "cursor_fontcolor")    { return "#000000"; }
		elseif ($what == "cursor_bgcolor")      { return "#9999FF"; }
		elseif ($what == "border_color")        { return "#000000"; }
		elseif ($what == "selected_fontcolor")  { return "#000000"; }
		elseif ($what == "selected_bgcolor")    { return "#FFAA33"; }
	}
	elseif ($skin == "2") { // 2-pastel
		if     ($what == "heading_fontcolor")   { return "#000000"; }
		elseif ($what == "heading_bgcolor")     { return "#ECE9D9"; }
		elseif ($what == "rows_fontcolor_odd")  { return "#000000"; }
		elseif ($what == "rows_bgcolor_odd")    { return "#FFFFFF"; }
		elseif ($what == "rows_fontcolor_even") { return "#000000"; }
		elseif ($what == "rows_bgcolor_even")   { return "#F0F0F0"; }
		elseif ($what == "cursor_fontcolor")    { return "#000000"; }
		elseif ($what == "cursor_bgcolor")      { return "#CDCDCD"; }
		elseif ($what == "border_color")        { return "#000000"; }
		elseif ($what == "selected_fontcolor")  { return "#000000"; }
		elseif ($what == "selected_bgcolor")    { return "#DAB93D"; }
	}

	elseif ($skin == "3") { // 3-black
		if     ($what == "heading_fontcolor")   { return "#FFFFFF"; }
		elseif ($what == "heading_bgcolor")     { return "#5E5E5E"; }
		elseif ($what == "rows_fontcolor_odd")  { return "#FFFFFF"; }
		elseif ($what == "rows_bgcolor_odd")    { return "#000000"; }
		elseif ($what == "rows_fontcolor_even") { return "#FFFFFF"; }
		elseif ($what == "rows_bgcolor_even")   { return "#232323"; }
		elseif ($what == "cursor_fontcolor")    { return "#000000"; }
		elseif ($what == "cursor_bgcolor")      { return "#898033"; }
		elseif ($what == "border_color")        { return "#000000"; }
		elseif ($what == "selected_fontcolor")  { return "#FFFFFF"; }
		elseif ($what == "selected_bgcolor")    { return "#FFAA33"; }
	}
	elseif ($skin == "4") { // 4-grey
		if     ($what == "heading_fontcolor")   { return "#AAAAAA"; }
		elseif ($what == "heading_bgcolor")     { return "#CCCCCC"; }
		elseif ($what == "rows_fontcolor_odd")  { return "#AAAAAA"; }
		elseif ($what == "rows_bgcolor_odd")    { return "#FFFFFF"; }
		elseif ($what == "rows_fontcolor_even") { return "#AAAAAA"; }
		elseif ($what == "rows_bgcolor_even")   { return "#EEEEEE"; }
		elseif ($what == "cursor_fontcolor")    { return "#AAAAAA"; }
		elseif ($what == "cursor_bgcolor")      { return "#DDDDDD"; }
		elseif ($what == "border_color")        { return "#000000"; }
		elseif ($what == "selected_fontcolor")  { return "#AAAAAA"; }
		elseif ($what == "selected_bgcolor")    { return "#FFAA33"; }
	}
	elseif ($skin == "5") { // 5-yellow
		if     ($what == "heading_fontcolor")   { return "#000000"; }
		elseif ($what == "heading_bgcolor")     { return "#FFEE33"; }
		elseif ($what == "rows_fontcolor_odd")  { return "#000000"; }
		elseif ($what == "rows_bgcolor_odd")    { return "#FFFFFF"; }
		elseif ($what == "rows_fontcolor_even") { return "#000000"; }
		elseif ($what == "rows_bgcolor_even")   { return "#FFFFFF"; }
		elseif ($what == "cursor_fontcolor")    { return "#000000"; }
		elseif ($what == "cursor_bgcolor")      { return "#FFCC11"; }
		elseif ($what == "border_color")        { return "#000000"; }
		elseif ($what == "selected_fontcolor")  { return "#000000"; }
		elseif ($what == "selected_bgcolor")    { return "#FFAA33"; }
	}
	else {
		if     ($what == "heading_fontcolor")   { return "#000000"; }
		elseif ($what == "heading_bgcolor")     { return "#CCCCFF"; }
		elseif ($what == "rows_fontcolor_odd")  { return "#000000"; }
		elseif ($what == "rows_bgcolor_odd")    { return "#FFFFFF"; }
		elseif ($what == "rows_fontcolor_even") { return "#000000"; }
		elseif ($what == "rows_bgcolor_even")   { return "#EFEFEF"; }
		elseif ($what == "cursor_fontcolor")    { return "#000000"; }
		elseif ($what == "cursor_bgcolor")      { return "#9999FF"; }
		elseif ($what == "border_color")        { return "#000000"; }
		elseif ($what == "selected_fontcolor")  { return "#000000"; }
		elseif ($what == "selected_bgcolor")    { return "#FFAA33"; }
	}

} // end  function getSkinColors

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function getMime($filename) {

// --------------
// Checks the extension of a file to determine which is the type of the file and the icon
// --------------

// -------------------------------------------------------------------------
// Global variables and settings
// -------------------------------------------------------------------------
	global $browser_agent, $browser_version, $browser_platform;
	global $net2ftp_skin;
	$skinArray = getSkinArray();
	
	$last = get_filename_extension($filename);

// -------------------------------------------------------------------------
// Icon names
// -------------------------------------------------------------------------
	if ($last == "directory") {
		$icon = "folder";
		$type = __("Directory");
	}
	elseif ($last == "symlink") {
		$icon = "folder_grey";
		$type = __("Symlink");
	}

// Web files
	elseif ($last == "asp") {
		$icon = "";
		$type = __("ASP script");
	}
	elseif ($last == "css") {
		$icon = "stylesheet";
		$type = __("Cascading Style Sheet");
	}
	elseif ($last == "htm" || $last == "html") {
		$icon = "html";
		$type = __("HTML file");
	}
	elseif ($last == "java") {
		$icon = "source_java";
		$type = __("Java source file");
	}
	elseif ($last == "js") {
		$icon = "";
		$type = __("JavaScript file");
	}
	elseif ($last == "phps") {
		$icon = "php-icon";
		$type = __("PHP Source");
	}
	elseif (substr($last,0,3) == "php") {
		$icon = "php-icon";
		$type = __("PHP script");
	}
	elseif ($last == "txt") {
		$icon = "document";
		$type = __("Text file");
	}

// Images
	elseif ($last == "bmp") {
		$icon = "colors";
		$type = __("Bitmap file");
	}
	elseif ($last == "gif") {
		$icon = "colors";
		$type = __("GIF file");
	}
	elseif ($last == "jpg" || $last == "jpeg") {
		$icon = "colors";
		$type = __("JPEG file");
	}
	elseif ($last == "png") {
		$icon = "colors";
		$type = __("PNG file");
	}
	elseif ($last == "tif" || $last == "tiff") {
		$icon = "colors";
		$type = __("TIF file");
	}
	elseif ($last == "xcf") {
		$icon = "gimp";
		$type = __("GIMP file");
	}

// Executables and scripts
	elseif ($last == "exe" || $last == "com") {
		$icon = "exec";
		$type = __("Executable");
	}
	elseif ($last == "sh") {
		$icon = "terminal";
		$type = __("Shell script");
	}

// MS Office
	elseif ($last == "doc") {
		$icon = "";
		$type = __("MS Office - Word document");
	}
	elseif ($last == "xls") {
		$icon = "";
		$type = __("MS Office - Excel spreadsheet");
	}
	elseif ($last == "ppt") {
		$icon = "";
		$type = __("MS Office - PowerPoint presentation");
	}
	elseif ($last == "mdb") {
		$icon = "";
		$type = __("MS Office - Access database");
	}
	elseif ($last == "vsd") {
		$icon = "";
		$type = __("MS Office - Visio drawing");
	}
	elseif ($last == "mpp") {
		$icon = "";
		$type = __("MS Office - Project file");
	}

// OpenOffice 6
	elseif ($last == "sxw") {
		$icon = "openoffice";
		$type = __("OpenOffice - Writer 6.0 document");
	}
	elseif ($last == "stw") {
		$icon = "openoffice";
		$type = __("OpenOffice - Writer 6.0 template");
	}
	elseif ($last == "sxc") {
		$icon = "openoffice";
		$type = __("OpenOffice - Calc 6.0 spreadsheet");
	}
	elseif ($last == "stc") {
		$icon = "openoffice";
		$type = __("OpenOffice - Calc 6.0 template");
	}
	elseif ($last == "sxd") {
		$icon = "openoffice";
		$type = __("OpenOffice - Draw 6.0 document");
	}
	elseif ($last == "std") {
		$icon = "openoffice";
		$type = __("OpenOffice - Draw 6.0 template");
	}
	elseif ($last == "sxi") {
		$icon = "openoffice";
		$type = __("OpenOffice - Impress 6.0 presentation");
	}
	elseif ($last == "sti") {
		$icon = "openoffice";
		$type = __("OpenOffice - Impress 6.0 template");
	}
	elseif ($last == "sxg") {
		$icon = "openoffice";
		$type = __("OpenOffice - Writer 6.0 global document");
	}
	elseif ($last == "sxm") {
		$icon = "openoffice";
		$type = __("OpenOffice - Math 6.0 document");
	}

// StarOffice 5
	elseif ($last == "sdw") {
		$icon = "openoffice";
		$type = __("StarOffice - StarWriter 5.x document");
	}
	elseif ($last == "sgl") {
		$icon = "openoffice";
		$type = __("StarOffice - StarWriter 5.x global document");
	}
	elseif ($last == "sdc") {
		$icon = "openoffice";
		$type = __("StarOffice - StarCalc 5.x spreadsheet");
	}
	elseif ($last == "sda") {
		$icon = "openoffice";
		$type = __("StarOffice - StarDraw 5.x document");
	}
	elseif ($last == "sdd") {
		$icon = "openoffice";
		$type = __("StarOffice - StarImpress 5.x presentation");
	}
	elseif ($last == "sdp") {
		$icon = "openoffice";
		$type = __("StarOffice - StarImpress Packed 5.x file");
	}
	elseif ($last == "smf") {
		$icon = "openoffice";
		$type = __("StarOffice - StarMath 5.x document");
	}
	elseif ($last == "sds") {
		$icon = "openoffice";
		$type = __("StarOffice - StarChart 5.x document");
	}
	elseif ($last == "sdm") {
		$icon = "openoffice";
		$type = __("StarOffice - StarMail 5.x mail file");
	}

// PDF and PS
	elseif ($last == "pdf") {
		$icon = "acroread";
		$type = __("Adobe Acrobat document");
	}

// Archives
	elseif ($last == "arc") {
		$icon = "tgz";
		$type = __("ARC archive");
	}
	elseif ($last == "arj") {
		$icon = "tgz";
		$type = __("ARJ archive");
	}
	elseif ($last == "rpm") {
		$icon = "rpm";
		$type = __("RPM");
	}
	elseif ($last == "gz") {
		$icon = "tgz";
		$type = __("GZ archive");
	}
	elseif ($last == "tar") {
		$icon = "tar";
		$type = __("TAR archive");
	}
	elseif ($last == "zip") {
		$icon = "tgz";
		$type = __("Zip archive");
	}

// Movies
	elseif ($last == "mov") {
		$icon = "video";
		$type = __("MOV movie file");
	}
	elseif ($last == "mpg" || $last == "mpeg") {
		$icon = "video";
		$type = __("MPEG movie file");
	}
	elseif ($last == "rm" || $last == "ram") {
		$icon = "realplayer";
		$type = __("Real movie file");
	}
	elseif ($last == "qt") {
		$icon = "quicktime";
		$type = __("Quicktime movie file");
	}

// Flash
	elseif ($last == "fla") {
		$icon = "";
		$type = __("Shockwave flash file");
	}
	elseif ($last == "swf") {
		$icon = "";
		$type = __("Shockwave file");
	}


// Sound
	elseif ($last == "wav") {
		$icon = "irc_voice";
		$type = __("WAV sound file");
	}

// Fonts
	elseif ($last == "ttf") {
		$icon = "fonts";
		$type = __("Font file");
	}

// Default Extension
	elseif ($last) {
		$icon = "mime";
		$type = __("%1\$s File", strtoupper($last));
	}

// Default File
	else {
		$icon = "mime";
		$type = __("File");
	}

	if ($icon == "") { $icon = "mime"; }
	if ($type == "") { $type = __("File"); }

// -------------------------------------------------------------------------
// Return mime icon and mime type
// -------------------------------------------------------------------------
	$icon .= ".png";
	$icon_directory = "images/mime/" . $skinArray[$net2ftp_skin]['iconset'];

	// Internet Explorer does not display transparent PNG images correctly.
	// A solution is described here: http://support.microsoft.com/default.aspx?scid=kb;en-us;Q294714
	if ($browser_agent == "IE" && $browser_platform == "Win" && ($browser_version == "5.5" || $browser_version == "6.0")) { 
		$mime['mime_icon'] = "<img src=\"$icon_directory/spacer.gif\" alt=\"icon\" style=\"width: 16px; height: 16px; filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='$icon_directory/$icon', sizingMethod='scale')\" />\n"; 
	}
	else { 
		$mime['mime_icon'] = "<img src=\"$icon_directory/$icon\"      alt=\"icon\" style=\"width: 16px; height: 16px;\" />\n"; 
	}

	$mime['mime_type'] = $type;

	return $mime;

} // end getMime

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function getAction($action, $onClick) {

// --------------
// Checks the icon related to an action
// --------------

// -------------------------------------------------------------------------
// Global variables and settings
// -------------------------------------------------------------------------
	global $browser_agent, $browser_version, $browser_platform;
	global $net2ftp_skin;
	$skinArray = getSkinArray();

// -------------------------------------------------------------------------
// Icon name
// -------------------------------------------------------------------------
	if ($action == "back") {
		$alt = __("Back");
		$icon = "back";
		$accesskey = "b";
	}
	elseif ($action == "forward") {
		$alt = __("Submit");
		$icon = "button_ok";
		$accesskey = "v";
	}
	elseif ($action == "refresh") {
		$alt = __("Refresh");
		$icon = "reload";
		$accesskey = "r";
	}
	elseif ($action == "view_details") {
		$alt = __("Details");
		$icon = "view_detailed";
		$accesskey = "";
	}
	elseif ($action == "view_icons") {
		$alt = __("Icons");
		$icon = "view_icon";
		$accesskey = "";
	}
	elseif ($action == "listdirectories") {
		$alt = __("List");
		$icon = "view_tree";
		$accesskey = "";
	}
	elseif ($action == "logout") {
		$alt = __("Logout");
		$icon = "exit";
		$accesskey = "l";
	}
	elseif ($action == "help") {
		$alt = __("Help");
		$icon = "info";
		$accesskey = "i";
	}
	elseif ($action == "bookmark") {
		$alt = __("Bookmark");
		$icon = "bookmark";
		$accesskey = "h";
	}
	elseif ($action == "save") {
		$alt = __("Save");
		$icon = "filesave";
		$accesskey = "s";
	}
	else {
		$alt = __("Default");
		$icon = "mime";
		$accesskey = "";
	}

	$icon .= ".png";
	if ($accesskey != "") { 
		$alt = $alt . " (accesskey $accesskey)";
		$accesskey = "accesskey=\"$accesskey\"" ; 
	}

// -------------------------------------------------------------------------
// Icon directory
// -------------------------------------------------------------------------
	$icon_directory = "images/actions/" . $skinArray[$net2ftp_skin]['iconset'];

// -------------------------------------------------------------------------
// Return icon
// -------------------------------------------------------------------------
	// Internet Explorer does not display transparent PNG images correctly.
	// A solution is described here: http://support.microsoft.com/default.aspx?scid=kb;en-us;Q294714

	if ($browser_agent == "IE" && $browser_platform == "Win" && ($browser_version == "5.5" || $browser_version == "6.0")) { 
		$icon_total = "<a href=\"javascript: $onClick\" $accesskey><img src=\"$icon_directory/spacer.gif\" alt=\"$alt\" onMouseOver=\"this.style.margin='0px';this.style.width='34px';this.style.height='34px';\" onMouseOut=\"this.style.margin='1px';this.style.width='32px';this.style.height='32px';\" style=\"border: 0px; margin: 1px; width: 32px; height: 32px; vertical-align: middle; filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='$icon_directory/$icon', sizingMethod='scale');\" /></a>\n"; 
	}
	else { 
		$icon_total = "<a href=\"javascript: $onClick\" title=\"$alt\" $accesskey><img src=\"$icon_directory/$icon\"      alt=\"$alt\" onMouseOver=\"this.style.margin='0px';this.style.width='34px';this.style.height='34px';\" onMouseOut=\"this.style.margin='1px';this.style.width='32px';this.style.height='32px';\" style=\"border: 0px; margin: 1px; width: 32px; height: 32px; vertical-align: middle;\" /></a>\n"; 
	}

	return $icon_total;


/* -------------------------------------------------------------------------

---------------------------
  Accesskey documentation
---------------------------

Tutorial
http://www.cs.tut.fi/~jkorpela/forms/accesskey.html
ALT-A and ALT-F may not be used on IE

Login page
---------------------------
l login

Logout page
---------------------------
l link to login page

Browse page
---------------------------
See icons above.
Used: b, v, r, l, i, h, s

g directory textbox

Actions
w new dir
y new file
e install template
u upload
n advanced
c copy
m move
d delete
o rename
p chmod
x download
z zip
q size
j search

Headers
k up
t all

Items
1 item 1
2 item 2
...
9 item 9


------------------------------------------------------------------------- */

} // end getAction

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************







// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function getMode($setting, $on_off, $onClick) {

// --------------
// Checks the icon related to a mode
// --------------

// -------------------------------------------------------------------------
// Global variables and settings
// -------------------------------------------------------------------------
	global $browser_agent, $browser_version, $browser_platform;

	if ($setting == "details") {
		$alt = __("Details");
		$icon = "view_detailed";
	}
	elseif ($setting == "icons") {
		$alt = __("Icons");
		$icon = "view_icon";
	}

// Default
	else {
		$alt = __("Default");
		$icon = "mime";
	}

// Default
	if ($alt  == "") { $alt  = "Default"; }
	if ($icon == "") { $icon = "mime"; }

// On or off: icon and style
	if ($on_off == "on") {
		$icon_normal      = $icon;
		$icon_onmouseover = $icon;
	}
	else {
		$icon_normal      = $icon . "_light";
		$icon_onmouseover = $icon;
	}

// -------------------------------------------------------------------------
// Icon directory
// -------------------------------------------------------------------------
	$icon_directory = "images/settings/";

// -------------------------------------------------------------------------
// Return icon
// -------------------------------------------------------------------------

// DO NOT CLOSE THE IMAGE TAG TO ALLOW ADDITIONAL ACTIONS
	if ($on_off == "on") {
		if ($browser_agent == "IE" && $browser_platform == "Win" && ($browser_version == "5.5" || $browser_version == "6.0")) {	$icon_total = "<img src=\"$icon_directory/spacer.gif\"   alt=\"$alt\" style=\"border: 2px solid #000000; padding-top: 1px; padding-left: 2px; width: 32px; height: 32px; vertical-align: middle; filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='$icon_directory/$icon', sizingMethod='scale');\" />\n"; }
		else                                                                                                                  { $icon_total = "<img src=\"$icon_directory/$icon_normal\" alt=\"$alt\" style=\"border: 2px solid #000000; padding-top: 1px; padding-left: 2px; width: 32px; height: 32px; vertical-align: middle;\" />\n"; }
	}
	else {
		if ($browser_agent == "IE" && $browser_platform == "Win" && ($browser_version == "5.5" || $browser_version == "6.0")) {	$icon_total = "<a href=\"javascript: $onClick\"><img src=\"$icon_directory/spacer.gif\"   alt=\"$alt\" onMouseOver=\"this.style.margin='0px';this.style.width='34px';this.style.height='34px';\" onMouseOut=\"this.style.margin='1px';this.style.width='32px';this.style.height='32px';\" style=\"border: 0px; margin: 1px; width: 32px; height: 32px; vertical-align: middle; filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='$icon_directory/$icon', sizingMethod='scale');\" /></a>\n"; }
		else                                                                                                                  { $icon_total = "<a href=\"javascript: $onClick\" title=\"$alt\"><img src=\"$icon_directory/$icon_normal\" alt=\"$alt\" onMouseOver=\"this.style.margin='0px';this.style.width='34px';this.style.height='34px';\" onMouseOut=\"this.style.margin='1px';this.style.width='32px';this.style.height='32px';\" style=\"border: 0px; margin: 1px; width: 32px; height: 32px; vertical-align: middle;\" /></a>\n"; }
	}

	return $icon_total;

} // end getMode

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************







// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function getTitleIcon() {

// --------------
// This function returns the title icon based on the $state and $state2 variables
// --------------

// -------------------------------------------------------------------------
// Global variables and settings
// -------------------------------------------------------------------------
	global $browser_agent, $browser_version, $browser_platform;
	global $state, $state2;
	global $net2ftp_skin;
	$skinArray = getSkinArray();
	
// -------------------------------------------------------------------------
// Icon names
// -------------------------------------------------------------------------
	if ($state == "homepage") {
		$icon = "home";
	}
	elseif ($state == "browse") {
		$icon = "browse";
	}
	elseif ($state == "manage") {
		switch ($state2) {
			case "copy":
				$icon = "edit_copy";
			break;
			case "move":
				$icon = "edit_copy";
			break;
			case "delete":
				$icon = "edit_delete";
			break;
			case "rename":
				$icon = "";
			break;
			case "chmod":
				$icon = "";
			break;
			case "download":
				// Everything is done in httpheaders.inc.php
				$icon = "";
			break;
			case "zip":
				$icon = "";
			break;
			case "calculatesize":
				$icon = "";
			break;
			case "findstring":
				$icon = "";
			break;
			case "newdirectory":
				$icon = "";
			break;
			case "view":
				$icon = "";
			break;
			case "edit":
				$icon = "";
			break;
			case "newfile":
				$icon = "";
			break;
			case "uploadfile":
				$icon = "";
			break;
			case "updatefile":
				$icon = "";
			break;
		} // End switch		
	}
	elseif ($state == "bookmark") {
		$icon = "bookmark";
	}
	elseif ($state == "advanced") {
		switch ($state2) {
			case "main":
				$icon = "";
			break;
			case "troubleshoot_webserver":
				$icon = "";
			break;
			case "troubleshoot_ftpserver":
				$icon = "";
			break;
			case "printTranslationFunctions":
				$icon = "";
			break;
			case "translate_extract":
				$icon = "";
			break;
			case "translate_check":
				$icon = "";
			break;
			case "site":
				$icon = "";
			break;
			case "apache":
				$icon = "";
			break;
			case "mysql":
				$icon = "";
			break;
		} // End switch
	}
	elseif ($state == "logout") {
		$icon = "logout";
	}
	elseif ($state == "admin") {
		switch ($state2) {
			case "main":
				$icon = "";
			break;
			case "viewLogs":
				$icon = "";
			break;
			case "emptyLogs":
				$icon = "";
			break;
			case "createTables":
				$icon = "";
			break;
		} // End switch
	}
// Default File
	else {
		$icon = "";
	}

	if ($icon == "") { $icon = "mime"; }

// -------------------------------------------------------------------------
// Return title icon
// -------------------------------------------------------------------------
	$icon .= ".png";
	$icon_directory = "images/title/" . $skinArray[$net2ftp_skin]['iconset'];
	
	// Internet Explorer does not display transparent PNG images correctly.
	// A solution is described here: http://support.microsoft.com/default.aspx?scid=kb;en-us;Q294714
	if ($browser_agent == "IE" && $browser_platform == "Win" && ($browser_version == "5.5" || $browser_version == "6.0")) { 
		$icon_total = "<img src=\"$icon_directory/spacer.gif\" alt=\"icon\" style=\"width: 32px; height: 32px; vertical-align: middle; filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='$icon_directory/$icon', sizingMethod='scale')\" />\n"; 
	}
	else { 
		$icon_total = "<img src=\"$icon_directory/$icon\"      alt=\"icon\" style=\"width: 32px; height: 32px; vertical-align: middle;\" />\n"; 
	}

	return $icon_total;

} // end getTitleIcon

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




?>