<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------



// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **    

function admin($state2, $formresult, $dbusername2, $dbpassword2, $dbname2, $dbserver2, $sqlquerystring, $datefrom, $dateto) {

// --------------
// This function shows the admin panel
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;

// -------------------------------------------------------------------------
// Switch
// -------------------------------------------------------------------------
	switch ($state2) {
		case "main":
			printAdminFunctions();
			if ($execution_success == false) { return false; }
		break;
		case "viewLogs":
			viewLogs($datefrom, $dateto, true);
			if ($execution_success == false) { return false; }
		break;
		case "emptyLogs":
			emptyLogs($datefrom, $dateto);
			if ($execution_success == false) { return false; }
		break;
		case "createTables":
			createTables($formresult, $dbusername2, $dbpassword2, $dbname2, $dbserver2, $sqlquerystring);
			if ($execution_success == false) { return false; }
		break;
		default:
			$errormessage = __("Unexpected state2 string. Exiting."); 
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
  		break;

	} // End switch

} // End function admin

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************







// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printAdminFunctions() {

// --------------
// This function prints the advanced options screen
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $settings;

	echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
	echo "<tr>\n";
	echo "<td>\n";

	printTitle(__("Admin functions"));

	echo "<form name=\"AdminOptionsForm\" id=\"AdminOptionsForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
	printLoginInfo();
	echo "<input type=\"hidden\" name=\"state\" value=\"admin\" />\n";
	echo "<input type=\"hidden\" name=\"state2\" value=\"main\" />\n";
	echo getAction("back", "document.AdminOptionsForm.state.value='homepage'; document.AdminOptionsForm.state2.value='login'; document.AdminOptionsForm.submit();") . " &nbsp ";
	echo "<br /><br />\n";

// -------------------------------------------------------------------------
// Version checking
// -------------------------------------------------------------------------
	echo "<div class=\"header31\">" . __("Version information") . "</div><br />\n";

// This function gets a Javascript file on net2ftp.com which contains the latest version nr.
// It compares it with the current version and displays a message if there is a new stable or beta version.

	echo "<div style=\"border: 1px solid black; background-color: #DDDDDD; margin-top: 10px; margin-left: 100px; margin-right: 100px; padding: 10px;\">\n";
	echo "<table border=\"0\" cellspacing=\"2\" cellpadding=\"2\"><tr><td>\n";

	echo "<script type=\"text/javascript\">\n";
	echo "<!--\n";
	echo "var current_build = " . $settings["application_build_nr"] . ";\n";
	// The following variables:  latest_stable_build, latest_stable_version, latest_stable_url, 
	//                           latest_beta_build, latest_beta_version, latest_beta_url
	// come from the remote file that is included
	echo "if (typeof(latest_stable_build)!=\"undefined\" && typeof(latest_beta_build)!=\"undefined\") {\n";
	echo "	if (latest_stable_build > current_build) {\n";
	echo "		document.write('There is a <a href=\"' + latest_stable_url + '\"> new stable version</a> of net2ftp available for download (' + latest_stable_version + ').<br />');\n";
	echo "	}\n";
	echo "	else if (latest_beta_build > current_build) {\n";
	echo "		document.write('There is a <a href=\"' + latest_beta_url + '\">new beta version</a> of net2ftp available for download (' + latest_beta_version + ').<br />');\n";
	echo "	}\n";
	echo "	else {\n";
	echo "		document.write('" . __("This version of net2ftp is up-to-date") . ".<br />');\n";
	echo "	}\n";
	echo "}\n";

	echo "else {\n";
	echo "		document.write('" . __("The latest version could not be retrieved from the net2ftp.com server. Check the security settings of your browser, which may prevent the loading of a small file from the net2ftp.com server.") . "<br />');\n";	
	echo "}\n";

	echo "//-->\n";
	echo "</script>\n";


	echo "</td></tr></table>\n";
	echo "</div><br /><br />\n";

// -------------------------------------------------------------------------
// Logs
// -------------------------------------------------------------------------
	echo "<div class=\"header31\">" . __("Logging") . "</div><br />\n";

	$today = date("Y-m-d");
	$oneweekago = date("Y-m-d", time() - 3600*24*7);
	echo __("Date from:") . " <input type=\"text\" name=\"datefrom\" value=\"$oneweekago\" />  " . __("to:") . " <input type=\"text\" name=\"dateto\" value=\"$today\" />\n";
	echo "<input type=\"button\" class=\"button\" value=\"" . __("View logs") . "\" onClick=\"document.AdminOptionsForm.state2.value='viewLogs'; document.AdminOptionsForm.submit();\" /> &nbsp; \n";
	echo "<input type=\"button\" class=\"button\" value=\"" . __("Empty logs") . "\" onClick=\"document.AdminOptionsForm.state2.value='emptyLogs'; document.AdminOptionsForm.submit();\" /><br />\n";

	echo "<br /><br />\n";

// -------------------------------------------------------------------------
// Setup
// -------------------------------------------------------------------------
	echo "<div class=\"header31\">" . __("Setup MySQL tables") . "</div><br />\n";
	echo "<input type=\"button\" class=\"smallbutton\" value=\"" . __("Go") . "\" onClick=\"document.AdminOptionsForm.state2.value='createTables';   document.AdminOptionsForm.submit();\" /> " . __("Create the MySQL database tables") . "<br /><br />\n";

// -------------------------------------------------------------------------
// Beta functions
// -------------------------------------------------------------------------
//	if ($settings["show_beta"] == "yes") {
//		echo "<div class=\"header31\">" . __("Beta functions") . "</div><br />\n";
//		echo "<input type=\"button\" class=\"smallbutton\" value=\"" . __("Go") . "\" onClick=\"document.AdvancedOptionsForm.state2.value='site';   document.AdvancedOptionsForm.submit();\" /> " . __("Send a site command to the FTP server") . "<br /><br />\n";
//	}

	echo "</form>\n";

	echo "</tr>\n";
	echo "</td>\n";
	echo "</table>\n";


} // End function printAdminFunctions

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function viewLogs($datefrom, $dateto) {

// --------------
// This function shows the logs
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;

// -------------------------------------------------------------------------
// Input checks
// -------------------------------------------------------------------------
// Add slashes to variables which are used in a SQL query, and which are
// potentially unsafe (supplied by the user).
	$datefrom = addslashes($datefrom);
	$dateto   = addslashes($dateto);

	echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
	echo "<tr>\n";
	echo "<td>\n";
	printTitle(__("View logs"));

// -------------------------------------------------------------------------
// Connect to the database
// -------------------------------------------------------------------------
	$mydb = connect2db();
	if ($execution_success == false) { return false; }

// -------------------------------------------------------------------------
// Execute the SQL query and print the data
// -------------------------------------------------------------------------

// Query 1
	$sqlquery1 = "SELECT * FROM net2ftp_logAccess WHERE date BETWEEN '$datefrom' AND '$dateto' ORDER BY date DESC, time DESC;";
	printTable($sqlquery1);
	if ($execution_success == false) { return false; }

// Query 2
	$sqlquery2 = "SELECT * FROM net2ftp_logLogin WHERE date BETWEEN '$datefrom' AND '$dateto' ORDER BY date DESC, time DESC;";
	printTable($sqlquery2);
	if ($execution_success == false) { return false; }
	
// Query 3
	$sqlquery3 = "SELECT * FROM net2ftp_logError WHERE date BETWEEN '$datefrom' AND '$dateto' ORDER BY date DESC, time DESC;";
	printTable($sqlquery3);
	if ($execution_success == false) { return false; }
	
// Query 4
	$sqlquery4 = "SELECT * FROM net2ftp_logConsumptionFtpserver WHERE date BETWEEN '$datefrom' AND '$dateto' ORDER BY dataTransfer DESC, date DESC;";
	printTable($sqlquery4);
	if ($execution_success == false) { return false; }
	
// Query 5
	$sqlquery5 = "SELECT * FROM net2ftp_logConsumptionIpaddress WHERE date BETWEEN '$datefrom' AND '$dateto' ORDER BY dataTransfer DESC, date DESC;";
	printTable($sqlquery5);
	if ($execution_success == false) { return false; }
	
	echo "</tr>\n";
	echo "</td>\n";
	echo "</table>\n";

} // End viewLogs

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function emptyLogs($datefrom, $dateto, $printmessage) {

// --------------
// This function empties the logs
// $printmessage is used to indicate if messages have to be printed or not.
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $settings;

// -------------------------------------------------------------------------
// Input checks
// -------------------------------------------------------------------------	
// Add slashes to variables which are used in a SQL query, and which are
// potentially unsafe (supplied by the user).
	$datefrom = addslashes($datefrom);
	$dateto   = addslashes($dateto);
	
	if ($datefrom == "" || $datefrom == 0) { return false; }
	if ($dateto == "" || $dateto == 0)     { return false; }

// -------------------------------------------------------------------------
// Delete empty logs
// -------------------------------------------------------------------------		
	$mydb = connect2db();
	if ($execution_success == false)  { return false; }

	$tables[1] = "net2ftp_logAccess";
	$tables[2] = "net2ftp_logLogin";
	$tables[3] = "net2ftp_logError";
	$tables[4] = "net2ftp_logConsumptionFtpserver";
	$tables[5] = "net2ftp_logConsumptionIpaddress";
	
	for ($i=1; $i<=5; $i++) {
		$sqlquery_empty   = "DELETE FROM $tables[$i] WHERE date BETWEEN '$datefrom' AND '$dateto';";
		$result_empty[$i] = mysql_query("$sqlquery_empty");
		
		$sqlquery_optimize   = "OPTIMIZE TABLE '" . $tables[$i] . "';";
		$result_optimize[$i] = mysql_query("$sqlquery_optimize");
	} // end for


// -------------------------------------------------------------------------
// Print result
// -------------------------------------------------------------------------		

	if ($printmessage == true) {
		
		echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
		echo "<tr>\n";
		echo "<td>\n";
		printTitle(__("Empty logs"));

		for ($i=1; $i<=5; $i++) {
			if ($result_empty[$i] == true) { echo __("The table <b>%1\$s</b> was emptied successfully.", $tables[$i]) . "<br />\n"; }
			else                           { echo __("The table <b>%1\$s</b> could not be emptied.", $tables[$i])     . "<br />\n"; }
			echo "<br />\n";
			if ($result_optimize[$i] == true) { echo __("The table <b>%1\$s</b> was optimized successfully.", $tables[$i]) . "<br />\n"; }
			else                              { echo __("The table <b>%1\$s</b> could not be optimized.", $tables[$i])     . "<br />\n"; }
			flush();
		} // end for
			
		echo "</tr>\n";
		echo "</td>\n";
		echo "</table>\n";
	
	} // end if
	
} // End emptyLogs

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function createTables($formresult, $dbusername2, $dbpassword2, $dbname2, $dbserver2, $sqlquerystring) {

// --------------
// This function creates MySQL tables
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $application_rootdir;

	echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
	echo "<tr>\n";
	echo "<td>\n";
	printTitle(__("Create tables"));

// -------------------------------------------------------------------------
// Read the SQL file
// -------------------------------------------------------------------------
	$filename = glueDirectories($application_rootdir, "create_tables.sql");
	$handle = fopen($filename, "rb"); // Open the file for reading only
	if ($handle == false) { echo __("The handle of file %1\$s could not be opened", $filename) . "<br />\n"; }

	clearstatcache(); // for filesize

	$sqlquerystring = fread($handle, filesize($filename));
	if ($sqlquerystring == false) { echo __("The file %1\$s could not be opened", $filename) . "<br />\n"; }

	$result1 = fclose($handle);
	if ($result1 == false) { echo __("The handle of file %1\$s could not be closed", $filename) . "<br />\n"; }


// -------------------------------------------------------------------------
// Form
// -------------------------------------------------------------------------
	if ($formresult != "result") {

		echo "<form name=\"CreateTablesForm\" id=\"CreateTablesForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
		echo "<input type=\"hidden\" name=\"state\"  value=\"admin\" />\n";
		echo "<input type=\"hidden\" name=\"state2\" value=\"createTables\" />\n";
		echo "<input type=\"hidden\" name=\"formresult\" value=\"result\" />\n";

		echo "<table>";
		echo "<tr><td>" . __("MySQL username") . "</td><td> <input type=\"text\" name=\"dbusername2\" /></td></tr>\n";
		echo "<tr><td>" . __("MySQL password") . "</td><td> <input type=\"password\" name=\"dbpassword2\" /></td></tr>\n";
		echo "<tr><td>" . __("MySQL database") . "</td><td> <input type=\"text\" name=\"dbname2\" />    </td></tr>\n";
		echo "<tr><td>" . __("MySQL server")   . "</td><td> <input type=\"text\" name=\"dbserver2\" value=\"localhost\" /></td></tr>\n";
		echo "</table><br /><br />";

		echo __("This SQL query is going to be executed:") . "<br /><br />\n";
		echo "<textarea name=\"text\" class=\"edit\" rows=\"15\" cols=\"65\" wrap=\"off\">\n";
		echo "$sqlquerystring\n";
		echo "</textarea><br /><br />\n";

		echo "<div style=\"text-align: center;\"><input type=\"submit\" class=\"button\" value=\"" . __("Execute") . "\" /></div>\n";
		echo "</form>\n";
	}

// -------------------------------------------------------------------------
// Result
// -------------------------------------------------------------------------
	elseif ($formresult == "result") {

		echo "<div class=\"header31\">" . __("Settings used:") . "</div>\n";
		echo __("MySQL username")        . ": $dbusername2<br />\n";
		echo __("MySQL password length") . ": " . strlen($dbpassword2) . "<br />\n";
		echo __("MySQL database")        . ": $dbname2<br />\n";
		echo __("MySQL server")          . ": $dbserver2<br /><br />\n";

		echo "<div class=\"header31\">" . __("Results:") . "</div>\n";

// Connect
		$mydb = mysql_connect($dbserver2, $dbusername2, $dbpassword2);
		if ($mydb == false) { echo __("The connection to the server <b>%1\$s</b> could not be set up", $dbserver2) . "\n"; }

// Select
		$result1 = mysql_select_db($dbname2);
		if ($result1 == false) { echo __("Unable to select the database <b>%1\$s</b>", $dbserver2) . "\n"; }

// Query
// $sqlquerystring comes from a file on the web server, so it is assumed to be safe
		$result2 = mysql_query($sqlquerystring);
		if ($result2 == false) { echo __("The SQL query could not be executed") . "\n"; }
		else { echo __("The tables were created successfully") . "\n"; }

	} // end if

	echo "</tr>\n";
	echo "</td>\n";
	echo "</table>\n";

} // End createTables

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// ************************************************************************************** 
// ************************************************************************************** 
// **                                                                                  ** 
// **                                                                                  ** 

function printTable($sqlquery) {

// --------------
// This function executes the SQL query and prints a nice HTML table with the results
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;


// -------------------------------------------------------------------------
// Execute the SQL query
// -------------------------------------------------------------------------
	$result = mysql_query("$sqlquery");
	if ($result == false) { 
		$errormessage = __("Unable to execute the SQL query %1\$s.", $sqlquery); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;	
	}
	$nrofrows = mysql_num_rows($result);
	$nrofcolumns_withindex = mysql_num_fields($result) + 1;
	 

// ------------------------------------------------------------------------- 
// Print the table
// ------------------------------------------------------------------------- 

// Table begin
	echo "<table border=\"1\">\n";

// First row: SQL query
	echo "<tr><td colspan=\"$nrofcolumns_withindex\" class=\"tdheader1\" style=\"font-size: 120%;\">$sqlquery</td></tr>\n";


	if ($nrofrows != 0) {
// Second row: header
		$row = mysql_fetch_array($result, MYSQL_ASSOC);
		echo "<tr>\n";
		echo "<td>Index</td>\n";
		while(list($fieldname, $fieldvalue) = each($row) ) { echo "<td>$fieldname</td>\n"; }
		echo "</tr>\n";
		mysql_data_seek($result, 0); // reset row pointer to the first row

// 3rd and next rows: data
		$rowcounter = 1;
		while($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
			echo "<tr>\n";
			echo "<td>$rowcounter</td>\n";
			while(list($fieldname, $fieldvalue) = each($row) ) { echo "<td>$fieldvalue</td>\n"; }
			echo "</tr>\n";
			$rowcounter++;
			flush();
		}
	}

// If there is no data
	else { 
		echo "<tr><td colspan=\"$nrofcolumns_withindex\">" . __("No data") . "</td></tr>"; 
	}

// Table end
	echo "</table>\n";
	echo "<p> &nbsp; </p>\n\n\n";
	flush();

// ------------------------------------------------------------------------- 
// Free the $result
// ------------------------------------------------------------------------- 
	mysql_free_result($result);

	return true;
	
} // End printTable

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************



?>