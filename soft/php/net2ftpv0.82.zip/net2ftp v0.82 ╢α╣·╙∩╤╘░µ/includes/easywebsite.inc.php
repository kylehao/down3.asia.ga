<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function easyWebsite($state2, $directory, $screen, $template, $standalone) {

// --------------
// This function allows to create a website from pre-made HTML templates
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $settings;
	global $net2ftp_ftpserver;
	global $application_rootdir, $application_templatesdir;
	global $templateList;
	require_once($application_templatesdir . "/templates.inc.php");

	if ($screen == "") { $screen = 1; }

// -------------------------------------------------------------------------
// Page header
// -------------------------------------------------------------------------
	echo "<table style=\"margin-left: 30px; width: 100%;\">\n";
	echo "<tr>\n";
	echo "<td>\n";
	printTitle(__("Create a website in 4 easy steps"));

	if ($standalone != "yes") { 
		printBack($directory);
	}

// -------------------------------------------------------------------------
// Roadmap
// -------------------------------------------------------------------------

	$style_begin = "<span style=\"font-size: 120%; font-weight: bold; color: #3333DD;\">";
	$style_end   = "</span>";

	$roadmap_part1 = "1 - " . __("Template overview");
	$roadmap_part2 = "2 - " . __("Template details");
	$roadmap_part3 = "3 - " . __("Files are copied");
	$roadmap_part4 = "4 - " . __("Edit your pages");

	$roadmapToHighlight = "roadmap_part" . $screen;
	$$roadmapToHighlight = $style_begin . $$roadmapToHighlight . $style_end;

	echo "<div style=\"border: 2px dashed #C6C6C6; background-color: #F3F3F3; text-align: center; padding: 5px; width: 90%; margin-left: auto; margin-right: auto; margin-bottom: 20px;\">";
	echo  $roadmap_part1 . " | " . $roadmap_part2 . " | " . $roadmap_part3 . " | " . $roadmap_part4 . "<br />\n"; 
//	if ($standalone != "yes") { 
//		$browse_url = printPHP_SELF("easyWebsite_edit") . "&amp;state=browse&amp;state2=main&amp;directory=" . htmlentities($directory);
//		echo "<a href=\"$browse_url\" style=\"font-size: 80%;\">" . __("Back to the Browse screen") . "</a>\n";
//	}
	echo "</div>\n";
	
	echo "<form name=\"easyWebsiteForm\" id=\"easyWebsiteForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
	printLoginInfo();
	echo "<input type=\"hidden\" name=\"state\" value=\"easyWebsite\" />\n";
	echo "<input type=\"hidden\" name=\"directory\" value=\"$directory\" />\n";

// -------------------------------------------------------------------------
// Screen 1: Template overview
// -------------------------------------------------------------------------
	if ($screen == 1) {
		echo "<input type=\"hidden\" name=\"screen\" value=\"2\" />\n";
		echo "<input type=\"hidden\" name=\"template\" value=\"\" />\n";
		echo "<input type=\"hidden\" name=\"standalone\" value=\"$standalone\" />\n";
		printTemplateOverview($directory, "easyWebsiteForm", $standalone);
	} // end if $screen


// -------------------------------------------------------------------------
// Screen 2: Template details
// -------------------------------------------------------------------------
	elseif ($screen == 2) {
		echo "<input type=\"hidden\" name=\"screen\" value=\"3\" />\n";
		echo "<input type=\"hidden\" name=\"template\" value=\"$template\" />\n";
		echo "<input type=\"hidden\" name=\"standalone\" value=\"$standalone\" />\n";
		printTemplateDetails($directory, "easyWebsiteForm", $template, $standalone);
	} // end if $screen


// -------------------------------------------------------------------------
// Screen 3: Copy all files to the website
// -------------------------------------------------------------------------
	elseif ($screen == 3) {
		echo "<input type=\"hidden\" name=\"screen\" value=\"4\" />\n";
		echo "<input type=\"hidden\" name=\"template\" value=\"$template\" />\n";
		echo "<input type=\"hidden\" name=\"standalone\" value=\"$standalone\" />\n";
		
		echo __("Please wait while the template files are being transferred to your server: ") . "<br />\n";

// Open connection
		$conn_id = ftp_openconnection();
		if ($execution_success == false) { return false; }

// Copy files
		$list[1]['scanrule']        = "local";
		$list[1]['dirorfile']       = "d";
		$list[1]['dirfilename']     = "";
		$list[1]['size']            = 0;
		$list[1]['sourcedirectory'] = $application_rootdir . "/html_templates/" . $templateList[$template]["directory"]; // Local source directory
		$list[1]['targetdirectory'] = $directory;                                                                        // Remote target directory

// ----------------------------
		ftp_copy_local2ftp($conn_id, $list, 0);
// ----------------------------
		if ($execution_success == false)  { return false; }

// Close connection
		ftp_closeconnection($conn_id);

		echo "<br />" . __("Done.") . "<br /><br />\n";

		$onClick = "document.easyWebsiteForm.submit();";
		echo "<input type=\"button\" class=\"button\" value=\"" . __("Continue") . "\" onClick=\"$onClick\">\n";

	} // end elseif $screen


// -------------------------------------------------------------------------
// Screen 4: Print links to edit pages
// -------------------------------------------------------------------------
	elseif ($screen == 4) {

		echo "<input type=\"hidden\" name=\"screen\" value=\"3\" />\n";
		echo "<input type=\"hidden\" name=\"standalone\" value=\"$standalone\" />\n";
		printEasyAdminPanel($directory, "easyWebsiteForm", $template, $standalone);
	
	} // End elseif $screen


// -------------------------------------------------------------------------
// Page footer
// -------------------------------------------------------------------------
	echo "</form>\n";
	echo "</td>\n";
	echo "</tr>\n";
	echo "</table>\n";

} // End function easyWebsite

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printTemplateOverview($directory, $formName, $standalone) {

// --------------
// This function prints a table with an overview of the available templates
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $application_templatesdir;
	global $templateList;
	require_once($application_templatesdir . "/templates.inc.php");

// -------------------------------------------------------------------------
// Table
// -------------------------------------------------------------------------	
	echo __("Click on the image to view the details of a template.") . "<br />\n";

	echo "<table cellspacing=\"10\" style=\"padding: 10px;\">\n";

	for ($i=1; $i<=sizeof($templateList); $i=$i+2) {
		$j = $i+1;
		$onClick1 = "javascript: document.$formName.template.value=$i; document.$formName.submit();";
		$onClick2 = "javascript: document.$formName.template.value=$j; document.$formName.submit();";
		$alt1     = __("Template") . " " . $templateList[$i]["name"];
		$alt2     = __("Template") . " " . $templateList[$j]["name"];
		$title1   = __("Click on the image to view the details of this template");
		$title2   = $title1;
		$src1     = "html_templates/" . $templateList[$i]["directory"] . "/screenshot-small.jpg";
		$src2     = "html_templates/" . $templateList[$j]["directory"] . "/screenshot-small.jpg";
		$caption1 = __("Template") . " " . $templateList[$i]["name"] . "<br />" . __("Copyright") . " " . $templateList[$i]["copyright"];
		$caption2 = __("Template") . " " . $templateList[$j]["name"] . "<br />" . __("Copyright") . " " . $templateList[$j]["copyright"];
		$total1   = "<a href=\"$onClick1\" alt=\"$alt1\" title=\"$title1\"><img src=\"$src1\" border=\"2\"></a><br />$caption1";
		$total2   = "<a href=\"$onClick2\" alt=\"$alt2\" title=\"$title2\"><img src=\"$src2\" border=\"2\"></a><br />$caption2";
		if ($j>sizeof($templateList)) { $total2 = ""; } // Odd nr of templates ==> do not print an unexisting template (last one)
		echo "<tr>\n";
		echo "<td valign=\"top\">$total1</td>\n";
		echo "<td valign=\"top\">$total2</td>\n";
		echo "</tr>\n";
	}

	echo "</table>\n";

} // End function printTemplateOverview

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printTemplateDetails($directory, $formName, $template, $standalone) {

// --------------
// This function prints a HTML <SELECT>, a list of pages to be previewed and a screenshot
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	
	global $application_templatesdir;
	global $templateList;
	require_once($application_templatesdir . "/templates.inc.php");

// -------------------------------------------------------------------------
// Check input and set defaults
// -------------------------------------------------------------------------
	if ($template == "") { $template = 1; }

// -------------------------------------------------------------------------
// Print the select <select>
// -------------------------------------------------------------------------
//	$onChange = "document.$formName.screen.value=2; document.$formName.submit();";
//	echo "<select name=\"template\" id=\"template\" onChange=\"$onChange\">\n";
//	for ($i=1; $i<=sizeof($templateList); $i++) {
//		if ($i == $template) { $selected = "selected"; }
//		else                 { $selected = ""; }
//		echo "<option value=\"$i\" $selected>" . $templateList[$i]["name"] . "</option>\n";
//	}
//	echo "</select>\n";
	

// -------------------------------------------------------------------------
// Directory
// -------------------------------------------------------------------------
	if (strlen($directory) > 0) { $printdirectory = $directory; }
	else                        { $printdirectory = "/"; }
	$text_prompt = __('The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?');
	$onClick = "confirm_prompt('" . $formName . "', '$text_prompt');";

	echo __("Install template to directory: ") . " <input type=\"text\" class=\"longinput\" name=\"directory\" value=\"$printdirectory\" />\n";
	printDirectoryTreeLink($directory, "$formName.directory");
	echo "<input type=\"button\" class=\"button\" value=\"" . __("Install") . "\" onClick=\"$onClick\">\n";
	echo "<br /><br />\n";

// -------------------------------------------------------------------------
// Print the basic info and links to preview the pages
// -------------------------------------------------------------------------
	echo __("Template")  . ": " . $templateList[$template]["name"] . "<br />\n";
	echo __("Size")      . ": " . $templateList[$template]["size"] . "<br />\n";
	echo __("Copyright") . ": " . $templateList[$template]["copyright"] . "<br /><br />\n";

	for ($j=1; $j<=sizeof($templateList[$template]["pages"]); $j++) {
		$url = "html_templates/" . $templateList[$template]["directory"] . "/" . $templateList[$template]["pages"][$j];
		echo __("Preview page") . " <a href=\"$url\" target=\"_blank\">" . $templateList[$template]["pages"][$j] . "</a> (" . __("opens in a new window") . ")<br />\n";
	}

// -------------------------------------------------------------------------
// Print the screenshot
// -------------------------------------------------------------------------

	echo "<br /><img src=\"html_templates/" . $templateList[$template]["directory"] . "/" . "screenshot.jpg\" width=\"600px\" /><br />\n";	

// -------------------------------------------------------------------------
// Copyright textarea
// -------------------------------------------------------------------------
	$copyright_file = $application_templatesdir . DIRECTORY_SEPARATOR . $templateList[$template]["directory"] . DIRECTORY_SEPARATOR . "copyright.txt";

	$handle = @fopen($copyright_file, "r"); // Open the local template file for reading only
	if ($handle == false) { 
		$copyright_message = "[The file copyright.txt was not found.]";
	}
	else {
		clearstatcache(); // for filesize
		$copyright_message = fread($handle, filesize($copyright_file));
	}
	echo "<br /><textarea cols=\"60\" rows=\"6\" readonly>$copyright_message</textarea>\n";

	
} // End function printTemplateDetails

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printEasyAdminPanel($directory, $formName, $template, $standalone) {

// --------------
// This function prints the Easy Admin Panel to edit the template pages
// --------------

	global $execution_success;
	global $net2ftp_ftpserver;
	global $application_templatesdir;
	global $templateList;
	require_once($application_templatesdir . "/templates.inc.php");

	echo "<div style=\"border: 2px solid #C6C6C6; background-color: #EFEFEF; text-align: left; padding: 10px; width: 80%; margin-left: auto; margin-right: auto; margin-bottom: 40px;\">";

// Links to edit the pages
	$edit_url = printPHP_SELF("easyWebsite_edit") . "&amp;state=manage&amp;state2=edit&amp;textareaType=htmlarea3rc1&amp;directory=" . htmlentities($directory);
	for ($j=1; $j<=sizeof($templateList[$template]["pages"]); $j++) {
		$url = $edit_url . "&amp;entry=" . $templateList[$template]["pages"][$j];
		echo __("Edit page") . " <a href=\"$url\" target=\"_blank\">" . $templateList[$template]["pages"][$j] . "</a> (" . __("opens in a new window") . ")<br />\n";
	}

// Link to browse the FTP server
	$browse_url = printPHP_SELF("easyWebsite_edit") . "&amp;state=browse&amp;state2=main&amp;directory=" . htmlentities($directory);
	echo "<br /><a href=\"$browse_url\" target=\"_blank\">" . __("Browse the FTP server") . "</a> (" . __("opens in a new window") . ")<br />";
	
	echo "</div>\n";

// Link to bookmark this page
	echo __("Add this link to your favorites to return to this page later on!") . "<br />\n";
	$url  = printPHP_SELF("easyWebsite_bookmark") . "&amp;template=$template&amp;standalone=$standalone";
	$text = __("Edit website at %1\$s", $net2ftp_ftpserver);
	echo "<a href=\"$url\">$text</a><br />\n";
	echo "<ul>\n";
	echo "	<li> " . __("Internet Explorer: right-click on the link and choose \"Add to Favorites...\"") . "</li>\n";
	echo "	<li> " . __("Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\"") . " </li>\n";
	echo "</ul>\n";
	echo "<br />\n";

} // End function printEasyAdminPanel

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function ftp_copy_local2ftp($conn_id, $list, $divelevel) {

// --------------
// This function copies all the template files to the FTP server, and creates subdirectories as needed
//
// This function copies everything from a directory on the **webserver** to a directory on the FTP server
// ftp_copymovedelete does the same, but from an **FTP** server to the same or to a different FTP server
// --------------

	global $execution_success;

// -------------------------------------------------------------------------
// Print begin
// -------------------------------------------------------------------------
//	if ($divelevel == 0) { echo "<ul>\n"; }

// -------------------------------------------------------------------------
// Separate the directories from the files
// -------------------------------------------------------------------------
	$counter_directories = 1;
	$counter_files = 1;
	for ($i=1; $i<=count($list); $i=$i+1) {
		if     ($list[$i]['dirorfile'] == "d") { $list_directories[$counter_directories] = $list[$i]; $counter_directories = $counter_directories + 1; }
		elseif ($list[$i]['dirorfile'] == "-") { $list_files[$counter_files] = $list[$i];             $counter_files = $counter_files + 1; }
	}

// -------------------------------------------------------------------------
// For all directories
// -------------------------------------------------------------------------
	for ($i=1; $i<=count($list_directories); $i=$i+1) {

// Source and target
		if ($divelevel == 0) { 
			$source = $list_directories[$i]['sourcedirectory'];
			$target = $list_directories[$i]['targetdirectory'];  
		}
		else { 
			$source = glueDirectories($list_directories[$i]['sourcedirectory'], $list_directories[$i]['dirfilename']);
			$target = glueDirectories($list_directories[$i]['targetdirectory'], $list_directories[$i]['dirfilename']); 
		}

// Create the targetdirectory
		if ($divelevel > 0) {
			$success1 = @ftp_mkdir($conn_id, $target);
			if ($success1 == false) { echo __("WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing...", $target) . "<br />\n"; }
			else                    { echo __("Created target subdirectory <b>%1\$s</b>", $target) . " <br />\n"; }
		}
		
// Get a new list
		$newlist = local_getlist($source);
		if ($execution_success == false) { return false; }

// Add information to the list
		for ($j=1; $j<=count($newlist); $j++) {
			$newlist[$j]['sourcedirectory'] = $source;
			$newlist[$j]['targetdirectory'] = $target;
		}

// Call the function recursively
		$newdivelevel = $divelevel + 1;
		ftp_copy_local2ftp($conn_id, $newlist, $newdivelevel);

	} // end for list_directories

// -------------------------------------------------------------------------
// Process the files
// -------------------------------------------------------------------------
	for ($i=1; $i<=count($list_files); $i=$i+1) {

// Source and target
		$localsourcedir   = $list_files[$i]['sourcedirectory'];
		$remotetargetdir  = $list_files[$i]['targetdirectory'];
		$localsourcefile  = $list_files[$i]['dirfilename'];
		$remotetargetfile = $list_files[$i]['dirfilename'];
		$ftpmode = ftpAsciiBinary($list_files[$i]['dirfilename']);
			
// Put file from the local source directory to remote target directory
		ftp_putfile($conn_id, $localsourcedir, $localsourcefile, $remotetargetdir, $remotetargetfile, $ftpmode, "copy");
		if ($execution_success == false) { 
			setErrorVars(true, "", "");
			echo __("WARNING: Unable to copy the file <b>%1\$s</b>. Continuing...", $localsourcefile) . "<br />\n";
			continue; 
		}
		else { echo __("Copied file <b>%1\$s</b>", $list_files[$i]['dirfilename']) . " <br />\n"; }

	} // end for list_files

// -------------------------------------------------------------------------
// Print end
// -------------------------------------------------------------------------
//	if ($divelevel == 0) { echo "</ul>\n"; }
	
} // End function ftp_copy_local2ftp

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






?>