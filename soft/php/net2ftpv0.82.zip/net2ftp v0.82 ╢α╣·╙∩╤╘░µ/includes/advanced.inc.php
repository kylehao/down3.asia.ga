<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function advanced($state2, $directory, $entry, $formresult, $screen, $functionname) {

// --------------
// This function allows to execute advanced functions
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $settings;

// -------------------------------------------------------------------------
// Switch
// -------------------------------------------------------------------------
	switch ($state2) {
		case "main":
			printAdvancedFunctions($directory);	
		break;
		case "troubleshoot_webserver":
			troubleshoot_webserver($directory, $formresult);
		break;
		case "troubleshoot_ftpserver":
			troubleshoot_ftpserver($directory, $formresult);
		break;
		case "test_list_parsing":
			test_list_parsing($formresult);
		break;
		case "printTranslationFunctions":
			printTranslationFunctions($directory);
		break;
		case "translate_extract":
			translate_extract($directory, $entry, $screen, $functionname);
		break;
		case "translate_check":
			translate_check($directory, $entry, $screen);
		break;
		case "site":
			if ($settings["show_beta"] == yes) { sendsitecommand($directory, $command, $formresult); }
			else { 
				$errormessage = __("The site command functions are not available on this webserver.");  
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}
		break;
		case "apache":
			if ($settings["show_beta"] == yes) { apache($directory, $command, $formresult); }
			else { 
				$errormessage = __("The Apache functions are not available on this webserver.");
				setErrorVars(false, $errormessage, debug_backtrace());
				return false; 
			}
		break;
		case "mysql":
			if ($settings["show_beta"] == yes) { mysqlfunctions($directory, $formresult); }
			else { 
				$errormessage = __("The MySQL functions are not available on this webserver.");
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}
		break;
		default:
			$errormessage = __("Unexpected state2 string. Exiting."); 
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
  		break;

	} // End switch

} // End function advanced

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printAdvancedFunctions($directory) {

// --------------
// This function prints the advanced options screen
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $settings;

	echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
	echo "<tr>\n";
	echo "<td>\n";

	printTitle(__("Advanced functions"));

	echo "<form name=\"AdvancedOptionsForm\" id=\"AdvancedOptionsForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
	printLoginInfo();
	echo "<input type=\"hidden\" name=\"state\" value=\"advanced\" />\n";
	echo "<input type=\"hidden\" name=\"state2\" value=\"main\" />\n";
	echo "<input type=\"hidden\" name=\"directory\" value=\"$directory\" />\n";
	printBackInForm($directory, "AdvancedOptionsForm");
	echo "<br /><br />\n";

	echo "<div class=\"header31\">" . __("Troubleshooting functions") . "</div><br />\n";
	echo "<input type=\"button\" class=\"smallbutton\" value=\"" . __("Go") . "\" onClick=\"document.AdvancedOptionsForm.state2.value='troubleshoot_webserver'; document.AdvancedOptionsForm.submit();\" /> " . __("Troubleshoot net2ftp on this webserver") . "<br /><br />\n";
	echo "<input type=\"button\" class=\"smallbutton\" value=\"" . __("Go") . "\" onClick=\"document.AdvancedOptionsForm.state2.value='troubleshoot_ftpserver'; document.AdvancedOptionsForm.submit();\" /> " . __("Troubleshoot an FTP server") . "<br /><br />\n";
	echo "<input type=\"button\" class=\"smallbutton\" value=\"" . __("Go") . "\" onClick=\"document.AdvancedOptionsForm.state2.value='test_list_parsing';      document.AdvancedOptionsForm.submit();\" /> " . __("Test the net2ftp list parsing rules") . "<br /><br />\n";

	echo "<div class=\"header31\">" . __("Translation functions") . "</div><br />\n";
	echo "<input type=\"button\" class=\"smallbutton\" value=\"" . __("Go") . "\" onClick=\"document.AdvancedOptionsForm.state2.value='printTranslationFunctions'; document.AdvancedOptionsForm.submit();\" /> " . __("Introduction to the translation functions") . " <br /><br />\n";
	echo "<input type=\"button\" class=\"smallbutton\" value=\"" . __("Go") . "\" onClick=\"document.AdvancedOptionsForm.state2.value='translate_extract'; document.AdvancedOptionsForm.submit();\" /> " . __("Extract messages to translate from code files") . " <br /><br />\n";
	echo "<input type=\"button\" class=\"smallbutton\" value=\"" . __("Go") . "\" onClick=\"document.AdvancedOptionsForm.state2.value='translate_check';   document.AdvancedOptionsForm.submit();\" /> " . __("Check if there are new or obsolete messages") . " <br /><br />\n";

	if ($settings["show_beta"] == "yes") {
		echo "<div class=\"header31\">" . __("Beta functions") . "</div><br />\n";
		echo "<input type=\"button\" class=\"smallbutton\" value=\"" . __("Go") . "\" onClick=\"document.AdvancedOptionsForm.state2.value='site';   document.AdvancedOptionsForm.submit();\" /> " . __("Send a site command to the FTP server") . " <br /><br />\n";
		echo "<input type=\"button\" class=\"smallbutton\" value=\"" . __("Go") . "\" onClick=\"document.AdvancedOptionsForm.state2.value='apache'; document.AdvancedOptionsForm.submit();\" /> " . __("Apache: password-protect a directory, create custom error pages") . "<br /><br />\n";
		echo "<input type=\"button\" class=\"smallbutton\" value=\"" . __("Go") . "\" onClick=\"document.AdvancedOptionsForm.state2.value='mysql';  document.AdvancedOptionsForm.submit();\" /> " . __("MySQL: execute an SQL query") . "<br /><br />\n";
	}

	echo "</form>\n";

	echo "</tr>\n";
	echo "</td>\n";
	echo "</table>\n";


} // End function printAdvancedFunctions

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function troubleshoot_webserver($directory, $formresult) {

// --------------
// This function tests the net2ftp installation
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $application_tempdir;

	echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
	echo "<tr>\n";
	echo "<td>\n";

	printTitle(__("Troubleshoot your net2ftp installation"));

// FORM BELOW IS NOT USED, BUT I LEFT THE CODE HERE JUST IN CASE WE'RE GOING
// TO USE IT IN THE FUTURE.
// -------------------------------------------------------------------------
// Form
// -------------------------------------------------------------------------
//	if ($formresult != "result") {
//		echo "<form name=\"TroubleshootWebserverForm\" id=\"TroubleshootWebserverForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
//		echo "<input type=\"hidden\" name=\"state\" value=\"troubleshoot\" />\n";
//		echo "<input type=\"hidden\" name=\"state2\" value=\"webserver\" />\n";
//		echo "<input type=\"hidden\" name=\"formresult\" value=\"result\" />\n";
//		printBackInForm($directory, "TroubleshootWebserverForm");
//		echo "</form>\n";
//	}
// -------------------------------------------------------------------------
// Result
// -------------------------------------------------------------------------
//	elseif ($formresult == "result") {
//		printBack($directory);
//	} // End if elseif (form or result)


	printBack($directory);

	echo "<ul>\n";

// Check if the FTP functions are availabe
	echo "<li>" . __("Checking if the FTP module of PHP is installed: ");
	if (function_exists("ftp_connect") == true) { echo "<span style=\"color: green; font-weight: bold;\">" . __("yes") . "</span>\n"; }
	else                                        { echo "<span style=\"color: red; font-weight: bold;\">" . __("no - please install it!") . "</span>\n"; }
	echo "</li><br /> &nbsp; \n";
	flush();

// Check if the /net2ftp/temp folder has been chmodded to 777
	echo "<li>" . __("Checking the permissions of the directory on the web server: a small file will be written to the /temp folder and then deleted.") . "</li>";
	echo "<ul>";
	echo "<li>" . __("Creating filename: ");
	$tempfilename = @tempnam($application_tempdir, "net2ftp-test") . ".txt";
	if ($tempfilename == true)  { echo "<span style=\"color: green; font-weight: bold;\">" . __("OK. Filename: %1\$s", $tempfilename) . "</span>\n"; }
	else                        { echo "<span style=\"color: red; font-weight: bold;\">" . __("not OK") . "</span>\n"; }
	echo "</li>\n";

	echo "<li>" . __("Opening the file in write mode: ");
	$handle = @fopen($tempfilename, "wb");
	if ($handle == true)  { echo "<span style=\"color: green; font-weight: bold;\">" . __("OK") . "</span>\n"; }
	else                  { echo "<span style=\"color: red; font-weight: bold;\">" . __("not OK. Check the permissions of the %1\$s directory", $application_tempdir) . "</span>\n"; }
	echo "</li>\n";

	$string = "This is a test file generated net2ftp, which should have been deleted automatically. The function responsible for this is troubleshoot_webserver(). You can safely delete this file.";
	echo "<li>" . __("Writing some text to the file: ");
	$success1 = @fwrite($handle, $string);	
	if ($success1 == true)  { echo "<span style=\"color: green; font-weight: bold;\">" . __("OK") . "</span>\n"; }
	else                    { echo "<span style=\"color: red; font-weight: bold;\">" . __("not OK") . "</span>\n"; }
	echo "</li>\n";

	echo "<li>" . __("Closing the file: ");
	$success2 = @fclose($handle);
	if ($success2 == true)  { echo "<span style=\"color: green; font-weight: bold;\">" . __("OK") . "</span>\n"; }
	else                    { echo "<span style=\"color: red; font-weight: bold;\">" . __("not OK") . "</span>\n"; }
	echo "</li>\n";

	echo "<li>" . __("Deleting the file: ");
	$success3 = @unlink($tempfilename);
	if ($success3 == true) { echo "<span style=\"color: green; font-weight: bold;\">" . __("OK") . "</span>\n"; } 
	else                   { echo "<span style=\"color: red; font-weight: bold;\">" . __("not OK") . "</span>\n"; }
	echo "</li>\n";

	echo "</ul><br /> &nbsp; \n";
	flush();

// Try to connect to an FTP server

// Try to upload a file

	echo "</ul>\n";
	echo "</tr>\n";
	echo "</td>\n";
	echo "</table>\n";

} // End function troubleshoot_webserver

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function troubleshoot_ftpserver($directory, $formresult) {

// --------------
// This function tests a connection to an FTP server
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $troubleshoot_ftpserver, $troubleshoot_ftpserverport, $troubleshoot_username, $troubleshoot_password;
	global $troubleshoot_language, $troubleshoot_skin, $troubleshoot_directory, $troubleshoot_passivemode;
	global $net2ftp_ftpserver, $net2ftp_username, $net2ftp_language, $net2ftp_skin;

	echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
	echo "<tr>\n";
	echo "<td>\n";

	printTitle(__("Troubleshoot an FTP server"));


// -------------------------------------------------------------------------
// Form
// -------------------------------------------------------------------------

	if ($formresult != "result") {
		echo "<form name=\"TroubleshootFtpserverForm\" id=\"TroubleshootFtpserverForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
		printLoginInfo();
		echo "<input type=\"hidden\" name=\"state\" value=\"advanced\" />\n";
		echo "<input type=\"hidden\" name=\"state2\" value=\"troubleshoot_ftpserver\" />\n";
		echo "<input type=\"hidden\" name=\"formresult\" value=\"result\" />\n";
		printBackInForm($directory, "TroubleshootFtpserverForm");
		printForwardInForm("TroubleshootFtpserverForm");

		echo "<table border=\"0\" cellspacing=\"2\" cellpadding=\"2\" style=\"margin-left: 20px;\">\n";
		echo "<tr><td>" . __("FTP server") . "</td><td><input type=\"text\" class=\"input\" name=\"troubleshoot_ftpserver\" value=\"$net2ftp_ftpserver\" /></td></tr>\n";
		echo "<tr><td>" . __("FTP server port") . "</td><td><input type=\"text\" class=\"input\" size=\"3\" maxlength=\"5\" name=\"troubleshoot_ftpserverport\" value=\"21\" /></td></tr>\n";
		echo "<tr><td>" . __("Username") . "</td><td><input type=\"text\" class=\"input\" name=\"troubleshoot_username\" value=\"$net2ftp_username\" /></td></tr>\n";
		echo "<tr><td>" . __("Password") . "</td><td><input type=\"password\" class=\"input\" name=\"troubleshoot_password\" /></td></tr>\n";
		echo "<tr><td>" . __("Passive mode") . "</td><td><input type=\"checkbox\" class=\"input\" name=\"troubleshoot_passivemode\" value=\"yes\"></td></tr>\n";
		echo "<tr><td>" . __("Directory") . "</td><td><input type=\"text\" class=\"input\" name=\"troubleshoot_directory\" value=\"$directory\"></td></tr>\n";

		echo "<input type=\"hidden\" name=\"troubleshoot_language\" value=\"$net2ftp_language\" />\n";
		echo "<input type=\"hidden\" name=\"troubleshoot_skin\" value=\"$net2ftp_skin\" />\n";

		echo "</form>\n";
	}

// -------------------------------------------------------------------------
// Result
// -------------------------------------------------------------------------

	elseif ($formresult == "result") {

		printBack($directory);

// Initial checks
		if ($troubleshoot_passivemode != "yes") { $troubleshoot_passivemode = "no"; }

// Print out connection settings
		echo "<br /><u>" . __("Connection settings:") . "</u><br />";
		echo __("FTP server") . ": $troubleshoot_ftpserver <br />\n";
		echo __("FTP server port") . ": $troubleshoot_ftpserverport <br />\n";
		echo __("Username") . ": $troubleshoot_username <br />\n";
		echo __("Password length") . ": " . strlen($troubleshoot_password) . "<br />\n";
		echo __("Passive mode") . ": $troubleshoot_passivemode <br />\n";
		echo __("Directory") . ": $troubleshoot_directory <br />\n";
		echo __("Language") . ": $troubleshoot_language <br />\n";
		echo __("Skin number") . ": $troubleshoot_skin <br />\n";

		echo "<br /><br />\n";


		echo "<u>" . __("Connecting to the FTP server: ") . "</u>\n";
		echo "<ul>\n";

// Connect
		echo "<li>" . __("Connecting to the FTP server: ");
		$conn_id = @ftp_connect("$troubleshoot_ftpserver", $troubleshoot_ftpserverport);
		if ($conn_id == true) { echo "<span style=\"color: green; font-weight: bold;\">" . __("OK") . "</span>\n"; }
		else                  { echo "<span style=\"color: red; font-weight: bold;\">" . __("not OK") . "</span>\n"; }
		echo "</li>\n";
		flush();

// Login with username and password
		echo "<li>" . __("Logging into the FTP server: ");
		$login_result = @ftp_login($conn_id, $troubleshoot_username, $troubleshoot_password);
		if ($login_result == true) { echo "<span style=\"color: green; font-weight: bold;\">" . __("OK") . "</span>\n"; }
		else                       { echo "<span style=\"color: red; font-weight: bold;\">" . __("not OK") . "</span>\n"; }
		echo "</li>\n";
		flush();

// Passive mode
		if ($troubleshoot_passivemode == "yes") {
			echo "<li>" . __("Setting the passive mode: ");
			$success = @ftp_pasv($conn_id, TRUE);
			if ($success == true) { echo "<span style=\"color: green; font-weight: bold;\">" . __("OK") . "</span>\n"; }
			else                  { echo "<span style=\"color: red; font-weight: bold;\">" . __("not OK") . "</span>\n"; }
			echo "</li>\n";
			flush();
		}

// Get the FTP system type
		echo "<li>" . __("Getting the FTP server system type: ");
		$systype = @ftp_systype($conn_id);
		if ($systype != false) { echo "<span style=\"color: green; font-weight: bold;\">$systype</span>\n"; }
		else                   { echo "<span style=\"color: red; font-weight: bold;\">" . __("not OK") . "</span>\n"; }
		echo "</li>\n";
		flush();

// Change the directory
		echo "<li>" . __("Changing to the directory %1\$s: ", $troubleshoot_directory);
		$result1 = @ftp_chdir($conn_id, $troubleshoot_directory);
		if ($result1 == true) { echo "<span style=\"color: green; font-weight: bold;\">" . __("OK") . "</span>\n"; }
		else                  { echo "<span style=\"color: red; font-weight: bold;\">" . __("not OK") . "</span>\n"; }
		echo "</li>\n";
		flush();

// Get the current directory from the FTP server
		$directory_ftp = @ftp_pwd($conn_id);
		echo "<li>" . __("The directory from the FTP server is: %1\$s ", $directory_ftp) . "\n";
		echo "</li>\n";
		flush();

// Try to get a raw list
		echo "<li>" . __("Getting the raw list of directories and files: ");
		$rawlist = @ftp_rawlist($conn_id, "-a");
		if (sizeof($rawlist) > 1) { 
			echo "<span style=\"color: green; font-weight: bold;\">" . __("OK") . "</span>\n"; 
			echo "</li>\n";
		}
		else { 
			echo "<span style=\"color: red; font-weight: bold;\">" . __("not OK") . "</span>\n";
			echo "</li>\n";
			echo "<li>" . __("Trying a second time to get the raw list of directories and files: ");
			$rawlist = @ftp_rawlist($conn_id, ""); 
			if (sizeof($rawlist) > 1) {
				echo "<span style=\"color: green; font-weight: bold;\">" . __("OK") . "</span>\n"; 
				echo "</li>\n";
			}
			else { 
				echo "<span style=\"color: red; font-weight: bold;\">" . __("not OK") . "</span>\n";
				echo "</li>\n";
			}
		}
		flush();

// Quiting; ftp_quit doesn't return a value
		echo "<li>" . __("Closing the connection: ");
		@ftp_quit($conn_id);
		echo "<span style=\"color: green; font-weight: bold;\">" . __("OK") . "</span>\n"; 
		echo "</li>\n";

		echo "</ul>\n";

// Print the raw list
		echo "<br /><u>" . __("Raw list of directories and files:") . "</u><br />\n";
		print_r($rawlist);
		flush();

// Print the parsed list
		echo "<br /><br /><u>" . __("Parsed list of directories and files:") . "</u><br />\n";
		for($i=0; $i<count($rawlist); $i++) {
			echo " &nbsp; <u>Line $i</u> \n";
			$templist[$i] = ftp_scanline($rawlist[$i]);
			print_r($templist[$i]);
			echo "<br />";
		} // End for
		flush();

	} // End if elseif (form or result)

	echo "</tr>\n";
	echo "</td>\n";
	echo "</table>\n";

} // End function troubleshoot_ftpserver

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************








// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function test_list_parsing($formresult) {

// --------------
// This function tests the net2ftp LIST parsing rules in browse.inc.php
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $application_includesdir;

	global $list_samples;
	require_once($application_includesdir . "/list_samples.inc.php");

	echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
	echo "<tr>\n";
	echo "<td>\n";

	printTitle("Test the net2ftp list parsing rules");

// FORM BELOW IS NOT USED, BUT I LEFT THE CODE HERE JUST IN CASE WE'RE GOING
// TO USE IT IN THE FUTURE.
// -------------------------------------------------------------------------
// Form
// -------------------------------------------------------------------------
//	if ($formresult != "result") {
//		echo "<form name=\"TestListParsingForm\" id=\"TestListParsingForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
//		echo "<input type=\"hidden\" name=\"state\" value=\"troubleshoot\" />\n";
//		echo "<input type=\"hidden\" name=\"state2\" value=\"webserver\" />\n";
//		echo "<input type=\"hidden\" name=\"formresult\" value=\"result\" />\n";
//		printBackInForm($directory, "TestListParsingForm");
//		echo "</form>\n";
//	}
// -------------------------------------------------------------------------
// Result
// -------------------------------------------------------------------------
//	elseif ($formresult == "result") {
//		printBack($directory);
//	} // End if elseif (form or result)


	printBack($directory);

	echo __("Test list parsing message"); 
	echo "<br /><br />\n";

	while(list($sampleName, $sampleLines) = each($list_samples)) {
		echo "<span style=\"font-size: 120%; font-weight: bold;\">" . $sampleName . "</span><br />\n";
// Input
		echo "<u>Sample input</u>:<br />\n";
		for ($i=1; $i<=sizeof($sampleLines); $i++) {
			 echo "Line $i: " . @htmlentities($sampleLines[$i], ENT_QUOTES, __("iso-8859-1")) . "<br />\n";
		}
		echo "<br />\n";
// Output
		echo "<u>Parsed output</u>:<br />\n";
		for ($i=1; $i<=sizeof($sampleLines); $i++) {
			$outputArray = ftp_scanline($sampleLines[$i]);
			while(list($fieldName, $fieldValue) = each($outputArray)) {
				echo "Line $i: " . $fieldName . ": " . @htmlentities($fieldValue, ENT_QUOTES, __("iso-8859-1")) . "<br />\n";
			} // end while
			echo "<br />\n";
		}
		echo "<br /><br />\n";
	}
	
	echo "</tr>\n";
	echo "</td>\n";
	echo "</table>\n";

} // End function test_list_parsing

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************







// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printTranslationFunctions($directory) {

// --------------
// This function prints the introduction to the translation functions
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $settings;

	echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
	echo "<tr>\n";
	echo "<td>\n";

	printTitle(__("net2ftp translation functions"));

	echo "<form name=\"TranslationForm\" id=\"TranslationForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
	printLoginInfo();
	echo "<input type=\"hidden\" name=\"state\" value=\"advanced\" />\n";
	echo "<input type=\"hidden\" name=\"state2\" value=\"main\" />\n";
	echo "<input type=\"hidden\" name=\"directory\" value=\"$directory\" />\n";
	printBackInForm($directory, "TranslationForm");
	echo "</form>\n";

	echo __("A PHP application can be translated using the standard <a href=\"http://www.php.net/gettext\">gettext</a> functions, or using a self-made translation function.") . "<br />\n";
	echo __("In both cases, the steps to take are similar.") . "<br /><br />\n";

	echo "<div class=\"header21\">" . __("Step 1: change code") . "</div>";
	echo __("All messages must be translated using a translation function, for example translate().") . "<br /><br />\n";
	echo __("This Hello World code:")   . "<br />\n";
	printCode("file.php", "echo \"Hello world!\";");
	echo __("must be changed to this:") . "<br />\n";
	printCode("file.php", "echo translate(\"Hello world!\");");
	echo "<br /><br />\n";

	echo "<div class=\"header21\">" . __("Step 2: extract messages") . "</div>";
	echo __("All messages which are used by the translate() function must be extracted from the code files, and copied to a <b>main message file</b>.") . "<br />\n";
	echo "<br /><br />\n";

	echo "<div class=\"header21\">" . __("Step 3: translate messages") . "</div>";
	echo __("The main message file is given to translators, who rename the file and replace the messages in English by the translation.") . "<br />\n";
	echo __("The translators return the <b>translated message files</b>.") . "<br />\n";
	echo "<br /><br />\n";

	echo "<div class=\"header21\">Step 4: check new or obsolete messages</div>";
	echo __("Each time the application is modified, a new main message file must be generated, as in step 2.") . "<br />\n";
	echo __("In order to avoid translating everything all over again, it must then be compared to all translated message files, to check if there are new or obsolete messages.") . "<br />\n";
	echo "<br /><br />\n";

	echo "<form name=\"AdvancedOptionsForm\" id=\"AdvancedOptionsForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
	printLoginInfo();
	echo "<input type=\"hidden\" name=\"state\" value=\"advanced\" />\n";
	echo "<input type=\"hidden\" name=\"state2\" value=\"main\" />\n";
	echo "<input type=\"hidden\" name=\"directory\" value=\"$directory\" />\n";
	echo "<div class=\"header21\">How can net2ftp help?</div>";
	echo "<input type=\"button\" class=\"smallbutton\" value=\"" . __("Go") . "\" onClick=\"document.AdvancedOptionsForm.state2.value='translate_extract'; document.AdvancedOptionsForm.submit();\" /> " . __("net2ftp can help in step 2 to extract messages to translate from code files") . " <br /><br />\n";
	echo "<input type=\"button\" class=\"smallbutton\" value=\"" . __("Go") . "\" onClick=\"document.AdvancedOptionsForm.state2.value='translate_check';   document.AdvancedOptionsForm.submit();\" /> " . __("net2ftp can help in step 4 to check if there are new or obsolete messages") . " <br /><br />\n";
	echo "</form>\n";
	echo "<br /><br />\n";

	echo "</tr>\n";
	echo "</td>\n";
	echo "</table>\n";


} // End function printTranslationFunctions

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************







// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function translate_extract($directory, $entry, $screen, $functionname) {

// --------------
// This function":
// - prints an introduction
// - reads code files and extracts the messages to be translated to a main message file
// - compares the main message file with the translated files to find new/obsolete messages
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;

// -------------------------------------------------------------------------
// Initial checks
// -------------------------------------------------------------------------
	if ($screen == "") { $screen = "screen1"; }

	echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
	echo "<tr>\n";
	echo "<td>\n";
	printTitle(__("Extract messages from code files"));

// -------------------------------------------------------------------------
// Screen 1
// -------------------------------------------------------------------------
	if ($screen == "screen1") {
		echo "<form name=\"TranslateExtractForm\" id=\"TranslateExtractForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
		printLoginInfo();
		echo "<input type=\"hidden\" name=\"state\" value=\"advanced\" />\n";
		echo "<input type=\"hidden\" name=\"state2\" value=\"translate_extract\" />\n";
		echo "<input type=\"hidden\" name=\"screen\" value=\"screen2\" />\n";
		printBackInForm($directory, "TranslateExtractForm");
		printForwardInForm("TranslateExtractForm");

// Directory containing code files
		echo __("Directory containing code files:") . " <input type=\"text\" class=\"longinput\" name=\"directory\" value=\"$directory\" />\n";
		printDirectoryTreeLink($directory, "TranslateExtractForm.directory");
		echo "<br /><br />\n";

// Translation function
		$defaultfunctionname = "__";
		echo __("Translation function used in the code:") . " <input type=\"text\" class=\"input\" name=\"functionname\" value=\"$defaultfunctionname\" /><br /><br />\n";

// Output file
		$defaultname = "lang.inc.php";
		echo __("File to generate:") . " <input type=\"text\" class=\"input\" name=\"entry\" value=\"$defaultname\" /><br /><br />\n";

	} // end if ($screen == "screen1")

// -------------------------------------------------------------------------
// Screen 2
// -------------------------------------------------------------------------
	elseif ($screen == "screen2") {

		printBack($directory);

// Open connection
		setStatus_php(2, 10, __("Connecting to the FTP server"));
		$conn_id = ftp_openconnection();
		if ($execution_success == false)  { return false; }

// Get the list of directories and files
		setStatus_php(4, 10, __("Getting the list of directories and files"));
		$nicelist_warnings_directory = ftp_getlist($conn_id, $directory);
		if ($execution_success == false) { return false; }
		$list = $nicelist_warnings_directory[1];

// Separate the directories from the files
		$counter_directories = 1;
		$counter_files = 1;
		for ($i=1; $i<=count($list); $i=$i+1) {
			if     ($list[$i]['dirorfile'] == "d") { $list_directories[$counter_directories] = $list[$i]; $counter_directories = $counter_directories + 1; }
			elseif ($list[$i]['dirorfile'] == "-") { $list_files[$counter_files] = $list[$i];             $counter_files = $counter_files + 1; }
		}

// Initialization
		$allMessages = "";
		setStatus_php(6, 10, __("Processing the entries"));
		echo __("Extracted messages:") . "<br /><br />\n";
		echo "<textarea name=\"messages\" class=\"edit\" rows=\"20\" cols=\"100\" wrap=\"off\">\n";

// For all files:
		for ($i=1; $i<=count($list_files); $i=$i+1) {
			$separator  = "\n\n// -------------------------------------------------------------------------\n";
			$separator .= "// Messages from file " . $list_files[$i]['dirfilename'] . "\n";
			$separator .= "// -------------------------------------------------------------------------\n";
			echo $separator;
			$allMessages .= $separator;

// Read file
			$text = ftp_readfile($conn_id, $directory, $list_files[$i]['dirfilename']);

			// If the file could not be read correctly, continue to the next one
			if ($execution_success == false)   { setErrorVars(true, "", ""); continue; }

// Extract messages
			// Define pattern
//			$pattern = "~^.*" . $functionname . "\\(\\\"" . "(.*)" . "\\\"" . "\s*\,*.*" . "\)\s*[\\.|\\,|\\;|\\)]{1}.*~Um";
			$pattern = '~' . $functionname . '\\("(([^\\\\]|\\\\.)*)"[,)]~U';
			preg_match_all($pattern, $text, $matches);

			$matches2 = array_unique(array_flip($matches[1]));

			foreach ($matches2 as $key => $value) {
				echo $key . "\n";
				$allMessages .= "\$messages[\"" . $key . "\"] = \"" . $key . "\";\n";
			} // end foreach

		} // end for files

		echo "</textarea><br /><br />\n";

// Write message to file
		if ($allMessages == "") { 
			echo __("No messages were found, so no file was put on the FTP server.") . "\n"; 
		}
		else {
			$allMessages = "This file contains the messages which were extracted from source code.\n\n" . $allMessages;
			ftp_writefile($conn_id, $directory, $entry, $allMessages);
			if ($execution_success == false)  { return false; }
			else                              { echo __("The main language file <b>%1\$s</b> was transferred to directory <b>%2\$s</b>.", $entry, $directory); }
		}

// Close connection
		ftp_closeconnection($conn_id);

	} // end elseif ($screen == "screen2")

	echo "</tr>\n";
	echo "</td>\n";
	echo "</table>\n";

} // End function translate_extract

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function translate_check($directory, $entry, $screen) {

// --------------
// This function reads code files, and extracts the messages to be translated
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;

// -------------------------------------------------------------------------
// Initial checks
// -------------------------------------------------------------------------
	if ($screen == "") { $screen = "screen1"; }

	echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
	echo "<tr>\n";
	echo "<td>\n";
	printTitle(__("Check if there are new or obsolete messages"));

// -------------------------------------------------------------------------
// Screen 1
// -------------------------------------------------------------------------
	if ($screen == "screen1") {
		echo "<form name=\"TranslateCheckForm\" id=\"TranslateCheckForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
		printLoginInfo();
		echo "<input type=\"hidden\" name=\"state\" value=\"advanced\" />\n";
		echo "<input type=\"hidden\" name=\"state2\" value=\"translate_check\" />\n";
		echo "<input type=\"hidden\" name=\"screen\" value=\"screen2\" />\n";
		printBackInForm($directory, "TranslateCheckForm");
		printForwardInForm("TranslateCheckForm");

// Introduction

// Main language file
		$defaultname = glueDirectories($directory, "lang.inc.php");
		echo __("Main language file:") . " <input type=\"text\" class=\"longinput\" name=\"entry\" value=\"$defaultname\" /><br /><br />\n";

// Directory containing translated language files
		echo __("Directory containing translated language files:") . " <input type=\"text\" class=\"longinput\" name=\"directory\" value=\"$directory\" />\n";
		printDirectoryTreeLink($directory, "TranslateCheckForm.directory");
		echo "<br /><br />\n";

	} // end if ($screen == "screen1")

// -------------------------------------------------------------------------
// Screen 2
// -------------------------------------------------------------------------
	elseif ($screen == "screen2") {

		printBack($directory);

// Open connection
		setStatus_php(2, 10, __("Connecting to the FTP server"));
		$conn_id = ftp_openconnection();
		if ($execution_success == false)  { return false; }

// Get the list of directories and files
		setStatus_php(4, 10, __("Getting the list of directories and files"));
		$nicelist_warnings_directory = ftp_getlist($conn_id, $directory);
		if ($execution_success == false) { return false; }
		$list = $nicelist_warnings_directory[1];

// Separate the directories from the files
		$counter_directories = 1;
		$counter_files = 1;
		for ($i=1; $i<=count($list); $i=$i+1) {
			if     ($list[$i]['dirorfile'] == "d") { $list_directories[$counter_directories] = $list[$i]; $counter_directories = $counter_directories + 1; }
			elseif ($list[$i]['dirorfile'] == "-") { $list_files[$counter_files] = $list[$i];             $counter_files = $counter_files + 1; }
		}

// Read main file
		$main_text = ftp_readfile($conn_id, "", $entry);

		// If the file could not be read correctly, continue to the next one
		if ($execution_success == false || $main_text == "") { 
			$errormessage = "The main language file could not be read. Are you sure the path and filename you entered are correct?";
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}

// Extract messages from main file
//		$pattern = "~^\\\$messages\\[\\\"" . "(.*)" . "\"\]\s*\=\s*\".*\";~m";
//		$pattern = "~^\\\$messages\\[\\\"" . "(.*[^\\|\\\\])" . "\"\]~m";
		$pattern = '~\$messages\["(([^\\\\]|\\\\.)*)"\]~U';

		preg_match_all($pattern, $main_text, $matches);
		$main_messages = array_unique(array_flip($matches[1]));

// For all translated files:
		setStatus_php(6, 10, __("Processing the entries"));
		for ($i=1; $i<=count($list_files); $i=$i+1) {

// Read file
			$translated_text = ftp_readfile($conn_id, $directory, $list_files[$i]['dirfilename']);

			// If the file could not be read correctly, continue to the next one
			if ($execution_success == false)   { 
				setErrorVars(true, "", "");
				echo __("File %1\$s was skipped because it could not be read, or because it was empty.", $i) . "<br />\n";
				continue; 
			}

// Extract messages from translated file
			// $pattern is defined higher up
			preg_match_all($pattern, $translated_text, $matches2);
			$translated_messages = array_unique(array_flip($matches2[1]));

			$new_messages = $main_messages;
			$obsolete_messages = $translated_messages;

			foreach ($main_messages as $key => $value) {
				if (array_key_exists($key, $translated_messages)) { 
					unset($new_messages[$key]); 
					unset($obsolete_messages[$key]); 
				}
			} // end foreach

// Print new and obsolete messages
			echo __("File nr %1\$s <b>%2\$s</b>", $i, $list_files[$i]['dirfilename']) . "<br /><br />\n";

			echo __("New messages:") . "<br />\n";
			echo "<textarea name=\"newMessages$i\" class=\"edit\" rows=\"20\" cols=\"100\" wrap=\"off\">\n";
			foreach ($new_messages as $key => $value) {
				echo "\$messages[\"$key\"] = \"$key\";\n";
			} // end foreach
			echo "</textarea><br /><br />\n";

			echo __("Obsolete messages:") . "<br /><br />\n";
			echo "<textarea name=\"obsoleteMessages$i\" class=\"edit\" rows=\"20\" cols=\"100\" wrap=\"off\">\n";
			foreach ($obsolete_messages as $key => $value) {
				echo "\$messages[\"$key\"] = \"$key\";\n";
			} // end foreach
			echo "</textarea><br /><br /><br /><br />\n";

			flush();

		} // end for files

// Close connection
		ftp_closeconnection($conn_id);

// Display list of new and obsolete messages
		echo "<br /><span style=\"font-weight: bold;\">" . __("All the files have been processed") . "</span><br /><br />";

	} // end elseif ($screen == "screen2")

	echo "</tr>\n";
	echo "</td>\n";
	echo "</table>\n";

} // End function translate_check

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************









// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function sendsitecommand($directory, $command, $formresult) {

// --------------
// This function allows to send a site command to the FTP server
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;

	echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
	echo "<tr>\n";
	echo "<td>\n";

	printTitle(__("Send site command"));

// -------------------------------------------------------------------------
// Form
// -------------------------------------------------------------------------

	if ($formresult != "result") {

		echo "<form name=\"SiteCommandForm\" id=\"SiteCommandForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
		printLoginInfo();
		echo "<input type=\"hidden\" name=\"state\" value=\"manage\" />\n";
		echo "<input type=\"hidden\" name=\"state2\" value=\"site\" />\n";
		echo "<input type=\"hidden\" name=\"directory\" value=\"$directory\" />\n";
		echo "<input type=\"hidden\" name=\"formresult\" value=\"result\" />\n";

		printBackInForm($directory, "SiteCommandForm");
		printForwardInForm("SiteCommandForm");

		echo "<input type=\"text\" class=\"input\" name=\"command\" value=\"\" /> " . __("Enter the site command") . " <br /><br />\n";

		echo "<div style=\"font-size: 80%;\">" . __("The commands you can use depends on your FTP server. These commands are not standard and vary a lot from one server to the other.") . "</div><br />\n";
		echo "<div style=\"font-size: 80%;\">" . __("Note that net2ftp cannot display the output of the FTP server, it can only tell if the command returned TRUE or FALSE. This is not a limitation of net2ftp but of PHP, the language in which net2ftp is written.") . "</div><br />\n";

		echo "</form>\n";

	} // end if


// -------------------------------------------------------------------------
// Result
// -------------------------------------------------------------------------

	else {

		printBack($directory);

// Open connection
		$conn_id = ftp_openconnection();
		if ($execution_success == false) { return false; }

// Send site command
		ftp_mysite($conn_id, $command);
		if ($execution_success == false) { return false; }
		else { echo __("The command <b>$command</b> was executed successfully.") . "<br />"; }

// Close connection
		ftp_closeconnection($conn_id);

	} // end else

	echo "</tr>\n";
	echo "</td>\n";
	echo "</table>\n";

} // End function sendsitecommand

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function apache($directory, $formresult) {

// --------------
// This function allows to perform Apache specific actions
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;

	if (strlen($directory) > 0) { $printdirectory = $directory; }
	else                        { $printdirectory = "/"; }

	echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
	echo "<tr>\n";
	echo "<td>\n";

// -------------------------------------------------------------------------
// Form
// -------------------------------------------------------------------------

	if ($formresult != "result") {

// Password protection
		printTitle("Password protect a directory");

		echo "<form name=\"ApachePasswordForm\" id=\"ApachePasswordForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
		printLoginInfo();
		echo "<input type=\"hidden\" name=\"state\" value=\"advanced\" />\n";
		echo "<input type=\"hidden\" name=\"state2\" value=\"apache\" />\n";
		echo "<input type=\"hidden\" name=\"directory\" value=\"$directory\" />\n";
		echo "<input type=\"hidden\" name=\"formresult\" value=\"result\" />\n";

		printBackInForm($directory, "ApachePasswordForm");
		printForwardInForm("ApachePasswordForm");

		echo "Protect directory: <input type=\"text\" class=\"longinput\" name=\"directory1\" value=\"$printdirectory\" />\n";
		printDirectoryTreeLink($directory, "ApachePasswordForm.directory1");

		echo "<br /><br />\n";

		for ($i=1; $i<=5; $i=$i+1) {
			echo "Username $i: <input type=\"text\" class=\"input\" name=\"apache_username$i\" value=\"\" />  Password $i: <input type=\"password\" class=\"input\" name=\"apache_password$i\" value=\"\" /><br />\n";
		} // end for

		echo "</form>\n";

		echo "<br /><br />\n\n";

// Custom error page
		printTitle("Create custom error messages");

		echo "<form name=\"ApacheProtectForm\" id=\"ApacheProtectForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
		printLoginInfo();
		echo "<input type=\"hidden\" name=\"state\" value=\"advanced\" />\n";
		echo "<input type=\"hidden\" name=\"state2\" value=\"apache\" />\n";
		echo "<input type=\"hidden\" name=\"directory\" value=\"$directory\" />\n";
		echo "<input type=\"hidden\" name=\"formresult\" value=\"result\" />\n";

		printBackInForm($directory, "ApacheProtectForm");
		printForwardInForm("ApacheProtectForm");

		echo "Error <input type=\"text\" class=\"input\" name=\"apache_error_1\" value=\"400\" /> is redirected to page <input type=\"text\" class=\"input\" name=\"apache_page_1\" value=\"400.html\" /><br />\n";
		echo "Error <input type=\"text\" class=\"input\" name=\"apache_error_2\" value=\"401\" /> is redirected to page <input type=\"text\" class=\"input\" name=\"apache_page_2\" value=\"401.html\" /><br />\n";
		echo "Error <input type=\"text\" class=\"input\" name=\"apache_error_3\" value=\"404\" /> is redirected to page <input type=\"text\" class=\"input\" name=\"apache_page_3\" value=\"404.html\" /><br />\n";
		echo "Error <input type=\"text\" class=\"input\" name=\"apache_error_4\" value=\"500\" /> is redirected to page <input type=\"text\" class=\"input\" name=\"apache_page_4\" value=\"500.html\" /><br />\n";
		echo "Error <input type=\"text\" class=\"input\" name=\"apache_error_5\" value=\"501\" /> is redirected to page <input type=\"text\" class=\"input\" name=\"apache_page_5\" value=\"501.html\" /><br />\n";
		echo "Error <input type=\"text\" class=\"input\" name=\"apache_error_6\" value=\"502\" /> is redirected to page <input type=\"text\" class=\"input\" name=\"apache_page_6\" value=\"502.html\" /><br />\n";
		echo "Error <input type=\"text\" class=\"input\" name=\"apache_error_7\" value=\"503\" /> is redirected to page <input type=\"text\" class=\"input\" name=\"apache_page_7\" value=\"503.html\" /><br />\n";
		echo "Error <input type=\"text\" class=\"input\" name=\"apache_error_8\" value=\"505\" /> is redirected to page <input type=\"text\" class=\"input\" name=\"apache_page_8\" value=\"505.html\" /><br />\n";

		echo "</form>\n";

	} // end if


// -------------------------------------------------------------------------
// Result
// -------------------------------------------------------------------------

	else {

		printBack($directory);

// Do something
		echo "Join the development team! ;-)\n";

	} // end else

	echo "</tr>\n";
	echo "</td>\n";
	echo "</table>\n";

} // End function apache

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function mysqlfunctions($directory, $formresult) {

// --------------
// This function allows to perform MySQL specific actions
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;

	if (strlen($directory) > 0) { $printdirectory = $directory; }
	else                        { $printdirectory = "/"; }

	echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
	echo "<tr>\n";
	echo "<td>\n";

	printTitle("MySQL");

// -------------------------------------------------------------------------
// Form
// -------------------------------------------------------------------------

	if ($formresult != "result") {

// Password protection
		echo "<form name=\"MySQLForm\" id=\"MySQLForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
		printLoginInfo();
		echo "<input type=\"hidden\" name=\"state\" value=\"advanced\" />\n";
		echo "<input type=\"hidden\" name=\"state2\" value=\"mysql\" />\n";
		echo "<input type=\"hidden\" name=\"directory\" value=\"$directory\" />\n";
		echo "<input type=\"hidden\" name=\"formresult\" value=\"result\" />\n";

		printBackInForm($directory, "MySQLForm");
		printForwardInForm("MySQLForm");

		echo "UNDER CONSTRUCTION...\n";

		echo "</form>\n";

	} // end if


// -------------------------------------------------------------------------
// Result
// -------------------------------------------------------------------------

	else {

		printBack($directory);

		echo "Join the development team! ;-)\n";

	} // end else

	echo "</tr>\n";
	echo "</td>\n";
	echo "</table>\n";

} // End function mysqlfunctions

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




?>