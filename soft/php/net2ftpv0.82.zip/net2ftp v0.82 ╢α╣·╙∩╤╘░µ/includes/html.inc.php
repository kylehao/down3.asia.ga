<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------



// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function HtmlBegin($state, $state2, $screen, $directory, $entry) {

// -------------------------------------------------------------------------
// Global variables and settings
// -------------------------------------------------------------------------
	global $client_css;
	global $textareaType;
	global $net2ftp_ftpserver, $net2ftp_skin, $net2ftpcookie_skin;
	$skinArray = getSkinArray();

// -------------------------------------------------------------------------
// Replace ' by \' in $directory and $dirfilename to avoid javascript errors if
// these variables contain single quotes (they may not contain double quotes).
// -------------------------------------------------------------------------
	$directory_js   = javascriptEncode($directory);


// -------------------------------------------------------------------------
// HTML begin
// -------------------------------------------------------------------------

// Strict XHTML 1.0
//	echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">\n";

// Transitional HTML 4.01
	echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n";


	echo "<html>\n";
// -------------------------------------------------------------------------
// Head
// -------------------------------------------------------------------------
	echo "<head>\n";
	echo "<meta http-equiv=\"Content-type\" content=\"text/html; charset=" . __("iso-8859-1") . "\">\n";
	echo "<meta name=\"keywords\" content=\"net2ftp, web, ftp, based, web-based, xftp, client, PHP, SSL, password, server, free, gnu, gpl, gnu/gpl, net, net to ftp, netftp, connect, user, gui, interface, web2ftp, edit, editor, online, code, php, upload, download, copy, move, delete, zip, tar, unzip, untar, recursive, rename, chmod, syntax, highlighting, host, hosting, ISP, webserver, plan, bandwidth\">\n";
	echo "<meta name=\"description\" content=\"net2ftp is a web based FTP client. It is mainly aimed at managing websites using a browser. Edit code, upload/download files, copy/move/delete directories recursively, rename files and directories -- without installing any software.\">\n";
	if     ($net2ftp_ftpserver != "" && $directory != "" && $entry != "") { echo "<title>net2ftp - $net2ftp_ftpserver - $directory - $entry</title>\n"; }
	elseif ($net2ftp_ftpserver != "" && $directory != "")                 { echo "<title>net2ftp - $net2ftp_ftpserver - $directory</title>\n"; }
	elseif ($net2ftp_ftpserver != "")                                     { echo "<title>net2ftp - $net2ftp_ftpserver</title>\n"; }
	else                                                                  { echo "<title>net2ftp - a web based FTP client</title>\n"; }

// Include stylesheet
	$css = $skinArray[$net2ftp_skin]['css'];
	if (!trim($css)) { $css = $skinArray[1]['css']; }

	echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"$css\">\n";

// Include the CSS files of the plugins
	integratePlugin("includeCssFiles");

// Include the net2ftp Javascript functions
	printJavascriptFunctions($state, $state2, $screen);

// Run the Javascript code of the plugins BEFORE the includes
	integratePlugin("runJavascriptCodeAtHeaderPre");

// Include the Javascript source files of the plugins
	integratePlugin("includeJavascriptFiles");

// Run the Javascript code of the plugins AFTER the includes
	integratePlugin("runJavascriptCodeAtHeaderPost");

// Link to favicon
//	echo "<link rel=\"shortcut icon\" href=\"favicon.ico\">\n";

	echo "</head>\n\n\n";

// -------------------------------------------------------------------------
// Body
// -------------------------------------------------------------------------

// Calculate which Javascript functions should be run for the plugins at the body onload event
	$onload = integratePlugin("runJavascriptCodeAtBodyOnload");

// Body
	if ($onload == "") { echo "<body>\n"; }
	else { echo "<body onload=\"$onload\">\n"; }

// Print function tags
	printFunctionTags("HtmlBegin", "begin");

// -------------------------------------------------------------------------
// Top status bar
// -------------------------------------------------------------------------
	if (($state=="manage" && $state2=="edit") || ($state=="manage" && $state2=="updatefile" && $screen=="screen3") || ($state=="manage" && $state2=="newfile") || ($state=="browse" && $state2=="popup") || $state=="error" || ($state == "easyWebsite" && $standalone == "yes")) {
		// Do not print anything
	}
	elseif ($state == "browse" || $state == "manage" || $state == "bookmark" || $state == "advanced" || ($state == "easyWebsite" && $standalone != "yes")) {
		echo "<table align=\"center\" class=\"header_table\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n";
		echo "<tr style=\"height: 32px; vertical-align: middle;\">\n";

// FTP server
		echo "<td style=\"font-size: 120%; font-weight: bold;\">$net2ftp_ftpserver</td>\n";

// Space
		echo "<td style=\"width:30px;\">&nbsp;\n";
		echo "</td>\n";

// HTML progress bar
		echo "<td>\n";
		if (isActivePlugin("html_progress") == true) { printProgressBar(); }
		echo "</td>\n";

// Status message
//		echo "<td style=\"width: 250px; text-align: left; padding-left: 2px; \">";
//		echo "<input type=\"text\" style=\"width: 250px; background-color: #FFFFFF; color: #000000;\" id=\"status\" value=\"Starting the script...\" readonly />\n";
//		echo "</td>\n";

		echo "<td style=\"text-align: right; width:180px;\">\n";
// Bookmark
		if ($state != "bookmark") { printBookmarkLink(); }

// Refresh
		echo getAction("refresh", "window.location.reload();");
//		echo getAction("refresh", "history.go(0);");

// Help
		echo getAction("help", "void(window.open('help.html', 'Help', 'location, menubar, resizable, scrollbars, status, toolbar'));");
// Logout
		echo getAction("logout", "document.LogoutForm.submit();");
		echo "<form name=\"LogoutForm\" id=\"LogoutForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
		echo "<input type=\"hidden\" name=\"state\" value=\"logout\" />\n";
		echo "</form>\n";
		echo "</td>\n";
		echo "</tr>\n";
		echo "</table>\n";
	}
	else {
		echo "<div class=\"header11\">net2ftp</div>\n";
	}

	printFunctionTags("HtmlBegin", "end");

	flush();

} // end function HtmlBegin

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function HtmlEnd($state, $state2, $screen) {

// -------------------------------------------------------------------------
// Global variables and settings
// -------------------------------------------------------------------------
	global $settings;
	$help_text  = $settings["help_text"];
	$help_link  = $settings["help_link"];

	printFunctionTags("HtmlEnd", "begin");

// -------------------------------------------------------------------------
// Edit: do not print anything
// -------------------------------------------------------------------------
	if (($state=="manage" && $state2=="edit") || ($state=="manage" && $state2=="newfile") || ($state=="manage" && $state2=="updatefile" && $screen=="screen3") || ($state=="browse" && $state2=="popup")) {
		// Do not print anything
	}

// -------------------------------------------------------------------------
// Other pages: print link to forum, help guide, license, ...
// -------------------------------------------------------------------------
	else  {

// Google Adsense code
	if ($settings["show_google_ads"] == "yes") {
		echo "<br />\n";
		echo "<div style=\"text-align: center;\">\n";
		echo "<script type=\"text/javascript\"><!--\n";
		echo "google_ad_client = \"pub-8420366685399799\";\n";
		echo "google_ad_width = 728;\n";
		echo "google_ad_height = 90;\n";
		echo "google_ad_format = \"728x90_as\";\n";
		echo "google_ad_channel =\"\";\n";
		echo "google_color_border = \"336699\";\n";
		echo "google_color_bg = \"FFFFFF\";\n";
		echo "google_color_link = \"0000FF\";\n";
		echo "google_color_url = \"008000\";\n";
		echo "google_color_text = \"000000\";\n";
		echo "//--></script>\n";
		echo "<script type=\"text/javascript\" src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\"></script>\n";
		echo "</div>\n";
	}

// Advertisement
// You are entitled to remove the "advertisement" below, because this
// software is released under the GPL license. However, the copyright
// notice at the beginning of this file may not be removed; note though
// that this is not printed.

		echo "<table align=\"center\" style=\"margin-top: 20px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n";
		echo "<tr>\n";
		echo "<td style=\"text-align: center;\">\n";

// Link to forum, help guide, license
		if ($help_text != "" && $help_link != "") { echo "<a href=\"$help_link\">$help_text</a> | \n"; }
		echo "<a href=\"help.html\">" . __("net2ftp Help Guide") . "</a> | \n";
		echo "<a href=\"http://www.net2ftp.org/forums\">" . __("net2ftp Forums") . "</a> | \n";
		echo "<a href=\"_LICENSE.txt\">" . __("License") . "</a>\n";
		echo "<br /><br />\n";

// Powered by...
		echo __("Powered by") . " <a href=\"http://www.net2ftp.com\">net2ftp</a> - a web based FTP client<br /><br />\n";

// Version check 
// Will appear only on the logout page and on the admin panel
// This function gets a Javascript file on net2ftp.com which contains the latest version nr.
// It compares it with the current version and displays a message if there is a new stable or beta version.
		if (isActivePlugin("versioncheck") == true) {
			echo "<script type=\"text/javascript\">\n";
			echo "<!--\n";
			echo "var current_build = " . $settings["application_build_nr"] . ";\n";
			// The following variables:  latest_stable_build, latest_stable_version, latest_stable_url, 
			//                           latest_beta_build, latest_beta_version, latest_beta_url
			// come from the remote file that is included
			echo "if (typeof(latest_stable_build)!=\"undefined\" && typeof(latest_beta_build)!=\"undefined\") {\n";
			echo "	if (latest_stable_build > current_build) {\n";
			echo "		document.write('There is a <a href=\"' + latest_stable_url + '\"> new stable version<\/a> of net2ftp available for download (' + latest_stable_version + ')');\n";
			echo "	}\n";
			echo "	else if (latest_beta_build > current_build) {\n";
			echo "		document.write('There is a <a href=\"' + latest_beta_url + '\">new beta version<\/a> of net2ftp available for download (' + latest_beta_version + ')');\n";
			echo "	}\n";
			echo "	else {\n";
			echo "		document.write('This version of net2ftp is up-to-date');\n";
			echo "	}\n";
			echo "}\n";
			echo "//-->\n";
			echo "</script><br /><br />\n";
		}

// Get Firefox button
		echo "<a href=\"http://www.spreadfirefox.com/?q=affiliates&amp;id=54600&amp;t=82\"><img border=\"0\" alt=\"Get Firefox!\" title=\"Get Firefox!\" src=\"http://sfx-images.mozilla.org/affiliates/Buttons/80x15/white_1.gif\" /></a><br />\n";

		echo "</td>\n";
		echo "</tr>\n";
		echo "</table><br />\n";

	}

// -------------------------------------------------------------------------
// Update the status
// -------------------------------------------------------------------------
	if (($state=="manage" && $state2=="edit") || ($state=="manage" && $state2=="updatefile" && $screen=="screen3") || ($state=="manage" && $state2=="newfile") || ($state=="browse" && $state2=="popup") || $state=="error") {
		// Do not print anything
	}
	elseif ($state == "browse" || $state == "manage" || $state == "bookmark" || $state == "advanced") {
		$time_taken = timer();
		$statusmessage = __("Script finished in %1\$s seconds", $time_taken);
		setStatus_php(1, 1, $statusmessage);
	}

	echo "<!-- net2ftp version " . $settings["application_version"] . " -->\n";

	printFunctionTags("HtmlEnd", "end");

	echo "</body>\n";
	echo "</html>\n";
}

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************



// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printJavascriptFunctions($state, $state2, $screen) {

// --------------
// This functions prints the Javascript functions in the header of each HTML page
// --------------

// -------------------------------------------------------------------------
// Global variables and settings
// -------------------------------------------------------------------------
	$max_execution_time = ini_get("max_execution_time");
	$browse_rows_fontcolor_odd  = getSkinColors("rows_fontcolor_odd");
	$browse_rows_bgcolor_odd    = getSkinColors("rows_bgcolor_odd");
	$browse_rows_fontcolor_even = getSkinColors("rows_fontcolor_even");
	$browse_rows_bgcolor_even   = getSkinColors("rows_bgcolor_even");
	$browse_selected_fontcolor  = getSkinColors("selected_fontcolor");
	$browse_selected_bgcolor    = getSkinColors("selected_bgcolor");


// -------------------------------------------------------------------------
// Javascript functions
// -------------------------------------------------------------------------
	printFunctionTags("printJavascriptFunctions", "begin");
	echo "<script type=\"text/javascript\"><!--\n";

	if (($state == "browse" && $state2 == "main") || ($state == "manage" && $state2 == "findstring")) {
		echo "function CheckAll(myform) {\n";
		echo "	var nr_checkboxes = 0;\n";
		echo "	for (var i = 0; i < myform.elements.length; i++) {\n";
		echo "		if (myform.elements[i].type == 'checkbox') {\n";
		echo "			myform.elements[i].checked = !(myform.elements[i].checked);\n";
		echo "			nr_checkboxes = nr_checkboxes + 1;\n";
		echo "		}\n";
		echo "	}\n";
		echo "	for (var j = 1; j <= nr_checkboxes; j++) {\n";
		echo "		setColor_js(j)\n";
		echo "	}\n";
		echo "}\n";

		echo "function setColor_js(i) {\n";
		// Parameters
		echo "	row_id = 'row' + i;\n";
		echo "	checkbox_id = 'list[' + i + '][dirfilename]';\n";
		echo "	if (i%2 == 1) { bgcolor_true = '$browse_selected_bgcolor'; fontcolor_true = '$browse_selected_fontcolor'; bgcolor_false = '$browse_rows_bgcolor_odd'; fontcolor_false = '$browse_rows_fontcolor_odd'; }\n";   // odd
		echo "	else          { bgcolor_true = '$browse_selected_bgcolor'; fontcolor_true = '$browse_selected_fontcolor'; bgcolor_false = '$browse_rows_bgcolor_even'; fontcolor_false = '$browse_rows_fontcolor_even'; }\n"; // even
		// Code
		echo "	if (document.getElementById) {\n";
		echo "		if (document.getElementById(checkbox_id).checked == true) { document.getElementById(row_id).style.background = bgcolor_true;  document.getElementById(row_id).style.color = fontcolor_true; }\n";
		echo "		else                                                      { document.getElementById(row_id).style.background = bgcolor_false; document.getElementById(row_id).style.color = fontcolor_false; }\n";
		echo "	}\n";
		echo "	else if (document.all) {\n";
		echo "		if (document.all[checkbox_id].checked == true) { document.all[row_id].style.background = bgcolor_true;  document.all[row_id].style.color = fontcolor_true; }\n";
		echo "		else                                           { document.all[row_id].style.background = bgcolor_false; document.all[row_id].style.color = fontcolor_false; }\n";
		echo "	}\n";
		echo "}\n";
	}

	if (($state == "browse" && $state2 == "main") || $state == "manage" || $state == "bookmark" || $state == "advanced") {
		echo "function setStatus_js(text) {\n";
		echo "	id = 'status';\n";
		echo "	if (document.getElementById) {\n";
		echo "		document.getElementById(id).value = text;\n";
		echo "	}\n";
		echo "	else if (document.all) {\n";
		echo "		document.all[id].value = text;\n";
		echo "	}\n";
		echo "}\n";
	}

	if (($state == "browse" && $state2 == "main") || ($state == "manage" && ($state2 == "copy" || $state2 == "move" || $state2 == "uploadfile")) || ($state == "advanced") || ($state == "easyWebsite")) {
		echo "\nfunction createDirectoryTreeWindow(directory, FormAndFieldName) {\n";
		echo "	directoryTreeWindow = window.open(\"\",\"directoryTreeWindow\",\"height=450,width=300,resizable=yes,scrollbars=yes\");\n";
		echo "	var d = directoryTreeWindow.document;\n";
		echo "	d.writeln('<html>');\n";
		echo "	d.writeln('<head>');\n";
		echo "	d.writeln('<title>" . __("Choose a directory") . "<\/title>');\n";
		echo "	d.writeln('<\/head>');\n";
		echo "	d.writeln('<bo' + 'dy on' + 'load=\"document.DirectoryTreeForm.submit();\">');\n";
//		echo "	d.writeln('<body>');\n";
		echo "	d.writeln('" . __("Please wait...") . "<br /><br />');\n";
		echo "	d.writeln('<form name=\"DirectoryTreeForm\" id=\"DirectoryTreeForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\" />');\n";
		printLoginInfo_javascript();
		echo "	d.writeln('<input type=\"hidden\" name=\"state\" value=\"browse\" />');\n";
		echo "	d.writeln('<input type=\"hidden\" name=\"state2\" value=\"popup\" />');\n";
		echo "	d.writeln('<input type=\"hidden\" name=\"directory\" value=\"' + directory + '\"  />');\n";
		echo "	d.writeln('<input type=\"hidden\" name=\"FormAndFieldName\" value=\"' + FormAndFieldName + '\"  />');\n";
//		echo "	d.writeln('<input type=\"submit\" class=\"smallbutton\" value=\"Submit\" />');\n";
//		echo "	d.writeln('<input type=\"button\" class=\"smallbutton\" value=\"Close\" onClick=\"self.close()\" />');\n";
		echo "	d.writeln('<\/form>');\n";
		echo "	d.writeln('<\/div>');\n";
		echo "	d.writeln('<\/body>');\n";
		echo "	d.writeln('<\/html>');\n";
		echo "	d.close();\n";
		echo "} // end function createDirectoryTreeWindow\n";
	}

	if ($state == "manage" && $state2 == "uploadfile") {

		echo "\nfunction add_file(id, i) {\n";
		echo "	if (document.getElementById(id + '_' + i).innerHTML.search('uploadinputbutton') == -1) {\n";
		echo "		document.getElementById(id + '_' + i).innerHTML = '<input type=\"file\" class=\"uploadinputbutton\" maxsize=\"$max_upload_size\" name=\"' + id + '[]\" onChange=\"return add_file(\\'' + id + '\\', ' + (i+1) + ');\" /><br /><span id=\"' + id + '_' + (i+1) + '\"><input type=\"button\" value=\"Add other\" onClick=\"add_file(\\'' + id + '\\', ' + (i+1) + ');\" /><\/span>\\n';\n";
		echo "	}\n";
		echo "}\n";

		echo "\nfunction createUploadWindow() {\n";
		echo "	uploadWindow = window.open(\"\",\"uploadWindow\",\"height=170,width=400,resizable=yes,scrollbars=yes\");\n";
		echo "	var d = uploadWindow.document;\n";
		echo "	d.writeln('<html>');\n";
		echo "	d.writeln('<head>');\n";
		echo "	d.writeln('<title>" . __("Uploading... please wait...") . "<\/title>');\n";
		echo "	d.writeln('<\/head>');\n";
		echo "	d.writeln('<body>');\n";
		echo "	d.writeln('" . __("Uploading... please wait...") . "<br /><br />');\n";
		echo "	d.writeln('" . __("If the upload takes more than the allowed <b>%1\$s seconds<\/b>, you will have to try again with less/smaller files.", $max_execution_time) . "<br /><br />');\n";

		echo "	d.writeln('<scr' + 'ipt lan' + 'guage=\"jav' + 'ascript\">');\n";
		echo "	d.writeln('setTimeout(\"self.close()\",8000);');\n";
		echo "	d.writeln('<\/scr' + 'ipt>');\n";

		echo "	d.writeln('<form><span style=\"font-size: 100%;\">');\n";
		echo "	d.writeln('" . __("This window will close automatically in a few seconds.") . "<br />');\n";
		echo "	d.writeln('<a href=\"jav' + 'ascript:self.close();\">" . __("Close window now") . "<\/a>');\n";
		echo "	d.writeln('<\/span><\/form>');\n";

		echo "	d.writeln('<\/body>');\n";
		echo "	d.writeln('<\/html>');\n";
		echo "	d.close();\n";

		echo "} // end function createUploadWindow\n";
	}

	if ($state == "browse" && $state2 == "popup") {
		echo "\nfunction submitDirectoryTreeForm() {\n";
		echo "	if (document.DirectoryTreeForm.DirectoryTreeSelect.options[document.DirectoryTreeForm.DirectoryTreeSelect.selectedIndex].value != 'up') { document.DirectoryTreeForm.directory.value=document.DirectoryTreeForm.directory.value + '/' + document.DirectoryTreeForm.DirectoryTreeSelect.options[document.DirectoryTreeForm.DirectoryTreeSelect.selectedIndex].value; }\n";
		echo "	else { document.DirectoryTreeForm.directory.value = document.DirectoryTreeForm.updirectory.value; }\n";
		echo "	document.DirectoryTreeForm.submit();\n";
		echo "} // end function submitDirectoryTreeForm\n";

	}

	if ($state == "manage" && ($state2 == "edit" || $state2 == "newfile") && ($textareaType == "" || $textareaType == "plain")) {
		echo "\nfunction TabText() {\n";
		echo "	if (event != null) {\n";
		echo "		if (event.srcElement) {\n";
		echo "			if (event.srcElement.value) {\n";
		echo "				if (event.keyCode == 9) {\n";
		echo "					if (document.selection != null) {\n";
		echo "						document.selection.createRange().text = '\\t';\n";
		echo "						event.returnValue = false;\n";
		echo "					}\n";
		echo "					else {\n";
		echo "						event.srcElement.value += '\\t';\n";
		echo "						return false;\n";
		echo "					}\n";
		echo "				}\n";
		echo "			}\n";
		echo "		}\n";
		echo "	}\n";
		echo "}\n";
	}
	
	
	if ($state == "manage" && ($state2 == "copy" || $state2 == "move")) {
		echo "\nfunction CopyValueToAll(myform, mysourcefield, mytargetfieldname) {\n";
		echo "	for (var i = 0; i < myform.elements.length; i++) {\n";
		echo "		if (myform.elements[i].name.indexOf(mytargetfieldname) >= 0) {\n";
		echo "			myform.elements[i].value = mysourcefield.value;\n";
		echo "		}\n";
		echo "	}\n";
		echo "}\n";
	}

	if ($state == "manage" && $state2 == "chmod") {
		echo "function update_field(id,text) {\n";
		echo "	if (document.getElementById) {\n";
		echo "		document.getElementById(id).value = text;\n";
		echo "	}\n";
		echo "	else if (document.all) {\n";
		echo "		document.all[id].value = text;\n";
		echo "	}\n";
		echo "}\n";

		echo "function get_field(id) {\n";
		echo "	if (document.getElementById) {\n";
		echo "		var value = document.getElementById(id).value;\n";
		echo "	}\n";
		echo "	else if (document.all) {\n";
		echo "		var value = document.all[id].value;\n";
		echo "	}\n";
		echo "	return value;\n";
		echo "}\n";

		echo "function update_input(num) {\n";
		echo "	var myform = document.ChmodForm;\n";
		echo "	var myfield = 'chmod';\n";
		echo "	var regexp = /list\\[([0-9]+)\\]\\[(owner|group|other)_(read|write|execute)\\]/i;\n";
		echo "	var myArray = new Array();\n";
		echo "	var maxfields = 0;\n";
		echo "	for (var i = 0; i < myform.elements.length; i++) {\n";
		echo "		if (regexp.test(myform.elements[i].name)) {\n";
		echo "			var ar = regexp.exec(myform.elements[i].name);\n";
		echo "			var checked = myform.elements[i].checked;\n";
		echo "			if (maxfields<ar[1]) maxfields = ar[1];\n";
		echo "			myArray[myArray.length] = new Array(ar[1],ar[2],ar[3],checked);\n";
		echo "		}\n";
		echo "	}\n";
		echo "	if (!num || num==\"all\" || num == '') num = 0;\n";
		echo "		for(var i=0; i<maxfields; i++) {\n";
		echo "			var id = i+1;\n";
		echo "			if (num==0 || num==id) {\n";
		echo "				var owner = 0;\n";
		echo "				var group = 0;\n";
		echo "				var other = 0;\n";
		echo "				var add = 0;\n";
		echo "				for (var j=0; j<myArray.length; j++) {\n";
		echo "					checked = myArray[j][3];\n";
		echo "					if (checked && id==myArray[j][0]) {\n";
		echo "						if(myArray[j][2]=='read') add = 4;\n";
		echo "						else if(myArray[j][2]=='write') add = 2;\n";
		echo "						else if(myArray[j][2]=='execute') add = 1;\n";
		echo "						if(myArray[j][1]=='owner') owner += add;\n";
		echo "						else if(myArray[j][1]=='group') group += add;\n";
		echo "						else if(myArray[j][1]=='other') other += add;\n";
		echo "					}\n";
		echo "				}\n";
		echo "			update_field(myfield+id,owner+''+group+''+other);\n";
		echo "			if (num!=0 && num==id) break;\n";
		echo "		}\n";
		echo "	}\n";
		echo "}\n";

		echo "function update_checkbox(num) {\n";
		echo "	var myform = document.ChmodForm;\n";
		echo "	var myfield = 'chmod';\n";
		echo "	var regexp = /list\\[([0-9]+)\\]\\[(owner|group|other)_(read|write|execute)\\]/i;\n";
		echo "	if (!num || num==\"all\" || num == '') num = 0;\n";
		echo "		for (var i = 0; i < myform.elements.length; i++) {\n";
		echo "			var name = myform.elements[i].name;\n";
		echo "			if (name.substr(0,myfield.length) == myfield) {\n";
		echo "				var id = name.substr(myfield.length,name.length);\n";
		echo "				if (id>0 && (num==0 || num==id)) {\n";
		echo "					var field = get_field(myfield+id);\n";
		echo "					var o = field.substr(0,1);\n";
		echo "					var g = field.substr(1,1);\n";
		echo "					var e = field.substr(2,1);\n";
		echo "					if (field.length==3 && o>=0 && o<=7 && g>=0 && g<=7 && e>=0 && e<=7) {\n";
		echo "						for (var j = 0; j < myform.elements.length; j++) {\n";
		echo "							if (regexp.test(myform.elements[j].name)) {\n";
		echo "								var ar = regexp.exec(myform.elements[j].name);\n";
		echo "								if (ar[1]==id) {\n";
		echo "									var check = false;\n";
		echo "									if (ar[2]=='owner') {\n";
		echo "										if (ar[3]=='read' && (o==4 || o==5 || o==6 || o==7))\n";
		echo "											check = true;\n";
		echo "										if (ar[3]=='write' && (o==2 || o==3 || o==6 || o==7))\n";
		echo "					 						check = true;\n";
		echo "           									if (ar[3]=='execute' && (o==1 || o==3 || o==5 || o==7))\n";
		echo "           										check = true;\n";
		echo "									}\n";
		echo "									else if (ar[2]=='group') {\n";
		echo "										if (ar[3]=='read' && (g==4 || g==5 || g==6 || g==7))\n";
		echo "											check = true;\n";
		echo "										if (ar[3]=='write' && (g==2 || g==3 || g==6 || g==7))\n";
		echo "											check = true;\n";
		echo "										if (ar[3]=='execute' && (g==1 || g==3 || g==5 || g==7))\n";
		echo "											check = true;\n";
		echo "									}\n";
		echo "									else if (ar[2]=='other') {\n";
		echo "										if (ar[3]=='read' && (e==4 || e==5 || e==6 || e==7))\n";
		echo "											check = true;\n";
		echo "										if (ar[3]=='write' && (e==2 || e==3 || e==6 || e==7))\n";
		echo "											check = true;\n";
		echo "										if (ar[3]=='execute' && (e==1 || e==3 || e==5 || e==7))\n";
		echo "											check = true;\n";
		echo "									}\n";
		echo "									if (check==true) myform.elements[j].checked = 1;\n";
		echo "									else myform.elements[j].checked = 0;\n";
		echo "								}\n";
		echo "							}\n";
		echo "						}\n";
		echo "					}\n";
		echo "				else {\n";
		echo "					update_input(id);\n";
		echo "				}\n";
		echo "			}\n";
		echo "		}\n";
		echo "	}\n";
		echo "}\n";

		echo "\nfunction CopyCheckboxToAll(myform, mysourcefieldname, mytargetfieldname) {\n";
		echo "	for (var i = 0; i < myform.elements.length; i++) {\n";
		echo "		if (myform.elements[i].name.indexOf(mysourcefieldname) >= 0) {\n";
		echo "			for (var j = 0; j < myform.elements.length; j++) {\n";
		echo "				if (myform.elements[j].name.indexOf(mytargetfieldname) >= 0) {\n";
		echo "					myform.elements[j].checked = myform.elements[i].checked;\n";
		echo "				}\n";
		echo "			}\n";
		echo "		}\n";
		echo "	}\n";
		echo "}\n";
	}
	if ($state == "easyWebsite") {
		echo "\nfunction confirm_prompt(formname, text) {\n";
		echo "	if (confirm(text)) {\n";
		echo "		eval('document.' + formname + '.submit();');\n";
		echo "	}\n";
		echo "}\n";
	}

//	if ($state == "" || $state == "login") {
//		THE JAVASCRIPT FUNCTIONS USED ON THE LOGIN PAGE ARE LOCATED
//          IN THE FILE net2ftp_loginform.inc.php
//	}

	echo "//--></script>\n";
	printFunctionTags("printJavascriptFunctions", "end");

} // end printJavascriptFunctions

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function setStatus_php($current, $total, $text) {

// --------------
// This function prints the Javascript which will update the status in the top table
// See also the Javascript function setStatus_js defined in the PHP function printJavascriptFunctions.
// --------------

// If the plugin is not active, do nothing
	if (isActivePlugin("html_progress") == false) { return true; }

// HTML encode the $string
	$string = floor($current/$total*100) . "% " . javascriptEncode($text);

	setProgressBarStatus($current, $total, $string);

// Old status bar
//	echo "<script type=\"text/javascript\"><!--\n";
//	echo "	setStatus_js('$text');\n";
//	echo "//--></script>\n";

	flush();

} // End function setStatus_php

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function timer() {

// --------------
// This function calculates the time between starttime and endtime in milliseconds
// --------------

	global $starttime, $endtime; // the value is set in index.php

	list($start_usec, $start_sec) = explode(' ', $starttime);
	$starttime  = ((float)$start_usec + (float)$start_sec);
	list($end_usec, $end_sec) = explode(' ', $endtime);
	$endtime    = ((float)$end_usec + (float)$end_sec);
	$time_taken = ($endtime - $starttime);   // to convert from microsec to sec
	$time_taken = number_format($time_taken, 2);     // optional

	return $time_taken;

} // End function timer

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function mytime() {
	$datetime = date("Y-m-d H:i:s");
	return $datetime;
}

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************



// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printTitle($title) {

// --------------
// This function prints the a title
// --------------

	echo "<div class=\"header21\">\n";
	echo "$title\n";
	echo "</div>\n";

} // End function printTitle

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function getBrowser($what) {

// --------------
// This function returns the browser name, version and platform using the http_user_agent string
// --------------

// Original code comes from http://www.phpbuilder.com/columns/tim20000821.php3?print_mode=1
// Written by Tim Perdue, and released under the GPL license
//
// SourceForge: Breaking Down the Barriers to Open Source Development
// Copyright 1999-2000 (c) The SourceForge Crew
// http://sourceforge.net
//
// $Id: tim20000821.php3,v 1.2 2001/05/22 19:22:47 tim Exp $


	global $HTTP_USER_AGENT;

	if ($what == "version" || $what == "agent") {

// -------------------------------------------------------------------------
// Determine browser and version
// -------------------------------------------------------------------------

// !!! If a new browser is added, add is also in the plugin properties
// Else, functionality will be broken when loading the plugin in printTextareaSelect().

		if (ereg('MSIE ([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$regs)) {
			$BROWSER_VERSION = $regs[1];
			$BROWSER_AGENT = 'IE';
		}
		elseif (ereg('Opera ([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$regs)) {
			$BROWSER_VERSION = $regs[1];
			$BROWSER_AGENT = 'Opera';
		}
		elseif (ereg('Mozilla/([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$regs)) {
			$BROWSER_VERSION = $regs[1];
			$BROWSER_AGENT = 'Mozilla';
		}
		else {
			$BROWSER_VERSION = 0;
			$BROWSER_AGENT = 'Other';
		}

		if ($what == "version") { return $BROWSER_VERSION; }
		elseif ($what == "agent")   { return $BROWSER_AGENT; }

	} // end if

// -------------------------------------------------------------------------
// Determine platform
// -------------------------------------------------------------------------

	elseif ($what == "platform") {

		if (strstr($HTTP_USER_AGENT,'Win')) {
			$BROWSER_PLATFORM = 'Win';
		}
		else if (strstr($HTTP_USER_AGENT,'Mac')) {
			$BROWSER_PLATFORM = 'Mac';
		}
		else if (strstr($HTTP_USER_AGENT,'Linux')) {
			$BROWSER_PLATFORM = 'Linux';
		}
		else if (strstr($HTTP_USER_AGENT,'Unix')) {
			$BROWSER_PLATFORM = 'Unix';
		}
		else {
			$BROWSER_PLATFORM = 'Other';
		}

		return $BROWSER_PLATFORM;

	} // end if elseif

} // End function getBrowser

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************

?>