<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function edit($directory, $entry, $text, $formresult) {

// --------------
// This function allows to edit a file in a textarea
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $state2;
	global $application_rootdir;

// -------------------------------------------------------------------------
// First step: show edit form
// -------------------------------------------------------------------------
	if ($formresult != "result") {
		if ($state2 == "edit") {
			$text_fromfile = ftp_readfile("", $directory, $entry);
			if ($execution_success == false)  { return false; }
		}
		elseif ($state2 == "newfile") {
			$handle = fopen("$application_rootdir/template.txt", "r"); // Open the local template file for reading only
			if ($handle == false) { 
				$errormessage = __("Unable to open the template file");
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}

			clearstatcache(); // for filesize

			$text_fromfile = fread($handle, filesize("$application_rootdir/template.txt"));
			if ($text_fromfile == false) { 
				$errormessage = __("Unable to read the template file");
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}

			$success1 = @fclose($handle);
		}

		printEditForm($directory, $entry, $text_fromfile, "notsavedyet");
	}

// -------------------------------------------------------------------------
// Second step: save to remote file, and show View/Edit screen
// -------------------------------------------------------------------------
	elseif ($formresult == "result") {
		if (strlen($entry)<1) { 
			$errormessage = __("Please specify a filename"); 
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}

		// Write the string to the FTP server
		// Note: this function also replaces CarriageReturn+LineFeed by LineFeed
		ftp_writefile("", $directory, $entry, $text);
		if ($execution_success == false)  { return false; }

		printEditForm($directory, $entry, $text, $execution_success);
	}

} // End function edit

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printTextareaSelect($entry) {

// --------------
// This function prints a select with the available skins
// Skin nr 1 is the default skin
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $browser_agent, $browser_version;
	global $textareaType;
	$pluginProperties = getPluginProperties("ALL");

	$filename_extension = get_filename_extension($entry);

	$onchange = "document.EditForm.textareaType.value=document.EditForm.textareaSelect.options[document.EditForm.textareaSelect.selectedIndex].value; document.EditForm.submit();";

	echo "<select name=\"textareaSelect\" id=\"textareaSelect\" onChange=\"$onchange\">\n";
	if ($textareaType == "" || $textareaType == "plain") { $plainselected = "selected"; }
	echo "<option value=\"plain\" $plainselected>Normal textarea</option>\n";

	while(list($pluginName,$value) = each($pluginProperties)) {
// Print only the plugins which have 'use' set to yes
//                        which are textareas
//                        which are suitable for this browser
//                        which are suitable for this type of file
		if ($pluginProperties[$pluginName]["use"] == "yes" && $pluginProperties[$pluginName]["type"] == "textarea" && in_array($browser_agent, $pluginProperties[$pluginName]["browsers"]) == true && in_array($filename_extension, $pluginProperties[$pluginName]["filename_extensions"]) == true) {
			if ($pluginName == $textareaType) { $selected = "selected"; }
			else                                { $selected = ""; }
			echo "<option value=\"$pluginName\" $selected>" . $pluginProperties[$pluginName]["label"] . "</option>\n";
		} // end if
	} // end while

	echo "</select>\n";

} // End function printTextareaSelect

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printEditForm($directory, $entry, $text, $success_save) {

// --------------
// This function prints the form containing the textarea in which text is edited
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $settings;
	global $state, $state2;
	global $textareaType;
	global $net2ftp_language;
	$edit_nrofcolumns            = $settings["edit_nrofcolumns"];
	$edit_nrofrows               = $settings["edit_nrofrows"];
	$edit_htmlarea203_width      = $settings["edit_htmlarea203_width"];
	$edit_htmlarea203_height     = $settings["edit_htmlarea203_height"];
	$edit_htmlarea3rc1_width     = $settings["edit_htmlarea3rc1_width"];
	$edit_htmlarea3rc1_height    = $settings["edit_htmlarea3rc1_height"];
	$edit_fckeditor20_width      = $settings["edit_fckeditor20_width"];
	$edit_fckeditor20_height     = $settings["edit_fckeditor20_height"];
	$edit_helene05_top_width     = $settings["edit_helene05_top_width"];
	$edit_helene05_top_height    = $settings["edit_helene05_top_height"];
	$edit_helene05_bottom_width  = $settings["edit_helene05_bottom_width"];
	$edit_helene05_bottom_height = $settings["edit_helene05_bottom_height"];

	if (strlen($directory) > 0) { $printdirectory = $directory; }
	else                        { $printdirectory = "/"; }

// -------------------------------------------------------------------------
// Form
// -------------------------------------------------------------------------
	echo "<form name=\"EditForm\" id=\"EditForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
	printLoginInfo();
	echo "<input type=\"hidden\" name=\"state\" value=\"manage\" />\n";
	echo "<input type=\"hidden\" name=\"state2\" value=\"edit\" />\n";
	echo "<input type=\"hidden\" name=\"directory\" value=\"$directory\" />\n";
	echo "<input type=\"hidden\" name=\"entry\" value=\"$entry\" />\n";
	echo "<input type=\"hidden\" name=\"textareaType\" value=\"$textareaType\" />\n";
	echo "<input type=\"hidden\" name=\"formresult\" value=\"result\" />\n";

	echo "<table style=\"padding: 2px; width: 100%; height: 100%; border: 0px;\">\n";

// -------------------------------------------------------------------------
// Row 1, Col 1: Buttons (back and save)
// -------------------------------------------------------------------------
	echo "<tr>\n";
	echo "<td valign=\"top\" style=\"text-align: left; width: 20%;\">\n";

	echo getAction("back", "document.EditForm.state.value='browse'; document.EditForm.state2.value='main'; document.EditForm.submit();") . "&nbsp;\n";

	if ($textareaType == "htmlarea3rc1") { echo getAction("save", "document.EditForm.onsubmit();document.EditForm.submit();") . "\n"; }
	else                                 { echo getAction("save", "document.EditForm.submit();") . "\n"; }
	echo "</td>\n";

// -------------------------------------------------------------------------
// Row 1, Col 2: Directory and Filename
// -------------------------------------------------------------------------
	echo "<td valign=\"top\" style=\"text-align: left; width: 40%;\">\n";
  // Edit ==> print filename
	if ($state2 == "edit" || $state2 == "updatefile") {
		echo "<table border=\"0\">\n";
		echo "<tr><td valign=\"top\">" . __("Directory: ") . "</td><td><b>$printdirectory</b></td></tr>\n";
		echo "<tr><td valign=\"top\">" . __("File: ") . "</td><td><b>$entry</b></td></tr>\n";
		echo "</table>\n";
	}
  // Newfile ==> print new filename textbox
	elseif ($state2 == "newfile") {
		echo "<table>\n";
		echo "<tr><td valign=\"top\">" . __("Directory: ") . "</td><td><b>$printdirectory</b></td></tr>\n";
		echo "<tr><td valign=\"top\">" . __("New file name: ") . "</td><td> <input class=\"input\" type=\"text\" name=\"entry\" /></td></tr>\n";
		echo "</table>\n";
	}
	echo "</td>\n";

// -------------------------------------------------------------------------
// Row 1, Col 3
// -------------------------------------------------------------------------
	echo "<td valign=\"top\" style=\"text-align: right; width: 40%;\">\n";
	echo "Textarea: ";
	printTextareaSelect($entry);
	echo "<br /><span style=\"font-size: 80%;\">" . __("Note: changing the textarea type will save the changes") . "</span>\n";
	echo "</td>\n";

	echo "</tr>\n";

// -------------------------------------------------------------------------
// Row 2: Saving-status
// -------------------------------------------------------------------------
	$ftpmode = ftpAsciiBinary($entry);
	if ($ftpmode == FTP_ASCII) { $printftpmode = "FTP_ASCII"; }
	elseif ($ftpmode == FTP_BINARY) { $printftpmode = "FTP_BINARY"; }

	echo "<tr>\n";
	echo "<td colspan=\"3\" valign=\"top\" style=\"text-align: left;\">\n";
	$mytime = mytime();
	if ($success_save === "notsavedyet") { echo "<div style=\"font-size: 80%;\">" . __("Status: This file has not yet been saved") . "</div>\n"; }
	elseif ($success_save === true)      { echo "<div style=\"font-size: 80%;\">" . __("Status: Saved on <b>%1\$s</b> using mode %2\$s", $mytime, $printftpmode) . "</div>\n"; }
	elseif ($success_save === false)     { echo "<div style=\"font-size: 80%;\">" . __("Status: <b>This file could not be saved</b>") . "</div>\n"; }
	echo "</td>\n";
	echo "</tr>\n";

// -------------------------------------------------------------------------
// Row 3: Textarea
// -------------------------------------------------------------------------
	echo "<tr>\n";
	echo "<td colspan=\"3\" valign=\"top\" style=\"text-align: left;\">\n";

	echo "<div style=\"margin-left: 0px; text-align: left;\">\n";

	if ($textareaType == "" || $textareaType == "plain") {
		$text = htmlspecialchars($text, ENT_QUOTES);

		echo "\n\n<!-- -------------------- Start of code -------------------- -->\n";
		echo "<textarea name=\"text\" class=\"edit\" rows=\"$edit_nrofrows\" cols=\"$edit_nrofcolumns\" wrap=\"off\" onkeydown=\"TabText()\">";
		echo "$text";  // do not add a \n at the end, this would add a final newline at the end of each file!!
		echo "</textarea>\n";
		echo "<!-- -------------------- End  of code  -------------------- -->\n\n\n";
		echo "</div>\n";
		echo "</td>\n";
		echo "</tr>\n";
		echo "</table>\n";
		echo "</form>\n";
	}

	elseif ($textareaType == "htmlarea203") {
		$text = htmlspecialchars($text, ENT_QUOTES);

		echo "\n\n<!-- -------------------- Start of code -------------------- -->\n";
		echo "<textarea name=\"text\" class=\"edit\" style=\"width: $edit_htmlarea203_width; height: $edit_htmlarea203_height\" wrap=\"off\">";
		echo "$text";  // do not add a \n at the end, this would add a final newline at the end of each file!!
		echo "</textarea>\n";
		echo "<!-- -------------------- End  of code  -------------------- -->\n\n\n";
		echo "<script type=\"text/javascript\" defer> editor_generate('text'); </script>\n";

		echo "</div>\n";
		echo "</td>\n";
		echo "</tr>\n";
		echo "</table>\n";
		echo "</form>\n";
	}

	elseif ($textareaType == "htmlarea3rc1") {
		$text = htmlspecialchars($text, ENT_QUOTES);

		echo "\n\n<!-- -------------------- Start of code -------------------- -->\n";
		echo "<textarea name=\"text\" id=\"text\" style=\"width: $edit_htmlarea3rc1_width; height: $edit_htmlarea3rc1_height;\">";
		echo "$text";  // do not add a \n at the end, this would add a final newline at the end of each file!!
		echo "</textarea>\n";
		echo "<!-- -------------------- End  of code  -------------------- -->\n\n\n";
//		echo "<script type=\"text/javascript\" defer=\"1\">\n";
//		echo "var config = new HTMLArea.Config();\n";
//		echo "config.pageStyle = 'body { background-color: white; color: black; font-family: verdana,sans-serif } ' + 'p { font-width: normal; } ';\n";
//		echo "config.width = '$edit_htmlarea3rc1_width';\n";
//		echo "config.height = '$edit_htmlarea3rc1_height';\n";
//		echo "HTMLArea.replace('text', config);\n";
//		echo "</script>\n";

		echo "</div>\n";
		echo "</td>\n";
		echo "</tr>\n";
		echo "</table>\n";
		echo "</form>\n";
	}

	elseif ($textareaType == "fckeditor20") {

// It is not needed to execute htmlspecialchars, this is done by FCKEditor itself
//		$text = htmlspecialchars($text, ENT_QUOTES);

// Determine the language to be used
		if     ($net2ftp_language == "cs") { $fckeditor20_language = "cs"; }
		elseif ($net2ftp_language == "de") { $fckeditor20_language = "en"; }
		elseif ($net2ftp_language == "es") { $fckeditor20_language = "es"; }
		elseif ($net2ftp_language == "fr") { $fckeditor20_language = "fr"; }
		elseif ($net2ftp_language == "it") { $fckeditor20_language = "it"; }
		elseif ($net2ftp_language == "nl") { $fckeditor20_language = "nl"; }
		elseif ($net2ftp_language == "pl") { $fckeditor20_language = "pl"; }
		elseif ($net2ftp_language == "ru") { $fckeditor20_language = "ru"; }
		elseif ($net2ftp_language == "tc") { $fckeditor20_language = "zh-tw"; }
		elseif ($net2ftp_language == "zh") { $fckeditor20_language = "zh-cn"; }
		else                               { $fckeditor20_language = "en"; }

		echo "\n\n<!-- -------------------- Start of code -------------------- -->\n";

		$oFCKeditor = new FCKeditor("text") ;
		$oFCKeditor->BasePath = "plugins/fckeditor-2.0/";
		$oFCKeditor->Value    = "$text";
		$oFCKeditor->Width    = "$edit_fckeditor20_width" ;
		$oFCKeditor->Height   = "$edit_fckeditor20_height" ;
		$oFCKeditor->Config['AutoDetectLanguage']	= false;
		$oFCKeditor->Config['DefaultLanguage'] = $fckeditor20_language;
		$oFCKeditor->ToolbarSet = "Default";
		$oFCKeditor->Create() ;

		echo "<!-- -------------------- End  of code  -------------------- -->\n\n\n";

		echo "</div>\n";
		echo "</td>\n";
		echo "</tr>\n";
		echo "</table>\n";
		echo "</form>\n";
	}
	
	elseif ($textareaType == "helene05") {
		$text_syntax = syntaxTextareaEncode($text);
		$text = htmlspecialchars($text, ENT_QUOTES);

		echo "<input type=\"hidden\" name=\"keybinding\" value=\"default\" />\n";
		echo "\n\n<!-- -------------------- Start of code -------------------- -->\n";
		echo "<textarea name=\"text\" id=\"text\" style=\"width: $edit_helene05_top_width; height: $edit_helene05_top_height\" wrap=\"off\">";
		echo "$text";
		echo "</textarea><br />\n";
		echo "<!-- -------------------- End  of code  -------------------- -->\n\n\n";

		echo "<input type=\"button\" name=\"save\"  value=\"Copy up\"    onClick=\"text.value = editor.getContents();\">\n";
		echo "<input type=\"button\" name=\"load\"  value=\"Copy down\"  onClick=\"editor.setContents(text.value);\">\n";
//		echo "<input type=\"button\" name=\"clear\" value=\"Clear down\" onClick=\"editor.setContents('');\">\n";

		echo "</div>\n";
		echo "</td>\n";
		echo "</tr>\n";
		echo "</table>\n";
		echo "</form>\n";

		echo "<iframe name=\"editor\" src=\"plugins/helene-0.5/editor.html\" style=\"width: $edit_helene05_bottom_width; height: $edit_helene05_bottom_height\"></iframe>\n";
		echo "<script type=\"text/javascript\"> function init(text) { editor.setContents('$text_syntax'); } </script>\n";
	}

//	echo "</div>\n";
//	echo "</td>\n";
//	echo "</tr>\n";
//	echo "</table>\n";
//	echo "</form>\n";

} // End function printEditForm

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function syntaxTextareaEncode($string) {

// --------------
// Replace tabs, line-feeds and carriage-returns by \t and \n respectively.
// --------------

	$tab = chr(9);
	$lf = chr(10);
	$cr = chr(13);

	$newstring = $string;

// Replace \' and '
	$newstring = str_replace("\'", "\\\'", $newstring);
	$newstring = str_replace("'", "\'", $newstring);

// Replace $cr$lf by $lf
	$newstring = str_replace("$cr$lf", "$lf", $newstring);

// Replace $lf and $tab
	$newstring = str_replace($lf, "\\n", $newstring);
	$newstring = str_replace($tab, "\\t", $newstring);

	return $newstring;

} // end syntaxTextareaEncode

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************


?>