<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function view($directory, $entry) {

// --------------
// This function allows to view a file
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $browser_agent, $browser_version, $browser_platform;

	$filename_extension = get_filename_extension($entry);

// -------------------------------------------------------------------------
// Image
// -------------------------------------------------------------------------
	if (getFileType($entry) == "IMAGE") {
		echo "<div style=\"margin-left: 30px;\">\n";
		printTitle(__("View image %1\$s", $entry));
		printBack($directory);
		echo "</div>\n";

		echo "<div style=\"font-size: 80%; text-align: center;\">\n";

		if ($filename_extension == "png" && $browser_agent == "IE" && ($browser_version == "5.5" || $browser_version == "6") && $browser_platform == "Win") {
			echo "<img src=\"images/mime/spacer.gif\"   alt=\"" . __("Image") . " $entry\" style=\"border: 1px solid black; filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='".printPHP_SELF("image")."', sizingMethod='scale');\" />";
		} else {
			echo "<img src=\"" . printPHP_SELF("image") . "\" alt=\"" . __("Image") . " $entry\" style=\"border: 1px solid black;\" /><br /><br />\n";
		}

		echo __("To save the image, right-click on it and choose 'Save picture as...'") . "<br />\n";
		echo "</div>\n";
	}

// -------------------------------------------------------------------------
// Flash movie
// -------------------------------------------------------------------------
	elseif ($filename_extension == "swf") {
		echo "<div style=\"margin-left: 30px;\">\n";
		printTitle(__("View Macromedia ShockWave Flash movie %1\$s", $entry));
		printBack($directory);
		echo "</div>\n";

		echo "<div style=\"font-size: 80%; text-align: center;\">\n";
		echo "<object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" codebase=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0\" id=\"flashfile\">\n";
		echo "<param name=\"movie\" value=\"/".printPHP_SELF("image")."\">\n";
		echo "<param name=\"quality\" value=\"high\">\n";
		echo "<param name=\"bgcolor\" value=\"#FFFFFF\">\n";
		echo "<embed src=\"" . printPHP_SELF("full") . "\" quality=\"high\" bgcolor=\"#FFFFFF\" NAME=\"flashfile\" ALIGN TYPE=\"application/x-shockwave-flash\" PLUGINSPAGE=\"http://www.macromedia.com/go/getflashplayer\">\n";
		echo "</object>\n";
		echo "</div>\n";
	}
	
// -------------------------------------------------------------------------
// Text
// -------------------------------------------------------------------------
	else {
		echo "<div style=\"margin-left: 30px;\">\n";
		printTitle(__("View file %1\$s", $entry));
		printBack($directory);
		echo "</div>\n";

// ------------------------
// geshi_text
// ------------------------
		$geshi_text = ftp_readfile("", $directory, $entry);
		if ($execution_success == false)  { return false; }

// ------------------------
// geshi_language
// ------------------------
		$geshi_language = "";

		$list_language_extensions = array(
// List the most popular languages first for speed reasons 
			'html4strict' => array('html', 'htm'),
			'javascript'  => array('js'),
			'css'  => array('css'),
			'php'  => array('php', 'php5', 'phtml', 'phps'),
			'perl' => array('pl', 'pm', 'cgi'),
			'sql'  => array('sql'),
			'java' => array('java'),
// Other languages in alphabetic order 
			'actionscript' => array('as'),
			'ada' => array('a', 'ada', 'adb', 'ads'),
			'apache' => array('conf'),
			'asm' => array('ash', 'asm'),
			'asp' => array('asp'),
			'bash' => array('sh'),
			'c' => array('c', 'h'),
			'c_mac' => array('c'),
			'caddcl' => array(),
			'cadlisp' => array(),
			'cpp' => array('cpp'),
			'csharp' => array(),
			'delphi' => array('dpk'),
			'lisp' => array('lisp'),
			'lua' => array('lua'),
			'mpasm' => array(),
			'nsis' => array(),
			'objc' => array(),
			'oobas' => array(),
			'oracle8' => array(),
			'pascal' => array('pas'),
			'python' => array('py'),
			'qbasic' => array('bi'),
			'smarty' => array('tpl'),
			'vb' => array('bas'),
			'vbnet' => array(),
			'visualfoxpro' => array(),
			'xml' => array('xml')
		);


		while(list($language, $extensions) = each($list_language_extensions)) {
			if (in_array($filename_extension, $extensions)) {
				$geshi_language = $language;
				break;
			}
		} 

// ------------------------
// geshi_path
// ------------------------
		$geshi_path = "plugins/geshi/geshi/";
		
// ------------------------
// Call geshi
// ------------------------
		$geshi = new GeSHi($geshi_text, $geshi_language, $geshi_path);
		$geshi->set_encoding(__("iso-8859-1"));
		$geshi->set_header_type(GESHI_HEADER_PRE);
		$geshi->enable_line_numbers(GESHI_FANCY_LINE_NUMBERS, 10);
//		$geshi->enable_classes();
		$geshi->set_overall_style('border: 2px solid #d0d0d0; background-color: #f6f6f6; color: #000066; padding: 10px;', true);
		$geshi->set_link_styles(GESHI_LINK, 'color: #000060;');
		$geshi->set_link_styles(GESHI_HOVER, 'background-color: #f0f000;');
		$geshi->set_tab_width(4); 
		echo $geshi->parse_code();
	}

} // End function view

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function viewImage($directory, $entry) {

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;

	header("Content-Type: " . getContentType($entry));
	header("Content-Disposition: inline; filename=\"$entry\""); 

	$text = ftp_readfile("", $directory, $entry);
	if ($execution_success == false)  { return false; }

	echo $text;
	flush();

	header("Connection: close");
}

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************



?>