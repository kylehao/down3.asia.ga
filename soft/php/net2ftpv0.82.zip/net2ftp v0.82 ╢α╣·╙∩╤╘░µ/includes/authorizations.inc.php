<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function encryptPassword($password) {

// --------------
// This function takes a clear-text password and returns an encrypted password
// Written by Jakub
// --------------

	global $settings;

// XOR with random string (which is set in settings.inc.php)
	$password_encrypted = "";
	$encryption_string = $settings["encryption_string"];
	if ($encryption_string % 2 == 1) { // we need even number of characters
		$encryption_string .= $encryption_string{0};
	}
	for ($i=0; $i < strlen($password); $i++) { // encrypts one character - two bytes at once
		$password_encrypted .= sprintf("%02X", hexdec(substr($encryption_string, 2*$i % strlen($encryption_string), 2)) ^ ord($password{$i}));
	}
	return $password_encrypted;

} // End function encryptPassword

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function decryptPassword($password_encrypted) {

// --------------
// This function takes an encrypted password and returns the clear-text password
// Written by Jakub
// --------------

	global $settings;

// XOR with random string (which is set in settings.inc.php)
	$password = "";
	$encryption_string = $settings["encryption_string"];
	if ($encryption_string % 2 == 1) { // we need even number of characters
		$encryption_string .= $encryption_string{0};
	}
	for ($i=0; $i < strlen($password_encrypted); $i += 2) { // decrypts two bytes - one character at once
		$password .= chr(hexdec(substr($encryption_string, $i % strlen($encryption_string), 2)) ^ hexdec(substr($password_encrypted, $i, 2)));
	}
	return $password;

} // End function decryptPassword

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printLoginInfo() {

// --------------
// This function prints the ftpserver, username and login information
// --------------

// -------------------------------------------------------------------------
// Global variables and settings
// -------------------------------------------------------------------------
	global $net2ftp_ftpserver, $net2ftp_ftpserverport, $net2ftp_username, $net2ftp_password_encrypted, $net2ftp_language, $net2ftp_skin, $net2ftp_ftpmode, $net2ftp_passivemode, $net2ftp_sslconnect, $net2ftp_viewmode, $net2ftp_sort, $net2ftp_sortorder;

	printFunctionTags("printLoginInfo", "begin");

	echo "<input type=\"hidden\" name=\"ftpserver\" value=\"$net2ftp_ftpserver\" />\n";
	echo "<input type=\"hidden\" name=\"ftpserverport\" value=\"$net2ftp_ftpserverport\" />\n";
	echo "<input type=\"hidden\" name=\"username\" value=\"$net2ftp_username\" />\n";
	echo "<input type=\"hidden\" name=\"password_encrypted\" value=\"$net2ftp_password_encrypted\" />\n";
	echo "<input type=\"hidden\" name=\"language\" value=\"$net2ftp_language\" />\n";
	echo "<input type=\"hidden\" name=\"skin\" value=\"$net2ftp_skin\" />\n";
	echo "<input type=\"hidden\" name=\"ftpmode\" value=\"$net2ftp_ftpmode\" />\n";
	echo "<input type=\"hidden\" name=\"passivemode\" value=\"$net2ftp_passivemode\" />\n";
	echo "<input type=\"hidden\" name=\"sslconnect\" value=\"$net2ftp_sslconnect\" />\n";
	echo "<input type=\"hidden\" name=\"viewmode\" value=\"$net2ftp_viewmode\" />\n";
	echo "<input type=\"hidden\" name=\"sort\" value=\"$net2ftp_sort\" />\n";
	echo "<input type=\"hidden\" name=\"sortorder\" value=\"$net2ftp_sortorder\" />\n";
	printFunctionTags("printLoginInfo", "end");

} // End function printLoginInfo

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printLoginInfo_javascript() {

// --------------
// This function prints the ftpserver, username and login information -- for javascript input
// --------------

	global $net2ftp_ftpserver, $net2ftp_ftpserverport, $net2ftp_username, $net2ftp_password_encrypted, $net2ftp_language, $net2ftp_skin, $net2ftp_ftpmode, $net2ftp_passivemode, $net2ftp_sslconnect, $net2ftp_viewmode, $net2ftp_sort, $net2ftp_sortorder;

	printFunctionTags("printLoginInfo_javascript", "begin");

	echo "	d.writeln('<input type=\"hidden\" name=\"ftpserver\" value=\"$net2ftp_ftpserver\" />');\n";
	echo "	d.writeln('<input type=\"hidden\" name=\"ftpserverport\" value=\"$net2ftp_ftpserverport\" />');\n";
	echo "	d.writeln('<input type=\"hidden\" name=\"username\" value=\"$net2ftp_username\" />');\n";
	echo "	d.writeln('<input type=\"hidden\" name=\"password_encrypted\" value=\"$net2ftp_password_encrypted\" />');\n";
	echo "	d.writeln('<input type=\"hidden\" name=\"language\" value=\"$net2ftp_language\" />');\n";
	echo "	d.writeln('<input type=\"hidden\" name=\"skin\" value=\"$net2ftp_skin\" />');\n";
	echo "	d.writeln('<input type=\"hidden\" name=\"ftpmode\" value=\"$net2ftp_ftpmode\" />');\n";
	echo "	d.writeln('<input type=\"hidden\" name=\"passivemode\" value=\"$net2ftp_passivemode\" />');\n";
	echo "	d.writeln('<input type=\"hidden\" name=\"sslconnect\" value=\"$net2ftp_sslconnect\" />');\n";
	echo "	d.writeln('<input type=\"hidden\" name=\"viewmode\" value=\"$net2ftp_viewmode\" />');\n";
	echo "	d.writeln('<input type=\"hidden\" name=\"sort\" value=\"$net2ftp_sort\" />');\n";
	echo "	d.writeln('<input type=\"hidden\" name=\"sortorder\" value=\"$net2ftp_sortorder\" />');\n";

	printFunctionTags("printLoginInfo_javascript", "end");

} // End function printLoginInfo

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************









// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printBack($directory) {

// --------------
// This function prints a Back button which has its own form
// --------------

	printFunctionTags("printBack", "begin");

	echo "<form name=\"stateForm\" id=\"stateForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
	printLoginInfo();
	echo "<input type=\"hidden\" name=\"directory\" value=\"$directory\" />\n";
	echo "<input type=\"hidden\" name=\"state\" value=\"browse\" />\n";
	echo "<input type=\"hidden\" name=\"state2\" value=\"main\" />\n";

	echo getAction("back", "document.stateForm.submit();");

	echo "</form>\n";

	printFunctionTags("printBack", "end");

} // End function printBack

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printBackInForm($directory, $form) {

// --------------
// This function prints a Back button which can be put into another form
// --------------

	printFunctionTags("printBackInForm", "begin");

	echo getAction("back", "document.$form.state.value='browse'; document.$form.state2.value='main'; document.$form.submit();") . " &nbsp ";

	printFunctionTags("printBackInForm", "end");

} // End function printBackInForm

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printForwardInForm($form) {

// --------------
// This function prints a forward button which can be put into another form
// --------------

	printFunctionTags("printForwardInForm", "begin");

	echo getAction("forward", "document.$form.submit();") . "<br /><br />\n";

	printFunctionTags("printForwardInForm", "end");

} // End function printForwardInForm

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printPHP_SELF($options) {

// --------------
// This function prints $PHP_SELF, the name of the script itself
// --------------

// -------------------------------------------------------------------------
// Global variables and settings
// -------------------------------------------------------------------------
	global $PHP_SELF, $net2ftp_ftpserver, $net2ftp_ftpserverport, $net2ftp_username, $net2ftp_password_encrypted, $net2ftp_language, $net2ftp_skin, $net2ftp_ftpmode, $net2ftp_passivemode, $net2ftp_sslconnect, $net2ftp_viewmode, $net2ftp_sort, $net2ftp_sortorder;
	global $state, $state2, $directory, $entry;

	$ftpserver          = htmlentities($net2ftp_ftpserver);
	$ftpserverport      = htmlentities($net2ftp_ftpserverport);
	$username           = htmlentities($net2ftp_username);
	$password_encrypted = htmlentities($net2ftp_password_encrypted);
	$language           = htmlentities($net2ftp_language);
	$skin               = htmlentities($net2ftp_skin);
	$ftpmode            = htmlentities($net2ftp_ftpmode);
	$passivemode        = htmlentities($net2ftp_passivemode);
	$sslconnect         = htmlentities($net2ftp_sslconnect);
	$viewmode           = htmlentities($net2ftp_viewmode);
	$sort               = htmlentities($net2ftp_sort);
	$sortorder          = htmlentities($net2ftp_sortorder);
	$state_html         = htmlentities($state);
	$state2_html        = htmlentities($state2);
	$directory_html     = htmlentities($directory);
	$entry_html         = htmlentities($entry);

	if ($options == "state") {
		// Password is not transmitted
		$URL = "$PHP_SELF?ftpserver=$ftpserver&amp;ftpserverport=$ftpserverport&amp;username=$username&amp;language=$language&amp;skin=$skin&amp;ftpmode=$ftpmode&amp;passivemode=$passivemode&amp;sslconnect=$sslconnect&amp;viewmode=$viewmode&amp;sort=$sort&amp;sortorder=$sortorder&amp;state=$state_html&amp;state2=$state2_html&amp;directory=$directory_html&amp;entry=$entry_html";
	}
	elseif ($options == "easyWebsite_edit") {
		// Used in easyWebsite() to link to the Edit screen:
		//     Password is transmitted
		//     $state and $state2 are not set
		//     $directory and $entry are not set
		$URL = "$PHP_SELF?ftpserver=$ftpserver&amp;ftpserverport=$ftpserverport&amp;username=$username&amp;password_encrypted=$password_encrypted&amp;language=$language&amp;skin=$skin&amp;ftpmode=$ftpmode&amp;passivemode=$passivemode&amp;sslconnect=$sslconnect&amp;viewmode=$viewmode&amp;sort=$sort&amp;sortorder=$sortorder";
	}
	elseif ($options == "easyWebsite_bookmark") {
		// Used in easyWebsite() to print the bookmark link:
		//     Password is not transmitted
		//     $state is set to easyWebsite, $screen is set to 4
		//     $directory is set (as the templates may be installed in any directory)
		$URL = "$PHP_SELF?ftpserver=$ftpserver&amp;ftpserverport=$ftpserverport&amp;language=$language&amp;skin=$skin&amp;ftpmode=$ftpmode&amp;passivemode=$passivemode&amp;sslconnect=$sslconnect&amp;viewmode=$viewmode&amp;sort=$sort&amp;sortorder=$sortorder&amp;state=easyWebsite&amp;screen=4&amp;directory=$directory_html";
	}
	elseif ($options == "image") {
		// Used in view():
		//     Password is transmitted
		//     $state2 is set to viewimage
		$URL = "$PHP_SELF?ftpserver=$ftpserver&amp;ftpserverport=$ftpserverport&amp;username=$username&amp;password_encrypted=$password_encrypted&amp;language=$language&amp;skin=$skin&amp;ftpmode=$ftpmode&amp;passivemode=$passivemode&amp;sslconnect=$sslconnect&amp;viewmode=$viewmode&amp;sort=$sort&amp;sortorder=$sortorder&amp;state=$state_html&amp;state2=viewimage&amp;directory=$directory_html&amp;entry=$entry_html";
	}
	else {
		$URL = $PHP_SELF;
	}

	return $URL;

} // End function printPHP_SELF

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function checkAuthorization($ftpserver, $ftpserverport, $directory) {

// --------------
// This function
//    checks if the FTP server is in the list of those that may be accessed
//    checks if the FTP server is in the list of those that may NOT be accessed
//    checks if the IP address is in the list of banned IP addresses
//    checks if the FTP server port is in the allowed range
// If all is OK, then the user may continue...
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $settings;
	$net2ftp_allowed_ftpservers    = $settings["net2ftp_allowed_ftpservers"];
	$net2ftp_banned_ftpservers     = $settings["net2ftp_banned_ftpservers"];
	$net2ftp_banned_addresses      = $settings["net2ftp_banned_addresses"];
	$net2ftp_allowed_ftpserverport = $settings["net2ftp_allowed_ftpserverport"];
	$rootdirectory                 = $settings["rootdirectory"];

	global $REMOTE_ADDR;

// -------------------------------------------------------------------------
// Check if the FTP server is in the list of those that may be accessed
// -------------------------------------------------------------------------
	if ($net2ftp_allowed_ftpservers[1] != "ALL") {       // net2ftp_allowed_servers contains either "ALL", either a list of allowed servers
		$result1 = array_search($ftpserver, $net2ftp_allowed_ftpservers);
		if ($result1 == false) {
			$errormessage = __("The FTP server <b>%1\$s</b> is not in the list of allowed FTP servers.", $ftpserver);
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}
	}

// -------------------------------------------------------------------------
// Check if the FTP server is in the list of those that may NOT be accessed
// -------------------------------------------------------------------------
	$result2 = array_search($ftpserver, $net2ftp_banned_ftpservers);
	if ($result2 != false) {
		$errormessage = __("The FTP server <b>%1\$s</b> is in the list of banned FTP servers.", $ftpserver);
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

// -------------------------------------------------------------------------
// Check if the IP address is in the list of banned IP addresses
// -------------------------------------------------------------------------
	$result3 = array_search($REMOTE_ADDR, $net2ftp_banned_addresses);
	if ($result3 != false) {
		$errormessage = __("Your IP address (%1\$s) is in the list of banned IP addresses.", $REMOTE_ADDR);
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

// -------------------------------------------------------------------------
// Check if the FTP server port is OK
// -------------------------------------------------------------------------
// Do not perform this check if ALL ports are allowed
	if ($net2ftp_allowed_ftpserverport != "ALL" ) {
// Report the error if another port nr has been entered than the one which is allowed
		if ($ftpserverport != $net2ftp_allowed_ftpserverport) {
			$errormessage = __("The FTP server port %1\$s may not be used.", $ftpserverport);
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}
	}

// -------------------------------------------------------------------------
// Check if the current directory is a subdirectory of the rootdirectory
// -------------------------------------------------------------------------
	if (isAuthorizedDirectory($directory) == false) {
		$errormessage = __("You don't have the authorizations to view directory <b>%1\$s</b>.", $directory);
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

// -------------------------------------------------------------------------
// If everything is OK, return true
// -------------------------------------------------------------------------
	return true;

} // end checkAuthorization

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function isAuthorizedDirectory($directory) {

// --------------
// This function checks if the directory is a subdirectory of the $rootdirectory
// The rootdirectory is first checked for the current user; if this is not set, the default rootdirectory is checked
// --------------

	global $net2ftp_username;

	$rootdirectory_to_check = getRootdirectory();

	if (isSubdirectory($rootdirectory_to_check, $directory) == false) { return false; }
	else { return true; }

} // end isAuthorizedDirectory

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function getRootdirectory() {

// --------------
// This function gets the user's rootdirectory:
//   - his own if it is set
//   - the default one if his is not set
//   - / if the default one is not set
// --------------

	global $net2ftp_username;
	global $settings;

	$rootdirectory = $settings["rootdirectory"];

	if (isset($rootdirectory["$net2ftp_username"]) == true) { $rootdirectory_to_check = $rootdirectory["$net2ftp_username"]; }
	elseif (isset($rootdirectory["default"]) == true)       { $rootdirectory_to_check = $rootdirectory["default"]; }
	else                                                    { $rootdirectory_to_check = "/"; }

	return $rootdirectory_to_check;

} // end getRootdirectory

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function isSubdirectory($parentdir, $childdir) {

// --------------
// Returns true if the childdir is a subdirectory of the parentdir
// --------------

	if ($parentdir == "" || $parentdir == "/" || $parentdir == "\\") { return true; }

	$parentdir = stripDirectory($parentdir);
	$childdir  = stripDirectory($childdir);

	if (substr($childdir, 0, strlen($parentdir)) == $parentdir) { return true; }
	else { return false; }
	
} // end isSubdirectory

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function logAccess() {

// --------------
// This function logs user accesses to the site
// Used in the function HtmlBegin(), see file html.inc.php
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $settings;
	global $net2ftp_ftpserver, $net2ftp_username;
	global $PHP_SELF, $REMOTE_ADDR, $REMOTE_PORT, $HTTP_USER_AGENT, $HTTP_REFERER;
	global $state, $state2, $directory, $entry;

// -------------------------------------------------------------------------
// Check if the logging of Errors is ON or OFF
// -------------------------------------------------------------------------

	if ($settings["log_access"] == "yes" && $settings["use_database"] == "yes") {

// -------------------------------------------------------------------------
// Input checks
// -------------------------------------------------------------------------
// Add slashes to variables which are used in a SQL query, and which are
// potentially unsafe (supplied by the user).
		// $date is calculated in this function
		// $time is calculated in this function
		$REMOTE_ADDR_safe       = addslashes($REMOTE_ADDR);
		$REMOTE_PORT_safe       = addslashes($REMOTE_PORT);
		$HTTP_USER_AGENT_safe   = addslashes($HTTP_USER_AGENT);
		$net2ftp_ftpserver_safe = addslashes($net2ftp_ftpserver);
		$net2ftp_username_safe  = addslashes($net2ftp_username); 
		$state_safe             = addslashes($state);
		$state2_safe            = addslashes($state2);
		$directory_safe         = addslashes($directory);
		$entry_safe             = addslashes($entry);
		$HTTP_REFERER_safe      = addslashes($HTTP_REFERER);
	
// -------------------------------------------------------------------------
// Connect to the DB
// -------------------------------------------------------------------------
		$mydb = connect2db();
		if ($execution_success == false) { return false; }

// -------------------------------------------------------------------------
// Log the accesses
// -------------------------------------------------------------------------
		$date = date("Y-m-d");
		$time = date("H:i:s");
		$sqlquerystring = "INSERT INTO net2ftp_logAccess VALUES('$date', '$time', '$REMOTE_ADDR_safe', '$REMOTE_PORT_safe', '$HTTP_USER_AGENT_safe', '$PHP_SELF', '$net2ftp_ftpserver_safe', '$net2ftp_username_safe', '$state_safe', '$state2_safe', '$directory_safe', '$entry_safe', '$HTTP_REFERER_safe')";
		$result1 = @mysql_query($sqlquerystring);
		if ($result1 == false) { 
			$errormessage = "Unable to execute the SQL query"; 
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}
//		$affectedofrows = @mysql_affected_rows($mydb);

	} // end if logAccesses

} // end logAccess()

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function logLogin($input_ftpserver, $input_username) {

// --------------
// This function logs user logins to the site
// Called from registerglobals.inc.php, and jupload.php
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $settings;
	global $REMOTE_ADDR, $REMOTE_PORT, $HTTP_USER_AGENT;

// -------------------------------------------------------------------------
// Check if the logging of Logins is ON or OFF
// -------------------------------------------------------------------------
	if ($settings["log_login"] == "yes" && $settings["use_database"] == "yes") {

// -------------------------------------------------------------------------
// Input checks
// -------------------------------------------------------------------------
// Add slashes to variables which are used in a SQL query, and which are
// potentially unsafe (supplied by the user).
		// $date is calculated in this function
		// $time is calculated in this function
		$input_ftpserver_safe   = addslashes($input_ftpserver);
		$input_username_safe    = addslashes($input_username); 
		$REMOTE_ADDR_safe       = addslashes($REMOTE_ADDR);
		$REMOTE_PORT_safe       = addslashes($REMOTE_PORT);
		$HTTP_USER_AGENT_safe   = addslashes($HTTP_USER_AGENT);
	
// -------------------------------------------------------------------------
// Connect to the DB
// -------------------------------------------------------------------------
		$mydb = connect2db();
		if ($execution_success == false) { return false; }

// -------------------------------------------------------------------------
// Log the Logins
// -------------------------------------------------------------------------
		$date = date("Y-m-d");
		$time = date("H:i:s");
		$sqlquerystring = "INSERT INTO net2ftp_logLogin VALUES('$date', '$time', '$input_ftpserver_safe', '$input_username_safe', '$REMOTE_ADDR_safe', '$REMOTE_PORT_safe', '$HTTP_USER_AGENT_safe')";
		$result1 = @mysql_query($sqlquerystring);
		if ($result1 == false) { 
			$errormessage = "Unable to execute the SQL query"; 
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}
//		$affectedofrows = @mysql_affected_rows($mydb);

	} // end if logLogins

} // end logLogin()

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function logError() {

// --------------
// This function logs user accesses to the site
//
// IMPORTANT: this function uses, but does not change the global $execution_* variables.
// It returns true on success, false on failure.
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success, $execution_errormessage, $execution_debug_backtrace;
	global $settings;
	global $net2ftp_ftpserver, $net2ftp_username;
	global $state, $state2, $directory;
	global $REMOTE_ADDR, $REMOTE_PORT, $HTTP_USER_AGENT;

// -------------------------------------------------------------------------
// Check if the logging of Errors is ON or OFF
// -------------------------------------------------------------------------
	if ($settings["log_error"] == "yes" && $settings["use_database"] == "yes") {

// -------------------------------------------------------------------------
// Take a copy of the $execution_* variables
// -------------------------------------------------------------------------
		$execution_success_original         = $execution_success;
		$execution_errormessage_original    = $execution_errormessage;
		$execution_debug_backtrace_original = $execution_debug_backtrace;
		setErrorVars(true, "", "");

// -------------------------------------------------------------------------
// Input checks
// -------------------------------------------------------------------------
// Add slashes to variables which are used in a SQL query, and which are
// potentially unsafe (supplied by the user).
		// $date is calculated in this function
		// $time is calculated in this function
		$net2ftp_ftpserver_safe = addslashes($net2ftp_ftpserver);
		$net2ftp_username_safe  = addslashes($net2ftp_username); 
		$state_safe             = addslashes($state);
		$state2_safe            = addslashes($state2);
		$directory_safe         = addslashes($directory);
		$REMOTE_ADDR_safe       = addslashes($REMOTE_ADDR);
		$REMOTE_PORT_safe       = addslashes($REMOTE_PORT);
		$HTTP_USER_AGENT_safe   = addslashes($HTTP_USER_AGENT);

// -------------------------------------------------------------------------
// Errormessage and debug backtrace
// -------------------------------------------------------------------------
		$errormessage = $execution_errormessage_original;

		$debug_backtrace = "";
		$i = count($execution_debug_backtrace_original)-1;
		$debug_backtrace .= "function " . $execution_debug_backtrace_original[$i]["function"] . " (" . $execution_debug_backtrace_original[$i]["file"] . " on line " . $execution_debug_backtrace_original[$i]["line"] . ")\n";
		for ($j=0; $j<count($execution_debug_backtrace_original[$i]["args"]); $j++) {
			$debug_backtrace .= "argument $j: " . $execution_debug_backtrace_original[$i]["args"][$j] . "\n";
		}

// -------------------------------------------------------------------------
// Connect to the DB
// -------------------------------------------------------------------------
		$mydb = connect2db();
		if ($execution_success == false) { return false; }

// -------------------------------------------------------------------------
// Log the Errors
// -------------------------------------------------------------------------
		$date = date("Y-m-d");
		$time = date("H:i:s");
		$sqlquerystring = "INSERT INTO net2ftp_logError VALUES('$date', '$time', '$net2ftp_ftpserver_safe', '$net2ftp_username_safe', '$errormessage', '$debug_backtrace', '$state_safe', '$state2_safe', '$directory_safe', '$REMOTE_ADDR_safe', '$REMOTE_PORT_safe', '$HTTP_USER_AGENT_safe')";
		$result_mysql_query = mysql_query($sqlquerystring);
		if ($result_mysql_query == false) { return false; }
//		$affectedofrows = @mysql_affected_rows($mydb);

// -------------------------------------------------------------------------
// Reset the $execution_* variables to their original value
// -------------------------------------------------------------------------
		setErrorVars($execution_success_original, $execution_errormessage_original, $execution_debug_backtrace_original);
		
	} // end if logErrors

	return true;
	
} // end logError()

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




?>