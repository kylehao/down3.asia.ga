<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **
function getLanguageArray() {

// --------------
// This function returns an array of languages
// Use the ISO 639 code described here: http://www.w3.org/WAI/ER/IG/ert/iso639.htm
// --------------

	$languageArray["zh"]["name"] = "Simplified Chinese";
	$languageArray["zh"]["file"] = "zh.inc.php";
	$languageArray["tc"]["name"] = "Traditional Chinese";
	$languageArray["tc"]["file"] = "tc.inc.php";
	$languageArray["cs"]["name"] = "Czech";
	$languageArray["cs"]["file"] = "cs.inc.php";
	$languageArray["nl"]["name"] = "Dutch";
	$languageArray["nl"]["file"] = "nl.inc.php";
	$languageArray["en"]["name"] = "English";
	$languageArray["en"]["file"] = "en.inc.php";
	$languageArray["fr"]["name"] = "French";
	$languageArray["fr"]["file"] = "fr.inc.php";
	$languageArray["de"]["name"] = "German";
	$languageArray["de"]["file"] = "de.inc.php";
	$languageArray["it"]["name"] = "Italian";
	$languageArray["it"]["file"] = "it.inc.php";
	$languageArray["pl"]["name"] = "Polish";
	$languageArray["pl"]["file"] = "pl.inc.php";
	$languageArray["pt"]["name"] = "Portugese";
	$languageArray["pt"]["file"] = "pt.inc.php";
	$languageArray["ru"]["name"] = "Russian";
	$languageArray["ru"]["file"] = "ru.inc.php";
	$languageArray["es"]["name"] = "Spanish";
	$languageArray["es"]["file"] = "es.inc.php";

	return $languageArray;

} // End function getLanguageArray

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **
function printLanguageSelect($fieldname, $onchange) {


// --------------
// This function prints a select with the available languages
// Language nr 1 is the default language
// --------------

// -------------------------------------------------------------------------
// Global variables and settings
// -------------------------------------------------------------------------
	global $net2ftp_language;
	$languageArray = getLanguageArray();

	if ($net2ftp_language != "") { $currentlanguage = $net2ftp_language; }
	else                         { $currentlanguage = "en"; }

	echo "<select name=\"$fieldname\" id=\"$fieldname\" onChange=\"$onchange\">\n";

	while (list($key,$value) = each($languageArray)) {
	// $key loops over "en", "fr", "nl", ...
	// $value will be an array like $value["name"] = "English" and $value["file"] = "en.inc.php"
		if ($key == $currentlanguage) { $selected = "selected"; }
		else                          { $selected = ""; }
		echo "<option value=\"" . $key . "\" $selected>" . $value["name"] . "</option>\n";
	} // end while

	echo "</select>\n";

} // End function printLanguageSelect

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************







// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function includeLanguageFile() {

	global $settings;
	global $net2ftp_language;                            // "en"
	global $application_languagesdir;                    // "/languages"
	global $messages;                                    // array with all messages
	$languageArray = getLanguageArray();                 // array of languages available

// If language exists, include the language file
	if (array_key_exists($net2ftp_language, $languageArray) == true) { 
		$languageFile = glueDirectories($application_languagesdir, $languageArray[$net2ftp_language]["file"]);
		include_once($languageFile); 
		$messages = getMessages();
	}

// If it does not exist, use the default language nr "en" (English)
	else { 
		$net2ftp_language = "en";
		$languageFile = glueDirectories($application_languagesdir, $languageArray[$net2ftp_language]["file"]);
		include_once($languageFile);
		$messages = getMessages();
	}

	return true;

} // end  function includeLanguageFile

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function __() {

// --------------
// This function returns a translated message; the core standard function used is sprintf (see manual)
// Input: - from function argument: message name $args[0] and variable parts in the message $args[1], $args[2],... 
//                               (there is a variable nr of variable parts)
//        - from globals: the array of messages $message
// Output: string in the language indicated in $net2ftp_language
// --------------

// -------------------------------------------------------------------------
// Global variables and settings
// -------------------------------------------------------------------------
	global $messages;
	global $net2ftp_language;

// -------------------------------------------------------------------------
// Get the arguments of this function
// $args[0] contains the messagename
// $args[1], $args[2], ... contain the variables in the message
// -------------------------------------------------------------------------
	$numargs = func_num_args();
	$args = func_get_args();
	$messagename = $args[0];

// -------------------------------------------------------------------------
// Normally the language file is included in index.php.
// However, sometimes something goes wrong at the very beginning of the script, even
// before the language file is included.
// -------------------------------------------------------------------------
	if ($messages == "") { includeLanguageFile(); }

// -------------------------------------------------------------------------
// Create the argument for the sprintf function
// Aim is to have something like:  sprintf($string_with_percents, $args[1], $args[2], ...);
// As there is a variable nr of arguments in the function __, there is also a variable 
// nr of arguments in sprintf, and this must be constructed with a loop
// -------------------------------------------------------------------------

// Check if the message with that $messagename exists
	if (@array_key_exists($messagename, $messages)) { $string_with_percents = $messages[$messagename]; }
	else { return "MESSAGE NOT FOUND"; }

	$sprintf_argument = "\$translated_string = sprintf(\$string_with_percents";

	for ($i=1; $i<$numargs; $i++) {
		$sprintf_argument .= ", \$args[$i]";
	} // end for

	$sprintf_argument .= ");";

// -------------------------------------------------------------------------
// Run the sprintf function
// -------------------------------------------------------------------------
	eval($sprintf_argument);

	return $translated_string;

} // end function __

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************

?>