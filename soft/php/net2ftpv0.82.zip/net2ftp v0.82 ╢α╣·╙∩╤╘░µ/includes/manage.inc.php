<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function manage($state2, $directory, $entry, $list, $newNames, $formresult, $screen, $targetDirectories, $copymovedelete, $text, $textareaType, $uploadedFilesArray, $uploadedArchivesArray, $use_folder_names, $command, $to, $message, $zipactions, $searchoptions, $comparison) {

// --------------
// This function allows to manage a file: view/edit/rename/delete
// The real action is done in subfunctions
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $settings;

// Filter the list entries which were selected from the ones that were not selected
	$list = getSelectedEntries($list);

// Check that at least one entry was chosen
	if (sizeof($list) < 1 && $state2 != "view" && $state2 != "viewimage" && $state2 != "edit" && $state2 != "newdirectory" && $state2 != "newfile" && $state2 != "uploadfile" && $state2 != "javaupload" && $state2 != "updatefile") {
		$errormessage = __("Please select at least one directory or file!");
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

	switch ($state2) {
		case "copy":
			if ($settings['functionuse_copy'] == "yes") {
				copymovedeleteentry($directory, $list, $targetDirectories, $newNames, "copy", $formresult);
			}
			else {
				$errormessage = __("This function has been disabled by the Administrator of this website.");
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}
		break;
		case "move":
			if ($settings['functionuse_move'] == "yes") {
				copymovedeleteentry($directory, $list, $targetDirectories, $newNames, "move", $formresult);
			}
			else {
				$errormessage = __("This function has been disabled by the Administrator of this website.");
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}
		break;
		case "delete":
			if ($settings['functionuse_delete'] == "yes") {
				copymovedeleteentry($directory, $list, $targetDirectories, $newNames, "delete", $formresult);
			}
			else {
				$errormessage = __("This function has been disabled by the Administrator of this website.");
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}
		break;
		case "rename":
			if ($settings['functionuse_rename'] == "yes") {
				renameentry($directory, $list, $newNames, $formresult);
			}
			else {
				$errormessage = __("This function has been disabled by the Administrator of this website.");
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}
		break;
		case "chmod":
			if ($settings['functionuse_chmod'] == "yes") {
				chmodentry($directory, $list, $formresult);
			}
			else {
				$errormessage = __("This function has been disabled by the Administrator of this website.");
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}
		break;
		case "download":
			// Everything is done in httpheaders.inc.php
		break;
		case "zip":
			if ($settings['functionuse_zip_save_email'] == "yes") {
				zipentry($directory, $list, $zipactions, $newNames, $to, $message, $formresult);
			}
			else {
				$errormessage = __("This function has been disabled by the Administrator of this website.");
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}
		break;
		case "calculatesize":
			if ($settings['functionuse_calculatesize'] == "yes") {
				calculatesize($directory, $list);
			}
			else {
				$errormessage = __("This function has been disabled by the Administrator of this website.");
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}
		break;
		case "findstring":
			if ($settings['functionuse_findstring'] == "yes") {
				findstring($directory, $list, $searchoptions, $formresult);
			}
			else {
				$errormessage = __("This function has been disabled by the Administrator of this website.");
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}
		break;
// Directory specific
		case "newdirectory":
			if ($settings['functionuse_newdirectory'] == "yes") { 
				newdirectory($directory, $newNames, $formresult); 
			}
			else {
				$errormessage = __("This function has been disabled by the Administrator of this website.");
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}
		break;
// File specific
		case "view":
			if ($settings['functionuse_view'] == "yes") {
				view($directory, $entry);
			}
			else {
				$errormessage = __("This function has been disabled by the Administrator of this website.");
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}
		break;
		case "edit":
			if ($settings['functionuse_edit'] == "yes") {
				edit($directory, $entry, $text, $formresult);
			}
			else {
				$errormessage = __("This function has been disabled by the Administrator of this website.");
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}
		break;
		case "newfile":
			if ($settings['functionuse_newfile'] == "yes") {
				edit($directory, $newNames[0], $text, $textareaType, $formresult);
			}
			else {
				$errormessage = __("This function has been disabled by the Administrator of this website.");
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}
		break;
		case "uploadfile":
			if ($settings['functionuse_uploadfile'] == "yes") {
				uploadfile($directory, $uploadedFilesArray, $uploadedArchivesArray, $use_folder_names, $formresult);
			}
			else {
				$errormessage = __("This function has been disabled by the Administrator of this website.");
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}
		break;
		case "javaupload":
			if ($settings['functionuse_javaupload'] == "yes") {
				javaupload($directory);
			}
			else {
				$errormessage = __("This function has been disabled by the Administrator of this website.");
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}
		break;
		case "updatefile":
			if ($settings['functionuse_updatefile'] == "yes") {
				updatefile($directory, $entry, $uploadedFilesArray, $comparison, $screen); 
			}
			else {
				$errormessage = __("This function has been disabled by the Administrator of this website.");
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}
		break;
// Default
		default:
			$errormessage = __("Unexpected state2 string. Exiting.");
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
  		break;

	} // End switch

} // End function manage

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function renameentry($directory, $list, $newNames, $formresult) {

// --------------
// This function allows to rename a directory or file
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;

// -------------------------------------------------------------------------
// Initial checks
// -------------------------------------------------------------------------

	echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
	echo "<tr>\n";
	echo "<td>\n";
	printTitle(__("Rename directories and files"));

// -------------------------------------------------------------------------
// Form
// -------------------------------------------------------------------------

	if ($formresult != "result") {
		echo "<form name=\"RenameForm\" id=\"RenameForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
		printLoginInfo();
		echo "<input type=\"hidden\" name=\"state\" value=\"manage\" />\n";
		echo "<input type=\"hidden\" name=\"state2\" value=\"rename\" />\n";
		echo "<input type=\"hidden\" name=\"directory\" value=\"$directory\" />\n";
		echo "<input type=\"hidden\" name=\"formresult\" value=\"result\" />\n";

		printBackInForm($directory, "RenameForm");
		printForwardInForm("RenameForm");

		for ($i=1; $i<=count($list); $i++) {
			printDirFileProperties($i, $list[$i], "hidden", "");
			echo __("Old name: ") . "<b>" . $list[$i]['dirfilename'] . "</b><br />\n";
			echo __("New name: ") . "<input type=\"text\" class=\"input\" name=\"newNames[$i]\" value=\"" . $list[$i]['dirfilename'] . "\" /><br /><br />\n";
		} // End for

		echo "</form>\n";
	}

// -------------------------------------------------------------------------
// Result
// -------------------------------------------------------------------------

	elseif ($formresult == "result") {

		printBack($directory);

// Open connection
		setStatus_php(2, 10, __("Connecting to the FTP server"));
		$conn_id = ftp_openconnection();
		if ($execution_success == false) { return false; }

// Rename files
		setStatus_php(4, 10, __("Processing the entries"));
		for ($i=1; $i<=count($list); $i++) {
			if (strstr($list[$i]['dirfilename'], "..") != false) {
				echo __("The new name may not contain any dots. This entry was not renamed to <b>%1\$s</b>", $list[$i]['dirfilename']) . "<br />";
				continue;
			}
			ftp_myrename($conn_id, $directory, $list[$i]['dirfilename'], $newNames[$i]);	// filesystem.inc.php
			if ($execution_success ==	false) { setErrorVars(true, "", ""); printWarningMessage(__("<b>%1\$s</b> could not be renamed to <b>%2\$s</b>", $list[$i]['dirfilename'], $newNames[$i]) . "<br />"); continue; }
			else { echo __("<b>%1\$s</b> was successfully renamed to <b>%2\$s</b>", $list[$i]['dirfilename'], $newNames[$i]) . "<br />"; }
		} // End for

// Close connection
		ftp_closeconnection($conn_id);

	} // End if elseif (form or result)

	echo "</td>\n";
	echo "</tr>\n";
	echo "</table>\n";

} // End function renameentry

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function chmodentry($directory, $list, $formresult) {

// --------------
// This function allows to chmod a directory or file
// The initial permissions are contained in $list[$i]['permissions'], and are coming from the browse view
// The permissions to be set are contained in chmodoctal
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;

// -------------------------------------------------------------------------
// Initial checks
// -------------------------------------------------------------------------

	echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
	echo "<tr>\n";
	echo "<td>\n";
	printTitle(__("Chmod directories and files"));

// -------------------------------------------------------------------------
// Form
// -------------------------------------------------------------------------

	if ($formresult != "result") {

		echo "<form name=\"ChmodForm\" id=\"ChmodForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
		printLoginInfo();
		echo "<input type=\"hidden\" name=\"state\" value=\"manage\" />\n";
		echo "<input type=\"hidden\" name=\"state2\" value=\"chmod\" />\n";
		echo "<input type=\"hidden\" name=\"directory\" value=\"$directory\" />\n";
		echo "<input type=\"hidden\" name=\"formresult\" value=\"result\" />\n";
		printBackInForm($directory, "ChmodForm");
		printForwardInForm("ChmodForm");

// Header
		echo "<table style=\"border-color: #000000; border-style: solid; border-width: 1px; padding: 5px;\">\n";
		echo "<tr><td>\n";

		echo "<table border=\"0\" cellspacing=\"2\" cellpadding=\"2\" style=\"margin-left: 5px;\">\n";
		echo "	<tr>\n";
		echo "		<td rowspan=\"4\" valign=\"top\"><input type=\"button\" class=\"extralongbutton\" value=\"" . __("Set all permissions") . "\" onClick=\"";
		echo "		CopyCheckboxToAll(document.ChmodForm, 'header[owner_read]',    'owner_read'); ";
		echo "		CopyCheckboxToAll(document.ChmodForm, 'header[owner_write]',   'owner_write'); ";
		echo "		CopyCheckboxToAll(document.ChmodForm, 'header[owner_execute]', 'owner_execute'); ";
		echo "		CopyCheckboxToAll(document.ChmodForm, 'header[group_read]',    'group_read'); ";
		echo "		CopyCheckboxToAll(document.ChmodForm, 'header[group_write]',   'group_write'); ";
		echo "		CopyCheckboxToAll(document.ChmodForm, 'header[group_execute]', 'group_execute'); ";
		echo "		CopyCheckboxToAll(document.ChmodForm, 'header[other_read]',    'other_read'); ";
		echo "		CopyCheckboxToAll(document.ChmodForm, 'header[other_write]',   'other_write'); ";
		echo "		CopyCheckboxToAll(document.ChmodForm, 'header[other_execute]', 'other_execute'); ";
		echo "    update_input(); \" /></td>\n";

		echo "	</tr>\n";
		echo "	<tr>\n";
		echo "		<td>" . __("Owner") . ":</td>\n";
		echo "		<td><input type=\"checkbox\" name=\"header[owner_read]\" value=\"4\">" . __("Read") . "</td>\n";
		echo "		<td><input type=\"checkbox\" name=\"header[owner_write]\" value=\"2\">" . __("Write") . "</td>\n";
		echo "		<td><input type=\"checkbox\" name=\"header[owner_execute]\" value=\"1\">" . __("Execute") . "</td>\n";
		echo "	</tr>\n";
		echo "	<tr>\n";
		echo "		<td>" . __("Group") . ":</td>\n";
		echo "		<td><input type=\"checkbox\" name=\"header[group_read]\" value=\"4\">" . __("Read") . "</td>\n";
		echo "		<td><input type=\"checkbox\" name=\"header[group_write]\" value=\"2\">" . __("Write") . "</td>\n";
		echo "		<td><input type=\"checkbox\" name=\"header[group_execute]\" value=\"1\">" . __("Execute") . "</td>\n";
		echo "	</tr>\n";
		echo "	<tr>\n";
		echo "		<td>" . __("Everyone") . ":</td>\n";
		echo "		<td><input type=\"checkbox\" name=\"header[other_read]\" value=\"4\">" . __("Read") . "</td>\n";
		echo "		<td><input type=\"checkbox\" name=\"header[other_write]\" value=\"2\">" . __("Write") . "</td>\n";
		echo "		<td><input type=\"checkbox\" name=\"header[other_execute]\" value=\"1\">" . __("Execute") . "</td>\n";
		echo "	</tr>\n";
		echo "</table>\n";

		echo "<div style=\"font-size: 65%\">" . __("To set all permissions to the same values, enter those permissions above and click on the button \"Set all permissions\"") . "</div>\n";
		echo "</td></tr>\n";
		echo "</table>\n";
		echo "<br />";

// Items
		for ($i=1; $i<=count($list); $i++) {
			printDirFileProperties($i, $list[$i], "hidden", "");

			if     ($list[$i]['dirorfile'] == "d")   { echo __("Set the permissions of directory <b>%1\$s</b> to: ", $list[$i]['dirfilename']) . "<br />\n"; }
			elseif ($list[$i]['dirorfile'] == "-")   { echo __("Set the permissions of file <b>%1\$s</b> to: ", $list[$i]['dirfilename']) . "<br />\n"; }
			elseif ($list[$i]['dirorfile'] == "l")   { echo __("Set the permissions of symlink <b>%1\$s</b> to: ", $list[$i]['dirfilename']) . "<br />\n"; }


			$owner_chmod = 0;
			if (substr($list[$i]['permissions'], 0, 1) == "r") { $owner_chmod+=4; $owner_read = "checked=\"checked\""; }
			else $owner_read = "";
			if (substr($list[$i]['permissions'], 1, 1) == "w") { $owner_chmod+=2; $owner_write = "checked=\"checked\"";  }
			else $owner_write = "";
			if (substr($list[$i]['permissions'], 2, 1) == "x") { $owner_chmod+=1; $owner_execute = "checked=\"checked\"";  }
			else $owner_execute = "";

			$group_chmod = 0;
			if (substr($list[$i]['permissions'], 3, 1) == "r") { $group_chmod+=4; $group_read = "checked=\"checked\"";  }
			else $group_read = "";
			if (substr($list[$i]['permissions'], 4, 1) == "w") { $group_chmod+=2; $group_write = "checked=\"checked\"";  }
			else $group_write = "";
			if (substr($list[$i]['permissions'], 5, 1) == "x") { $group_chmod+=1; $group_execute = "checked=\"checked\"";  }
			else $group_execute = "";

			$other_chmod = 0;
			if (substr($list[$i]['permissions'], 6, 1) == "r") { $other_chmod+=4; $other_read = "checked=\"checked\"";  }
			else $other_read = "";
			if (substr($list[$i]['permissions'], 7, 1) == "w") { $other_chmod+=2; $other_write = "checked=\"checked\"";  }
			else $other_write = "";
			if (substr($list[$i]['permissions'], 8, 1) == "x") { $other_chmod+=1; $other_execute = "checked=\"checked\"";  }
			else $other_execute = "";

			$chmod_value = $owner_chmod.$group_chmod.$other_chmod;

			echo "<table border=\"0\" cellspacing=\"2\" cellpadding=\"2\" style=\"margin-left: 20px;\">\n";
			echo "	<tr>\n";
			echo "		<td>" . __("Owner") . ":</td>\n";
			echo "		<td><input type=\"checkbox\" name=\"list[$i][owner_read]\" value=\"4\" onclick=\"update_input($i);\" $owner_read />" . __("Read") . "</td>\n";
			echo "		<td><input type=\"checkbox\" name=\"list[$i][owner_write]\" value=\"2\" onclick=\"update_input($i);\" $owner_write />" . __("Write") . "</td>\n";
			echo "		<td><input type=\"checkbox\" name=\"list[$i][owner_execute]\" value=\"1\" onclick=\"update_input($i);\" $owner_execute />" . __("Execute") . "</td>\n";
			echo "	</tr>\n";
			echo "	<tr>\n";
			echo "		<td>" . __("Group") . ":</td>\n";
			echo "		<td><input type=\"checkbox\" name=\"list[$i][group_read]\" value=\"4\" onclick=\"update_input($i);\" $group_read />" . __("Read") . "</td>\n";
			echo "		<td><input type=\"checkbox\" name=\"list[$i][group_write]\" value=\"2\" onclick=\"update_input($i);\" $group_write />" . __("Write") . "</td>\n";
			echo "		<td><input type=\"checkbox\" name=\"list[$i][group_execute]\" value=\"1\" onclick=\"update_input($i);\" $group_execute />" . __("Execute") . "</td>\n";
			echo "	</tr>\n";
			echo "	<tr>\n";
			echo "		<td>" . __("Everyone") . ":</td>\n";
			echo "		<td><input type=\"checkbox\" name=\"list[$i][other_read]\" value=\"4\" onclick=\"update_input($i);\" $other_read />" . __("Read") . "</td>\n";
			echo "		<td><input type=\"checkbox\" name=\"list[$i][other_write]\" value=\"2\" onclick=\"update_input($i);\" $other_write />" . __("Write") . "</td>\n";
			echo "		<td><input type=\"checkbox\" name=\"list[$i][other_execute]\" value=\"1\" onclick=\"update_input($i);\" $other_execute />" . __("Execute") . "</td>\n";
			echo "	</tr>\n";
			echo "  <tr>\n";
			echo "    <td colspan=4>" . __("Chmod value") . ": <input class=\"smallinput\" value=\"$chmod_value\" name=\"chmod$i\" id=\"chmod$i\" onChange=\"update_checkbox($i);\" /></td>\n";
			echo "  </tr>\n";
			echo "</table>\n";

			if     ($list[$i]['dirorfile'] == "d")   {
				echo "<input type=\"checkbox\" name=\"list[$i][chmod_subdirectories]\" value=\"yes\" checked /> " . __("Chmod also the subdirectories within this directory") . "<br />\n";
				echo "<input type=\"checkbox\" name=\"list[$i][chmod_subfiles]\"          value=\"yes\" checked /> " . __("Chmod also the files within this directory") . "<br />\n";
			}

			echo "<br /><br />\n";

		} // End for

		echo "</form>\n";
	}

// -------------------------------------------------------------------------
// Result
// -------------------------------------------------------------------------

	elseif ($formresult == "result") {

		printBack($directory);

// Calculate the chmod octal
		for ($i=1; $i<=count($list); $i++) {
			$ownerOctal = $list[$i]['owner_read'] + $list[$i]['owner_write'] + $list[$i]['owner_execute'];
			$groupOctal = $list[$i]['group_read'] + $list[$i]['group_write'] + $list[$i]['group_execute'];
			$otherOctal = $list[$i]['other_read'] + $list[$i]['other_write'] + $list[$i]['other_execute'];

			$chmodOctal = $ownerOctal . $groupOctal . $otherOctal;

			if ($chmodOctal > 777 || $chmodOctal < 0) {
				$errormessage = __("The chmod nr <b>%1\$s</b> is out of the range 000-777. Please try again.", $chmodOctal);
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}
			else { $list[$i]['chmodoctal'] = $chmodOctal; }

		} // End for

// Open connection
		setStatus_php(2, 10, __("Connecting to the FTP server"));
		$conn_id = ftp_openconnection();
		if ($conn_id == false) { return false; }

// Chmod the entries
		setStatus_php(4, 10, __("Processing the entries"));
		ftp_mychmod($conn_id, $directory, $list, 0);
		if ($execution_success == false)  { return false; }

// Close connection
		ftp_closeconnection($conn_id);

	} // End if elseif (form or result)

	echo "</td>\n";
	echo "</tr>\n";
	echo "</table>\n";


} // End function chmodentry

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function copymovedeleteentry($directory, $list, $targetDirectories, $newNames, $copymovedelete, $formresult) {

// --------------
// This function allows to copy or move a directory or file
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $input_ftpserver2, $input_username2;


// -------------------------------------------------------------------------
// Initial checks
// -------------------------------------------------------------------------
	if (($copymovedelete != "move" && $copymovedelete != "delete")) { $copymovedelete = "copy"; }

	echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
	echo "<tr>\n";
	echo "<td>\n";
	if ($copymovedelete == "copy")       { printTitle(__("Copy directories and files")); }
	elseif ($copymovedelete == "move")   { printTitle(__("Move directories and files")); }
	elseif ($copymovedelete == "delete") { printTitle(__("Delete directories and files")); }


// -------------------------------------------------------------------------
// Show form
// -------------------------------------------------------------------------
	if ($formresult != "result") {

// Hidden stuff
		echo "<form name=\"CopyMoveDeleteForm\" id=\"CopyMoveDeleteForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
		printLoginInfo();
		echo "<input type=\"hidden\" name=\"state\" value=\"manage\" />\n";
		echo "<input type=\"hidden\" name=\"state2\" value=\"$copymovedelete\" />\n";
		echo "<input type=\"hidden\" name=\"directory\" value=\"$directory\" />\n";
		echo "<input type=\"hidden\" name=\"formresult\" value=\"result\" />\n";
		printBackInForm($directory, "CopyMoveDeleteForm");
		printForwardInForm("CopyMoveDeleteForm");

// Title and text
		if ($copymovedelete == "delete") { 
			echo __("Are you sure you want to delete these directories and files?") . "<br />\n";
			echo __("All the subdirectories and files of the selected directories will also be deleted!") . "<br /><br />\n"; 
		}

// Header: directory and button to copy text to all target directory textboxes -- only for copy/move
		if ($copymovedelete != "delete") {
			echo "<table style=\"border-color: #000000; border-style: solid; border-width: 1px; padding: 10px;\">\n";
			echo "<tr><td>\n";
			echo "<input type=\"button\" class=\"extralongbutton\" value=\"" . __("Set all targetdirectories") . "\" onClick=\"CopyValueToAll(document.CopyMoveDeleteForm, document.CopyMoveDeleteForm.headerDirectory, 'targetdirectory');\" /> &nbsp; \n";
			echo "<input type=\"text\" class=\"longinput\" name=\"headerDirectory\" value=\"$directory\" />\n";
			printDirectoryTreeLink($directory, "CopyMoveDeleteForm.headerDirectory");
			echo "<div style=\"font-size: 65%\">" . __("To set a common target directory, enter that target directory in the textbox above and click on the button \"Set all targetdirectories\".") . "</div>\n";
			echo "<div style=\"font-size: 65%\">" . __("Note: the target directory must already exist before anything can be copied into it.") . "</div>\n";
			echo "</td></tr>\n";
			echo "</table>\n";
		} // End if

		echo "<br />";

// Header: option to copy/move to a different FTP server -- only for copy/move
		if ($copymovedelete != "delete") {

			echo "<table style=\"border-color: #000000; border-style: solid; border-width: 1px; padding: 10px; margin-right: 100px; margin-bottom: 30px;\">\n";
			echo "<tr>\n";
			echo "<td valign=\"top\" width=\"40%\">" . __("Different target FTP server:") . "</td>\n";
			echo "<td>\n";
			echo "<input type=\"text\" class=\"input\" name=\"input_ftpserver2\" value=\"$net2ftpcookie_ftpserver\" /> port \n";
			if ($net2ftpcookie_ftpserverport != "") {
				echo "<input type=\"text\" class=\"input\" size=\"3\" maxlength=\"5\" name=\"input_ftpserverport2\" value=\"$net2ftpcookie_ftpserverport\" />\n";
			}
			else {
				echo "<input type=\"text\" class=\"input\" size=\"3\" maxlength=\"5\" name=\"input_ftpserverport2\" value=\"21\" />\n";
			}

			echo "</td>\n";
			echo "</tr>\n";

			echo "<tr>\n";
			echo "<td>" . __("Username") . ":</td>\n";
			echo "<td><input type=\"text\" class=\"input\" name=\"input_username2\" value=\"$net2ftpcookie_username\" /></td>\n";
			echo "</tr>\n";

			echo "<tr>\n";
			echo "<td>" . __("Password") . ":</td>\n";
			echo "<td><input type=\"password\" class=\"input\" name=\"input_password2\" /></td>\n";
			echo "</tr>\n";

			echo "<tr>\n";
			echo "<td colspan=\"2\">\n";
			echo "<div style=\"font-size: 65%;\">\n";

			if ($copymovedelete == "copy")       {
				echo __("Leave empty if you want to copy the files to the same FTP server.") . "<br />\n";
				echo __("If you want to copy the files to another FTP server, enter your login data.") . "\n";
			}
			elseif ($copymovedelete == "move")   {
				echo __("Leave empty if you want to move the files to the same FTP server.") . "<br />\n";
				echo __("If you want to move the files to another FTP server, enter your login data.") . "\n";
			}
			echo "</div>\n";
			echo "</td>\n";
			echo "</tr>\n";

			echo "</table>\n";
		} // End if

// Items
		for ($i=1; $i<=count($list); $i++) {

			printDirFileProperties($i, $list[$i], "hidden", "");

			if     ($copymovedelete == "copy" && $list[$i]['dirorfile']   == "d") { echo __("Copy directory <b>%1\$s</b> to:", $list[$i]['dirfilename']) . "<br />\n"; }
			elseif ($copymovedelete == "move" && $list[$i]['dirorfile']   == "d") { echo __("Move directory <b>%1\$s</b> to:", $list[$i]['dirfilename']) . "<br />\n"; }
			elseif ($copymovedelete == "delete" && $list[$i]['dirorfile'] == "d") { echo __("Directory <b>%1\$s</b>", $list[$i]['dirfilename']) . "<br />\n"; }
			elseif ($copymovedelete == "copy" && $list[$i]['dirorfile']   == "-") { echo __("Copy file <b>%1\$s</b> to:", $list[$i]['dirfilename']) . "<br />\n"; }
			elseif ($copymovedelete == "move" && $list[$i]['dirorfile']   == "-") { echo __("Move file <b>%1\$s</b> to:", $list[$i]['dirfilename']) . "<br />\n"; }
			elseif ($copymovedelete == "delete" && $list[$i]['dirorfile'] == "-") { echo __("File <b>%1\$s</b>", $list[$i]['dirfilename']) . "<br />\n"; }
			elseif ($copymovedelete == "copy" && $list[$i]['dirorfile']   == "l") { echo __("Copy symlink <b>%1\$s</b> to:", $list[$i]['dirfilename']) . "<br />\n"; }
			elseif ($copymovedelete == "move" && $list[$i]['dirorfile']   == "l") { echo __("Move symlink <b>%1\$s</b> to:", $list[$i]['dirfilename']) . "<br />\n"; }
			elseif ($copymovedelete == "delete" && $list[$i]['dirorfile'] == "l") { echo __("Symlink <b>%1\$s</b>", $list[$i]['dirfilename']) . "<br />\n"; }

// Options

			echo "<input type=\"hidden\" name=\"list[$i][sourcedirectory]\" value=\"$directory\" />\n";

//    Copy or move: ask for options
			if ($copymovedelete != "delete") {
				echo "<table>\n";
				echo "<tr><td>\n";
				echo __("Target directory:") . " </td><td><input type=\"text\" class=\"longinput\" name=\"list[$i][targetdirectory]\" value=\"$directory\" />\n";

				printDirectoryTreeLink($directory, "CopyMoveDeleteForm.elements[\'list[$i][targetdirectory]\']");

				echo "</td></tr>\n";
				echo "<tr><td>\n";
				echo __("Target name:") . "      </td><td><input type=\"text\" class=\"input\" name=\"list[$i][newname]\" value=\"" . $list[$i]['dirfilename'] . "\" /></td></tr>\n";
				echo "</table><br />\n";
			}

		} // End for
		echo "</form>\n";
	}

// -------------------------------------------------------------------------
// Show result
// -------------------------------------------------------------------------
	elseif ($formresult == "result") {

		printBack($directory);

		echo "<b><u>" . __("Processing the entries:") . "</u></b> <br />\n";

// Open connection to the source server
		setStatus_php(2, 10, __("Connecting to the FTP server"));
		$conn_id_source = ftp_openconnection();
		if ($execution_success == false)  { return false; }

// Open connection to the target server, if it is different from the source server, or if the username
// is different (different users may have different authorizations on the same FTP server)
		if (($input_ftpserver2 != $net2ftp_ftpserver) || ($input_username2 != $net2ftp_username)) {
			$conn_id_target = ftp_openconnection2();       // Note: ftp_openconnection2 cleans the input values
			if ($execution_success == false)  { return false; }
		}
		else { $conn_id_target = $conn_id_source; }

// Copy, move or delete the files and directories
		setStatus_php(4, 10, __("Processing the entries"));
		ftp_copymovedelete($conn_id_source, $conn_id_target, $list, $copymovedelete, 0);

// Close the connection to the source server
		ftp_closeconnection($conn_id_source);

// Close the connection to the target server, if it is different from the source server
		if ($conn_id_source != $conn_id_target) { ftp_closeconnection($conn_id_target); }

	} // End if elseif (form or result)

	echo "</td>\n";
	echo "</tr>\n";
	echo "</table>\n";

} // End function copymovedeleteentry

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************







// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function newdirectory($directory, $newNames, $formresult) {

// --------------
// This function allows to make a new directory
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;

	echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
	echo "<tr>\n";
	echo "<td>\n";
	printTitle(__("Create new directories"));

	if (strlen($directory) > 0) { $printdirectory = $directory; }
	else                        { $printdirectory = "/"; }

// -------------------------------------------------------------------------
// Show form
// -------------------------------------------------------------------------

	if ($formresult != "result") {
		echo "<form name=\"NewForm\" id=\"NewForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
		printLoginInfo();
		echo "<input type=\"hidden\" name=\"state\" value=\"manage\" />\n";
		echo "<input type=\"hidden\" name=\"state2\" value=\"newdirectory\" />\n";
		echo "<input type=\"hidden\" name=\"directory\" value=\"$directory\" />\n";
		echo "<input type=\"hidden\" name=\"formresult\" value=\"result\" />\n";
		printBackInForm($directory, "NewForm");
		printForwardInForm("NewForm");

		echo __("The new directories will be created in <b>%1\$s</b>.", $printdirectory) . "<br /><br />\n";

		for ($k=1; $k<=5; $k++) {
			echo __("New directory name:") . " <input type=\"text\" class=\"input\" name=\"newNames[$k]\" /><br /><br />\n";
		} // End for

		echo "</form>\n";
	}

// -------------------------------------------------------------------------
// Show result
// -------------------------------------------------------------------------

	elseif ($formresult == "result") {

		printBack($directory);

// Open connection
		setStatus_php(2, 10, __("Connecting to the FTP server"));
		$conn_id = ftp_openconnection();
		if ($execution_success == false)  { return false; }

// Create new directories
		setStatus_php(4, 10, __("Processing the entries"));
		for ($k=1; $k<=count($newNames); $k++) {
			if (strlen($newNames[$k]) > 0) {
				$newsubdir = glueDirectories($directory, $newNames[$k]);		// filesystem.inc.php
				ftp_newdirectory($conn_id, $newsubdir);
				if ($execution_success == false)  { return false; }
				else { echo __("Directory <b>%1\$s</b> was successfully created.", $newNames[$k]) . "<br />"; }
			} // End if
		} // End for

// Close connection
		ftp_closeconnection($conn_id);

	} // End if elseif (form or result)

	echo "</td>\n";
	echo "</tr>\n";
	echo "</table>\n";

} // End function newdirectory

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

// function newfile()
//
//    is now implemented using the edit() function
//

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function uploadfile($directory, $uploadedFilesArray, $uploadedArchivesArray, $use_folder_names, $formresult) {

// --------------
// This function allows to upload a file to a directory
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $application_tempdir;

	echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
	echo "<tr>\n";
	echo "<td>\n";

// -------------------------------------------------------------------------
// Form
// -------------------------------------------------------------------------

	if ($formresult != "result") {

		printTitle(__("Upload files and archives"));
		printUploadForm($directory);

	} // end if (show form, show result)

// -------------------------------------------------------------------------
// Result
// -------------------------------------------------------------------------
	else {

// -------------------------------------------------------------------------
// Results
// -------------------------------------------------------------------------

		printTitle(__("Upload results"));

		printBack($directory);

		echo "<table style=\"border-color: #000000; border-style: solid; border-width: 1px; padding: 10px; margin-right: 100px; margin-bottom: 30px;\">\n";
		echo "<tr>\n";
		echo "<td>\n";

// ---------------------------------------
// Check the files and move them to the net2ftp temp directory
// The .txt extension is added
// ---------------------------------------
		if (sizeof($uploadedFilesArray) > 0 || sizeof($uploadedArchivesArray) > 0) {
			setStatus_php(1, 10, __("Checking files"));

			echo "<b><u>" . __("Checking files:") . "</u></b> <br />\n";
			echo "<ul>\n";
			if (sizeof($uploadedFilesArray) > 0) {
				$acceptedFilesArray = acceptFiles($uploadedFilesArray);
				if ($execution_success == false)  { return false; }
			}
			if (sizeof($uploadedArchivesArray) > 0) {
				$acceptedArchivesArray = acceptFiles($uploadedArchivesArray);
				if ($execution_success == false)  { return false; }
			}
			echo "</ul>\n";
		}

// ---------------------------------------
// Transfer files
// ---------------------------------------
		if ($acceptedFilesArray != "all_uploaded_files_are_too_big" && sizeof($acceptedFilesArray) > 0) {
			setStatus_php(0, 10, __("Transferring files to the FTP server"));

			echo "<b><u>" . __("Transferring files to the FTP server:") . "</u></b> <br />\n";
			echo "<ul>\n";

			ftp_transferfiles($acceptedFilesArray, $application_tempdir, $directory);
			if ($execution_success == false)  { return false; }

			echo "</ul>\n";
		}

// ---------------------------------------
// Unzip archives and transfer the files (create subdirectories if needed)
// ---------------------------------------
		if ($acceptedArchivesArray != "all_uploaded_files_are_too_big" && sizeof($acceptedArchivesArray) > 0) {
			setStatus_php(0, 10, __("Decompressing archives and transferring files"));

			echo "<b><u>" . __("Decompressing archives and transferring files to the FTP server:") . "</u></b> <br />\n";
			echo "<ul>\n";

			ftp_unziptransferfiles($acceptedArchivesArray, $use_folder_names, $application_tempdir, $directory);
			if ($execution_success == false)  { return false; }

			echo "</ul>\n";
		}

		echo "</td>\n";
		echo "</tr>\n";
		echo "</table>\n";


// -------------------------------------------------------------------------
// Upload more files
// -------------------------------------------------------------------------
		printTitle(__("Upload more files and archives"));
		printUploadForm($directory);

	} // end else

	echo "</td>\n";
	echo "</tr>\n";
	echo "</table>\n";

} // End function uploadfile

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************







// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function javaupload($directory) {

// --------------
// This function prints the form for using the JUpload java applet
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $settings;
	global $application_tempdir;
	global $net2ftp_ftpserver, $net2ftp_ftpserverport, $net2ftp_username, $net2ftp_password_encrypted;
	global $net2ftp_language, $net2ftp_ftpmode, $net2ftp_passivemode, $net2ftp_sslconnect, $directory;

	$max_upload_filesize  = $settings["max_upload_filesize"];
	$max_upload_filesize_net2ftp = $max_upload_filesize / 1024;
	$maxFreeSpaceOnServer = $settings["maxFreeSpaceOnServer"];
	$maxTotalRequestSize  = $settings["maxTotalRequestSize"];
	$maxNumberFiles       = $settings["maxNumberFiles"];
	$maxFilesPerRequest   = $settings["maxFilesPerRequest"];

	$max_upload_filesize_php = ini_get("upload_max_filesize");
	$max_execution_time      = ini_get("max_execution_time");

	echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
	echo "<tr>\n";
	echo "<td>\n";

// -------------------------------------------------------------------------
// Form
// -------------------------------------------------------------------------
	printTitle(__("Upload directories and files using a Java applet"));

	printBack($directory);
	echo "<br />\n";

//	echo "<script type=\"text/javascript\">\n";
//	echo "function displayFileQueue() {\n";
//	echo "	if (!document.JUpload) return;\n";
//	echo "	if (!document.JUpload.jsIsReady()) return;\n";
//	echo "	var number = document.JUpload.jsGetFileNumber();\n";
//	echo "	var i = 0;\n";
//	echo "	alert('There are '+number + ' files in the filequeue.');\n";
//	echo "	for (i=0; i<number; i++) {\n";
//	echo "		alert(\"File #\" + i + \":\n\" + document.JUpload.jsGetFileAt(i));\n";
//	echo "	}\n";
//	echo "}\n";
//	echo "</script>\n";

	echo "<applet\n"; 
	echo "  code=\"JUpload/startup.class\"\n";
	echo "  archive=\"plugins/jupload-0.79/jupload.jar\"\n";
	echo "  width=\"650\"\n";
	echo "  height=\"350\"\n";
	echo "  mayscript\n";
	echo "  name=\"JUpload\"\n";
	echo "  alt=\"JUpload applet\">\n";

	echo " <!-- Java Plug-In Options -->\n";
	echo " <param name=\"progressbar\" value=\"true\">\n";
	echo " <param name=\"boxmessage\"  value=\"Loading the applet, please wait...\">\n";
	echo " <param name=\"mainSplitpaneLocation\" value=\"450\">\n"; // from left border, in px
	echo " <param name=\"leftSplitpaneLocation\" value=\"150\">\n"; // from top border, in px
	echo " <param name=\"showStatusPanel\"       value=\"true\">\n";

	echo "<param name=\"labelFiles\"    value=\"" . __("Number of files:") . "\">\n";
	echo "<param name=\"labelBytes\"    value=\"" . __("Size of files:") . "\">\n";
	echo "<param name=\"labelAdd \"     value=\"" . __("Add") . "\">\n";
	echo "<param name=\"labelRemove\"   value=\"" . __("Remove") . "\">\n";
	echo "<param name=\"labelUpload\"   value=\"" . __("Upload") . "\">\n";
	echo "<param name=\"addToolTip\"    value=\"" . __("Add files to the upload queue") . "\">\n";
	echo "<param name=\"removeToolTip\" value=\"" . __("Remove files from the upload queue") . "\">\n";
	echo "<param name=\"uploadToolTip\" value=\"" . __("Upload the files which are in the upload queue") . "\">\n";

	echo " <param name=\"actionURL\" value=\"jupload.php?ftpserver=$net2ftp_ftpserver&amp;ftpserverport=$net2ftp_ftpserverport&amp;username=$net2ftp_username&amp;password_encrypted=$net2ftp_password_encrypted&amp;language=$net2ftp_language&amp;ftpmode=$net2ftp_ftpmode&amp;passivemode=$net2ftp_passivemode&amp;sslconnect=$net2ftp_sslconnect&amp;directory=$directory&amp;\">\n";

 	echo "<param name=\"overwriteContentType\" value=\"true\">\n";
	echo "<param name=\"useRecursivePaths\"    value=\"true\">\n";
	echo "<param name=\"useAbsolutePaths\"     value=\"false\">\n";

	echo "<param name=\"checkResponse\"        value=\"true\">\n";
	echo "<param name=\"realTimeResponse\"     value=\"true\">\n";

	echo "<param name=\"maxFreeSpaceOnServer\"        value=\"$maxFreeSpaceOnServer\">\n";
	echo "<param name=\"maxFreeSpaceOnServerTitle\"   value=\"maxFreeSpaceOnServerTitle\">\n";
	echo "<param name=\"maxFreeSpaceOnServerWarning\" value=\"Maximum server space exceeded. Please select less/smaller files.\">\n";

	echo "<param name=\"maxTotalRequestSize\"         value=\"$maxTotalRequestSize\">\n";
	echo "<param name=\"maxTotalRequestSizeTitle\"    value=\"maxTotalRequestSizeTitle\">\n";
	echo "<param name=\"maxTotalRequestSizeWarning\"  value=\"Total size of the files is too big. Please select less/smaller files.\">\n";

	echo "<param name=\"maxNumberFiles\"              value=\"$maxNumberFiles\">\n";
	echo "<param name=\"maxNumberFilesTitle\"         value=\"maxNumberFilesTitle\">\n";
	echo "<param name=\"maxNumberFilesWarning\"       value=\"Total number of files is too high. Please select fewer files.\">\n";

	echo "<param name=\"maxFilesPerRequest\"          value=\"$maxFilesPerRequest\">\n";


// PUT METHOD
//	echo " <!-- in the actionURL, only the hostname is used by JUpload -->\n";
//	echo " <param name=\"actionURL\" value=\"http://www.net2ftp.com/temp/\">\n";
//	echo " <param name=\"usePutMethod\" value=\"true\">\n";

	echo " <!-- IF YOU HAVE PROBLEMS, CHANGE THIS TO TRUE BEFORE CONTACTING SUPPORT -->\n";
	echo " <param name=\"debug\" value=\"false\">\n";

// Original message
//	echo "Your browser does not support applets, or you have disabled applets in your browser settings.\n";
//	echo "To use this applet, please install the newest version of Sun's java. You can get it from <a href=\"http://www.java.com/\">java.com</a>. Click on Get It Now.\n";
//	echo "The online installation is about 1-2 MB and the offline installation is about 13 MB. This 'end-user' java is called JRE (Java Runtime Environment).\n";
//	echo "Alternatively, use net2ftp's normal upload or upload-and-unzip functionality.\n";
	echo __("Browser does not support Java applets");

	echo "</applet><br /><br />\n";

	echo "<u>" . __("Restrictions:") . "</u>\n";
	echo "<div style=\"font-size: 80%\">\n";
	echo "<ul>\n";
	echo "	<li> " . __("The maximum size of one file is restricted by net2ftp to <b>%1\$s kB</b> and by PHP to <b>%2\$s</b>", $max_upload_filesize_net2ftp, $max_upload_filesize_php) . "</li>\n";
	echo "	<li> " . __("The maximum execution time is <b>%1\$s seconds</b>", $max_execution_time) . "</li>\n";
	echo "	<li> " . __("The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension") . "\n";
	echo "	<li> " . __("If the destination file already exists, it will be overwritten") . "</li>\n";
	echo "</ul><br />\n";

	echo __("Note: to use this applet, Sun's Java plugin must be installed (version 1.4 or newer).") . "<br />\n"; 

// -------------------------------------------------------------------------
// Result
// -------------------------------------------------------------------------

	// See jupload.php

	echo "</td>\n";
	echo "</tr>\n";
	echo "</table>\n";

} // End function javaupload

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printUploadForm($directory) {

// --------------
// This function prints the upload form
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $settings;
	$max_upload_filesize         = $settings["max_upload_filesize"];
	$max_upload_filesize_net2ftp = $max_upload_filesize / 1024;
	$max_upload_filesize_php     = ini_get("upload_max_filesize");
	$max_execution_time          = ini_get("max_execution_time");

	if (strlen($directory) > 0) { $printdirectory = $directory; }
	else                        { $printdirectory = "/"; }

	echo "<form name=\"UploadForm\" id=\"UploadForm\" method=\"post\" enctype=\"multipart/form-data\" action=\"" . printPHP_SELF("") . "\">\n";

	printBackInForm($directory, "UploadForm");
	echo getAction("forward", "createUploadWindow(); document.UploadForm.submit();") . "<br /><br />\n";

// Directory
	echo __("Upload to directory:") . " <input type=\"text\" class=\"longinput\" name=\"directory\" value=\"$printdirectory\" />\n";
	printDirectoryTreeLink($directory, "UploadForm.directory");
	echo "<br /><br />\n";

	printLoginInfo();
	echo "<input type=\"hidden\" name=\"state\" value=\"manage\" />\n";
	echo "<input type=\"hidden\" name=\"state2\" value=\"uploadfile\" />\n";
	echo "<input type=\"hidden\" name=\"formresult\" value=\"result\" />\n";
	echo "<input type=\"hidden\" name=\"max_file_size\" value=\"$max_upload_filesize\" />\n"; // in bytes, advisory to browser, easy to circumvent; see also below, in PHP code!

	echo "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n";
	echo "<tr>\n";

// Titles
	echo "<td valign=\"top\" width=\"50%\">\n";
	echo "<div class=\"header31\">" . __("Files") . "</div>";
	echo "<div style=\"font-size: 80%;\">" . __("Files entered here will be transferred to the FTP server.") . "</div><br />\n";
	echo "</td>\n";
	echo "<td valign=\"top\" width=\"50%\">\n";
	echo "<div class=\"header31\">" . __("Archives") . " (zip, tar, tgz, gz)</div>";
	echo "<div style=\"font-size: 80%;\">" . __("Archives entered here will be decompressed, and the files inside will be transferred to the FTP server.") . "</div><br />\n";
	echo "</td>\n";
	echo "</tr>\n";
	echo "<tr>\n";
	echo "<td valign=\"top\" width=\"50%\">\n";

// Files
	echo "<input type=\"file\" class=\"uploadinputbutton\" maxsize=\"$max_upload_filesize\" name=\"file[]\" onChange=\"add_file('file', 1);\" /><br><span id=\"file_1\"><input type=\"button\" value=\"" . __("Add another") . "\" onClick=\"add_file('file', 1);\" /></span>\n";
	echo "<br />\n";

	echo "</td>\n";


// Archives
	echo "<td valign=\"top\" width=\"50%\">\n";

	echo "<input type=\"file\" class=\"uploadinputbutton\" maxsize=\"$max_upload_filesize\" name=\"archive[]\" onChange=\"add_file('archive', 1);\" /><br><span id=\"archive_1\"><input type=\"button\" value=\"" . __("Add another") . "\" onClick=\"add_file('archive', 1);\" /></span>\n";
	echo "<br /><div style=\"font-size: 80%;\"><input type=\"checkbox\" name=\"use_folder_names\" value=\"yes\" checked/> " . __("Use folder names (creates subdirectories automatically)") . "</div><br />\n";

	echo "</td>\n";
	echo "</tr>\n";
	echo "</table>\n";

	echo "</form>\n";


	echo "<u>" . __("Restrictions:") . "</u>\n";
	echo "<div style=\"font-size: 80%\">\n";
	echo "<ul>\n";
	echo "	<li> " . __("The maximum size of one file is restricted by net2ftp to <b>%1\$s kB</b> and by PHP to <b>%2\$s</b>", $max_upload_filesize_net2ftp, $max_upload_filesize_php) . "</li>\n";
	echo "	<li> " . __("The maximum execution time is <b>%1\$s seconds</b>", $max_execution_time) . "</li>\n";
	echo "	<li> " . __("The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension") . "\n";
	echo "	<li> " . __("If the destination file already exists, it will be overwritten") . "</li>\n";
	echo "</ul>\n";
	echo "</div><br />\n";

} // End function printUploadForm

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************









// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function zipentry($directory, $list, $zipactions, $newNames, $to, $message, $formresult) {

// --------------
// This function allows to zip directories and files, and to email/save the zip file.
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $REMOTE_ADDR, $HTTP_REFERER, $application_tempdir;


// -------------------------------------------------------------------------
// Initial checks
// -------------------------------------------------------------------------

	echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
	echo "<tr>\n";
	echo "<td>\n";
	printTitle(__("Zip entries"));


// -------------------------------------------------------------------------
// Form
// -------------------------------------------------------------------------

	if ($formresult != "result") {
		echo "<form name=\"ZipForm\" id=\"ZipForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
		printLoginInfo();
		echo "<input type=\"hidden\" name=\"state\" value=\"manage\" />\n";
		echo "<input type=\"hidden\" name=\"state2\" value=\"zip\" />\n";
		echo "<input type=\"hidden\" name=\"directory\" value=\"$directory\" />\n";
		echo "<input type=\"hidden\" name=\"formresult\" value=\"result\" />\n";
		printBackInForm($directory, "ZipForm");
		printForwardInForm("ZipForm");

// --------------------
// Save
// --------------------
		echo "<div style=\"border-color: #000000; border-style: solid; border-width: 1px; padding: 10px; margin-right: 100px; margin-bottom: 10px;\">\n";

		$zipfilename = get_filename_name($list[1]['dirfilename']) . ".zip";
		echo "<input type=\"checkbox\" name=\"zipactions[save]\" value=\"yes\" /> " . __("Save the zip file on the FTP server as:") . " <input type=text class=\"input\" name=\"zipactions[save_filename]\" value=\"$zipfilename\">\n";
		echo "</div> &nbsp; \n";

// --------------------
// Email
// --------------------
		echo "<div style=\"border-color: #000000; border-style: solid; border-width: 1px; padding: 10px; margin-right: 100px; margin-bottom: 10px;\">\n";
		echo "<input type=\"checkbox\" name=\"zipactions[email]\" value=\"yes\" /> " . __("Email the zip file in attachment to:") . " <input type=\"text\" class=\"input\" name=\"zipactions[email_to]\" value=\"\" /><br /><br />\n";
		echo __("Note that sending files is not anonymous: your IP address as well as the time of the sending will be added to the email.") . "<br /><br />\n";

// Additional comments
		echo __("Some additional comments to add in the email:") . "<br />\n";
		echo "<textarea name=\"zipactions[message]\" class=\"edit\" rows=\"5\" cols=\"60\" wrap=\"off\">\n";
		echo "</textarea>\n";

		echo "</div>\n";

// --------------------
// List of directories and files
// --------------------
//		echo "<br />Selected directories and files:<br />\n";
		for ($i=1; $i<=count($list); $i++) {
			printDirFileProperties($i, $list[$i], "hidden", "");
//			echo $list[$i]['dirfilename'] . "<br />\n";
		} // End for

		echo "</form>\n";
	}

// -------------------------------------------------------------------------
// Result
// -------------------------------------------------------------------------

	elseif ($formresult == "result") {

		printBack($directory);

// --------------------
// Check the input data
// --------------------
// Filename
		if ($zipactions['save'] == "yes" && $zipactions['save']['filename'] == "") {
			$errormessage = __("You did not enter a filename for the zipfile. Go back and enter a filename.") . "<br />";
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}

// Email address
		if ($zipactions['email'] == "yes" && checkEmailAddress($zipactions['email_to']) == false) {
			$errormessage = __("The email address you have entered (%1\$s) does not seem to be valid.<br />Please enter an address in the format <b>username@domain.com</b>", $zipactions['email_to']) . "<br />";
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}

// --------------------
// Execute the function
// --------------------
		setStatus_php(4, 10, __("Processing the entries"));
		$zipactions['download'] == "no";
		ftp_zip("", $directory, $list, $zipactions, "", 0);
	}

	echo "</td>\n";
	echo "</tr>\n";
	echo "</table>\n";

} // End function zipentry

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function calculatesize($directory, $list) {

// --------------
// This function calculates the size taken by the selected directories and files
// The directories are processed recursively
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;

// -------------------------------------------------------------------------
// Initial checks
// -------------------------------------------------------------------------

	echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
	echo "<tr>\n";
	echo "<td>\n";
	printTitle(__("Size of selected directories and files"));

// -------------------------------------------------------------------------
// Form
// -------------------------------------------------------------------------

// No form


// -------------------------------------------------------------------------
// Result
// -------------------------------------------------------------------------

	printBack($directory);

// Open connection
	setStatus_php(2, 10, __("Connecting to the FTP server"));
	$conn_id = ftp_openconnection();
	if ($execution_success == false) { return false; }

// Calculate the size
	$options = array();
	$result['size'] = 0;
	$result['skipped'] = 0;
	$result = ftp_processfiles("calculatesize", $conn_id, $directory, $list, $options, $result, 0);

// Close connection
	ftp_closeconnection($conn_id);

// Print message
	echo __("The total size taken by the selected directories and files is:") . " <b>" . formatFilesize($result['size']) . "</b> (" . $result['size'] . " Bytes) <br /><br />\n";

	if ($statistics['skipped'] > 0) {
		echo __("The nr of files which were skipped:") . " <b>" . $result['skipped'] . "</b><br /><br />\n";
	}

	echo "</td>\n";
	echo "</tr>\n";
	echo "</table>\n";

} // End function calculatesize

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function findstring($directory, $list, $searchoptions, $formresult) {

// --------------
// This function finds the files which contain a particular word
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	$heading_bgcolor = getSkinColors("heading_bgcolor");

	printFunctionTags("findstring", "begin");


// -------------------------------------------------------------------------
// Table begin
// -------------------------------------------------------------------------
	echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
	echo "<tr>\n";
	echo "<td>\n";

// -------------------------------------------------------------------------
// Form
// -------------------------------------------------------------------------

	if ($formresult != "result") {
		printTitle(__("Search directories and files"));
		printFindstringForm($directory, $list, $searchoptions);
	}

// -------------------------------------------------------------------------
// Result
// -------------------------------------------------------------------------

	elseif ($formresult == "result") {

		printTitle(__("Search results"));
		printBack($directory);

// Perl regular expression help:
// http://www.wdvl.com/Authoring/Languages/Perl/PerlfortheWeb/pattern_matching.html
// http://www.wdvl.com/Authoring/Languages/Perl/PerlfortheWeb/perlintro2_table1.html
// http://theoryx5.uwinnipeg.ca/CPAN/perl/pod/perlfaq6-full.html

// ------------
// CHECKS
// ------------
// Check if $searchoptions['string'] is a valid string
		if (is_string($searchoptions['string']) == false) { 
			$errormessage = __("Please enter a valid search word or phrase.");
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}

// Check if $searchoptions['filename'] is a valid filename with a possible wildcard character *
		if (preg_match("/^[a-zA-Z0-9_ *\.-]*$/", $searchoptions['filename']) == 0) { 
			$errormessage = __("Please enter a valid filename.");
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}

// Check if $searchoptions['size_from'] and $searchoptions['size_to'] are valid numbers
		if (is_numeric($searchoptions['size_from']) == false) { 
			$errormessage = __("Please enter a valid file size in the \"from\" textbox, for example 0.");
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}
		if (is_numeric($searchoptions['size_to']) == false) { 
			$errormessage = __("Please enter a valid file size in the \"to\" textbox, for example 500000.");
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}

// Check if $searchoptions['modified_from'] and $searchoptions['modified_to'] are valid dates
		if (preg_match("/^[0-9-]*$/", $searchoptions['modified_from']) == 0) { 
			$errormessage = __("Please enter a valid date in Y-m-d format in the \"from\" textbox.");
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}
		if (preg_match("/^[0-9-]*$/", $searchoptions['modified_to']) == 0) { 
			$errormessage = __("Please enter a valid date in Y-m-d format in the \"to\" textbox."); 
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}

// ------------
// CONVERSIONS
// ------------
// Convert the wildcard character * in the filename by the wildcard .* that can be read by preg_match
// So this *.* becomes this .*..*
		$searchoptions['filename'] = str_replace("*", ".*", $searchoptions['filename']);

// Convert the mtime to a unix timestamp
		$searchoptions['modified_from'] = strtotime($searchoptions['modified_from']);
		$searchoptions['modified_to'] = strtotime($searchoptions['modified_to']);

// Open connection
		setStatus_php(2, 10, __("Connecting to the FTP server"));
		$conn_id = ftp_openconnection();
		if ($execution_success == false) { return false; }

// Find the files
		$result = array();
		setStatus_php(4, 10, __("Searching the files..."));
		$result = ftp_processfiles("findstring", $conn_id, $directory, $list, $searchoptions, $result, 0);

// Close connection
		ftp_closeconnection($conn_id);

// Print result
		if (count($result) == 0) {
			echo __("The word <b>%1\$s</b> was not found in the selected directories and files.", $searchoptions['string']) . "<br /><br />\n";
			printTitle(__("Search again"));
			printFindstringForm($directory, $list, $searchoptions);
		}
		else {
			echo __("The word <b>%1\$s</b> was found in the following files:", $searchoptions['string']) . "<br /><br />\n";

			echo "<form name=\"BrowseForm\" id=\"BrowseForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
			printLoginInfo();
			echo "<input type=\"hidden\" name=\"state\" />\n";
			echo "<input type=\"hidden\" name=\"state2\" />\n";
			echo "<input type=\"hidden\" name=\"directory\" />\n";
			echo "<input type=\"hidden\" name=\"entry\" />\n";

			echo "<script type=\"text/javascript\"><!--\n";
			echo "function submitBrowseForm(directory, entry, state, state2) {\n";
			echo "	document.BrowseForm.state.value=state;\n";
			echo "	document.BrowseForm.state2.value=state2;\n";
			echo "	document.BrowseForm.directory.value=directory;\n";
			echo "	document.BrowseForm.entry.value=entry;\n";
			echo "	document.BrowseForm.submit();\n";
			echo "}\n"; // End javascript function submitBrowseForm
			echo "//--></script>\n";

			echo "<table cellpadding=\"2\" style=\"border: 2px solid $heading_bgcolor;\">\n";
			echo "	<tr class=\"browse_rows_heading\">\n";
			echo "		<td>File</td>\n";
			echo "		<td>Line</td>\n";
			echo "		<td colspan=\"2\">Action</td>\n";
			echo "	</tr>\n";

			$rowcounter = 0;

			for ($k=0; $k<count($result); $k++) {
				$rowcounter = $rowcounter + 1;
				if ($rowcounter % 2 == 1) { $thisrow_class = "browse_rows_odd";  }
				if ($rowcounter % 2 == 0) { $thisrow_class = "browse_rows_even"; }

				echo "	<tr class=\"$thisrow_class\">\n";
				echo "		<td>" . glueDirectories($result[$k]['directory'], $result[$k]['dirfilename']) . "</td>\n";
				echo "		<td>" . $result[$k]['line'] . "</td>\n";
				$dirfilename    = $result[$k]['dirfilename'];
				$directory_js   = javascriptEncode($result[$k]['directory']);
				$dirfilename_js = javascriptEncode($result[$k]['dirfilename']);
				echo "		<td onClick=\"submitBrowseForm('$directory_js', '$dirfilename_js', 'manage', 'view');\"           title=\"View the highlighted source code of file $dirfilename\" style=\"cursor: pointer; cursor: hand;\">View</td>\n";
				echo "		<td onClick=\"submitBrowseForm('$directory_js', '$dirfilename_js', 'manage', 'edit');\"           title=\"Edit the source code of file $dirfilename\" style=\"cursor: pointer; cursor: hand;\">Edit</td>\n";
				echo "	</tr>\n";
			} // end for
			echo "</table>\n";
			echo "</form>\n";
			echo "<br /><br />\n";

			printTitle(__("Search again"));
			printFindstringForm($directory, $list, $searchoptions);

		}

	} // End if elseif (form or result)

	echo "</td>\n";
	echo "</tr>\n";
	echo "</table>\n";

	printFunctionTags("findstring", "end");

} // End function findstring

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printFindstringForm($directory, $list, $searchoptions) {

// --------------
// This function prints the search form
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;

	echo "<form name=\"FindStringForm\" id=\"FindStringForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
	printLoginInfo();
	echo "<input type=\"hidden\" name=\"state\" value=\"manage\" />\n";
	echo "<input type=\"hidden\" name=\"state2\" value=\"findstring\" />\n";
	echo "<input type=\"hidden\" name=\"directory\" value=\"$directory\" />\n";
	echo "<input type=\"hidden\" name=\"formresult\" value=\"result\" />\n";

	printBackInForm($directory, "FindStringForm");
	printForwardInForm("FindStringForm");

	for ($i=1; $i<=count($list); $i++) {
		printDirFileProperties($i, $list[$i], "hidden", "");
	} // End for

	echo "<table border=\"0\" cellspacing=\"2\" cellpadding=\"2\">\n";
// Search string
	if ($searchoptions['case_sensitive'] == "yes") { $checked_case_sensitive = "checked"; }
	echo "	<tr>\n";
	echo "		<td valign=\"top\">" . __("Search for a word or phrase") . "</td>\n";
	echo "		<td valign=\"top\"><input type=\"text\" class=\"input\" name=\"searchoptions[string]\" value=\"" . $searchoptions['string'] . "\" /><br />\n";
	echo "					<input type=\"checkbox\" name=\"searchoptions[case_sensitive]\" value=\"yes\" $checked_case_sensitive/> " . __("Case sensitive search") . " </td>\n";
	echo "	</tr>\n";

	echo "	<tr>\n";
	echo "		<td colspan=\"2\">" . __("Restrict the search to:") . " </td>\n";
	echo "	</tr>\n";
// Filename
	$searchoptions['filename'] = str_replace(".*", "*", $searchoptions['filename']);
	if ($searchoptions['filename'] == "") { $searchoptions['filename'] = "*.*"; }
	echo "	<tr>\n";
	echo "		<td> &nbsp; " . __("files with a filename like") . "</td>\n";
	echo "		<td><input type=\"text\" class=\"input\" name=\"searchoptions[filename]\" value=\"" . $searchoptions['filename'] . "\" /> " . __("(wildcard character is *)") . " </td>\n";
	echo "	</tr>\n";
// Size
	if ($searchoptions['size_from'] == "") { $searchoptions['size_from'] = 0; }
	if ($searchoptions['size_to'] == "")   { $searchoptions['size_to'] = 500000; }
	echo "	<tr>\n";
	echo "		<td> &nbsp; " . __("files with a size") . "</td>\n";
	echo "		<td>" . __("from") . " <input type=\"text\" class=\"input\" name=\"searchoptions[size_from]\" value=\"" . $searchoptions['size_from'] . "\" maxlength=\"7\" /> " . __("to") . " <input type=\"text\" class=\"input\" name=\"searchoptions[size_to]\" value=\"" . $searchoptions['size_to'] . "\" maxlength=\"7\" /> Bytes</td>\n";
	echo "	</tr>\n";
// Modified
	if ($searchoptions['modified_from'] == "") { $searchoptions['modified_from'] = date("Y-m-d", time() - 3600*24*7); }
	else                                       { $searchoptions['modified_from'] = date("Y-m-d", $searchoptions['modified_from']); }
	if ($searchoptions['modified_to'] == "")   { $searchoptions['modified_to'] = date("Y-m-d"); }
	else                                       { $searchoptions['modified_to'] = date("Y-m-d", $searchoptions['modified_to']); }
	echo "	<tr>\n";
	echo "		<td> &nbsp; " . __("files which were last modified") . " </td>\n";
	echo "		<td>" . __("from") . " <input type=\"text\" class=\"input\" name=\"searchoptions[modified_from]\" id=\"modified_from\" value=\"" . $searchoptions['modified_from'] . "\" /><input type=\"button\" id=\"from_trigger\" class=\"microbutton\" value=\"...\"> " . __("to") . " <input type=\"text\" class=\"input\" name=\"searchoptions[modified_to]\" id=\"modified_to\" value=\"" . $searchoptions['modified_to'] . "\" /><input type=\"button\" id=\"to_trigger\" class=\"microbutton\" value=\"...\"> </td>\n";
	echo "	</tr>\n";

	echo "</table>\n";
	echo "</form>\n";

	echo "<script type=\"text/javascript\">\n";
	echo "    Calendar.setup({\n";
	echo "        inputField     :    \"modified_from\",   // id of the input field\n";
	echo "        ifFormat       :    \"%Y-%m-%d\",        // format of the input field\n";
	echo "        button         :    \"from_trigger\",    // trigger for the calendar (button ID)\n";
	echo "        align          :    \"Tl\",              // alignment (defaults to \"Bl\")\n";
	echo "        singleClick    :    true\n";
	echo "    });\n";
	echo "    Calendar.setup({\n";
	echo "        inputField     :    \"modified_to\",     // id of the input field\n";
	echo "        ifFormat       :    \"%Y-%m-%d\",        // format of the input field\n";
	echo "        button         :    \"to_trigger\",      // trigger for the calendar (button ID)\n";
	echo "        align          :    \"Tl\",              // alignment (defaults to \"Bl\")\n";
	echo "        singleClick    :    true\n";
	echo "    });\n";
	echo "</script>\n";

} // End function printFindstringForm

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function updatefile($directory, $entry, $uploadedFilesArray, $comparison, $screen) {

// --------------
// This function allows to merge 2 files
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	$max_upload_filesize_net2ftp = $settings["max_upload_filesize"];
	$max_upload_filesize_net2ftp = $max_upload_filesize_net2ftp / 1024;
	$max_upload_filesize_php     = ini_get("upload_max_filesize");
	$max_execution_time          = ini_get("max_execution_time");
	global $application_tempdir;

// -------------------------------------------------------------------------
// Initial checks
// -------------------------------------------------------------------------

	if ($screen == "") { $screen = "screen1"; }

// -------------------------------------------------------------------------
// Screen 1
// -------------------------------------------------------------------------
	if ($screen == "screen1") {

		echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
		echo "<tr>\n";
		echo "<td>\n";

		printTitle(__("Update file"));

		echo "<form name=\"UpdateFileForm\" id=\"UpdateFileForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\" enctype=\"multipart/form-data\">\n";
		printLoginInfo();
		echo "<input type=\"hidden\" name=\"state\" value=\"manage\" />\n";
		echo "<input type=\"hidden\" name=\"state2\" value=\"updatefile\" />\n";
		echo "<input type=\"hidden\" name=\"directory\" value=\"$directory\" />\n";
		echo "<input type=\"hidden\" name=\"entry\" value=\"$entry\" />\n";
		echo "<input type=\"hidden\" name=\"screen\" value=\"screen2\" />\n";

		printBackInForm($directory, "UpdateFileForm");
		printForwardInForm("UpdateFileForm");

		echo __("<b>WARNING: THIS FUNCTION IS STILL IN EARLY DEVELOPMENT. USE IT ONLY ON TEST FILES! YOU HAVE BEEN WARNED!") . "<br />\n";
		echo __("Known bugs: - erases tab characters - doesn't work well with big files (> 50kB) - was not tested yet on files containing non-standard characters</b>") . "<br /><br /><br />\n";

		echo __("This function allows you to upload a new version of the selected file, to view what are the changes and to accept or reject each change. Before anything is saved, you can edit the merged files.") . "<br /><br /><br />\n";

		echo __("Old file:") . " <b>$entry</b> <br /><br />\n";
		echo __("New file:") . " <input type=\"file\" class=\"uploadinputbutton\" maxsize=\"$max_upload_filesize\" name=\"file[]\" /> <br />\n";

		echo "</form>\n";

		echo "<u>" . __("Restrictions:") . "</u>\n";
		echo "<div style=\"font-size: 80%\">\n";
		echo "<ul>\n";
		echo "	<li> " . __("The maximum size of one file is restricted by net2ftp to <b>%1\$s kB</b> and by PHP to <b>%2\$s</b>", $max_upload_filesize_net2ftp, $max_upload_filesize_php) . "</li>\n";
		echo "	<li> " . __("The maximum execution time is <b>%1\$s seconds</b>", $max_execution_time) . "</li>\n";
		echo "	<li> " . __("The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension") . "\n";
		echo "</ul>\n";
		echo "</div><br />\n";

		echo "</td>\n";
		echo "</tr>\n";
		echo "</table>\n";

	} // end if ($screen == "screen1")

// -------------------------------------------------------------------------
// Screen 2
// -------------------------------------------------------------------------

	elseif ($screen == "screen2") {

		echo "<table style=\"margin-left: 30px; margin-right: auto;\">\n";
		echo "<tr>\n";
		echo "<td>\n";

		printTitle(__("Update file"));

// ---------------------------------------
// Upload the new file
// ---------------------------------------
		if (sizeof($uploadedFilesArray) > 0) {
			setStatus_php(4, 10, __("Uploading new file"));
			if (sizeof($uploadedFilesArray) > 0) {
				$acceptedFilesArray = acceptFiles($uploadedFilesArray);
				if ($execution_success == false)  { return false; }
				$newfilename = $acceptedFilesArray[1]["tmp_name"];
			}
		}
		else {
			$errormessage = __("You did not provide any files or archives to upload.");
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}

// ---------------------------------------
// Read the old and the new file
// The old file is on the FTP server
// The new file is in the /temp directory of the web server
// ---------------------------------------

// New file
		setStatus_php(4, 10, __("Reading the new file"));

		$string_new = local_readfile($newfilename);
		if ($execution_success == false) { @unlink($newfilename); return false; }

		$success = unlink($newfilename);
		if ($success == false) { 
			$errormessage = __("Unable to delete the new file"); 
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}
		registerTempfile("unregister", $newfilename);

// Old file
		setStatus_php(6, 10, __("Reading the old file"));

		$string_old = ftp_readfile("", $directory, $entry);
		if ($execution_success == false)  { return false; }

// ---------------------------------------
// Compare files
// ---------------------------------------
		setStatus_php(8, 10, __("Comparing the 2 files"));

//	$comparison = compareFiles($string_old, $string_new);
//	if ($execution_success == false) { return false; }
		$comparison = compareFiles($string_old, $string_new);

// ---------------------------------------
// Print out the select
// ---------------------------------------
		setStatus_php(9, 10, __("Printing the comparison"));
//		printComparisonSelect($comparison, $directory, $entry);
		printComparisonList($comparison, $directory, $entry);

		echo "</tr>\n";
		echo "</td>\n";
		echo "</table>\n";

	} // end elseif ($screen == "screen2")

// -------------------------------------------------------------------------
// Screen 3
// -------------------------------------------------------------------------

	elseif ($screen == "screen3") {

// Merge strings based on the comparison array
		$string_merged = mergeStrings($comparison);

// Print the Edit form
		printEditForm($directory, $entry, $string_merged, "plain", "notsavedyet");

	} // end elseif ($screen == "screen3")


} // End function updatefile

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function compareFiles($string_old, $string_new) {

// --------------
// This function compares a new file to an old file and indicates the changes
// The input of the function are 2 strings.
// The output of the function is an array:
// $comparison[$index]['string']   = "a code line";
// $comparison[$index]['line_old'] = $line_old; // if line was deleted
// $comparison[$index]['line_new'] = $line_new; // if line was added
// $comparison[$index]['change']   = "deleted", "added" or "unchanged";
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $application_tempdir;

// Convert to Unix style EOL and
// Explode them into separate lines
	$string_old_exploded = explode_lines($string_old);
	$string_new_exploded = explode_lines($string_new);

// Initialize the variables
	$line_old = 1;
	$line_new = 1;
	$line_total = 1;

// For each line in the new file...
// Note that the third argument of the for loop is not filled in; the index is incremented inside the for loop
	for ($line_new = 1; $line_new <= count($string_new_exploded);) {

// Check if the current new line is equal to the current old line

// If they are equal, then set the status to "unchanged"
		if (trim($string_new_exploded[$line_new]) == trim($string_old_exploded[$line_old])) {
			$string_old_change[$line_old] = "unchanged";
			$string_new_change[$line_new] = "unchanged";
			$comparison[$line_total]['string'] = $string_new_exploded[$line_new];
			$comparison[$line_total]['line_old'] = $line_old;
			$comparison[$line_total]['line_new'] = $line_new;
			$comparison[$line_total]['change'] = "unchanged";
			$line_old++;
			$line_new++;
			$line_total++;
		} // end if

// If the current new line is empty, then set its status directly as added
		elseif (trim($string_new_exploded[$line_new]) == "") {
			$string_new_change[$line_new] = "added";
			$comparison[$line_total]['string'] = $string_new_exploded[$line_new];
			$comparison[$line_total]['line_old'] = " ";
			$comparison[$line_total]['line_new'] = $line_new;
			$comparison[$line_total]['change'] = "added";
			$line_new++;
			$line_total++;
		}

// If the current old line is empty, then set its status directly as deleted
		elseif (trim($string_old_exploded[$line_old]) == "") {
			$string_old_change[$line_old] = "deleted";
			$comparison[$line_total]['string'] = $string_old_exploded[$line_old];
			$comparison[$line_total]['line_old'] = $line_old;
			$comparison[$line_total]['line_new'] = " ";
			$comparison[$line_total]['change'] = "deleted";
			$line_old++;
			$line_total++;
		}

		else {
// If they are not equal, then either lines have been deleted, or lines have been added
// 	nr of old lines "deleted" = occurence new line in old file - current old line
//    nr of new lines "added"   = occurence old line in new file - current new line
// The smallest nr of lines indicates which of the 2 is true

// Occurence of old line in new file
				$current_old_line = trim($string_old_exploded[$line_old]);
				$oldline_in_newfile = 0;
				for ($j = $line_new; ($j <= count($string_new_exploded) && $oldline_in_newfile == 0); $j++) {
					if (trim($string_new_exploded[$j]) == $current_old_line) { $oldline_in_newfile = $j; }
				} // end for Occurence of old line in new file

	// If the old line does not occur in the new file, then it is deleted
	// Set its status as "deleted"
	// Increase $lines_old
	// Do not compare the nr of lines deleted versus added
				if ($oldline_in_newfile == 0) {
					$string_old_change[$line_old] = "deleted";
					$comparison[$line_total]['string'] = $string_old_exploded[$line_old];
					$comparison[$line_total]['line_old'] = $line_old;
					$comparison[$line_total]['line_new'] = " ";
					$comparison[$line_total]['change'] = "deleted";
					$line_old++;
					$line_total++;
				} // end if $oldline_in_newfile == 0

			else {

// Occurence of new line in old file
			$current_new_line = trim($string_new_exploded[$line_new]);
			$newline_in_oldfile = 0;
			for ($i = $line_old; ($i <= count($string_old_exploded) && $newline_in_oldfile == 0); $i++) {
				if (trim($string_old_exploded[$i]) == $current_new_line) { $newline_in_oldfile = $i; }
			} // end for Occurence of new line in old file

	// If the new line does not occur in the old file, then it is added
	// Set its status to "added"
	// Increase $lines_new
	// Do not search for the occurence of the old line in the new file; do not compare the nr of lines deleted versus added
			if ($newline_in_oldfile == 0) {
				$string_new_change[$line_new] = "added";
				$comparison[$line_total]['string'] = $string_new_exploded[$line_new];
				$comparison[$line_total]['line_old'] = " ";
				$comparison[$line_total]['line_new'] = $line_new;
				$comparison[$line_total]['change'] = "added";
				$line_new++;
				$line_total++;
			} // end if $newline_in_oldfile == 0

				else {
// -------------------------------------------------------------------------
// If the new line occurs in the old file, and the old line occurs also in the new file,
// then either lines have been added, either lines have been deleted.
// For example:
//    Old file: 1 2 3 4 5
//    New file: 1 5 6 5 2 3 4 5
//    ==> Are lines 2 3 4 deleted, or are lines 5 6 5 added?
// Compare how many lines have been added versus deleted, and take the option with the smallest nr
//					$deleted = $newline_in_oldfile - $line_old;
//					$added   = $oldline_in_newfile - $line_new;
//					if ($added <= $deleted) { set new lines as added }
//					else                    { set old lines as deleted }
// -------------------------------------------------------------------------

					$deleted = $newline_in_oldfile - $line_old;
					$added   = $oldline_in_newfile - $line_new;

			// Added
			// Set the status of all new lines until the occurence of the old line to "added"
			// Set the status of the occurence of the old line and of the next new line to "unchanged"
					if ($added <= $deleted) {
						for ($k = $line_new; $k < $oldline_in_newfile; $k++) {
							$string_new_change[$k] = "added";
							$comparison[$line_total]['string'] = $string_new_exploded[$k];
							$comparison[$line_total]['line_old'] = " ";
							$comparison[$line_total]['line_new'] = $k;
							$comparison[$line_total]['change'] = "added";
							$line_total++;
						}
						$string_new_change[$oldline_in_newfile] = "unchanged";
						$string_old_change[$line_old] = "unchanged";
						$comparison[$line_total]['string'] = $string_new_exploded[$oldline_in_newfile];
						$comparison[$line_total]['line_old'] = $line_old;
						$comparison[$line_total]['line_new'] = $oldline_in_newfile;
						$comparison[$line_total]['change'] = "unchanged";
						$line_total++;
						$line_old++;
						$line_new = $oldline_in_newfile + 1;
					} // end if $added <= $deleted

			// Deleted
			// Set the status of all old lines until the occurence of the new line to "deleted"
			// Set the status of the occurence of the new line and of the next old line to "unchanged"
					else {
						for ($k = $line_old; $k < $newline_in_oldfile; $k++) {
							$string_old_change[$k] = "deleted";
							$comparison[$line_total]['string'] = $string_old_exploded[$k];
							$comparison[$line_total]['line_old'] = $k;
							$comparison[$line_total]['line_new'] = " ";
							$comparison[$line_total]['change'] = "deleted";
							$line_total++;
						}
						$string_old_change[$newline_in_oldfile] = "unchanged";
						$string_new_change[$line_new] = "unchanged";
						$comparison[$line_total]['string'] = $string_old_exploded[$newline_in_oldfile];
						$comparison[$line_total]['line_old'] = $newline_in_oldfile;
						$comparison[$line_total]['line_new'] = $line_new;
						$comparison[$line_total]['change'] = "unchanged";
						$line_total++;
						$line_new++;
						$line_old = $newline_in_oldfile + 1;
					} // end if else $added <= $deleted

				} // end if else $oldline_in_newfile == 0

			} // end if else $newline_in_oldfile == 0

		} // end if else trim($string_new_exploded[$line_new]) == trim($string_old_exploded[$line_old])

	} // end for ($line_new = 0; $line_new < count($string_new_exploded);) {

// If the end of the new file is reached, while the end of the old file is not reached, then
// this means that the rest of the old file has been deleted
	if ($line_old < count($string_old_exploded)) {
		for ($k = $line_old; $k < count($string_old_exploded); $k++) {
			$string_old_change[$k] = "deleted";
			$comparison[$line_total]['string'] = $string_old_exploded[$k];
			$comparison[$line_total]['line_old'] = $k;
			$comparison[$line_total]['line_new'] = " ";
			$comparison[$line_total]['change'] = "deleted";
			$line_total++;
		} // end for
		$line_old = count($string_old_exploded);
	} // end if


// Set all the changed lines to validated
	for ($k=1; $k<count($comparison); $k++) {
		if ($comparison[$k]['change'] != "unchanged") { $comparison[$k]['validation'] = "yes"; }
		else { $comparison[$k]['validation'] = "no"; }
	} // end for

// Print out the result
//	echo "OLD FILE: <br />";
//	for ($m = 0; $m < count($string_old_exploded); $m++) {
//		echo $string_old_exploded[$m] . " &nbsp; " . $string_old_change[$m] . "<br />";
//	} // end for
//
//	echo "<br /><br />";
//
//	echo "NEW FILE: <br />";
//	for ($m = 0; $m < count($string_new_exploded); $m++) {
//		echo $string_new_exploded[$m] . " &nbsp; " . $string_new_change[$m] . "<br />";
//	} // end for
//
//	echo "<br /><br />";

	return $comparison;

} // End function compareFiles

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printComparisonSelect($comparison, $directory, $entry) {

// --------------
// This function prints out the $comparison array returned by the function compareFiles
// with a <select> and some Javascript functions to validate or reject the changes
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $settings;


// -------------------------------------------------------------------------
// Javascript functions
// -------------------------------------------------------------------------
	echo "\n<script type=\"text/javascript\"><!--\n";

// -----------------------------------
	echo "function printComparisonValidation(startindex) {\n";
// -----------------------------------
// Note that the printing starts only from the startindex onwards; this is to avoid going through the rows
// which should anyway not be changed.
// The function is called the first time with startindex = 1; then, when options are validated or rejected,
// the function is called with startindex = first selected row.
	echo "	if (startindex == 0) { startindex = 1; }\n";
	echo "	for (var i = startindex; i < comparison.length; i++) {\n";
	echo "		if(comparison[i]['validation'] == 'yes') {\n";
// The selected options are validated
// ==> Set the first 2 characters of the select option to OK
//     Set the color to green or red
	echo "			if      (comparison[i]['change'] != 'unchanged') { document.ComparisonForm.ComparisonSelect.options[i].text = 'OK' + document.ComparisonForm.ComparisonSelect.options[i].text.substr(2); }\n";
	echo "			if      (comparison[i]['change'] == 'added')     { document.ComparisonForm.ComparisonSelect.options[i].style.backgroundColor = '#55CC44'; }\n";
	echo "			else if (comparison[i]['change'] == 'deleted')   { document.ComparisonForm.ComparisonSelect.options[i].style.backgroundColor = '#EE4422'; }\n";
	echo "		}\n";
// The selected options are rejected
// ==> Set the first 2 characters of the select option to --
//     Set the color to grey
	echo "		else {\n";
	echo "			if      (comparison[i]['change'] != 'unchanged') { document.ComparisonForm.ComparisonSelect.options[i].text = '--' + document.ComparisonForm.ComparisonSelect.options[i].text.substr(2); }\n";
	echo "			if      (comparison[i]['change'] == 'added')     { document.ComparisonForm.ComparisonSelect.options[i].style.backgroundColor = '#CCEECC'; }\n";
	echo "			else if (comparison[i]['change'] == 'deleted')   { document.ComparisonForm.ComparisonSelect.options[i].style.backgroundColor = '#EECCCC'; }\n";
	echo "			\n";
	echo "		}\n";
	echo "	}\n";
	echo "	return true;\n";
	echo "}\n";

// -----------------------------------
	echo "function setValidation(dowhat) {\n";
// -----------------------------------
	// Code snippet from http://developer.irt.org/script/1663.htm
	echo "	for (var i = document.ComparisonForm.ComparisonSelect.selectedIndex; i < document.ComparisonForm.ComparisonSelect.options.length; i++) {\n";
	echo "		if((document.ComparisonForm.ComparisonSelect.options[i].selected) & (i != 0)) {\n";
	echo "			if (dowhat == 'accept') { comparison[i]['validation'] = 'yes'; }\n";
	echo "			if (dowhat == 'reject') { comparison[i]['validation'] = 'no';  }\n";
	echo "		}\n";
	echo "	}\n";
	echo "	printComparisonValidation(document.ComparisonForm.ComparisonSelect.selectedIndex);\n";
	echo "	return true;\n";
	echo "}\n";

// -----------------------------------
	echo "function submitComparisonForm() {\n";
// -----------------------------------
	echo "	var d = document;\n";
	echo "	d.writeln('<html><head></head><body><form name=\"NewForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">');\n";
//	echo "	d.writeln('" . __("Please wait...") . "<br /><br />');\n";
	printLoginInfo_javascript();
	echo "	d.writeln('<input type=\"hidden\" name=\"state\" value=\"manage\">');\n";
	echo "	d.writeln('<input type=\"hidden\" name=\"state2\" value=\"updatefile\">');\n";
	echo "	d.writeln('<input type=\"hidden\" name=\"screen\" value=\"screen3\">');\n";
	echo "	d.writeln('<input type=\"hidden\" name=\"directory\" value=\"$directory\">');\n";
	echo "	d.writeln('<input type=\"hidden\" name=\"entry\" value=\"$entry\">');\n";
	echo "	for(i=1; i<comparison.length; i++) {;\n";
	echo "		d.writeln('<input type=\"hidden\" name=\"comparison[' + i + '][line_old]\"   value=\"' + comparison[i]['line_old']   + '\">');\n";
	echo "		d.writeln('<input type=\"hidden\" name=\"comparison[' + i + '][line_new]\"   value=\"' + comparison[i]['line_new']   + '\">');\n";
	echo "		d.writeln('<input type=\"hidden\" name=\"comparison[' + i + '][string]\"     value=\"' + comparison[i]['string']     + '\">');\n";
	echo "		d.writeln('<input type=\"hidden\" name=\"comparison[' + i + '][change]\"     value=\"' + comparison[i]['change']     + '\">');\n";
	echo "		d.writeln('<input type=\"hidden\" name=\"comparison[' + i + '][validation]\" value=\"' + comparison[i]['validation'] + '\">');\n";
	echo "	}\n";
	echo "	d.writeln('</form></body></html>');\n";
	echo "	d.NewForm.submit();\n";
	echo "}\n";

	echo "//--></script>\n";


// -------------------------------------------------------------------------
// Form
// -------------------------------------------------------------------------
	echo "<form name=\"ComparisonForm\" id=\"ComparisonForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
	printLoginInfo();
	echo "<input type=\"hidden\" name=\"state\" value=\"manage\" />\n";
	echo "<input type=\"hidden\" name=\"state2\" value=\"updatefile\" />\n";
	echo "<input type=\"hidden\" name=\"directory\" value=\"$directory\" />\n";

// -------------------------------------------------------------------------
// Buttons
// -------------------------------------------------------------------------
	echo "<table border=\"0\" width=\"100%\" cellspacing=\"2\" cellpadding=\"2\">\n";
	echo "	<tr>\n";
	echo "		<td valign=\"top\">\n";
	printBackInForm($directory, "ComparisonForm");
	echo getAction("forward", "submitComparisonForm();");
	echo "		</td>\n";
	echo "		<td valign=\"top\" style=\"text-align: right;\">\n";
	echo "			<input type=\"button\" class=\"longbutton\" value=\"Accept change\" onClick=\"setValidation('accept');\"> &nbsp;\n";
	echo "			<input type=\"button\" class=\"longbutton\" value=\"Reject change\" onClick=\"setValidation('reject');\"> &nbsp;\n";
	echo "		</td>\n";
	echo "	</tr>\n";
	echo "</table>\n";

// -------------------------------------------------------------------------
// Select
// -------------------------------------------------------------------------
	echo "<select name=\"ComparisonSelect\" multiple size=\"" . $settings["edit_nrofrows"] . "\" style=\"width: 900px; font-family: courier;\">\n";

	echo "<option style=\"background-color: #FFFFFF\">" . __("Select lines below, accept or reject changes and submit the form.") . "</option>\n";

	for ($k=1; $k<count($comparison); $k++) {
// Background colors
		if     ($comparison[$k]['change'] == "deleted") { $bgcolor = "#EE4422"; }
		elseif ($comparison[$k]['change'] == "added")   { $bgcolor = "#55CC44"; }
		else                                            { $bgcolor = "#FFFFFF"; }

// Add trailing spaces to the line nr
		$linenr = $k;
		for ($i=strlen($k); $i<strlen(count($comparison)); $i++) { $linenr = $linenr . "&nbsp;"; }

// Add trailing spaces to the change
		if     ($comparison[$k]['change'] == "unchanged") { $change = "unchanged"; }
		elseif ($comparison[$k]['change'] == "added")     { $change = "added&nbsp;&nbsp;&nbsp;&nbsp;"; }
		elseif ($comparison[$k]['change'] == "deleted")   { $change = "deleted&nbsp;&nbsp;"; }

// Set spaces to the validation
		if     ($comparison[$k]['validation'] == "yes") { $validation = "OK"; }
		else                                            { $validation = "--"; }

// Replace special characters to display them nicely in HTML
		$string_printed = htmlspecialchars($comparison[$k]['string'], ENT_QUOTES);

		// Replace space " " by " &nbsp;"
		$string_printed = str_replace("  "," &nbsp;", $string_printed);

		// Replace tab "	" by " &nbsp; &nbsp; &nbsp; &nbsp;"
		$string_printed = str_replace("\t", "&nbsp&nbsp&nbsp&nbsp;", $string_printed);

		echo "<option style=\"background-color: $bgcolor;\">" . $validation . " " . $linenr . " " . $change . " | " . $string_printed . "</option>\n";

	} // end for

	echo "</select>\n";

// -------------------------------------------------------------------------
// Javascript comparison array
// -------------------------------------------------------------------------
	echo "\n<script type=\"text/javascript\"><!--\n";
	echo "comparison = new Array();\n";
	for ($k=1; $k<count($comparison); $k++) {
		echo "comparison[$k] = new Array();\n";
		echo "comparison[$k]['line_old']   = '" . $comparison[$k]['line_old'] . "';\n";
		echo "comparison[$k]['line_new']   = '" . $comparison[$k]['line_new'] . "';\n";
		echo "comparison[$k]['string']     = '" . rtrim(htmlspecialchars($comparison[$k]['string'], ENT_QUOTES)) . "';\n";
		echo "comparison[$k]['change']     = '" . $comparison[$k]['change'] . "';\n";
		echo "comparison[$k]['validation'] = '" . $comparison[$k]['validation'] . "';\n";
	} // end for
	echo "printComparisonValidation(1);\n";
	echo "//--></script>\n";



	echo "</form>\n";

} // End function printComparisonSelect

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printComparisonList($comparison, $directory, $entry) {

// --------------
// This function prints out the $comparison array returned by the function compareFiles
// as a text with the list of additions and deletions
//
// Input:
// $comparison[$index]['string']   = "a code line";
// $comparison[$index]['line_old'] = $line_old; // if line was deleted
// $comparison[$index]['line_new'] = $line_new; // if line was added
// $comparison[$index]['change']   = "deleted", "added" or "unchanged";
//
// Output:
// The $comparison array that will be returned when submiting the form, is slightly different
// from the input one, because the lines are grouped as blocks
//
// $comparison[$k]['string'] == "line k\nline k+1\n"; // all lines of the block
// $comparison[$k]['validation'] == "yes";            // all lines of the block
// $comparison[$k+1]['string'] == "";                 // empty
// $comparison[$k+1]['validation'] == "";             // empty
//
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	$update_nrofcolumns = 100;

// -------------------------------------------------------------------------
// Form
// -------------------------------------------------------------------------
	echo "<form name=\"ComparisonForm\" id=\"ComparisonForm\" action=\"" . printPHP_SELF("") . "\" method=\"post\">\n";
	printLoginInfo();
	echo "<input type=\"hidden\" name=\"state\" value=\"manage\" />\n";
	echo "<input type=\"hidden\" name=\"state2\" value=\"updatefile\" />\n";
	echo "<input type=\"hidden\" name=\"screen\" value=\"screen3\" />\n";
	echo "<input type=\"hidden\" name=\"directory\" value=\"$directory\" />\n";
	echo "<input type=\"hidden\" name=\"entry\" value=\"$entry\" />\n";

	printBackInForm($directory, "ComparisonForm");
	printForwardInForm("ComparisonForm");

// -------------------------------------------------------------------------
// List
// -------------------------------------------------------------------------

	echo "<table border=\"0\" width=\"100%\" cellspacing=\"2\" cellpadding=\"2\">\n";

// -------------------------------------------------------------------------
// Primary loop over the whole array
// Note that the third argument of the for loop is not filled in; the index is incremented inside the for loop
// -------------------------------------------------------------------------
	for ($k=1; $k<count($comparison);) {

// Background colors
		if     ($comparison[$k]['change'] == "deleted") { $bgcolor = "#EE4422"; }
		elseif ($comparison[$k]['change'] == "added")   { $bgcolor = "#55CC44"; }
		else                                            { $bgcolor = "#CCCCCC"; }
// Calculate how big the block of unchanged/added/deleted lines is
		$nr_changed_lines = 1;
		while ($comparison[$k+$nr_changed_lines]["change"] == $comparison[$k]["change"]) { $nr_changed_lines++; }

// Header row
		if ($comparison[$k]['change'] == "unchanged") {
			echo "<tr style=\"background-color: $bgcolor;\"><td colspan=\"2\">\n";
			echo "Unchanged code\n";
			echo "<input type=\"hidden\" name=\"comparison[$k]['change']\" value=\"" . $comparison[$k]['change'] . "\" />\n";
			echo "</td></tr>\n";
		}
		elseif ($comparison[$k]['change'] == "added" || $comparison[$k]['change'] == "deleted") {
			echo "<tr style=\"background-color: $bgcolor;\"><td colspan=\"2\">\n";
			if ($comparison[$k]['change'] == "added")   { $yes_text = "Add";    $no_text = "Don't add"; }
			if ($comparison[$k]['change'] == "deleted") { $yes_text = "Delete"; $no_text = "Don't delete"; }

			echo "Validate change: <input type=\"radio\" name=\"comparison[$k]['validation']\" value=\"yes\" checked> $yes_text &nbsp &nbsp <input type=\"radio\" name=\"comparison[$k]['validation']\" value=\"yes\"> $no_text\n";
			echo "<input type=\"hidden\" name=\"comparison[$k]['change']\" value=\"" . $comparison[$k]['change'] . "\" />\n";
			echo "</td></tr>\n";
		}

// Start of the textarea
		if ($comparison[$k]['change'] == "unchanged" || $comparison[$k]['change'] == "added") {
			$beginline = $comparison[$k]["line_new"];
			$endline = $beginline + $nr_changed_lines - 1;
			$whichfile = "new file";
		}
		else {
			$beginline = $comparison[$k]["line_old"];
			$endline = $beginline + $nr_changed_lines - 1;
			$whichfile = "old file";
		}
		echo "<tr style=\"background-color: $bgcolor;\"><td valign=\"top\"> $beginline to $endline <br /> $whichfile</td><td>\n";
		if ($comparison[$k]['change'] != "added") { $readonly = "readonly"; }
		$update_nrofrows = $nr_changed_lines;
		echo "<textarea name=\"comparison[$k]['string']\" class=\"edit\" rows=\"$update_nrofrows\" cols=\"$update_nrofcolumns\" wrap=\"off\" $readonly>";


// -------------------------------------------------------------------------
// Secondary loop over the block of unchanged/added/deleted lines
// -------------------------------------------------------------------------
		for ($m=$k; $m<$k+$nr_changed_lines; $m++) {

// Replace special characters to display them nicely in HTML
// Replace space " " by " &nbsp;"
// Replace tab "	" by " &nbsp; &nbsp; &nbsp; &nbsp;"
			$string_html = htmlspecialchars($comparison[$m]['string'], ENT_QUOTES);
//			$string_printed = str_replace("  "," &nbsp;", $string_html);
//			$string_printed = str_replace("\t", "&nbsp&nbsp&nbsp&nbsp;", $string_printed);

			echo "$string_html\n";

		} // end for $m

// -----------------------------------
// End of secondary loop
// -----------------------------------
		echo "</textarea>\n";
		echo "</td></tr>\n";

		$k = $k + $nr_changed_lines;

	} // end for $k

	echo "</table>\n";

} // End function printComparisonList

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************








// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function mergeStrings($comparison) {

// --------------
// This function merges 2 files based on the comparison array
// --------------

	$string_merged = "";

// Don't use for loop because there are holes in the comparison array: 
// Index 1, 39, 40, 44 corresponds with count()=4
//	for ($k=1; $k<=count($comparison); $k++) {

	while (list($key,$value) = each($comparison)) {
echo "<br />key: ";
print_r($key);
echo "<br />value: ";
print_r($value);
echo "<br />value, change: " . $value['change'];
echo "<br />value, validation: " . $value['validation'];
//		if ($value['change'] == "unchanged" || ($value['change'] == "added"   && $value['validation'] == "yes") || ($value['change'] == "deleted" && $value['validation'] == "no")) { $string_merged .= $value['string']; }
	} // end while

	return $string_merged;

} // End function mergeStrings

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






?>