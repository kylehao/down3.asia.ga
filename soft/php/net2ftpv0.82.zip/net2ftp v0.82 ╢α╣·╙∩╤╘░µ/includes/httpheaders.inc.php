<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------

// -------------------------------------------------------------------------
// Don't cache any page
// -------------------------------------------------------------------------
if ($state == "manage" && ($state2 != "downloadfile" && $state2!= "download")) {
	header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
}

// -------------------------------------------------------------------------
// Character set
// -------------------------------------------------------------------------
header("content-type: text/html;charset=" . __("iso-8859-1") . " \r\n");


// -------------------------------------------------------------------------
// Set cookie with login information and last directory used
// See index.php, printLoginForm and browse
// -------------------------------------------------------------------------
if ($state == "browse") {
// This if condition is needed, otherwise the directory is set to ""
// when logging out (the directory is "" at that point)
	setcookie ("net2ftpcookie_ftpserver",     $net2ftp_ftpserver, time()+60*60*24*30);
	setcookie ("net2ftpcookie_ftpserverport", $net2ftp_ftpserverport, time()+60*60*24*30);
	setcookie ("net2ftpcookie_username",      $net2ftp_username, time()+60*60*24*30);
	setcookie ("net2ftpcookie_language",      $net2ftp_language, time()+60*60*24*30);
	setcookie ("net2ftpcookie_skin",          $net2ftp_skin, time()+60*60*24*30);
	setcookie ("net2ftpcookie_ftpmode",       $net2ftp_ftpmode, time()+60*60*24*30);
	setcookie ("net2ftpcookie_passivemode",   $net2ftp_passivemode, time()+60*60*24*30);
	setcookie ("net2ftpcookie_sslconnect",    $net2ftp_sslconnect, time()+60*60*24*30);
	setcookie ("net2ftpcookie_viewmode",      $net2ftp_viewmode, time()+60*60*24*30);
	setcookie ("net2ftpcookie_sort",          $net2ftp_sort, time()+60*60*24*30);
	setcookie ("net2ftpcookie_sortorder",     $net2ftp_sortorder, time()+60*60*24*30);
	setcookie ("net2ftpcookie_directory",     $directory, time()+60*60*24*30);
}
elseif ($cookieset == "clear") {
	setcookie ("net2ftpcookie_ftpserver",     "", 0);
	setcookie ("net2ftpcookie_ftpserverport", "", 0);
	setcookie ("net2ftpcookie_username",      "", 0);
	setcookie ("net2ftpcookie_language",      "", 0);
	setcookie ("net2ftpcookie_skin",          "", 0);
	setcookie ("net2ftpcookie_ftpmode",       "", 0);
	setcookie ("net2ftpcookie_passivemode",   "", 0);
	setcookie ("net2ftpcookie_sslconnect",    "", 0);
	setcookie ("net2ftpcookie_viewmode",      "", 0);
	setcookie ("net2ftpcookie_sort",          "", 0);
	setcookie ("net2ftpcookie_sortorder",     "", 0);
	setcookie ("net2ftpcookie_directory",     "", 0);
	header("Location:index.php");
	exit();
}


// -------------------------------------------------------------------------
// Delete cookie with login information; see printLogoutForm()
// -------------------------------------------------------------------------
//if ($cookiedeleteonlogout == "yes") {
//	setcookie ("net2ftpcookie_password", "", time()+60*60*24*30);
//}


// -------------------------------------------------------------------------
// Download one file
// -------------------------------------------------------------------------
if ($state == "manage" && $state2 == "downloadfile") {
	if ($settings['functionuse_downloadfile'] == "yes") {
		ftp_downloadfile($directory, $entry);
	}
	else {
		$errormessage = __("This function has been disabled by the Administrator of this website.");
		setErrorVars(false, $errormessage, debug_backtrace());
		printErrorMessage();
	}
} // end if downloadfile

// -------------------------------------------------------------------------
// Zip-and-download files and directories
// -------------------------------------------------------------------------
elseif ($state == "manage" && $state2 == "download") {
	if ($settings['functionuse_zip_download'] == "yes") {
	// Filter the list entries which were selected from the ones that were not selected
		$list = getSelectedEntries($list);
	// Check that at least one entry was selected
		if (sizeof($list) < 1) {
			$errormessage = "Please select at least one directory or file !";
			setErrorVars(false, $errormessage, debug_backtrace());
		}
		else {
			$zipactions['download'] = "yes";
			$zipactions['email'] = "no";
			$zipactions['save'] = "no";
			ftp_zip($conn_id, $directory, $list, $zipactions, $zipdir, 0);
		}
	}
	else {
		$errormessage = __("This function has been disabled by the Administrator of this website.");
		setErrorVars(false, $errormessage, debug_backtrace());
	}
} // end elseif download

// -------------------------------------------------------------------------
// View images
// -------------------------------------------------------------------------
elseif ($state == "manage" && $state2 == "viewimage") {
	if ($settings['functionuse_view'] == "yes") {
		viewImage($directory, $entry);
	}
	else {
		$errormessage = __("This function has been disabled by the Administrator of this website.");
		setErrorVars(false, $errormessage, debug_backtrace());
	}
}

// -------------------------------------------------------------------------
// END OF SCRIPT
// -------------------------------------------------------------------------
if ($state == "manage" && ($state2 == "downloadfile" || $state2 == "download" || $state2 == "viewimage")) {

// Store consumption
	$endtime = microtime();
	addConsumption(0, timer());
	putConsumption();
	
// If an error did occur, print out an error message
	if ($execution_success == false) { printErrorMessage(); }

// Exit: do not continue the script
	exit();
}


// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function sendDownloadHeaders($filename, $filesize) {

// --------------
// This function sends download headers to the browser
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $browser_agent, $browser_version;

// -------------------------------------------------------------------------
// Clean the input, and encode the filename with htmlentities
// -------------------------------------------------------------------------
	$filename = trim($filename);
	$filename_html = @htmlentities($filename, ENT_QUOTES, __("iso-8859-1"));

// -------------------------------------------------------------------------
// Check which is the content type and disposition
// -------------------------------------------------------------------------
	$content_type = getContentType($filename);

	$content_disposition = "attachment";
	if (strpos($filename, ".zip") !== false) { $content_disposition = "inline"; }

// -------------------------------------------------------------------------
// Send the headers - Internet Explorer
// php.net, arabold AT nero DOT com (15-May-2003 10:11)
// PhpMyAdmin: lem9 & loic1
// -------------------------------------------------------------------------
	if ($browser_agent == "IE") {
		if (isset($_SERVER["HTTPS"])) {
			header("Pragma: ");
			header("Cache-Control: ");
			header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
			header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
			header("Cache-Control: no-store, no-cache, must-revalidate"); // HTTP/1.1
			header("Cache-Control: post-check=0, pre-check=0", false);
		}
		else {
			header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
			header('Pragma: public');
		}
	} 
// -------------------------------------------------------------------------
// Send the headers - Mozilla, Opera and other browsers
// -------------------------------------------------------------------------
	else {
		header('Pragma: no-cache');
	}

	header('Content-Type: ' . $content_type);
	header('Content-Disposition: $content_disposition; filename="' . $filename_html . '"');
	header("Content-Description: $filename_html");
	header("Content-Length: $filesize"); 
	header("Connection: close");

} // End function sendDownloadHeaders

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






?>