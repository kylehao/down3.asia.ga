<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function ftp_openconnection() {

// --------------
// This function opens an ftp connection
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $net2ftp_ftpserver, $net2ftp_ftpserverport, $net2ftp_username, $net2ftp_password_encrypted, $net2ftp_passivemode, $net2ftp_sslconnect;
	global $net2ftp_systype;

// Check if the FTP module of PHP is installed
	if (function_exists("ftp_connect") == false) { 
		$errormessage = __("The <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this FTP module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">php.net</a><br />");
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

// Decrypt password
	$net2ftp_password = decryptPassword($net2ftp_password_encrypted);

// Check if port nr is filled in
	if ($net2ftp_ftpserverport < 1 || $net2ftp_ftpserverport > 65535 || $net2ftp_ftpserverport == "") { $net2ftp_ftpserverport = 21; }

// Set up basic connection
	$ftp_connect = "ftp_connect";
	if ($net2ftp_sslconnect == "yes" && function_exists("ftp_ssl_connect")) { $ftp_connect = "ftp_ssl_connect"; }
	$conn_id = $ftp_connect("$net2ftp_ftpserver", $net2ftp_ftpserverport);
	if ($conn_id == false) {
		$errormessage = __("Unable to connect to FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />", $net2ftp_ftpserver, $net2ftp_ftpserverport); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

// Login with username and password
	$login_result = ftp_login($conn_id, $net2ftp_username, $net2ftp_password);
	if ($login_result == false) { 
		$errormessage = __("Unable to login to FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />", $net2ftp_ftpserver, $net2ftp_username);
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

// Set passive mode
	if ($net2ftp_passivemode == "yes") { 
		$success = ftp_pasv($conn_id, TRUE); 
		if ($success == false) { 
			$errormessage = __("Unable to switch to the passive mode on FTP server <b>%1\$s</b>.", $net2ftp_ftpserver);
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}
	}

// Get the system type
	$net2ftp_systype = ftp_systype($conn_id);

// Return the connection ID
	return $conn_id;


} // End function ftp_openconnection

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **
function ftp_openconnection2() {

// --------------
// This function opens an ftp connection to the secondary FTP server, to which
// files can be copied or moved.
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $input_ftpserver2, $input_ftpserverport2, $input_username2, $input_password2, $net2ftp_passivemode;
	global $net2ftp_systype2;

// Check if the FTP module of PHP is installed
	if (function_exists("ftp_connect") == false) { 
		$errormessage = __("The <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this FTP module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">php.net</a><br />");
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

// Clean the values that have been filled in 
	$input_ftpserver2 = cleanFtpserver($input_ftpserver2);
	$input_ftpserverport2 = trim($input_ftpserverport2);
	$input_username2 = trim($input_username2);
	$input_password2 = trim($input_password2);

// Check if port nr is correct
	if ($input_ftpserverport2 < 1 || $input_ftpserverport2 > 65535 || $input_ftpserverport2 == "") { $input_ftpserverport2 = 21; }

// Set up basic connection
	$conn_id = ftp_connect("$input_ftpserver2", $input_ftpserverport2);
	if ($conn_id == false) { 
		$errormessage = __("Unable to connect to the second (target) FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the second (target) FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />");
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

// Login with username and password
	$login_result = ftp_login($conn_id, $input_username2, $input_password2);
	if ($login_result == false) { 
		$errormessage = __("Unable to login to the second (target) FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />", $input_ftpserver2, $input_username2);
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

// Set passive mode
	if ($net2ftp_passivemode == "yes") { 
		$success = ftp_pasv($conn_id, TRUE); 
		if ($success == false) { 
			$errormessage = __("Unable to switch to the passive mode on the second (target) FTP server <b>%1\$s</b>.", $input_ftpserver2); 
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}
	}

// Get the system type
	$net2ftp_systype2 = ftp_systype($conn_id);

// Return the connection ID
	return $conn_id;

} // End function ftp_openconnection2

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function ftp_closeconnection($conn_id) {

// --------------
// This function closes an ftp connection
// --------------

	ftp_quit($conn_id);

} // End function ftp_closeconnection

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function ftp_myrename($conn_id, $directory, $entry, $newName) {

// --------------
// This function renames a directory
// --------------

	$old = glueDirectories($directory, $entry);
	$new = glueDirectories($directory, $newName);

	$success1 = ftp_rename($conn_id, $old, $new);
	if ($success1 == false) { 
		$errormessage = __("Unable to rename directory or file <b>%1\$s</b> into <b>%2\$s</b>", $old, $new);
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

} // End function ftp_myrename

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************







// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function ftp_mychmod($conn_id, $directory, $list, $divelevel) {

// --------------
// This function chmods a directory or file
//
// $list[$i]['dirorfile'] contains d or - which indicates if the entry is a directory or a file
// $list[$i]['dirfilename'] contains the name of the entry
// $list[$i]['chmodoctal'] contains the 3-digit nr 
//
// If the entry is a directory, $list[$i]['chmod_subdirectories'] and $list[$i]['chmod_subfiles'] are "yes" if 
// the subdirectories and files within the chmodded directory should also be chmodded
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;

// -------------------------------------------------------------------------
// Separate the directories from the files
// -------------------------------------------------------------------------
	$counter_directories = 1;
	$counter_files = 1;
	for ($i=1; $i<=count($list); $i=$i+1) {
		if     ($list[$i]['dirorfile'] == "d") { $list_directories[$counter_directories] = $list[$i]; $counter_directories = $counter_directories + 1; }
		elseif ($list[$i]['dirorfile'] == "-") { $list_files[$counter_files] = $list[$i];             $counter_files = $counter_files + 1; }
	}

// -------------------------------------------------------------------------
// For all directories
// -------------------------------------------------------------------------
	for ($i=1; $i<=count($list_directories); $i=$i+1) {

		$currentdirectory = glueDirectories($directory, $list_directories[$i]['dirfilename']);

// ------------------------------------
// Chmod the directory
// If the $divelevel == 0 then chmod it in any case as it is the top directory
// If the $divelevel > 0  then chmod it only if chmod_subdirectories == "yes"
// ------------------------------------
		if ($list_directories[$i]['chmod_subdirectories'] == "yes" || $divelevel == 0) {
			$sitecommand = "chmod 0" . $list_directories[$i]['chmodoctal'] . " $currentdirectory";
			$success1 = ftp_site($conn_id, $sitecommand);
			if ($success1 == false) { 
				$errormessage =  __("Unable to execute site command <b>%1\$s</b>. Note that the CHMOD command is only available on Unix FTP servers, not on Windows FTP servers.", $sitecommand); 
				setErrorVars(false, $errormessage, debug_backtrace());
				return false; 
			}
			elseif ($success1 == true)  { 
				echo __("Directory <b>%1\$s</b> successfully chmodded to <b>%2\$s</b>", $currentdirectory, $list_directories[$i]['chmodoctal']) . "<br />\n"; 
			}
		}

// ------------------------------------
// If the subdirectories and files within the current directory also have to be chmodded...
// ------------------------------------
		if ($list_directories[$i]['chmod_subdirectories'] == "yes" || $list_directories[$i]['chmod_subfiles'] == "yes") {

// Get a new list
			$nicelist_warnings_directory = ftp_getlist($conn_id, $currentdirectory);
			if ($execution_success == false) { return false; }

			$newlist = $nicelist_warnings_directory[1];

// Add information to the list
			for ($j=1; $j<=count($newlist); $j++) {
				$newlist[$j]['chmodoctal'] = $list_directories[$i]['chmodoctal'];
				$newlist[$j]['chmod_subdirectories'] = $list_directories[$i]['chmod_subdirectories'];
				$newlist[$j]['chmod_subfiles'] = $list_directories[$i]['chmod_subfiles'];
			}

// Call the function recursively
			$newdivelevel = $divelevel + 1;
			ftp_mychmod($conn_id, $currentdirectory, $newlist, $newdivelevel);

		} // end if subdirectories and files

	} // end for list_directories

// -------------------------------------------------------------------------
// Process the files
// -------------------------------------------------------------------------

	for ($i=1; $i<=count($list_files); $i=$i+1) {

		$currentfile = glueDirectories($directory, $list_files[$i]['dirfilename']);

// Chmod the files
// If the $divelevel == 0 then chmod them in any case as they are the top files
// If the $divelevel > 0  then chmod them only if chmod_subfiles == "yes"

		if ($list_files[$i]['chmod_subfiles'] == "yes" || $divelevel == 0) {
			$sitecommand = "chmod 0" . $list_files[$i]['chmodoctal'] . " $currentfile";
			$success2 = ftp_site($conn_id, $sitecommand);
			if ($success2 == false) { 
				$errormessage =  __("Unable to execute site command <b>%1\$s</b>. Note that the CHMOD command is only available on Unix FTP servers, not on Windows FTP servers.", $sitecommand); 
				setErrorVars(false, $errormessage, debug_backtrace());
				return false; 
			}
			elseif ($success2 == true)  { 
				echo __("File <b>%1\$s</b> was successfully chmodded to <b>%2\$s</b>", $currentfile, $list_files[$i]['chmodoctal']) . "<br />\n"; 
			}
		}

	} // end for list_files

// Print message
	if ($divelevel == 0) { echo "<br /><br />" . __("All the selected directories and files have been processed.") . "<br /><br />\n"; }

} // End function ftp_mychmod

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************







// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function ftp_rmdir2($conn_id, $directory) {

// --------------
// This function deletes a directory
// --------------

// Replace \' by \\' to be able to delete directories with names containing \'
	$directory = str_replace("\'", "\\\'", $directory);

// QUICK WAY TO DELETE A DIRECTORY
	$success1 = ftp_rmdir($conn_id, $directory);

// THE FTP_RMDIR MAY NOT WORK WITH ALL FTP SERVERS, AS DESCRIBED ON THE FORUM
// http://www.net2ftp.org/forums/index.php?showtopic=658
// Solution: to delete /dir/parent/dirtodelete
//    1. chdir to the parent directory  /dir/parent
//    2. delete the subdirectory, but use only its name (dirtodelete), not the full path (/dir/parent/dirtodelete)

	if ($success1 == false) {
		ftp_chdir($conn_id, upDir($directory));
		$parts = explode("/", $directory);
		$lastpartnr = count($parts)-1;
		$success2 = ftp_rmdir($conn_id, $parts[$lastpartnr]);
		if ($success2 == false) { 
			$errormessage = __("Unable to delete the directory <b>%1\$s</b>", $directory); 
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}
	}

} // End function ftp_rmdir2

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function ftp_delete2($conn_id, $file) {

// --------------
// This function deletes a file
// --------------

// Replace \' by \\' to be able to delete directories with names containing \'
	$file = str_replace("\'", "\\\'", $file);

	$success1 = ftp_delete($conn_id, $file);

// THE FTP_RMDIR MAY NOT WORK WITH ALL FTP SERVERS, AS DESCRIBED ON THE FORUM
// http://www.net2ftp.org/forums/index.php?showtopic=658
// Solution: to delete /dir/parent/dirtodelete
//    1. chdir to the parent directory  /dir/parent
//    2. delete the subdirectory, but use only its name (dirtodelete), not the full path (/dir/parent/dirtodelete)

	if ($success1 == false) {
		ftp_chdir($conn_id, upDir($file));
		$parts = explode("/", $file);
		$lastpartnr = count($parts)-1;
		$success2 = ftp_delete($conn_id, $parts[$lastpartnr]);
		if ($success2 == false) { 
			$errormessage = __("Unable to delete the file <b>%1\$s</b>", $file); 
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}
	}

} // End function ftp_delete2

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function ftp_newdirectory($conn_id, $directory) {

// --------------
// This function creates a new remote directory
// --------------

	$success1 = ftp_mkdir($conn_id, $directory);
	if ($success1 == false) { 
		$errormessage = __("Unable to create the directory <b>%1\$s</b>", $directory);
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

} // End function ftp_newdirectory

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function ftp_readfile($conn_id, $directory, $file) {

// --------------
// This function opens a remote text file and it returns a string
// It can be used stand-alone (with conn_id = "") and then a new connection is opened
// Else it can also be used in a loop (with conn_id != false) and then the existing connection is opened
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $application_tempdir;

	$source = glueDirectories($directory, $file);

// Step 1/4: Create a temporary filename
	$tempfilename = tempnam($application_tempdir, "read__");
	if ($tempfilename == false)  { 
		@unlink($tempfilename); 
		$errormessage = __("Unable to create the temporary file. Check the permissions of the %1\$s directory.", $application_tempdir);		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}
	registerTempfile("register", $tempfilename);

// Step 2/4: Copy remote file to the temporary file
// Open connection if needed
	if ($conn_id == "") {
		$conn_id = ftp_openconnection();
		if ($execution_success == false)  { 
			@unlink($tempfilename); 
			return false;
		}
		$leave_conn_open = "no";
	}

// Check the consumption
	if(checkConsumption() == false) {
		$errormessage = __("Daily limit reached: the file <b>%1\$s</b> will not be transferred", $source);
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

// Get file
	$ftpmode = ftpAsciiBinary($source);

	$success1 = ftp_get($conn_id, "$tempfilename", "$source", $ftpmode);
	if ($success1 == false) { 
		@unlink($tempfilename); 
		$errormessage = __("Unable to get the file <b>%1\$s</b> from the FTP server and to save it as temporary file <b>%2\$s</b>.<br />Check the permissions of the %3\$s directory.<br />", $source, $tempfilename, $application_tempdir);
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

// Add the filesize to the global consumption variables
	addConsumption(filesize($tempfilename), 0);

// Close connection
	if ($leave_conn_open == "no") { ftp_closeconnection($conn_id); }

// Step 3/4: Read temporary file
	$string = local_readfile($tempfilename);
	if ($execution_success == false) { return false; }

// Step 4/4: Delete temporary file
	$success4 = @unlink($tempfilename);
	if ($success4 == false) {  
		$errormessage = __("Unable to delete the temporary file"); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	} 
	registerTempfile("unregister", $tempfilename);

// Change CarriageReturn+LineFeed by LineFeed
// This is because some FTP servers replace LineFeed by CarriageReturn+LineFeed
	if ($ftpmode == FTP_ASCII) {
		$string = standardize_eol($string);
	}

	return $string;

} // End function ftp_readfile

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************







// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function ftp_writefile($conn_id, $directory, $file, $string) {

// --------------
// This function writes a string to a remote text file.
// If it already existed, it will be overwritten without asking for a confirmation.
// It can be used stand-alone (with conn_id = "") and then a new connection is opened
// Else it can also be used in a loop (with conn_id != false) and then the existing connection is opened
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $application_tempdir;
	$target = glueDirectories($directory, $file);

// Step 0/4: Check if the string is empty; in that case, do nothing and return true
	if (strlen($string) < 1) { return true; }

	$ftpmode = ftpAsciiBinary($file);

// Change CarriageReturn+LineFeed by LineFeed
// This is because some FTP servers replace LineFeed by CarriageReturn+LineFeed
	if ($ftpmode == FTP_ASCII) {
		$string = standardize_eol($string);
	}

// Step 1/4: Create a temporary filename
	$tempfilename = tempnam($application_tempdir, "write__");
	if ($tempfilename == false)  { 
		@unlink($tempfilename); 
		$errormessage = __("Unable to create the temporary file. Check the permissions of the %1\$s directory.", $application_tempdir); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}
	registerTempfile("register", $tempfilename);

// Step 2/4: Write the string to the temporary file
	local_writefile($tempfilename, $string);
	if ($execution_success == false) { return false; }

// Step 3/4: Copy temporary file to remote file
// Open connection if needed
	if ($conn_id == "") {
		$conn_id = ftp_openconnection();
		if ($execution_success == false) {
			@unlink($tempfilename);
			return false;
		}
		$leave_conn_open = "no";
	}

// Add the filesize to the global consumption variables
	addConsumption(filesize($tempfilename), 0);

// Check the consumption
	if(checkConsumption() == false) {
		$errormessage = __("Daily limit reached: the file <b>%1\$s</b> will not be transferred", $target);
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

// Put file
	// The FTP mode is calculated a few lines above
	//$ftpmode = ftpAsciiBinary($file);

	$success3 = ftp_put($conn_id, $target, $tempfilename, $ftpmode);
	if ($success3 == false) { 
		@unlink($tempfilename); 
		$errormessage = __("Unable to put the file <b>%1\$s</b> on the FTP server.<br />You may not have write permissions on the directory.", $target);
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

// Close connection
	if ($leave_conn_open == "no") { ftp_closeconnection($conn_id); }

// Step 4/4: Delete temporary file
	$success4 = @unlink($tempfilename);
	if ($success4 == false) { 
		$errormessage = __("Unable to delete the temporary file"); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	} 
	registerTempfile("unregister", $tempfilename);

} // End function ftp_writefile

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function ftp_copymovedelete($conn_id_source, $conn_id_target, $list, $copymovedelete, $divelevel) {

// --------------
// This function copies/moves/deletes directories and files from an FTP server to the same
// or another FTP server. Files are first transferred from the source FTP server to the webserver, 
// and then transferred to the target FTP server.
//
// $list[$i]['dirorfile'] contains d or - which indicates if its a directory or a file
// $list[$i]['dirfilename'] contains the entry name
// $list[$i]['sourcedirectory'] contains the source directory
// $list[$i]['targetdirectory'] contains the target directory
// $list[$i]['newname'] contains the new name if divelevel = 0; for deeper levels the newname is the entry name itself
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $application_tempdir;

// -------------------------------------------------------------------------
// Separate the directories from the files
// -------------------------------------------------------------------------
	$counter_directories = 1;
	$counter_files = 1;
	for ($i=1; $i<=count($list); $i=$i+1) {
		if     ($list[$i]['dirorfile'] == "d") { $list_directories[$counter_directories] = $list[$i]; $counter_directories = $counter_directories + 1; }
		elseif ($list[$i]['dirorfile'] == "-") { $list_files[$counter_files] = $list[$i];             $counter_files = $counter_files + 1; }
	}

	if ($divelevel == 0) { echo "<ul>\n"; }

// -------------------------------------------------------------------------
// For all directories
// -------------------------------------------------------------------------
	for ($i=1; $i<=count($list_directories); $i=$i+1) {

// Source and target
		$source = glueDirectories($list_directories[$i]['sourcedirectory'], $list_directories[$i]['dirfilename']);
		if ($divelevel > 0) { $target = glueDirectories($list_directories[$i]['targetdirectory'], $list_directories[$i]['dirfilename']); } // Subdirectories keep their original names
		else                { $target = glueDirectories($list_directories[$i]['targetdirectory'], $list_directories[$i]['newname']); }     // First-level user-selected directories can have been renamed 

// Print starting message
		echo "<li> " . __("Processing directory <b>%1\$s</b>", $source) . " </li>\n";
		echo "<ul>\n";


// Check that the targetdirectory is not a subdirectory of the sourcedirectory
		if (($conn_id_source == $conn_id_target) && ($copymovedelete != "delete") && (isSubdirectory($source, $target) == true)) { 
			printWarningMessage("<li> " . __("The target directory <b>%1\$s</b> is the same as or a subdirectory of the source directory <b>%2\$s</b>, so this directory will be skipped", $target, $source) . " </li>"); 
			echo "</ul>\n";
			continue;			
		}

// Create the targetdirectory
		if ($copymovedelete == "copy" || $copymovedelete == "move") {
			$success1 = ftp_mkdir($conn_id_target, $target);
			if ($success1 == false) { printWarningMessage("<li> " . __("Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing the copy/move process...", $target) . " </li>"); }
			else                    { echo "<li> " . __("Created target subdirectory <b>%1\$s</b>", $target) . " </li>"; }
		}

// Get a new list
		$nicelist_warnings_directory = ftp_getlist($conn_id_source, $source);
		if ($execution_success == false) { return false; }
		$newlist = $nicelist_warnings_directory[1];

// Add information to the list
		for ($j=0; $j<count($newlist); $j++) {
			$newlist[$j]['sourcedirectory'] = $source;
			$newlist[$j]['targetdirectory'] = $target;
		}

// Call the function recursively
		$newdivelevel = $divelevel + 1;
		ftp_copymovedelete($conn_id_source, $conn_id_target, $newlist, $copymovedelete, $newdivelevel);

// Delete the source directory
		if ($copymovedelete == "move" || $copymovedelete == "delete") { 
			ftp_rmdir2($conn_id_source, $source);
 			if ($execution_success == false) { setErrorVars(true, "", ""); printWarningMessage ("<li> " . __("Unable to delete the subdirectory <b>%1\$s</b> - it may not be empty", $source) . " </li>"); }
			else                             { echo "<li> " . __("Deleted subdirectory <b>%1\$s</b>", $source) . " </li>"; }
		}

// Print ending message
		echo "<li> " . __("Processing of directory <b>%1\$s</b> completed", $source) . " </li>\n";
		echo "</ul>\n";

// Update the status 
		if ($divelevel == 0) {
			$total = $counter_directories + $counter_files - 2;
			setStatus_php($i, $total, __("Processing the entries"));
		}

	} // end for list_directories

// -------------------------------------------------------------------------
// Process the files
// -------------------------------------------------------------------------
	for ($i=1; $i<=count($list_files); $i=$i+1) {

// ------------------------------------
// Copy and move
// ------------------------------------
		if ($copymovedelete == "copy" || $copymovedelete == "move") {

// Source and target
			$source = glueDirectories($list_files[$i]['sourcedirectory'], $list_files[$i]['dirfilename']);
			if (isset($list_files[$i]['newname'])) { $target = glueDirectories($list_files[$i]['targetdirectory'], $list_files[$i]['newname']); }
			else                                   { $target = glueDirectories($list_files[$i]['targetdirectory'], $list_files[$i]['dirfilename']); }

// Check that the target is not the same as the source file
			if (($conn_id_source == $conn_id_target) && ($source == $target)) { 
				printWarningMessage("<li> " . __("The target for file <b>%1\$s</b> is the same as the source, so this file will be skipped", $source) . " </li>");
				continue;
			}

// Get file from remote sourcedirectory to local temp directory
// Don't delete the source file yet
			$localtargetdir = $application_tempdir;
			$localtargetfile = $list_files[$i]['dirfilename'] . ".txt";
			$remotesourcedir = $list_files[$i]['sourcedirectory'];
			$remotesourcefile = $list_files[$i]['dirfilename'];
			$ftpmode = ftpAsciiBinary($list_files[$i]['dirfilename']);
			$copymove = "copy";
	
			ftp_getfile($conn_id_source, $localtargetdir, $localtargetfile, $remotesourcedir, $remotesourcefile, $ftpmode, $copymove);
			if ($execution_success == false) { 
				setErrorVars(true, "", "");
				if     ($copymovedelete == "copy") { printWarningMessage("<li> " . __("Unable to copy the file <b>%1\$s</b>", $list_files[$i]['dirfilename']) . " </li>"); }
				elseif ($copymovedelete == "move") { printWarningMessage("<li> " . __("Unable to move the file <b>%1\$s</b>", $list_files[$i]['dirfilename']) . " </li>"); }
				continue; 
			}

// Put file from local temp directory to remote targetdirectory
// Delete the temporary file
			$localsourcedir = $application_tempdir;
			$localsourcefile = $list_files[$i]['dirfilename'] . ".txt";
			$remotetargetdir = $list_files[$i]['targetdirectory'];
			if (isset($list_files[$i]['newname'])) { $remotetargetfile  = $list_files[$i]['newname']; }
			else                                   { $remotetargetfile  = $list_files[$i]['dirfilename']; }
			$copymove = "move";

			ftp_putfile($conn_id_target, $localsourcedir, $localsourcefile, $remotetargetdir, $remotetargetfile, $ftpmode, $copymove);
			if ($execution_success == false) { 
				setErrorVars(true, "", "");
				if     ($copymovedelete == "copy") { printWarningMessage("<li> " . __("Unable to copy the file <b>%1\$s</b>", $list_files[$i]['dirfilename']) . " </li>"); }
				elseif ($copymovedelete == "move") { printWarningMessage("<li> " . __("Unable to move the file <b>%1\$s</b>", $list_files[$i]['dirfilename']) . " </li>"); }
				continue; 
			}
			elseif ($execution_success == true && $copymovedelete == "copy") { 
				echo "<li> " . __("Copied file <b>%1\$s</b>", $list_files[$i]['dirfilename']) . " </li>"; 
			}

// Move: only if the operation is successful, delete the source file
			elseif ($execution_success == true && $copymovedelete == "move") { 
				$remotesource = glueDirectories($list_files[$i]['sourcedirectory'], $list_files[$i]['dirfilename']);

				ftp_delete2($conn_id_source, $remotesource);
				if ($execution_success == false) { setErrorVars(true, "", ""); printWarningMessage("<li> " . __("Unable to move the file <b>%1\$s</b>", $list_files[$i]['dirfilename']) . " </li>"); }
				else                             { echo "<li> " . __("Moved file <b>%1\$s</b>", $list_files[$i]['dirfilename']) . " </li>"; }
			}

		} // end copy or move

// ------------------------------------
// Delete
// ------------------------------------
		elseif ($copymovedelete == "delete") {
			$remotesource = glueDirectories($list_files[$i]['sourcedirectory'], $list_files[$i]['dirfilename']);

			ftp_delete2($conn_id_source, $remotesource);
			if ($execution_success == false) { setErrorVars(true, "", ""); printWarningMessage("<li> " . __("Unable to delete the file <b>%1\$s</b>", $list_files[$i]['dirfilename']) . " </li>"); }
			else                             { echo "<li> " . __("Deleted file <b>%1\$s</b>", $list_files[$i]['dirfilename']) . " </li>"; }

		} // end delete

// Update the status 
		if ($divelevel == 0) {
			$total = $counter_directories + $counter_files - 2;
			setStatus_php($counter_directories + $i - 1, $total, __("Processing the entries"));
		}

	} // end for list_files

	if ($divelevel == 0) { echo "</ul>\n"; }

// Print message
	if ($divelevel == 0) { echo "<br /><span style=\"font-weight: bold;\">" . __("All the selected directories and files have been processed.") . "</span><br /><br />"; }

} // End function ftp_copymovedelete

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************








// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function ftp_processfiles($dowhat, $conn_id, $directory, $list, $options, $result, $divelevel) {

// --------------
// This function does something with files (get size, find string, ...)
// The $list contains both directories and files. The files are simply processed; the 
// directories are parsed recursively.
//
// $list[$i]['dirorfile'] contains d or - which indicates if the entry is a directory or a file
// $list[$i]['dirfilename'] contains the name of the entry
// $list[$i]['size'] contains the size of the entry
// 
// OPTIONS:
// if ($dowhat == "calculatesize") then
// 	$options = array()						doesn't contain anything
// if ($dowhat == "findstring") then
// 	$options['string'] 						a string
//	$options['case_sensitive'] 					blank or yes
//	$options['filename'] 						a filename with possible wildcard character * (it should match this preg_match regular expression: "/^[a-zA-Z0-9_ *-]*$/")
//	$options['size_from'], $options['size_to'] 		a number (in Bytes)
//	$options['modified_from'], $options['modified_to']	unix timestamps of the modification dates
//
// RESULT:
// if ($dowhat == "calculatesize") then
// 	$result['size']
//	$result['skipped']
// if ($dowhat == "findstring") then
// 	$result[$k]['directory'] contains the directory
// 	$result[$k]['dirfilename'] contains the filename
// 	$result[$k]['line'] contains the line nr 
//
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;

// -------------------------------------------------------------------------
// Separate the directories from the files
// -------------------------------------------------------------------------
	$counter_directories = 1;
	$counter_files = 1;
	for ($i=1; $i<=count($list); $i=$i+1) {
		if     ($list[$i]['dirorfile'] == "d") { $list_directories[$counter_directories] = $list[$i]; $counter_directories = $counter_directories + 1; }
		elseif ($list[$i]['dirorfile'] == "-") { $list_files[$counter_files] = $list[$i];             $counter_files = $counter_files + 1; }
	}

// -------------------------------------------------------------------------
// For all directories
// -------------------------------------------------------------------------
	for ($i=1; $i<=count($list_directories); $i=$i+1) {
		$currentdirectory = glueDirectories($directory, $list_directories[$i]['dirfilename']);

// Get a new list
		$nicelist_warnings_directory= ftp_getlist($conn_id, $currentdirectory);
		if ($execution_success == false) { return false; }
		$newlist = $nicelist_warnings_directory[1];

// Call the function recursively
		$newdivelevel = $divelevel + 1;
		$result = ftp_processfiles($dowhat, $conn_id, $currentdirectory, $newlist, $options, $result, $newdivelevel);
		if ($execution_success == false) { return false; }

	} // end for list_directories

// -------------------------------------------------------------------------
// Process the files
// -------------------------------------------------------------------------
	for ($i=1; $i<=count($list_files); $i=$i+1) {

// -------------------------------
// Calculate size
// -------------------------------
		if ($dowhat == "calculatesize") {
// Check if the size information is entered
// Check also if the size is numeric
			if (isset($list_files[$i]['size']) && preg_match("/^[0-9]+$/", $list_files[$i]['size'])) { $result['size']    = $result['size'] + $list_files[$i]['size']; }
			else                                                                                     { $result['skipped'] = $result['skipped'] + 1; }
		} // end if calculatesize

// -------------------------------
// Find string
// -------------------------------
		elseif ($dowhat == "findstring") {

// Check file size
			if ($list_files[$i]['size'] < $options['size_from'] || $list_files[$i]['size'] > $options['size_to'])   { continue; }

// Check modification date (if that data is returned by the FTP server in the correct format)

			$mtime_file = strtotime($list_files[$i]['mtime']);
			// If strtotime cannot interprete the data returned by the FTP server it returns -1
			if (($mtime_file != -1) && (($mtime_file < $options['modified_from']) || ($mtime_file > $options['modified_to']))) { continue; }

// Check the filename
			$pattern = "/^" . $options['filename'] . "$/i"; // i at the end is for a case-insensitive match
			if (preg_match($pattern, $list_files[$i]['dirfilename']) == 0) { continue; }

// Read the file
			$text = ftp_readfile("", $directory, $list_files[$i]['dirfilename']);

			// If the file could not be read correctly, continue to the next one
			if ($execution_success == false) { setErrorVars(true, "", ""); continue; }
			elseif ($text == "") { continue; }

// Split the file in an array, each element of the array containing one line of the file
			$text_lines = explode_lines($text);

// For each line, check if the string occurs
			for ($line=0; $line<count($text_lines); $line++) {

// STRSTR AND STRISTR
				if ($options['case_sensitive'] == "yes") { $found = strstr($text_lines[$line], $options['string']); }
				else                                     { $found = stristr($text_lines[$line], $options['string']); }

				if ($found != false) {
					$tempresult['directory'] = $directory;
					$tempresult['dirfilename'] = $list_files[$i]['dirfilename'];
					$tempresult['line']        = $line+1; // $text_lines[0] contains the line 1, etc...
					array_push($result, $tempresult);
				}

			} // end for 

		} // end if findstring

	} // end for list_files

	return $result;

} // End function ftp_processfiles

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************











// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function ftp_getfile($conn_id, $localtargetdir, $localtargetfile, $remotesourcedir, $remotesourcefile, $ftpmode, $copymove) {

// --------------
// This function copies or moves a remote file to a local file
// $ftpmode is used to specify whether the file is to be transferred in ASCII or BINARY mode
// $copymove is used to specify whether to delete (move) or not (copy) the local source
//
// True or false is returned
//
// The opposite function is ftp_putfile
// --------------

	if ($ftpmode == FTP_ASCII) { $printftpmode = "FTP_ASCII"; }
	elseif ($ftpmode == FTP_BINARY) { $printftpmode = "FTP_BINARY"; }

	$remotesource = glueDirectories($remotesourcedir, $remotesourcefile);
	$localtarget  = glueDirectories($localtargetdir, $localtargetfile);

// Check the consumption
	if(checkConsumption() == false) {
		$errormessage = __("Daily limit reached: the file <b>%1\$s</b> will not be transferred", $remotesource);
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

// Get file
	$success1 = ftp_get($conn_id, $localtarget, $remotesource, $ftpmode);
	if ($success1 == false) { 
		$errormessage = __("Unable to copy the remote file <b>%1\$s</b> to the local file using FTP mode <b>%2\$s</b>", $remotesource, $printftpmode); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}
	else { registerTempfile("register", $localtarget); }

// Add the filesize to the global consumption variables
	addConsumption(filesize($localtarget), 0);

// Copy ==> do nothing
// Move ==> delete remote source file
	if ($copymove != "copy") {
		$success2 = ftp_delete2($conn_id, $remotesource);
		if ($success2 == false) { 
			$errormessage = __("Unable to delete file <b>%1\$s</b>", $remotesource);
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}
	}

} // End function ftp_getfile

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function ftp_putfile($conn_id, $localsourcedir, $localsourcefile, $remotetargetdir, $remotetargetfile, $ftpmode, $copymove) {

// --------------
// This function copies or moves a local file to a remote file
// $ftpmode is used to specify whether the file is to be transferred in ASCII or BINARY mode
// $copymove is used to specify whether to delete (move) or not (copy) the local source
//
// The opposite function is ftp_getfile
// --------------

	$localsource  = glueDirectories($localsourcedir, $localsourcefile);
	$remotetarget = glueDirectories($remotetargetdir, $remotetargetfile);

// In the function ftp_put, use FTP_BINARY without the double quotes, otherwhise ftp_put assumes FTP_ASCII
// DO NOT REMOVE THIS OR THE BINARY FILES WILL BE CORRUPTED (when copying, moving, uploading,...)
	if ($ftpmode == "FTP_BINARY") { $ftpmode = FTP_BINARY; } 

	if ($ftpmode == FTP_ASCII) { $printftpmode = "FTP_ASCII"; }
	elseif ($ftpmode == FTP_BINARY) { $printftpmode = "FTP_BINARY"; }

// Add the filesize to the global consumption variables
	addConsumption(filesize($localsource), 0);

// Check the consumption
	if(checkConsumption() == false) {
		$errormessage = __("Daily limit reached: the file <b>%1\$s</b> will not be transferred", $remotetarget);
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

// Put local file to remote file
// int ftp_put (int ftp_stream, string remote_file, string local_file, int mode)
	$success1 = ftp_put($conn_id, $remotetarget, $localsource, $ftpmode);
	if ($success1 == false) { 
		$errormessage = __("Unable to copy the local file to the remote file <b>%1\$s</b> using FTP mode <b>%2\$s</b>", $remotetarget, $printftpmode); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

// If ftp_put fails, this function returns an error message and does not delete the temporary file.
// In case the file was copied, a copy exists in the source directory.
// In case the file was moved, the only copy is in the temporary directory, and so this has to be moved back to the source directory.

// Copy ==> do nothing
// Move ==> delete local source file
	if ($copymove != "copy") {
		$success2 = unlink($localsource);
		if ($success2 == false) { 
			$errormessage = __("Unable to delete the local file"); 
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}
		else { registerTempfile("unregister", $localsource); }
	}

} // End function ftp_putfile

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function getContentType($entry) {

// --------------------
// Content-type, for a complete list, see http://www.isi.edu/in-notes/iana/assignments/media-types/media-types
// Content-disposition: attachment. See http://www.w3.org/Protocols/HTTP/Issues/content-disposition.txt
// --------------------

// Default values
	$fileType = getFileType($entry);
	$content_type = "application/octet-stream";

	if (get_filename_extension($entry)=="swf")      { $content_type = "application/x-shockwave-flash"; }

	elseif ($fileType == "TEXT")                    { $content_type = "text/plain"; }
	elseif ($fileType == "IMAGE") {
		if     (strpos($entry, ".jpg") !== false) { $content_type = "image/jpeg"; }
		elseif (strpos($entry, ".png") !== false) { $content_type = "image/png";  }
		elseif (strpos($entry, ".gif") !== false) { $content_type = "image/gif";  }
	}
	elseif ($fileType == "ARCHIVE") {
		if     (strpos($entry, ".zip") !== false) { $content_type = "application/zip"; }
	}
	elseif ($fileType == "OFFICE") {
		if     (strpos($entry, ".doc") !== false) { $content_type = "application/msword"; }
		elseif (strpos($entry, ".xls") !== false) { $content_type = "application/vnd.ms-excel"; }
		elseif (strpos($entry, ".ppt") !== false) { $content_type = "application/vnd.ms-powerpoint"; }

		elseif (strpos($entry, ".mpp") !== false) { $content_type = "application/vnd.ms-project"; }
	}
	
	return $content_type;
}

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function ftp_downloadfile($directory, $entry) {


// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $application_tempdir;

// -------------------------------------------------------------------------
// Get the file from the FTP server to the web server
// -------------------------------------------------------------------------

// Open connection
	$conn_id = ftp_openconnection();
	if ($execution_success == false)  { return false; }

// FTP mode
	$ftpmode = ftpAsciiBinary($entry);

// Temporary filename
	$tempfilename = tempnam($application_tempdir, "downl__");
	if ($tempfilename == false)  { 
		@unlink($tempfilename); 
		$errormessage = __("Unable to create the temporary file. Check the permissions of the %1\$s directory.", $application_tempdir);		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}
	registerTempfile("register", $tempfilename);

// Get the file
//          ftp_getfile($conn_id, $localtargetdir, $localtargetfile, $remotesourcedir, $remotesourcefile, $ftpmode, $copymove)
		ftp_getfile($conn_id, "", $tempfilename, $directory, $entry, $ftpmode, "copy");
		if ($execution_success == false) { 
			@unlink($tempfilename); 
			$errormessage = __("Unable to get the file <b>%1\$s</b> from the FTP server and to save it as temporary file <b>%2\$s</b>.<br />Check the permissions of the %3\$s directory.<br />", $entry, $tempfilename, $application_tempdir); 
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}

// Close connection
	ftp_closeconnection($conn_id);

// -------------------------------------------------------------------------
// Transfer temp file to browser
// -------------------------------------------------------------------------

// Send the download headers - this function is in httpheaders.inc.php
	sendDownloadHeaders($entry, filesize($tempfilename));

// --------------------
// Open file
// --------------------
// From the PHP manual:
// Note:  The mode may contain the letter 'b'. 
// This is useful only on systems which differentiate between binary and text 
// files (i.e. Windows. It's useless on Unix). If not needed, this will be 
// ignored. You are encouraged to include the 'b' flag in order to make your scripts 
// more portable.
// Thanks to Malte for bringing this to my attention !
	registerTempfile("register", $tempfilename);
	$handle = fopen($tempfilename , "rb"); 
	if ($handle == false) {
		@unlink($tempfilename); 
		$errormessage = __("Unable to open the temporary file. Check the permissions of the %1\$s directory.", $application_tempdir); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

// --------------------
// Send file to browser
// --------------------
	$success1 = fpassthru($handle);
	if ($success1 == false) {
		@unlink($tempfilename); 
		$errormessage = __("Unable to send the file to the browser"); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

// --------------------
// Close file: not needed as fpassthru closes it already !!!
// --------------------
	//$success2 = @fclose($handle);

// --------------------
// Delete the temporary file
// --------------------
	$success3 = @unlink($tempfilename);
	if ($success3 == false) { 
		$errormessage = __("Unable to delete the temporary file"); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	} 
	registerTempfile("unregister", $tempfilename);

} // End function ftp_downloadfile

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function ftp_zip($conn_id, $directory, $list, $zipactions, $zipdir, $divelevel) {

// --------------
// This function allows to download/save/email a zipfile which contains the selected directories and files
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $settings;
	global $zipfile;
	global $application_tempdir;


// -------------------------------------------------------------------------
// Initialization
// -------------------------------------------------------------------------

// If $zipactions['download'] == "yes" and an error occurs, print the HTML header and footer
// In other cases, the header and footer are printed outside of this function
	if ($zipactions['download'] == "yes") { $printheaderfooter = "headerfooter"; }

	if ($divelevel == 0) {
// Create the zipfile
		$list = getSelectedEntries($list);
		$zipfile = new zipfile();
		$timenow = time();
		$zipdir = "";

// Open the connection
		$conn_id = ftp_openconnection();
		if ($execution_success == false)  { return false; }
	}

// -------------------------------------------------------------------------
// Separate the directories from the files
// -------------------------------------------------------------------------
	$counter_directories = 1;
	$counter_files = 1;
	for ($i=1; $i<=count($list); $i=$i+1) {
		if     ($list[$i]['dirorfile'] == "d") { $list_directories[$counter_directories] = $list[$i]; $counter_directories = $counter_directories + 1; }
		elseif ($list[$i]['dirorfile'] == "-") { $list_files[$counter_files] = $list[$i];             $counter_files = $counter_files + 1; }
	}

// -------------------------------------------------------------------------
// For all directories...
// -------------------------------------------------------------------------
	for ($i=1; $i<=count($list_directories); $i++) {
		$newdir = glueDirectories($directory, $list_directories[$i]['dirfilename']);
		$newzipdir = glueDirectories($zipdir, $list_directories[$i]['dirfilename']);
		$newdivelevel = $divelevel + 1;

		$nicelist_warnings_directory = ftp_getlist($conn_id, $newdir);
		if ($execution_success == false) { setErrorVars(true, "", ""); continue; }
		$newlist = $nicelist_warnings_directory[1];

		ftp_zip($conn_id, $newdir, $newlist, $zipactions, $newzipdir, $newdivelevel);
		if ($execution_success == false) { setErrorVars(true, "", ""); continue; }

		if ($divelevel == 0 && ($zipactions['save'] == "yes" || $zipactions['email'] == "yes")) {
			$total = $counter_directories + $counter_files - 2;
			setStatus_php($i, $total, __("Processing the entries"));
		}

	} // end for directories

// -------------------------------------------------------------------------
// For all files...
// -------------------------------------------------------------------------

	for ($i=1; $i<=count($list_files); $i++) {
		$text = ftp_readfile($conn_id, $directory, $list_files[$i]['dirfilename']);
		if ($execution_success == false) { setErrorVars(true, "", ""); continue; }

		$filename = stripDirectory(glueDirectories($zipdir, $list_files[$i]['dirfilename']));
		$zipfile->addFile($text, $filename);

		if ($divelevel == 0 && ($zipactions['save'] == "yes" || $zipactions['email'] == "yes")) {
			$total = $counter_directories + $counter_files - 2;
			setStatus_php($counter_directories + $i - 1, $total, __("Processing the entries"));
		}

	} // end for files

// -------------------------------------------------------------------------
// End
// -------------------------------------------------------------------------
	if ($divelevel == 0) {

// ------------------------
// Send the zipfile to the browser
// ------------------------
		if ($zipactions['download'] == "yes") {
			$timenow = time();
			
			$filenameToSend = "net2ftp-" . $timenow . ".zip";
			$filesizeToSend = strlen($zipfile->file());
			sendDownloadHeaders($filenameToSend, $filesizeToSend);

			echo $zipfile->file();
			flush();
		}

// ------------------------
// Save the zipfile string to a file
// ------------------------
		if ($zipactions['save'] == "yes" || $zipactions['email'] == "yes") {
			$string = $zipfile->file();

			$tempfilename = tempnam($application_tempdir, "zip__");
			if ($tempfilename == false)  { 
				@unlink($tempfilename); 
				$errormessage = __("Unable to create the temporary file. Check the permissions of the %1\$s directory.", $application_tempdir); 
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}
			registerTempfile("register", $tempfilename);

			local_writefile($tempfilename, $string);
			if ($execution_success == false) { return false; }
		}

// ------------------------
// Save the zip file to the FTP server
// ------------------------
		if ($zipactions['save'] == "yes") {
			ftp_putfile($conn_id, "", $tempfilename, $directory, $zipactions['save_filename'], FTP_BINARY, "copy");
			if ($execution_success == false) { 
				@unlink($tempfilename); 
				$errormessage = __("Unable to put the file <b>%1\$s</b> on the FTP server.<br />You may not have write permissions on the directory.", $zipactions['save_filename']); 
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}
			else { echo __("The zip file has been saved on the FTP server as <b>%1\$s</b>", $zipactions['save_filename']) . "<br /><br />\n"; }
		}		

// ------------------------
// Close the connection
// ------------------------
		ftp_closeconnection($conn_id);

// ------------------------
// Email
// ------------------------
		if ($zipactions['email'] == "yes") {

			$FromName = "net2ftp";
			$From = $settings["email_feedback"];

			$ToName = "";
			$To = $zipactions['email_to'];

			$Subject = __("Requested files");

			$Text = __("Zip email message", $To, $REMOTE_ADDR, mytime(), $HTTP_REFERER, $From, $zipactions['message']);
// Original English message:
//			$Text =  "Dear, \n\n";
//			$Text .= "Someone has requested the files in attachment to be sent to this email account ($To).\n";
//			$Text .= "If you know nothing about this or if you don't trust that person, please delete this email without opening the Zip file in attachment.\n";
//			$Text .= "Note that if you don't open the Zip file, the files inside cannot harm your computer.\n";
//			$Text .= "\n\n---------------------------------------\n";
//			$Text .= "Information about the sender:\n";
//			$Text .= "IP address: $REMOTE_ADDR\n";
//			$Text .= "Time of sending: " . mytime() . "\n";
//			$Text .= "Sent via the net2ftp application installed on this website: $HTTP_REFERER \n";
//			$Text .= "Webmaster's email: $From\n";
//			$Text .= "\n\n---------------------------------------\n";
//			$Text .= "Message of the sender:\n";
//			$Text .= $zipactions['message'] . "\n";
//			$Text .= "\n\n---------------------------------------\n";
//			$Text .= "net2ftp is free software, released under the GNU/GPL license. For more information, go to http://www.net2ftp.com\n\n\n";

			$AttmFiles = array($tempfilename);

			SendMail($From, $FromName, $To, $ToName, $Subject, $Text, $Html, $AttmFiles);
			if ($execution_success == false) { 
				@unlink($tempfilename); 
				return false; 
			}
			echo __("The zip file has been sent to <b>%1\$s</b>.", $To) . "<br /><br />";
		}

// ------------------------
// Delete the temporary zipfile
// ------------------------
		if ($zipactions['save'] == "yes" || $zipactions['email'] == "yes") {
			$success4 = @unlink($tempfilename);
			if ($success4 == false) { 
				$errormessage = __("Unable to delete the temporary file"); 
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}
			registerTempfile("unregister", $tempfilename);
		}

	}

} // End function ftp_zip

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function acceptFiles($uploadedFilesArray) {

// --------------
// This PHP function takes files that were just uploaded with HTTP POST, 
// verifies if the size is smaller than a certain value, and moves them 
// using move_uploaded_file() from the server's temporary directory to 
// net2ftp's temporary directory
//
// $uploadedFilesArray[number]["name"] and $acceptedFilesArray[number]["name"] contain the real name of the file
// $uploadedFilesArray[number]["tmp_name"] contains the temporary name of the file in the *webserver's* temporary directory (eg C:\temp)
// $acceptedFilesArray[number]["tmp_name"] contains the temporary name of the file in *net2ftp's* temporary directory (eg C:\web\net2ftp\temp)
//
// Note 1 - $acceptedFilesArray[number]["tmp_name"] may not be the same as $uploadedFilesArray[number]["tmp_name"] because 
//          $acceptedFilesArray[number]["tmp_name"] should be unique at the moment the file is transferred to the new directory.
// Note 2 - $acceptedFilesArray[number]["tmp_name"] 
//            - starts with upload (or upl on Windows, because on that platform only the first 3 letters are kept)
//            - has the same filename extension as the real filename 
//            - ends with .txt
//     The filename extension is needed by the PCL TAR library, which needs to determine if the archive is tar, tgz or gz.
//     The additional .txt is to ensure that no temporary file would be executed on the web server, which could compromise it.
//
// For example: script.php is uploaded to the web server's temporary directory C:\temp\f9skpqri
//              Then it is moved to net2ftp's temporary directory C:\web\net2ftp\temp\upload9oeic.php.txt
//              And finally it is transferred to the FTP server as script.php in functions ftp_transferfiles() and ftp_unziptransferfiles() -- see below
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $settings;
	global $state2, $application_tempdir; 
	$max_upload_filesize = $settings["max_upload_filesize"];
	
	printFunctionTags("acceptFiles", "begin");

	$too_big = 0;     // Index of the files which are too big
	$moved_ok = 0;    // Index of the files that have been treated successfully
	$moved_notok = 0; // Index of the files that have been treated unsuccessfully

	for ($i=1; $i<=sizeof($uploadedFilesArray); $i++) {

// Flush the buffer to the browser, so that intermediate results would be immediately shown on screen
		flush(); 

// -------------------------------------------------------------------------
// 1 -- Get the data from the filesArray (for each file, its location, name, size, ftpmode
// -------------------------------------------------------------------------
		$file_name     = $uploadedFilesArray["$i"]["name"];
		$file_tmp_name = $uploadedFilesArray["$i"]["tmp_name"];
		$file_size     = $uploadedFilesArray["$i"]["size"];

		if (($file_name != "" && $file_tmp_name == "") || $file_size > $max_upload_filesize) {
// The case ($file_name != "" && $file_tmp_name == "") occurs when the file is bigger than the directives set in php.ini
// In that case, only $uploadedFilesArray["$i"]["name"] is filled in.
			echo "<li> " . __("File <b>%1\$s</b> is too big. This file will not be uploaded.", $file_name) . " </li>"; 
			$too_big = $too_big + 1;
			@unlink($file_tmp_name); 
			continue;
		}

// -------------------------------------------------------------------------
// 3 -- upload and copy the file; if a file with the same name already exists, it is overwritten with the new file
// -------------------------------------------------------------------------
		$extension = get_filename_extension($file_name);
		if (substr($file_name, -6) == "tar.gz") { $extension = "tar.gz"; }

		$tempfilename = mytempnam($application_tempdir, "upload__", "." . $extension . ".txt");
		if ($tempfilename == false) { 
			@unlink($tempfilename); 
			$errormessage = __("Could not generate a temporary file."); 
			setErrorVars(false, $errormessage, debug_backtrace());
			return false;
		}

		$success2 = move_uploaded_file($file_tmp_name, $tempfilename);
		if ($success2 == false) { 
			echo "<li> " . __("File <b>%1\$s</b> could not be moved", $file_name) . " </li>\n"; 
			@unlink($file_tmp_name); 
			@unlink($tempfilename);
			$moved_notok = $moved_notok + 1;
			continue;
		}

// -------------------------------------------------------------------------
// 4 -- if everything went fine, put file in acceptedFilesArray
// -------------------------------------------------------------------------
		else {
// When uploading files, print some output
// When updating files, do not print anything
			registerTempfile("register", $tempfilename);
			if ($state2 == "uploadfile") { echo "<li> " . __("File <b>%1\$s</b> is OK", $file_name) . " </li>\n"; }
			$moved_ok = $moved_ok + 1;
			$acceptedFilesArray[$moved_ok]["name"] = $file_name;
			$acceptedFilesArray[$moved_ok]["tmp_name"] = $tempfilename;
		}

	} // End for

	printFunctionTags("acceptFiles", "end");

	if ($moved_notok > 0) { 
		$errormessage = __("Unable to move the uploaded file to the temp directory.<br /><br />The administrator of this website has to <b>chmod 777</b> the /temp directory of net2ftp."); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}
	elseif ($moved_ok == 0 && $too_big == 0) { 
		$errormessage = __("You did not provide any file to upload.");
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}
	elseif ($moved_ok == 0 && $too_big > 0) { 
		return "all_uploaded_files_are_too_big"; 
	}
	else { 
		return $acceptedFilesArray; 
	}

} // End function acceptFiles

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************







// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function ftp_transferfiles($filesArray, $application_tempdir, $targetDir) {

// --------------
// This PHP function takes a file that was uploaded from a client computer via a browser to the web server, 
// and puts it on another FTP server
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;

	printFunctionTags("ftp_transferfiles", "begin");

// ------------------------------
// Open connection
// ------------------------------
	$conn_id = ftp_openconnection();
	if ($execution_success == false) { 
		for ($i=1; $i<=sizeof($filesArray); $i++) { @unlink($filesArray[$i]["tmp_name"]); }
		return false; 
	}

// ------------------------------
// For loop
// ------------------------------
	for ($i=1; $i<=sizeof($filesArray); $i++) {

// Determine which FTP mode should be used
		$ftpmode = ftpAsciiBinary($filesArray[$i]["name"]);

		if ($ftpmode == FTP_ASCII) { $printftpmode = "FTP_ASCII"; }
		elseif ($ftpmode == FTP_BINARY) { $printftpmode = "FTP_BINARY"; }

// Put files
		ftp_putfile($conn_id, "", $filesArray[$i]["tmp_name"], $targetDir, $filesArray[$i]["name"], $ftpmode, "move");
		if ($execution_success == false) { 
			setErrorVars(true, "", "");
			@unlink($filesArray[$i]["tmp_name"]); 
			printWarningMessage("<li> " . __("File <b>%1\$s</b> could not be transferred to the FTP server", $filesArray[$i]["name"]) . " </li>\n"); 
			continue;
		}
		echo "<li> " . __("File <b>%1\$s</b> has been transferred to the FTP server using FTP mode <b>%2\$s</b>", $filesArray[$i]["name"], $printftpmode) . "</li>\n";

		setStatus_php($i, sizeof($filesArray), __("Transferring files to the FTP server"));

	} // End for

// ------------------------------
// Close connection
// ------------------------------
	ftp_closeconnection($conn_id);

	printFunctionTags("ftp_transferfiles", "end");


} // End function ftp_transferfiles

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function ftp_unziptransferfiles($archivesArray, $use_folder_names, $application_tempdir, $directory) {

// --------------
// Decompress the archives and transfer the files to the FTP server
// If $use_folder_names == "yes" then create subdirectories
// If it is set to no, then transfer everything in the archive to the directory
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;
	global $application_tempdir;
	global $zip_entry_tmp_name; // To export this variable to the pclzip and pcltar libraries

	printFunctionTags("ftp_unziptransferfiles", "begin");

// -------------------------------------------------------------------------
// Open connection
// -------------------------------------------------------------------------
	$conn_id = ftp_openconnection();
	if ($execution_success == false) { 
		for ($archive_nr=1; $archive_nr<=sizeof($archivesArray); $archive_nr++) { @unlink($archivesArray[$archive_nr]["tmp_name"]); }
		return false;
	}


	for ($archive_nr=1; $archive_nr<=sizeof($archivesArray); $archive_nr++) {

// -------------------------------------------------------------------------
// Determine the type of archive depending on the filename extension
// -------------------------------------------------------------------------
		$archive_name = $archivesArray[$archive_nr]["name"];
		$archive_file = $archivesArray[$archive_nr]["tmp_name"];
		$archivename_without_dottext = substr($archivesArray[$archive_nr]["tmp_name"], 0, strlen($archive)-4);
		$archive_type = get_filename_extension($archivename_without_dottext);

// -------------------------------------------------------------------------
// Print message
// -------------------------------------------------------------------------
		echo "<li> " . __("Processing archive nr %1\$s: <b>%2\$s</b>", $archive_nr, $archive_name) . "</li>\n";
		echo "<ul>\n";
		flush();

// -------------------------------------------------------------------------
// Zip archive unzipped with the PHP Zip module
// -------------------------------------------------------------------------
		if ($archive_type == "zip" && function_exists("zip_open") == true) {

// ------------------------------
// Open the archive
// ------------------------------
			$zip = zip_open($archive_file);
			if ($zip == false) { 
				$errormessage = __("Unable to open the archive <b>%1\$s</b> (file %2\$s)", $archive_name, $archive_file);
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}

			while ($zip_entry = zip_read($zip)) { 

				$zip_entry_name = zip_entry_name($zip_entry); 
				$zip_entry_filesize = zip_entry_filesize($zip_entry); 
				$zip_entry_compressedsize = zip_entry_compressedsize($zip_entry); 
				$zip_entry_compressionmethod = zip_entry_compressionmethod($zip_entry); 

// ------------------------------
// Go to the next entry if the filesize is zero
// ------------------------------
				if ($zip_entry_filesize == 0) { continue; }

// ------------------------------
// From the zip_entry_name, determine the path and the real filename
// For example:
// 	zip_entry_name = subdir1/subdir2/file.txt
//	==> 	directory where the file has to be put = directory/subdir1/subdir2
//		filename = file.txt
// ------------------------------
// Remove leading and trailing "/"
				$zip_entry_name = stripDirectory($zip_entry_name);

// Split down into parts
// parts[0] contains the first part, parts[1] the second,...
				$zip_entry_name_subdirectories = explode("/", $zip_entry_name);
				$zip_entry_name_filename = array_pop($zip_entry_name_subdirectories);

// ------------------------------
// Create the subdirectory if needed
// ------------------------------
				if ($use_folder_names == "yes") {

					$targetdirectory = $directory;

					for ($j=0; $j<sizeof($zip_entry_name_subdirectories); $j=$j+1) {

// Create the targetdirectory string
						$targetdirectory = glueDirectories($targetdirectory, $zip_entry_name_subdirectories[$j]);

// Check if the subdirectories exist
						$result = @ftp_chdir($conn_id, $targetdirectory);
						if ($result == false) {
							ftp_newdirectory($conn_id, $targetdirectory);
							if ($execution_success == false)  { 
								setErrorVars(true, "", "");
								printWarningMessage("<li> " . __("Could not create directory <b>%1\$s</b>", $targetdirectory) . " </li>\n"); 
								continue;
							}
							echo "<li> " . __("Created directory <b>%1\$s</b>", $targetdirectory) . " </li>\n";
						} // end if

					} // end for

				} // end if 

// ------------------------------
// Read the zip file entry content
// ------------------------------
				if (zip_entry_open($zip, $zip_entry, "r")) { 
//					echo __("File Contents:") . "<br /><br />\n"; 
					$buf = zip_entry_read($zip_entry, zip_entry_filesize($zip_entry)); 
//					echo $buf;

// ------------------------------
// Write content to a file
// ------------------------------
					if ($use_folder_names == "yes") {
						ftp_writefile($conn_id, $targetdirectory, $zip_entry_name_filename, $buf); 
						if ($execution_success == false)  { 
							setErrorVars(true, "", "");
							printWarningMessage("<li> " . __("Could not put the file <b>%1\$s</b> to the directory <b>%2\$s</b>", $zip_entry_name_filename, $targetdirectory) . " </li>"); 
						}
						else { echo "<li> " . __("Transferred file <b>%1\$s</b> to directory <b>%2\$s</b>", $zip_entry_name_filename, $targetdirectory) . " </li>\n"; }
					}
					else {
						ftp_writefile($conn_id, $directory, $zip_entry_name_filename, $buf); 
						if ($execution_success == false)  { 
							setErrorVars(true, "", "");
							printWarningMessage("<li> " . __("Could not put the file <b>%1\$s</b> to the directory <b>%2\$s</b>", $zip_entry_name_filename, $directory) . " </li>\n"); 
						}
						else { echo "<li> " . __("Transferred file <b>%1\$s</b> to directory <b>%2\$s</b>", $zip_entry_name_filename, $directory) . " </li>\n"; }
					}

// ------------------------------
// Close zip file entry
// ------------------------------
					zip_entry_close($zip_entry); 
					echo "\n"; 

				}  // end if

			} // end while

// ------------------------------
// Close the archive
// ------------------------------
			zip_close($zip);

// ------------------------------
// Delete the uploaded archive
// ------------------------------
			$success2 = @unlink($archive_file);
			if ($success2 == false) { 
				$errormessage = __("Unable to delete the archive <b>%1\$s</b> (file %2\$s)", $archive_name, $archive_file); 
				setErrorVars(false, $errormessage, debug_backtrace());
				return false;
			}
			else { registerTempfile("unregister", "$archive_file"); }

		} // end if


// -------------------------------------------------------------------------
// Archives decompressed the PCL libraries (see the files /includes/pclzip.lib.php and /includes/pcltar.lib.php)
// -------------------------------------------------------------------------
		elseif (($archive_type == "zip" && function_exists("zip_open") == false) || $archive_type == "tar" || $archive_type == "tgz" || $archive_type == "gz") {

// ------------------------------
// Open the archive
// ------------------------------
			if ($archive_type == "zip") {
				$zip = new PclZip($archive_file);
				$list = $zip->listContent();
				if ($list == 0) { 
					$errormessage = __("Unable to get the list of the contents of the Zip archive. Error code: %1\$s", $zip->errorInfo(true)); 
					setErrorVars(false, $errormessage, debug_backtrace());
					return false;
				}
			}
			elseif ($archive_type == "tar" || $archive_type == "tgz" || $archive_type == "gz") { 
				$list = PclTarList($archive_file);
				if ($list == 0) { 
					$errormessage = __("Unable to get the list of the contents of the Tar archive."); 
					setErrorVars(false, $errormessage, debug_backtrace());
					return false;
				}
					// ---------------------------------------------
					// Link between net2ftp and the PCL Tar library:
					// ---------------------------------------------
					// PclTarList calls 
					// PclTarHandleExtension to get the extension and PclTarHandleExtract to get the list
			}

// ------------------------------
// For each entry...
// ------------------------------
			for ($i=0; $i<sizeof($list); $i++) {

				if ($archive_type == "zip") {
					$zip_entry_name = $list[$i]['stored_filename']; 
					$zip_entry_filesize = $list[$i]['size'];
					$zip_entry_compressedsize = $list[$i]['compressed_size'];
					// $zip_entry_compressionmethod = "";
				}
				elseif ($archive_type == "tar" || $archive_type == "tgz" || $archive_type == "gz") { 
					$zip_entry_name = $list[$i]['filename']; 
					$zip_entry_filesize = $list[$i]['size'];
				}

// ------------------------------
// Go to the next entry if the filesize is zero
// ------------------------------
				if ($zip_entry_filesize == 0) { continue; }

// ------------------------------
// From the zip_entry_name, determine the path and the real filename
// For example:
// 	zip_entry_name = subdir1/subdir2/file.txt
//	==> 	directory where the file has to be put = directory/subdir1/subdir2
//		filename = file.txt
// ------------------------------
// Remove leading and trailing "/"
				$zip_entry_name = stripDirectory($zip_entry_name);

// Split down into parts
// parts[0] contains the first part, parts[1] the second,...
				$zip_entry_name_subdirectories = explode("/", $zip_entry_name);
				$zip_entry_name_filename = array_pop($zip_entry_name_subdirectories);

// ------------------------------
// Create the subdirectory if needed
// ------------------------------
				if ($use_folder_names == "yes") {

					$targetdirectory = $directory;

					for ($j=0; $j<sizeof($zip_entry_name_subdirectories); $j=$j+1) {

// Create the targetdirectory string
						$targetdirectory = glueDirectories($targetdirectory, $zip_entry_name_subdirectories[$j]);

// Check if the subdirectories exist
						$result = @ftp_chdir($conn_id, $targetdirectory);
						if ($result == false) {
							ftp_newdirectory($conn_id, $targetdirectory);
							if ($execution_success == false)  { setErrorVars(true, "", ""); printWarningMessage("<li> " . __("Could not create directory <b>%1\$s</b>", $targetdirectory) . " </li>\n"); }
							else { echo "<li> " . __("Created directory <b>%1\$s</b>", $targetdirectory) . " </li>\n"; }
						} // end if

					} // end for

				} // end if 

// ------------------------------
// Read the zip file entry content and write content to a file
// ------------------------------
				if ($archive_type == "zip") { 
					$zip_entry_tmp_name = tempnam($application_tempdir, "unzip__");
					if ($zip_entry_tmp_name == false)  { 
						@unlink($zip_entry_tmp_name); 
						$errormessage = __("Unable to create the temporary file"); 
						setErrorVars(false, $errormessage, debug_backtrace());
						return false;
					}
					registerTempfile("register", $zip_entry_tmp_name);

					$zip->extractByIndex($i, "temp");

					// ---------------------------------------------
					// Link between net2ftp and the PCL Zip library:
					// ---------------------------------------------
					// extractByIndex calls
					// privExtractByRule calls
					// privExtractFile extracts using the filename $zip_entry_tmp_name

				}
				elseif ($archive_type == "tar" || $archive_type == "tgz" || $archive_type == "gz") { 
					$zip_entry_tmp_name = tempnam($application_tempdir, "untar__");
					if ($zip_entry_tmp_name == false)  { 
						@unlink($zip_entry_tmp_name); 
						$errormessage = __("Unable to create the temporary file"); 
						setErrorVars(false, $errormessage, debug_backtrace());
						return false;
					}
					registerTempfile("register", $zip_entry_tmp_name);

					$result = PclTarExtractIndex($archive_file, $i, "temp");
//					if ($result == 0) { 
//						$errormessage = __("Unable to extract file nr <b>%1\$s</b> from the archive.", $i); 
//						setErrorVars(false, $errormessage, debug_backtrace());
//						return false;
//					}

					// ---------------------------------------------
					// Link between net2ftp and the PCL Tar library:
					// ---------------------------------------------
					// PclTarExtractIndex calls 
					// PclTarHandleExtractByIndexList calls
					// PclTarHandleExtractByIndex calls
					// PclTarHandleExtractFile extracts using the filename $zip_entry_tmp_name

				}

				$ftpmode = ftpAsciiBinary($zip_entry_name_filename);

				if ($use_folder_names == "yes") { $remotetargetdirectory = $targetdirectory; }
				else { $remotetargetdirectory = $directory; }

				ftp_putfile($conn_id, "", $zip_entry_tmp_name, $remotetargetdirectory, $zip_entry_name_filename, $ftpmode, "move");
				if ($execution_success == false)  { 
					setErrorVars(true, "", ""); 
					printWarningMessage("<li> " . __("Could not put file <b>%1\$s</b> to directory <b>%2\$s</b>", $zip_entry_name_filename, $remotetargetdirectory) . " </li>"); 
					@unlink($zip_entry_tmp_name);
				}
				else { echo "<li> " . __("Transferred file <b>%1\$s</b> to directory <b>%2\$s</b>", $zip_entry_name_filename, $remotetargetdirectory) . " </li>\n"; }

			} // end for

// ------------------------------
// Delete the uploaded archive
// ------------------------------
			$success2 = @unlink($archive_file);
			if ($success2 == false) { 
				$message = __("Unable to delete the temporary file <b>%1\$s</b>.", $archive_file) . "<br />\n";
				printWarningMessage($message);
			}
			else {
				registerTempfile("unregister", "$archive_file");
			}

		} // end elseif tar tgz gz

// -------------------------------------------------------------------------
// Other filename extensions
// -------------------------------------------------------------------------
		else {
			echo "<li> " . __("Archive <b>%1\$s</b> was not processed because its filename extension was not recognized. Only zip, tar, tgz and gz archives are supported at the moment.", $archive_name) . " </li>\n";
		} // end else

		echo "</ul>\n";

		setStatus_php($archive_nr, sizeof($archivesArray), __("Unzipping and transferring files"));

	} // End for

// -------------------------------------------------------------------------
// Close connection
// -------------------------------------------------------------------------
	ftp_closeconnection($conn_id);

	printFunctionTags("ftp_unziptransferfiles", "end");

} // End function ftp_unziptransferfiles

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function ftp_mysite($conn_id, $command) {

// --------------
// This function sends a site command to the FTP server
// Note:
//    - These commands vary a lot depending on the FTP server type
//    - PHP does not return any result other than TRUE or FALSE
// --------------

	$success1 = ftp_site($conn_id, $command);
	if ($success1 == false) { 
		$errormessage = __("Unable to execute site command <b>%1\$s</b>", $command); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

} // End function ftp_mysite

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************








// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function upDir($directory) {

// --------------
// This function takes a directory string and returns the parent directory string
// --------------
// directory = /david/cv
// parts = Array ( [0] => [1] => david [2] => cv ) 
// count($parts) = 3

	$parts = explode("/", $directory);

	$parentdirectory = "";
	for ($i=1; $i<count($parts)-1; $i++) {
		$parentdirectory = $parentdirectory . "/" . $parts[$i];
	}

	if ($parentdirectory == "") { $parentdirectory = "/"; }

	return $parentdirectory;

} // End function upDir

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************








// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function stripDirectory($directory) {

// --------------
// Removes a leading and trailing / or \ if there is one
// --------------

	$directory = trim($directory);

	$firstchar = substr($directory, 0, 1);
	$lastchar  = substr($directory, strlen($directory)-1, 1);

// Remove a / in front if needed
	if ($firstchar == "/" || $firstchar == "\\") { $directory = substr($directory, 1, strlen($directory)-1); }
// Remove a / at the end if needed
	if ($lastchar  == "/" || $lastchar == "\\")  { $directory = substr($directory, 0, strlen($directory)-1); }

	return $directory;

} // end stripDirectory

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************








// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function glueDirectories($part1, $part2) {

// --------------
// Returns the 2 dirs glued together in the format /home/dh1234/test (leading /, NO trailing /)
// --------------

// Strip leading and trailing / and \
	$part1 = stripDirectory($part1);
	$part2 = stripDirectory($part2);

// Length
	$part1_len = strlen($part1);
	$part2_len = strlen($part2);

// Check if Unix or Windows style directories are used
	if     ($part1_len > 1 && substr($part1, 1, 1) == ":") { $system = "windows"; }
	elseif ($part2_len > 1 && substr($part2, 1, 1) == ":") { $system = "windows"; }
	else                                                   { $system = "unix"; }

// Glue the 2 parts together
	if ($part1_len > 0 && $part2_len > 0) {
		if ($system == "windows") { return $part1 . "\\" . $part2; }
		else                      { return "/" . $part1 . "/" . $part2; }
	}
	elseif (($part1_len == 0 || $part1 == "/" || $part1 == "\\") && ($part2_len > 0)) {
		if ($system == "windows") { return $part2; }
		else                      { return "/" . $part2; }
	}
	elseif (($part2_len == 0 || $part2 == "/" || $part2 == "\\") && ($part1_len > 0)) {
		if ($system == "windows") { return $part1; }
		else                      { return "/" . $part1; }
	}
	else {
		return "";
	}

} // end glueDirectories

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function get_filename_extension($filename) {

// --------------
// This function returns the extension of a filename:
// 	name.ext1.ext2.ext3 --> ext3
// 	name --> name
// 	.name --> name
//	.name.ext --> ext
// It also converts the result to lower case:
// 	name.ext1.EXT2 --> ext2
// --------------

	$lastdotposition = strrpos($filename,".");

	if ($lastdotposition === 0)      { $extension = substr($filename, 1); }
	elseif ($lastdotposition == "")  { $extension = $filename; }
	else                             { $extension = substr($filename, $lastdotposition + 1); }

	return strtolower($extension);

} // End get_filename_extension

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************



// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function get_filename_name($filename) {

// --------------
// This function returns the name part of a filename:
// 	name.ext1.ext2.ext3 --> name
// 	name --> name
// 	.name --> name
//	.name.ext --> name.ext
// It also converts the result to lower case:
// 	NAME.ext --> name
// --------------

	$firstdotposition = strpos($filename,".");
	$lastdotposition  = strrpos($filename,".");

	if ($firstdotposition === 0)      { $name = substr($filename, 1); }
	elseif ($firstdotposition == "")  { $name = $filename; }
	else                              { $name = substr($filename, 0, $lastdotposition); }

	return strtolower($name);

} // End get_filename_name

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************



// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function ftpAsciiBinary($filename) {

// --------------
// Checks the first character of a file and its extension to see if it should be 
// transferred in ASCII or Binary mode
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $net2ftp_ftpmode;

// -------------------------------------------------------------------------
// If $net2ftp_ftpmode == "binary" then return FTP_BINARY
// -------------------------------------------------------------------------
	if ($net2ftp_ftpmode != "automatic") { return FTP_BINARY; }

// -------------------------------------------------------------------------
// If $net2ftp_ftpmode == "automatic" then return return 
// FTP_ASCII or FTP_BINARY
// -------------------------------------------------------------------------
	$firstcharacter = substr($filename, 0, 1);

	if ($firstcharacter == ".") { 
		$ftpmode = FTP_ASCII; 
		return $ftpmode;
	}

// -------------------------------------------------------------------------
// If the first character is not a dot, check the extension
// -------------------------------------------------------------------------
	$last = get_filename_extension($filename);

	if (
		$last == "asp"  		||
		$last == "bas"  		||
		$last == "bat"  		||
		$last == "c"  		||
		$last == "cfg"  		||
		$last == "cfm"  		||
		$last == "cgi"  		||
		$last == "conf"  		||
		$last == "cpp"  		||
		$last == "css"  		||
		$last == "dhtml"		||
		$last == "diz"		||
		$last == "default"	||
		$last == "file"  		||
		$last == "h"  		||
		$last == "hpp"  		||
		$last == "htaccess"	||
		$last == "htpasswd"	||
		$last == "htm"  		||
		$last == "html"  		||
		$last == "inc"  		||
		$last == "ini"  		||
		$last == "js"  		||
		$last == "jsp"  		||
		$last == "mak" 		||
		$last == "msg" 		||
		$last == "nfo" 		||
		$last == "old" 		||
		$last == "pas" 		||
		$last == "patch" 		||
		$last == "perl" 		||
		$last == "php" 		||
		$last == "php3" 		||
		$last == "phps" 		||
		$last == "phtml" 		||
		$last == "pinerc"		||
		$last == "pl" 		||
		$last == "pm" 		||
		$last == "qmail" 		||
		$last == "readme"		||
		$last == "setup" 		||
		$last == "sh" 		|| 
		$last == "shtml" 		|| 
		$last == "sql" 		|| 
		$last == "style" 		|| 
		$last == "tcl" 		|| 
		$last == "tex"		|| 
		$last == "threads"	|| 
		$last == "tmpl"  		||
		$last == "tpl"  		|| 
		$last == "txt"  		|| 
		$last == "ubb"  		||
		$last == "vbs"  		|| 
		$last == "xml"  		||
		$last == "conf"		||
		strstr($last, "htm")
							)	{ $ftpmode = FTP_ASCII; }
	else 							{ $ftpmode = FTP_BINARY; }

	return $ftpmode;

} // end ftpAsciiBinary

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************








// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function standardize_eol($string) {

// --------------
// Input:  text with Windows (\r\n), Unix (\n), or weird (\r\r) end-of-line characters
// Output: text with Unix style end-of-line characters (\n)
// --------------

	$patterns[0] = "/\\r\\r/"; // this is \r\r
	$patterns[1] = "/\\r\\n/"; // this is \r\n

	$replacements[0] = "\r\n";
	$replacements[1] = "\n";

	$string = preg_replace($patterns, $replacements, $string);

	return $string;

}

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************







// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function explode_lines($string) {

// --------------
// Input:  $string which may have Windows or Unix end-of-line characters
// Output: $lines array with the lines
// --------------

	$string = standardize_eol($string);

// Add a \n in the beginning of the strings so that the first line of the string would
// be in the first element of the exploded array
	$lines  = explode("\n", "\n" . $string);

	return $lines;

} // explode_lines

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************







// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function getFileType($filename) {

// --------------
// Checks the extension of a file to determine what should be done with it in the View and Edit functions
// Default: TEXT
// Exceptions (see list below): IMAGE, EXECUTABLE, OFFICE, ARCHIVE
// --------------

	$last = get_filename_extension($filename);

	if (
		$last == "asp"  		||
		$last == "bas"  		||
		$last == "bat"  		||
		$last == "c"  		||
		$last == "cfg"  		||
		$last == "cfm"  		||
		$last == "cgi"  		||
		$last == "conf"  		||
		$last == "cpp"  		||
		$last == "css"  		||
		$last == "dhtml"		||
		$last == "diz"		||
		$last == "default"	||
		$last == "file"  		||
		$last == "h"  		||
		$last == "hpp"  		||
		$last == "htaccess"	||
		$last == "htpasswd"	||
		$last == "htm"  		||
		$last == "html"  		||
		$last == "inc"  		||
		$last == "ini"  		||
		$last == "js"  		||
		$last == "jsp"  		||
		$last == "mak" 		||
		$last == "msg" 		||
		$last == "nfo" 		||
		$last == "old" 		||
		$last == "pas" 		||
		$last == "patch" 		||
		$last == "perl" 		||
		$last == "php" 		||
		$last == "php3" 		||
		$last == "phps" 		||
		$last == "phtml" 		||
		$last == "pinerc"		||
		$last == "pl" 		||
		$last == "pm" 		||
		$last == "qmail" 		||
		$last == "readme"		||
		$last == "setup" 		||
		$last == "sh" 		|| 
		$last == "shtml" 		|| 
		$last == "sql" 		|| 
		$last == "style" 		|| 
		$last == "tcl" 		|| 
		$last == "tex"		|| 
		$last == "threads"	|| 
		$last == "tmpl"  		||
		$last == "tpl"  		|| 
		$last == "txt"  		|| 
		$last == "ubb"  		||
		$last == "vbs"  		|| 
		$last == "xml"  		||
		$last == "conf"		||
		strstr($last, "htm")) { return "TEXT"; }

	elseif (	$last == "png"  || 
			$last == "jpg"  || 
			$last == "jpeg" || 
			$last == "gif"  ||
			$last == "bmp"  ||
			$last == "tif"  ||
			$last == "tiff")    { return "IMAGE"; }

	elseif (	$last == "exe"  || 
			$last == "com")     { return "EXECUTABLE"; }

	elseif (	$last == "doc"  || 
			$last == "rtf"  || 
			$last == "xls"  || 
			$last == "ppt"  || 
			$last == "mdb"  || 
			$last == "vsd"  || 
			$last == "mpp")     { return "OFFICE"; }

	elseif (	$last == "zip"  || 
			$last == "tar"  || 
			$last == "gz"   || 
			$last == "tgz"  || 
			$last == "rar"  || 
			$last == "arj"  || 
			$last == "arc")     { return "ARCHIVE"; }

	else					  { return "OTHER"; }
	

} // end getFileType

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************








// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function getSystemType() {

// --------------
// Gets the WEBSERVER system type on which PHP is running 
// (Not the one for which is was built)
// --------------

	$systemInfo = php_uname();

	if     (stristr($systemInfo, "Linux") != false) {
		$system = "Linux";
	}
	elseif (stristr($systemInfo, "BSD") != false) {
		$system = "BSD";
	}
	elseif (stristr($systemInfo, "Unix") != false) {
		$system = "Unix";
	}
	elseif (stristr($systemInfo, "Win") != false) {
		$system = "Windows";
	}

	return $system;

} // end getSystemType

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function cleanFtpserver($ftpserver) {

// --------------
// Input: " ftp://something.domainname.com:123/directory/file "
// Output: "something.domainname.com"
// --------------

// Remove invisible characters in the beginning and at the end
	$cleaned = trim($ftpserver);

// Remove possible "ftp://"
	if (preg_match("/[ftpFTP]{2,4}[:]{1}[\\/\\\\]{1,2}(.*)/", $cleaned, $regs) == true) {
		$cleaned = "$regs[1]";
	}

// Remove a possible port nr ":123"
	if (preg_match("/(.*)[:]{1}[0-9]+/", $cleaned, $regs) == true) {
		$cleaned = "$regs[1]";
	}

// Remove a possible trailing / or \ 
// Remove a possible directory and file "/directory/file"
	if (preg_match("/[\\/\\\\]*(.*)[\\/\\\\]{1,}.*/", $cleaned, $regs) == true) {
		// Any characters like / or \
		// Anything
		// Followed by at least one / or \
		// Followed by any characters
		$cleaned = "$regs[1]";
	}

	return $cleaned;

} // end cleanFTPserver

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function cleanDirectory($directory) {

// --------------
// Input: "/dir1/dir2/dir3/../../dir4/dir5"
// Output: "/dir1/dir4/dir5"
// --------------

// Nothing to do if the directory is the root directory
	if (strlen($directory) < 1) { return ""; }

// Remove leading and trailing "/"
	$directory = stripDirectory($directory);

// Split down into parts
// directoryparts[0] contains the first part, directoryparts[1] the second,...
	$directoryparts = explode("/", $directory);

// Start from the end
// If you encounter N times a "..", do not take into account the next N parts which are not ".."
// Example: "/dir1/dir2/dir3/../../dir4/dir5"  ---->  "/dir1/dir4/dir5"
	$doubledotcounter = 0;
	$newdirectory = "";
	for ($i=sizeof($directoryparts)-1; $i>=0; $i = $i - 1) {
		if ($directoryparts[$i] == "..") { $doubledotcounter = $doubledotcounter + 1; }
		else {  
			if ($doubledotcounter == 0) { $newdirectory = $directoryparts[$i] . "/" . $newdirectory; }    // Add the new part in front
			elseif ($doubledotcounter > 0) { $doubledotcounter = $doubledotcounter - 1; }                 // Don't add the part, and reduce the counter by 1
		}
	}

	$newdirectory = "/" . stripDirectory($newdirectory);
	return $newdirectory;

} // end cleanDirectory

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function checkEmailAddress($email) {

// --------------
// Returns true for valid email addresses, false for non-valid email addresses
// --------------

	if (eregi( "^" .
	           "[a-z0-9]+([_\.-][a-z0-9]+)*" .    //user
	           "@" .
	           "([a-z0-9]+([\.-][a-z0-9]+)*)+" .   //domain
	           "\\.[a-z]{2,}" .                    //sld, tld 
	           "$", $email, $regs)) { return true;	}
	else { return false; }

} // end checkEmailAddress

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************



// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function checkFilename($filename) {

// --------------
// Returns true for valid filename
// --------------

	if (preg_match("/^[a-zA-Z0-9_ \.-]*$/", $filename) == 0) { return false; }
	else { return true; }

} // end checkFilename

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************







// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function htmlEncode($string) {

// --------------
// This function HTML-encodes a string
// --------------

	$string = @htmlentities($string, ENT_QUOTES, __("iso-8859-1"));

	return $string;

} // end htmlEncode

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function javascriptEncode($string) {

// --------------
// Encode string characters which cause problems in Javascript
// <input type="button" onClick="alert('single quote \' single quote');" value="Test single"> OK      <br /><br />
// <input type="button" onClick="alert('double quote &quot; double quote');"  value="Test double"> OK <br /><br />
// <input type="button" onClick="alert('bs single \\\' bs single');" value="Test bs single"> OK       <br /><br />
// <input type="button" onClick="alert('bs double \\\&quot; bs double');" value="Test bs double"> OK  <br /><br />
// --------------

	$singlequote = "'";           // '
	$doublequote = "\"";          // "
	$backslash   = "\\";          // \
	$doublequote_html = "&quot;"; // &quot;

// Executing the 3 steps below in this order will convert:
//     '     -->    \'        in step 2
//     "     -->    &quot;    in step 3
//     \'    -->    \\\'      in step 1 and 2
//     \"    -->    \\\&quot; in step 1 and 3
	$string = str_replace($backslash, "$backslash$backslash", $string);
	$string = str_replace($singlequote, "$backslash$singlequote", $string);
	$string = str_replace($doublequote, $doublequote_html, $string);

	return $string;

} // end javascriptEncode

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************







// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function registerTempfile($dowhat, $filename) {

// --------------
// This function registers and unregisters temporary files which are created and deleted
// If the script is halted, all the registered temporary files are deleted by the shutdown() function
//
// $dowhat can be either "register" or "unregister"
// $filename is the absolute filename (/web/net2ftp/temp/file.txt)
// --------------

// -------------------------------------------------------------------------
// Global variables and settings
// -------------------------------------------------------------------------
	global $net2ftp_tempfiles;

// -------------------------------------------------------------------------
// Initialize $net2ftp_tempfiles if needed
// -------------------------------------------------------------------------
	if (isset($net2ftp_tempfiles) == false) { $net2ftp_tempfiles = array(); }

// -------------------------------------------------------------------------
// Add or remove the current file to/from the $net2ftp_tempfiles array
// -------------------------------------------------------------------------

// REGISTER
	if ($dowhat == "register") { 
		@array_push($net2ftp_tempfiles, $filename); 
	} // end if register

// UNREGISTER
	elseif ($dowhat == "unregister") {
		$newindex = 0;
		for ($i=0; $i<=count($net2ftp_tempfiles); $i++) {
			if ($net2ftp_tempfiles[$i] != $filename) { 
				$net2ftp_tempfiles_new[$newindex] = $net2ftp_tempfiles[$i]; 
				$newindex = $newindex + 1;
			}
		} // end for
		unset($net2ftp_tempfiles);
		$net2ftp_tempfiles = $net2ftp_tempfiles_new;
	} // end if unregister

	return true;

} // end registerTempfile

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function shutdown() {

// --------------
// This function is registered through register_shutdown_function, so that it would be
// executed when the script reaches the maximum execution time.
//
// The function displays a warning message, and deletes temporary files.
// --------------

// -------------------------------------------------------------------------
// Global variables and settings
// -------------------------------------------------------------------------
	global $execution_success;
	global $settings;
	global $state, $net2ftp_tempfiles;

	printFunctionTags("shutdown", "begin");


// -------------------------------------------------------------------------
// Delete the temporary files which were not deleted automatically
// -------------------------------------------------------------------------
	for ($i=0; $i<sizeof($net2ftp_tempfiles); $i++) { @unlink($net2ftp_tempfiles[$i]); }


// -------------------------------------------------------------------------
// Store the consumption counter values in the database
// -------------------------------------------------------------------------
	putConsumption();
//	if ($execution_success == false) { printErrorMessage(); }


// -------------------------------------------------------------------------
// Print a message to tell the user that the script was halted
// -------------------------------------------------------------------------
	$time_taken = timer();
	$max_execution_time = ini_get("max_execution_time");

// - Check if the $max_execution_time is > 0, because on some PHP configs it is -1 (more
// specifically: when PHP is run as CGI module).
// - Check the time taken versus the maximum execution time, because on Windows + Apache
// servers, the shutdown function is always called, even if the maximum execution time
// was not reached.
	if (($max_execution_time > 0) && ($time_taken > $max_execution_time - 1)) {
		if ($state == "browse" || $state == "manage" || $state == "bookmark" || $state == "advanced") {
			setStatus_php(10, 10, __("Script halted")); 
		}

// Original English message:
// $messages["Shutdown message"] .= "<b>Your task was stopped</b><br /><br />";
// $messages["Shutdown message"] .= "The task you wanted to perform with net2ftp took more time than the allowed %1\$s seconds, and therefor that task was stopped.<br />";
// $messages["Shutdown message"] .= "This time limit guarantees the fair use of the web server for everyone.<br /><br />";
// $messages["Shutdown message"] .= "Try to split your task in smaller tasks: restrict your selection of files, and omit the biggest files.<br /><br />";
// $messages["Shutdown message install own server"] .= "If you really need net2ftp to be able to handle big tasks which take a long time, consider installing net2ftp on your own server.";

		$text  = __("Shutdown message", $max_execution_time);

		if ($settings['net2ftpdotcom'] == "yes") {
			$text .= __("If you really need net2ftp to be able to handle big tasks which take a long time, consider installing net2ftp on your own server.");
		}

		echo "<div class=\"warning-box\"><div class=\"warning-text\">$text</div></div>\n\n";
	}

	printFunctionTags("shutdown", "end");

} // end shutdown

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function SendMail($From, $FromName, $To, $ToName, $Subject, $Text, $Html, $AttmFiles) {

// --------------
// This function taken from www.PHP.net.
// It was written by alex@bartl.net (29-Nov-2002 06:25)
// Alex was inspired by the function of kieran.huggins@rogers.com (06-Nov-2002 04:52)

// Note: it has been changed slightly to fit into the net2ftp application.
// (Mainly the way error handling is done.)
// --------------

/* Alex's comments:
This might be some useful stuff to send out emails in either text
or html or multipart version, and attach one or more files or even
none to it. Inspired by Kieran's msg above, I thought it might be 
useful to have a complete function for doing this, so it can be used 
wherever it's needed. Anyway I am not too sure how this script will
behave under Windows.
{br} represent the HTML-tag for line break and should be replaced,
but I did not know how to not get the original tag  parsed here.
function SendMail($From, $FromName, $To, $ToName, $Subject, $Text, $Html, $AttmFiles)
$From      ... sender mail address like "my@address.com"
$FromName  ... sender name like "My Name"
$To        ... recipient mail address like "your@address.com"
$ToName    ... recipients name like "Your Name"
$Subject   ... subject of the mail like "This is my first testmail"
$Text      ... text version of the mail
$Html      ... html version of the mail
$AttmFiles ... array containing the filenames to attach like array("file1","file2")
*/

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;

// Initial tests
//	$Html = $Html?$Html:preg_replace("/\n/","{br}",$Text) or die("neither text nor html part present.");
//	$Text = $Text?$Text:"Sorry, but you need an html mailer to read this mail.";
//	$From or die("sender address missing");
//	$To or die("recipient address missing");

	if ((strlen($Html) < 1) && (strlen($Text) < 1)) { 
		$errormessage = __("You did not provide any text to send by email!"); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}
	if (strlen($From) < 1) { 
		$errormessage = __("You did not supply a From address."); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}
	if (strlen($To) < 1) { 
		$errormessage = __("You did not supply a To address."); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}
	if (strlen($Html) < 1) { 
		$Html = preg_replace("/\n/","<br>",$Text); 
	}

// Check if the To email address is valid
	if (!eregi( "^" .
	           "[a-zA-Z0-9]+([_\.-][a-zA-Z0-9]+)*" .    //user
	           "@" .
	           "([a-zA-Z0-9]+([\.-][a-zA-Z0-9]+)*)+" .  //domain
	           "\\.[a-zA-Z]{2,}" .                      //sld, tld 
	           "$", $To, $regs)) { 
		$errormessage = __("The email address you have entered (%1\$s) does not seem to be valid.<br />Please enter an address in the format <b>username@domain.com</b>", $To); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

// Definition of some variables
	$OB = "----=_OuterBoundary_000";
	$IB = "----=_InnerBoundery_001";

// Headers
	$headers ="MIME-Version: 1.0\r\n"; 
	$headers.="From: ".$FromName." <".$From.">\n"; 
	$headers.="To: ".$ToName." <".$To.">\n"; 
	$headers.="Reply-To: ".$FromName." <".$From.">\n"; 
	$headers.="X-Priority: 1\n"; 
	$headers.="X-MSMail-Priority: High\n"; 
	$headers.="X-Mailer: My PHP Mailer\n"; 
	$headers.="Content-Type: multipart/mixed;\n\tboundary=\"".$OB."\"\n";

// Messages start with text/html alternatives in OB
	$Msg ="This is a multi-part message in MIME format.\n";
	$Msg.="\n--".$OB."\n";
	$Msg.="Content-Type: multipart/alternative;\n\tboundary=\"".$IB."\"\n\n";

// Plaintext section 
	$Msg.="\n--".$IB."\n";
	$Msg.="Content-Type: text/plain;\n\tcharset=\"iso-8859-1\"\n";
	$Msg.="Content-Transfer-Encoding: quoted-printable\n\n";

// Plaintext goes here
	$Msg.=$Text."\n\n";

// Html section 
	$Msg.="\n--".$IB."\n";
	$Msg.="Content-Type: text/html;\n\tcharset=\"iso-8859-1\"\n";
	$Msg.="Content-Transfer-Encoding: base64\n\n";

// Html goes here 
	$Msg.=chunk_split(base64_encode($Html))."\n\n";

// End of IB
	$Msg.="\n--".$IB."--\n";

// Attachments
	if($AttmFiles){
		foreach($AttmFiles as $AttmFile){
//			$patharray = explode ("/", $AttmFile); 
//			$FileName=$patharray[count($patharray)-1];
			$FileName = "RequestedFile.zip";

			$Msg.= "\n--".$OB."\n";
			$Msg.="Content-Type: application/octet-stream;\n\tname=\"".$FileName."\"\n";
			$Msg.="Content-Transfer-Encoding: base64\n";
			$Msg.="Content-Disposition: attachment;\n\tfilename=\"".$FileName."\"\n\n";

// File goes here
			$FileContent = local_readfile($AttmFile);
			if ($execution_success == false) { return false; }

			$FileContent = chunk_split(base64_encode($FileContent));
			$Msg.=$FileContent;
			$Msg.="\n\n";
		} // end for
	} // end if

// Message ends
	$Msg.="\n--".$OB."--\n";

// Send mail
	$success2 = mail($To, $Subject, $Msg, $headers); 
	if ($success2 == false) { 
		$errormessage = __("Due to technical problems the email to <b>%1\$s</b> could not be sent.", $To); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

// Logging
	//syslog(LOG_INFO,"Mail: Message sent to $ToName <$To>");

} // end function SendMail

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printDirFileProperties($number, $entry, $checkbox_hidden, $onClick) {

// --------------
// Prints a checkbox and some hidden fields
// $onClick should be like "onClick=\"do_something_javascript();\""
// --------------

// Replace ' by &#039; to avoid errors when using this variable in an HTML value tag
//	$dirfilename_html = htmlspecialchars($dirfilename, ENT_QUOTES);

// Print checkbox or hidden field
	if ($checkbox_hidden == "checkbox") {
		echo "<input type=\"checkbox\" name=\"list[$number][dirfilename]\" id=\"list[$number][dirfilename]\" value=\"" . $entry['dirfilename'] . "\" $onClick/>\n";
	}
	else {
		echo "<input type=\"hidden\"   name=\"list[$number][dirfilename]\" value=\"" . $entry['dirfilename'] . "\" />\n";
	}

// Print hidden fields
	echo "<input type=\"hidden\"   name=\"list[$number][dirorfile]\"   value=\"" . $entry['dirorfile'] . "\" />\n";
	echo "<input type=\"hidden\"   name=\"list[$number][size]\"        value=\"" . $entry['size'] . "\" />\n";
	echo "<input type=\"hidden\"   name=\"list[$number][permissions]\" value=\"" . $entry['permissions'] . "\" />\n";
	echo "<input type=\"hidden\"   name=\"list[$number][mtime]\"       value=\"" . $entry['mtime'] . "\" />\n";

} // end printDirFileProperties

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************



// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function getSelectedEntries($list) {

// --------------
// Input = array where dirfilename is set if the entry was selected, not set if not selected:
//   [1] => Array ( [dirfilename] => dir1 [dirorfile] => d [size] => 0 [permissions] => ---rw-rw- )   <-- selected
//   [2] => Array ( [dirfilename] => dir2 [dirorfile] => d [size] => 0 [permissions] => ---rw-rw- )   <-- selected 
//   [3] => Array ( [dirorfile] => d [size] => 0 [permissions] => ---rw-rw- )                         <-- not selected
//
// Output = array with only the selected entries:
//   [1] => Array ( [dirfilename] => dir1 [dirorfile] => d [size] => 0 [permissions] => ---rw-rw- ) 
//   [2] => Array ( [dirfilename] => dir2 [dirorfile] => d [size] => 0 [permissions] => ---rw-rw- ) 
// --------------

	$newlist = array();
	$counter = 1;

	for ($i=1; $i<=sizeof($list); $i=$i+1) {
		if (array_key_exists("dirfilename", $list[$i])) { $newlist[$counter] = $list[$i]; $counter = $counter + 1; }
	} // end for

	return $newlist;

} // end getSelectedEntries

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function formatFilesize($filesize) {

// --------------
// From php.net, code snippet submitted by sponger (10-Jun-2002 05:28)
// Edited for use in net2ftp.
//
// This may come in handy for someone.
// Returns the size of the passed file in the appropriate measurement format.
// --------------

// Setup some common file size measurements.
	$kb = 1024;         // Kilobyte
	$mb = 1048576;      // Megabyte
	$gb = 1073741824;   // Gigabyte
	$tb = 1099511627776;// Terabyte

// If it's less than a kb we just return the size, otherwise we keep going until
//   the size is in the appropriate measurement range.
	if($filesize< $kb) {
		return $filesize." B";
	}
	elseif($filesize< $mb) {
		return round($filesize/$kb,2) . " kB";
	}
	elseif($filesize< $gb) {
		return round($filesize/$mb,2) . " MB";
	}
	elseif($filesize< $tb) {
		return round($filesize/$gb,2) . " GB";
	}
	else {
		return round($filesize/$tb,2) . " TB";
	}

} // end formatFilesize

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printFunctionTags($function, $beginend) {

// --------------
// This function prints out hidden HTML tags at the beginning and end of functions
// --------------

	global $settings;

	if ($settings["print_function_tags"] == "yes" && $beginend == "begin") { 
		echo "\n\n\n<!-- " . __("Output generated by function %1\$s", $function) . " BEGIN -->\n"; 
	}

	if ($settings["print_function_tags"] == "yes" && $beginend == "end") { 
		echo "\n<!-- " . __("Output generated by function %1\$s", $function) . " END -->\n\n\n"; 
	}

} // end printFunctionTags

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function mytempnam($dir, $prefix, $postfix) {

// --------------
// Contributed by anonymous on http://www.php.net on 23-Jul-2003 04:56
// The tempnam() function will not let you specify a postfix to the filename created. 
// Here is a function that will create a new filename with pre and post fix'es. 
// It returns false if it can't create in the dir specified. (The function tempnam, on the contrary, creates the file in the systems temp dir.)
// --------------

	if ($dir[strlen($dir) - 1] == '/') { $trailing_slash = ""; }
	else { $trailing_slash = "/"; }
 
// Check if the $dir is a directory
	if (!is_dir($dir) || filetype($dir) != "dir") { return false; }

// Check if the directory is writeable
	if (!is_writable($dir)){ return false; }

// Create the temporary filename
	do { 
		$seed = substr(md5(microtime()), 0, 8);
		$filename = $dir . $trailing_slash . $prefix . $seed . $postfix;
	} while (file_exists($filename));


	$fp = fopen($filename, "wb");
	fclose($fp);
	return $filename;

} // end mytempnam

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function local_readfile($file) {

// --------------
// Open the local file $file and return its content as a string
// --------------

	global $application_tempdir;

// From the PHP manual:
// Note:  The mode may contain the letter 'b'. 
// This is useful only on systems which differentiate between binary and text 
// files (i.e. Windows. It's useless on Unix). If not needed, this will be 
// ignored. You are encouraged to include the 'b' flag in order to make your scripts 
// more portable.
// Thanks to Malte for bringing this to my attention !

	$handle = fopen($file, "rb"); // Open the file for reading only
	if ($handle == false) { 
		$errormessage = __("Unable to open the temporary file. Check the permissions of the %1\$s directory.", $application_tempdir); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

	clearstatcache(); // for filesize

	$filesize = filesize($file);
	if ($filesize == 0) { return ""; }

	$string = fread($handle, $filesize);
	if ($string == false && filesize($file)>0) { 
		$errormessage =  __("Unable to read the temporary file"); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

	$success3 = fclose($handle);
	if ($success3 == false) { 
		$errormessage = __("Unable to close the handle of the temporary file"); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

	return $string;

} // end local_readfile

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function local_writefile($file, $string) {

// --------------
// Open the local file $file and write the $string to it
// --------------

	global $application_tempdir;

	$handle = fopen($file, "wb");
	if ($handle == false) { 
		$errormessage = __("Unable to open the temporary file. Check the permissions of the %1\$s directory.", $application_tempdir); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

	$success1 = fwrite($handle, $string);
	if ($success1 == false && strlen($string)>0) { 
		$errormessage = __("Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory.", $file, $application_tempdir); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

	$success2 = fclose($handle);
	if ($success2 == false) { 
		$errormessage = __("Unable to close the handle of the temporary file"); 
		setErrorVars(false, $errormessage, debug_backtrace());
		return false;
	}

} // end local_writefile

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function local_getlist($localdirectory) {

// --------------
// This function gets the list of subdirectories and files within a directory,
// and returns it in the same format as ftp_getlist.
// Big differences with ftp_getlist is that local_getlist:
//   - does not return a warning message;
//   - cannot change the $localdirectory.
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $execution_success;

	printFunctionTags("local_getlist", "begin");


// -------------------------------------------------------------------------
// Initialization
// -------------------------------------------------------------------------
	$handle = opendir($localdirectory);
	$list = array();
	$list_directories = array();
	$list_files = array();
	$i = 0;
	$j = 1;

// -------------------------------------------------------------------------
// While loop 
// -------------------------------------------------------------------------
	while (false !== ($dirfilename = readdir($handle))) {
		if ($dirfilename != "." && $dirfilename != "..") {
			if (is_dir($dirfilename) == true) { 
				$listline['scanrule']    = "local";
				$listline['dirorfile']   = "d"; 
				$listline['dirfilename'] = $dirfilename;
				$listline['size']        = 0; 
				array_push($list_directories, $listline);
			}
			else { 
				$listline['scanrule']    = "local";
				$listline['dirorfile']   = "-"; 
				$listline['dirfilename'] = $dirfilename;
				$listline['size']        = filesize($localdirectory . "/" . $dirfilename); 
				array_push($list_files, $listline);
			}
		}
	} // end while

	for ($i=0; $i<count($list_directories); $i=$i+1)  { $list[$j] = $list_directories[$i]; $j=$j+1; }
	for ($i=0; $i<count($list_files); $i=$i+1)        { $list[$j] = $list_files[$i]; $j=$j+1; }


// -------------------------------------------------------------------------
// End
// -------------------------------------------------------------------------
	closedir($handle);

	printFunctionTags("ftp_getlist", "end");
	
	return $list;

} // End function local_getlist

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************


?>