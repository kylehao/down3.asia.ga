<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------



/* -------------------------------------------------------------------------
   This is how error-handing works within net2ftp
   -------------------------------------------------------------------------

There are 2 global variables:
- $execution_success, which is true or false
- $execution_errormessage, which contains an error message

---------------------------------
Low-level function executes a standard PHP function
- If everything goes OK, the low-level function simply returns its $finalresult
- If there is an error, the global variable $execution_success is set to false, and 
  $execution_errormessage will be filled with the error message
---------------------------------
function low_level {
	$result = php_function();
	if ($result == false) { setErrorVars(false, "errormessage"); return false; }
	...
	return $finalresult;
}

---------------------------------
Middle-level function executes a low-level function (it may also execute standard PHP functions)
- If everything goes OK, the middle-level function simply returns its $finalresult
- If there is an error, the function can either return to its parent, or continue
---------------------------------
function middle_level {
	global $execution_success, $execution_errormessage;
	$result = low_level();
// Return to its parent, leave the error message as is
	if ($execution_success == false) { return false; }
// Return to its parent, change the error message
	if ($execution_success == false) { setErrorVars(false, "errormessage2"); return false; }
// Print error message and exit
	if ($execution_success == false) { printErrorMessage(); }
// Continue
	if ($execution_success == false) { setErrorVars(true, ""); }
	...
	return $finalresult;
}

---------------------------------
High-level function executes a middle-level function (it may also execute standard PHP functions)
- If everything goes OK, the middle-level function simply returns its $finalresult
- If there is an error, an error message is printed and the script is exited
---------------------------------
function high_level {
	global $execution_success, $execution_errormessage;
	$result = middle_level();
	if ($execution_success == false) { printErrorMessage(); }
	...
	return $finalresult;
} 

------------------------------------------------------------------------- */






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function setErrorVars($success, $errormessage, $debug_backtrace) {

// --------------
// This function modifies the 2 global errorhandling variables
// --------------

	global $execution_success, $execution_errormessage, $execution_debug_backtrace;

	$execution_success = $success;
	$execution_errormessage = $errormessage;
	$execution_debug_backtrace = $debug_backtrace;

} // end setErrorVars

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printErrorMessage() {

// --------------
// Prints an error message
// --------------

// -------------------------------------------------------------------------
// Global variables and settings
// -------------------------------------------------------------------------
	global $execution_success, $execution_errormessage, $execution_debug_backtrace, $execution_output;
	global $settings;
	global $application_rootdir, $application_includesdir, $application_pluginsdir;


// -------------------------------------------------------------------------
// Include code files
// (Some error messages are called before the code files are included in index.php)
// -------------------------------------------------------------------------
	require_once($application_pluginsdir  . "/plugins.inc.php");
	getActivePlugins();
	includeLanguageFile();
	integratePlugin("includePhpFiles");


// -------------------------------------------------------------------------
// Log the error
// -------------------------------------------------------------------------
	if ($settings["log_error"] == "yes") {
		$logError_result = logError();
	}

// -------------------------------------------------------------------------
// Print the errormessage
// -------------------------------------------------------------------------
	if ($execution_output == "no") { HtmlBegin("error", "", "", "", ""); }

	if ($execution_output == "yes") { setStatus_php(10, 10, __("An error has occured")); }

	echo "<br /><br />\n";
	echo "<table class=\"error-table\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n";

// Message
	echo "<tr><td class=\"error-header\">" . __("An error has occured") . ":</td></tr>\n";
	echo "<tr><td class=\"error-text\">\n";
	echo $execution_errormessage . "<br /><br />";

	echo "<a href=\"javascript:top.history.back()\" style=\"font-size: 130%; font-weight: bold;\">" . __("Go back") . "</a> or \n";
	echo "<a href=\"" . printPHP_SELF("") . "?cookieset=clear\"   style=\"font-size: 130%; font-weight: bold;\">" . __("Go to the login page") . "</a><br /><br />\n";

	echo "</td></tr>\n";
	echo "<tr><td class=\"error-text\">\n";

// Debug backtrace
	echo "<b><u>Technical information for developers:</u></b><br />";
	echo "<ul>\n";
	for ($i=0; $i<count($execution_debug_backtrace); $i++) {
		echo "<li> function " . $execution_debug_backtrace[$i]["function"] . " <span style=\"font-size: 75%\">(" . $execution_debug_backtrace[$i]["file"] . " on line " . $execution_debug_backtrace[$i]["line"] . ")</span></li>\n";
		echo "<ul>\n";
		for ($j=0; $j<count($execution_debug_backtrace[$i]["args"]); $j++) {
			echo "<li> argument $j: " . $execution_debug_backtrace[$i]["args"][$j] . "</li>\n";
		}
		echo "</ul>\n";
	}
	echo "</ul>\n";

	if ($settings["log_error"] == "yes" && $logError_result == true)  { echo "<div style=\"font-size: 75%\">In order to improve the service of this website, a concise error report has been saved. This error report will be analysed by the developers in a confidential way to track and eliminate bugs.</div>\n"; }
	if ($settings["log_error"] == "yes" && $logError_result == false) { echo "<div style=\"font-size: 75%\">In order to improve the service of this website, a concise error report was generated, but it could not be saved.</div>\n"; }

	echo "</td></tr>\n";
	echo "</table><br /><br />\n";


// Google Adsense code
//	if ($settings["show_google_ads"] == "yes" && isset($_SERVER["HTTPS"]) == false) {
//		echo "<div style=\"text-align: center;\">\n";
//		echo "<script type=\"text/javascript\"><!--\n";
//		echo "google_ad_client = \"pub-8420366685399799\";\n";
//		echo "google_ad_width = 728;\n";
//		echo "google_ad_height = 90;\n";
//		echo "google_ad_format = \"728x90_as\";\n";
//		echo "google_ad_channel =\"\";\n";
//		echo "google_color_border = \"336699\";\n";
//		echo "google_color_bg = \"FFFFFF\";\n";
//		echo "google_color_link = \"0000FF\";\n";
//		echo "google_color_url = \"008000\";\n";
//		echo "google_color_text = \"000000\";\n";
//		echo "//--></script>\n";
//		echo "<script type=\"text/javascript\" src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\"></script>\n";
//		echo "</div>\n";
//	}

	HtmlEnd("error", "", "");

	exit();     //  <----------------- this is *not* the only exit() in the application ---------------------

} // end printErrorMessage

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printWarningMessage($message) {

// --------------
// Prints a warning message
// --------------

// -------------------------------------------------------------------------
// Global variables and settings
// -------------------------------------------------------------------------
	global $settings;


// -------------------------------------------------------------------------
// Handle string as well as array
// -------------------------------------------------------------------------
	if (is_array($message)) { 
		$message = $message['message'];
	}

// -------------------------------------------------------------------------
// Log the error
// -------------------------------------------------------------------------
	if ($settings["log_error"] == "yes") {
		logError();
	}

// -------------------------------------------------------------------------
// Print the warning message
// -------------------------------------------------------------------------
	echo "<span style=\"color: red;\">$message</span>\n";


} // end printWarningMessage

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************



?>