<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//   -------------------------------------------------------------------------------
//  |                                                                               |
//  |  Enter your settings and preferences below.                                   |
//  |                                                                               |
//  |  The structure of each line is like this:                                     |
//  |     $settings['setting_name'] = "setting_value";                              |
//  |                                                                               |
//  |  BE CAREFUL WHEN EDITING THE FILE: ONLY EDIT THE setting_value, AND DO NOT    |
//  |  ERASE THE " OR THE ; CHARACTERS.                                             |
//   -------------------------------------------------------------------------------


// ----------------------------------------------------------------------------------
// Network settings
// ----------------------------------------------------------------------------------

// Enter your email address
// This is used as "from" address when sending files in attachment
$settings['email_feedback'] = "your-email@yourdomain.com";

// Enter the address of your help pages, forum or ticket system
// Leave empty if you don't have this
$settings['help_text'] = "";
$settings['help_link'] = "";

// Check if net2ftp is up-to-date automatically? This adds a message on the 
// Logout page, and on the Admin page. When using HTTPS, this is disabled
// to avoid warning popups.
$settings['versioncheck_use'] = "no";


// ----------------------------------------------------------------------------------
// Admin Panel settings. 
// ----------------------------------------------------------------------------------

// Enter the username for the Admin panel
$settings['settings_admin_username'] = "admin";

// Enter the password for the Admin panel
// If it is not set, the Admin panel will not be accessible by anyone
$settings['settings_admin_password'] = "";


// ----------------------------------------------------------------------------------
// Language settings
// ----------------------------------------------------------------------------------

// Set the default language for the login screen
// Look in the /net2ftp/languages directory to see which languages are available
$settings['default_language'] = "en"; // enter a 2 letter code


// ----------------------------------------------------------------------------------
// Messages
// ----------------------------------------------------------------------------------

// If you want to display a message on the Browse screen, enter it here
	// No message:
$settings['message_browse']  = "";
	// Message:
//$settings['message_browse']  = "Welcome to our new web based FTP client.<br />\n";
//$settings['message_browse'] .= "Enjoy!\n";


// ----------------------------------------------------------------------------------
// Privacy settings
// ----------------------------------------------------------------------------------

// Random hexadecimal string to XOR with passwords to encrypt them
// Change it to improve security - but use only numbers and capital letters from A to F!
$settings['encryption_string'] = "F0F06CF80BDAF147EC26A9EFE37DBE3F6F7FF4379A4E1462BC74F9FB369BD6C3";


// ----------------------------------------------------------------------------------
// Upload settings
// Maximum upload settings allowed **by net2ftp**. 
// ----------------------------------------------------------------------------------

// Maximum size of one file (default 2 MB)
$settings['max_upload_filesize'] = "2097152"; // in Bytes

// Java Applet: Maximum free temporary space on server (default 10 MB)
$settings['maxFreeSpaceOnServer'] = "10485760"; // in Bytes

// Java Applet: Maximum total size of one upload request (default 2 MB)
// If a request exceeds this limit, it will the splitted into multiple 
// smaller requests. A single file size can not exceed this value.
$settings['maxTotalRequestSize'] = "2097152"; // in Bytes

// Java Applet: Maximum number of files (default 1000)
$settings['maxNumberFiles'] = "1000";

// Java Applet: Maximum number of files per request (default 250)
$settings['maxFilesPerRequest'] = "250";


// IF YOU WANT TO ALLOW LARGE FILE UPLOADS, YOU MAY HAVE TO ADJUST
// THE FOLLOWING PARAMETERS:
// 1 - in the file php.ini: upload_max_filesize, post_max_size,
//     max_execution_time, memory_limit
// 2 - in the file php.conf: LimitRequestBody


// ----------------------------------------------------------------------------------
// PHP error reporting
// ----------------------------------------------------------------------------------

// Set to "ALL" or "standard" while you are testing net2ftp
// Set to "NONE" once the testing is done

//$settings['error_reporting'] = "ALL";
//$settings['error_reporting'] = "NONE";
$settings['error_reporting'] = "standard";


// ----------------------------------------------------------------------------------
// A MySQL database is optional.
// It can be used for:
//    - logging the users;
//    - checking the consumption of network and server resources (data transfer 
//      volume and script execution time).
// ----------------------------------------------------------------------------------

// MASTER SETTING that overrides the other settings below: use a database?
// Set to "yes" or "no".
$settings['use_database'] = "no";

// Enter your MySQL settings
$settings['dbusername'] = "";
$settings['dbpassword'] = "";
$settings['dbname']     = "";
$settings['dbserver']   = "localhost"; // on many configurations, this is "localhost"

// Delete logs which are older than X days automatically
$settings['log_length_days'] = 14; // number of days

// Switch different types of logs on or off
$settings['log_access'] = "yes";
$settings['log_login'] = "yes";
$settings['log_error'] = "yes";

// Switch consumption checking on or off
$settings['check_consumption'] = "yes";

// Maximum data transfer volume per day (in Bytes)
$settings['max_consumption_ipaddress_dataTransfer'] = 50000000;  // per IP address
$settings['max_consumption_ftpserver_dataTransfer'] = 100000000; // per FTP server

// Maximum script execution time per day (in seconds)
$settings['max_consumption_ipaddress_executionTime'] = 2500; // per IP address
$settings['max_consumption_ftpserver_executionTime'] = 5000; // per FTP server


// ----------------------------------------------------------------------------------
// Layout
// ----------------------------------------------------------------------------------

// ---------------------------------
// Settings for the Edit screen
// ---------------------------------

// Plain textarea
$settings['edit_nrofcolumns'] = "118";
$settings['edit_nrofrows'] = "33";

// HTMLArea version 2.03
$settings['edit_htmlarea203_width'] = "100%";
$settings['edit_htmlarea203_height'] = "450px";

// HTMLArea version 3rc1
$settings['edit_htmlarea3rc1_width'] = "100%";
$settings['edit_htmlarea3rc1_height'] = "450px";

// FCKEditor version 2.0 beta 2
$settings['edit_fckeditor20_width'] = "100%";
$settings['edit_fckeditor20_height'] = "450px";

// Helena version 0.5 (syntax highligher)
$settings['edit_helene05_top_width'] = "100%";
$settings['edit_helene05_top_height'] = "100px";
$settings['edit_helene05_bottom_width'] = "100%";
$settings['edit_helene05_bottom_height'] = "350px";

// Show mime type icons on the browse screen
$settings['show_icons'] = "yes";


// ----------------------------------------------------------------------------------
// Developer settings
// ----------------------------------------------------------------------------------

// Use this to see from which net2ftp function some HTML output is coming.
// Hidden HTML tags are added to indicate when a function's output starts and ends.
// For example, when you look at the HTML source of the Browse Screen:
// <!-- Code generated by function browse() BEGIN -->
// [HTML code generated by browse()]
// <!-- Code generated by function browse() END -->
$settings['print_function_tags'] = "no";

// Show the beta functions which are not yet totally finished/stable
// USE ONLY IN TEST ENVIRONMENTS, NOT IN PRODUCTION ENVIRONMENTS
$settings['show_beta'] = "no";

// Allow the troubleshooting functions
$settings['troubleshoot'] = "yes";


// ----------------------------------------------------------------------------------
// DO NOT CHANGE ANYTHING BELOW THIS LINE
// ----------------------------------------------------------------------------------

$settings['application_version'] = "0.82";
$settings['application_build_nr'] = "36";

// Is this net2ftp.com, or a net2ftp installation elsewhere
$settings['net2ftpdotcom'] = "no";

// Google Adsense advertisements 
// Not shown when using HTTPS to avoid warnings on each pageload
$settings['show_google_ads'] = "no";

?>