var latest_stable_build = 35;
var latest_stable_version = '0.81';
var latest_stable_url = 'http://www.net2ftp.com/download/net2ftp_v0.81.zip';

var latest_beta_build = 36;
var latest_beta_version = '0.82';
var latest_beta_url = 'http://www.net2ftp.com/download/net2ftp_v0.82_beta4.zip';
