<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function getActivePlugins() {

// --------------
// This function modifies the global variable $activePlugins, which contains an array 
// with all active plugin names
//
// Which plugin is active depends on 2 things:
// 1 - if the plugin is enabled or disabled (see the ["use"] field in getPluginProperties())
// 2 - the $state and $state2 variables, as well as other specific variables (see this function)
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $activePlugins;
	global $state, $state2;
	global $textareaType;
	$pluginProperties = getPluginProperties("ALL");

	$plugincounter = 0;
	$activePlugins = array();

// -------------------------------------------------------------------------
// Plugins to always activate
// -------------------------------------------------------------------------
	if ($pluginProperties["html_progress"]["use"] == "yes")       { $activePlugins[$plugincounter] = "html_progress"; $plugincounter++; }

// -------------------------------------------------------------------------
// Plugins to activate depending on the $state and $state2 variables
// -------------------------------------------------------------------------
	if ($state == "logout" || $state == "admin") { 
		if ($pluginProperties["versioncheck"]["use"] == "yes")  { $activePlugins[$plugincounter] = "versioncheck"; $plugincounter++; } 
	}
	elseif ($state == "manage" && $state2 == "findstring") { 
		if ($pluginProperties["jscalendar"]["use"] == "yes")    { $activePlugins[$plugincounter] = "jscalendar"; $plugincounter++; } 
	}
	elseif ($state == "manage" && $state2 == "view") { 
		if ($pluginProperties["geshi"]["use"] == "yes")		  { $activePlugins[$plugincounter] = "geshi"; $plugincounter++; } 
	}

// -------------------------------------------------------------------------
// Plugins to activate depending on other variables
// -------------------------------------------------------------------------
	if ($textareaType != "" && array_key_exists($textareaType, $pluginProperties) == true) {
		if ($pluginProperties["$textareaType"]["use"] == "yes") { $activePlugins[$plugincounter] = $textareaType; $plugincounter++; } 
	}

} // end function getActivePlugins

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function isActivePlugin($plugin) {

// --------------
// This function checks if a plugin is active or not
// --------------

	global $activePlugins;
	return in_array($plugin, $activePlugins);

} // end function isActivePlugin

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************






// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function getPluginProperties($plugin) {

// --------------
// This function returns an array with all plugin properties
// The details are given for the first entry (HTMLArea 2.0.3)
// --------------

// -------------------------------------------------------------------------
// Global variables
// -------------------------------------------------------------------------
	global $net2ftp_language;

// -------------------------------------------------------------------------
// HTMLArea 2.0.3 - http://www.interactivetools.com/products/htmlarea/
// An HTML editor for IE5.5+
// -------------------------------------------------------------------------

// Use this plugin?
$pluginProperties["htmlarea203"]["use"] = "yes";

// Label of this plugin
$pluginProperties["htmlarea203"]["label"] = "HTMLArea 2.03";

// Directory where the plugin is located within the /net2ftp/plugin directory
$pluginProperties["htmlarea203"]["directory"] = "htmlarea-2.03";

// Plugin type
$pluginProperties["htmlarea203"]["type"] = "textarea";

// PHP files to include (starts with ./)
$pluginProperties["htmlarea203"]["php_include"][1] = "";
//$pluginProperties["htmlarea203"]["php_include"][2] = "./plugins/directory/file2.php";

// CSS files to include (does not start with ./ or / !!!)
//$pluginProperties["htmlarea203"]["css_include"][1] = "";
//$pluginProperties["htmlarea203"]["css_include"][2] = "";

// Javascript code to execute in the HTML HEAD *before* the Javascript files are included
// You can enter multiple lines of code, as shown below
// Note the first line uses = and the next lines use .=
$pluginProperties["htmlarea203"]["js_code_pre"] = "_editor_url = \"./plugins/htmlarea-2.03/\";\n";
$pluginProperties["htmlarea203"]["js_code_pre"] .= "_editor_lang = \"en\";\n";

// Javascript files to include (does not start with ./ or / !!!)
$pluginProperties["htmlarea203"]["js_include"][1] = "plugins/htmlarea-2.03/editor.js";
//$pluginProperties["htmlarea203"]["js_include"][2] = "file2.js";

// Javascript code to execute in the HTML HEAD *after* the Javascript files are included
// You can enter multiple lines of code, as shown below
// Note the first line uses = and the next lines use .=
$pluginProperties["htmlarea203"]["js_code_post"] = "";
$pluginProperties["htmlarea203"]["js_code_post"] .= "";

// Javascript code to execute in the BODY ONLOAD event
// Leave blank if there is no Javascript code to execute
$pluginProperties["htmlarea203"]["body_onload"] = "";

/// Enter a the code if there is -- end the code statements with a semi-colon ;
//$pluginProperties["htmlarea203"]["body_onload"] = "init();";

// Browser compatibility - list all browsers for which this plugin works
$pluginProperties["htmlarea203"]["browsers"][1] = "IE";
//$pluginProperties["htmlarea203"]["browsers"][2] = "Opera";
//$pluginProperties["htmlarea203"]["browsers"][3] = "Mozilla";
//$pluginProperties["htmlarea203"]["browsers"][4] = "Other";

// Filename extensions for which the editor can be used
$pluginProperties["htmlarea203"]["filename_extensions"][1] = "htm";
$pluginProperties["htmlarea203"]["filename_extensions"][2] = "html";



// -------------------------------------------------------------------------
// HTMLArea 3 rc1 - http://www.interactivetools.com/products/htmlarea
// An HTML editor for IE5.5+ and Mozilla 1.3+ (all platforms)
// -------------------------------------------------------------------------

// Language code (see /plugins/htmlarea-3.0-rc1/lang)
if     ($net2ftp_language == "cs") { $htmlarea3rc1_language = "cz"; }
elseif ($net2ftp_language == "de") { $htmlarea3rc1_language = "de"; }
elseif ($net2ftp_language == "es") { $htmlarea3rc1_language = "es"; }
elseif ($net2ftp_language == "fr") { $htmlarea3rc1_language = "fr"; }
elseif ($net2ftp_language == "it") { $htmlarea3rc1_language = "it"; }
elseif ($net2ftp_language == "nl") { $htmlarea3rc1_language = "nl"; }
elseif ($net2ftp_language == "pl") { $htmlarea3rc1_language = "pl"; }
elseif ($net2ftp_language == "ru") { $htmlarea3rc1_language = "ru"; }
elseif ($net2ftp_language == "tc") { $htmlarea3rc1_language = "b5"; }
else                               { $htmlarea3rc1_language = "en"; }

$pluginProperties["htmlarea3rc1"]["use"]                     = "yes";
$pluginProperties["htmlarea3rc1"]["label"]                   = "HTMLArea 3 rc1";
$pluginProperties["htmlarea3rc1"]["directory"]               = "htmlarea-3.0-rc1";
$pluginProperties["htmlarea3rc1"]["type"]                    = "textarea";
$pluginProperties["htmlarea3rc1"]["php_include"][1]          = "";
$pluginProperties["htmlarea3rc1"]["css_include"][1]          = "";
$pluginProperties["htmlarea3rc1"]["js_code_pre"]             = "_editor_url = \"./plugins/htmlarea-3.0-rc1/\";\n";
$pluginProperties["htmlarea3rc1"]["js_code_pre"]             .= "_editor_lang = \"$htmlarea3rc1_language\";\n";  // 2-letter code; see /htmlarea-3.0-rc1/lang/XX.js files
$pluginProperties["htmlarea3rc1"]["js_include"][1]           = "plugins/htmlarea-3.0-rc1/htmlarea.js";
$pluginProperties["htmlarea3rc1"]["js_include"][2]           = "plugins/htmlarea-3.0-rc1/dialog.js";
$pluginProperties["htmlarea3rc1"]["js_include"][3]           = "plugins/htmlarea-3.0-rc1/lang/" . $htmlarea3rc1_language . ".js";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            = "      HTMLArea.loadPlugin(\"TableOperations\");\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "      HTMLArea.loadPlugin(\"SpellChecker\");\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "      HTMLArea.loadPlugin(\"FullPage\");\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "      HTMLArea.loadPlugin(\"CSS\");\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "      HTMLArea.loadPlugin(\"ContextMenu\");\n";
//$pluginProperties["htmlarea3rc1"]["js_code_post"]          .= "      HTMLArea.loadPlugin(\"EnterParagraphs\");\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "var editor = null;\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "function initEditor() {\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "  // create an editor for the \"text\" textbox\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "  editor = new HTMLArea(\"text\");\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "  // register the FullPage plugin\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= " editor.registerPlugin(FullPage);\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= " // register the SpellChecker plugin\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= " editor.registerPlugin(TableOperations);\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= " // register the SpellChecker plugin\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= " editor.registerPlugin(SpellChecker);\n";
//$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= " // register the EnterParagraphs plugin\n";
//$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= " editor.registerPlugin(EnterParagraphs);\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= " // register the CSS plugin\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= " editor.registerPlugin(CSS, {\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "   combos : [\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "     { label: \"Syntax:\",\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "                  // menu text       // CSS class\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "       options: { \"None\"           : \"\",\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "                  \"Code\" : \"code\",\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "                  \"String\" : \"string\",\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "                  \"Comment\" : \"comment\",\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "                  \"Variable name\" : \"variable-name\",\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "                  \"Type\" : \"type\",\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "                  \"Reference\" : \"reference\",\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "                  \"Preprocessor\" : \"preprocessor\",\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "                  \"Keyword\" : \"keyword\",\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "                  \"Function name\" : \"function-name\",\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "                  \"Html tag\" : \"html-tag\",\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "                  \"Html italic\" : \"html-helper-italic\",\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "                  \"Warning\" : \"warning\",\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "                  \"Html bold\" : \"html-helper-bold\"\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "                },\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "       context: \"pre\"\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "     },\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "     { label: \"Info:\",\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "       options: { \"None\"           : \"\",\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "                  \"Quote\"          : \"quote\",\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "                  \"Highlight\"      : \"highlight\",\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "                  \"Deprecated\"     : \"deprecated\"\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "                }\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "     }\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "   ]\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= " });\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= " // add a contextual menu\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= " editor.registerPlugin(\"ContextMenu\");\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= " // load the stylesheet used by our CSS plugin configuration\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= " editor.config.pageStyle = \"@import url(custom.css);\";\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= " setTimeout(function() {\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "   editor.generate();\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= " }, 500);\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= " return false;\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "}\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "function insertHTML() {\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= " var html = prompt(\"Enter some HTML code here\");\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= " if (html) {\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "   editor.insertHTML(html);\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= " }\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "}\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "function highlight() {\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= " editor.surroundHTML('<span style=\"background-color: yellow\">','</span>');\n";
$pluginProperties["htmlarea3rc1"]["js_code_post"]            .= "}\n";
$pluginProperties["htmlarea3rc1"]["body_onload"]             = "initEditor();";
$pluginProperties["htmlarea3rc1"]["browsers"][1]             = "IE";
$pluginProperties["htmlarea3rc1"]["browsers"][2]             = "Opera";
$pluginProperties["htmlarea3rc1"]["browsers"][3]             = "Mozilla";
$pluginProperties["htmlarea3rc1"]["browsers"][4]             = "Other";
$pluginProperties["htmlarea3rc1"]["filename_extensions"][1]  = "htm";
$pluginProperties["htmlarea3rc1"]["filename_extensions"][2]  = "html";



// -------------------------------------------------------------------------
// FCKEditor 2.0 RC2 - http://www.fckeditor.net/
// A HTML editor for IE 5+, Mozilla and Netscape
// -------------------------------------------------------------------------

// Language code (see /plugins/fckeditor-2.0/editor/lang)
/* SEE /INCLUDES/EDIT.PHP -----------------------------------------
if     ($net2ftp_language == "cs") { $fckeditor20_language = "en"; }
elseif ($net2ftp_language == "de") { $fckeditor20_language = "en"; }
elseif ($net2ftp_language == "es") { $fckeditor20_language = "es"; }
elseif ($net2ftp_language == "fr") { $fckeditor20_language = "fr"; }
elseif ($net2ftp_language == "it") { $fckeditor20_language = "it"; }
elseif ($net2ftp_language == "nl") { $fckeditor20_language = "en"; }
elseif ($net2ftp_language == "pl") { $fckeditor20_language = "pl"; }
elseif ($net2ftp_language == "ru") { $fckeditor20_language = "en"; }
elseif ($net2ftp_language == "tc") { $fckeditor20_language = "en"; }
else                               { $fckeditor20_language = "en"; }
------------------------------------------------------------------- */

$pluginProperties["fckeditor20"]["use"]                      = "yes";
$pluginProperties["fckeditor20"]["label"]                    = "FCKEditor 2.0 RC2";
$pluginProperties["fckeditor20"]["directory"]                = "fckeditor-2.0";
$pluginProperties["fckeditor20"]["type"]                     = "textarea";
$pluginProperties["fckeditor20"]["php_include"][1]           = "./plugins/fckeditor-2.0/fckeditor.php";
$pluginProperties["fckeditor20"]["css_include"][1]           = "";
$pluginProperties["fckeditor20"]["js_code_pre"]              = "";
$pluginProperties["fckeditor20"]["js_include"][1]            = "plugins/fckeditor-2.0/fckeditor.js";
$pluginProperties["fckeditor20"]["js_code_post"]             = "";
$pluginProperties["fckeditor20"]["js_code_post"]             = "";
$pluginProperties["fckeditor20"]["body_onload"]              = "";
$pluginProperties["fckeditor20"]["browsers"][1]              = "IE";
$pluginProperties["fckeditor20"]["browsers"][2]              = "Mozilla";
//$pluginProperties["fckeditor20"]["browsers"][3]              = "Opera";
//$pluginProperties["fckeditor20"]["browsers"][4]              = "Other";
$pluginProperties["fckeditor20"]["filename_extensions"][1]   = "htm";
$pluginProperties["fckeditor20"]["filename_extensions"][2]   = "html";


// -------------------------------------------------------------------------
// Helene 0.5 - http://helene.muze.nl
// A syntax highlighting text editor in javascript
// -------------------------------------------------------------------------

$pluginProperties["helene05"]["use"]                      = "yes";
$pluginProperties["helene05"]["label"]                    = "Syntax HTML/PHP";
$pluginProperties["helene05"]["directory"]                = "helene-0.5";
$pluginProperties["helene05"]["type"]                     = "textarea";
$pluginProperties["helene05"]["php_include"][1]           = "";
$pluginProperties["helene05"]["css_include"][1]           = "";
$pluginProperties["helene05"]["js_code_pre"]              = "";
$pluginProperties["helene05"]["js_include"][1]            = "";
$pluginProperties["helene05"]["js_code_post"]             = "";
$pluginProperties["helene05"]["body_onload"]              = "init()";
$pluginProperties["helene05"]["browsers"][1]              = "IE";
$pluginProperties["helene05"]["browsers"][2]              = "Opera";
$pluginProperties["helene05"]["browsers"][3]              = "Mozilla";
$pluginProperties["helene05"]["browsers"][4]              = "Other";
$pluginProperties["helene05"]["filename_extensions"][1]   = "php";
$pluginProperties["helene05"]["filename_extensions"][2]   = "phps";


// -------------------------------------------------------------------------
// Version Checker - written by Slynderdale for net2ftp.
// This small Javascript function will check if a new version of net2ftp is available
// and display a message if there is. 
// -------------------------------------------------------------------------

$pluginProperties["versioncheck"]["use"]            = "yes";
$pluginProperties["versioncheck"]["label"]          = "Javascript Version Checker";
$pluginProperties["versioncheck"]["directory"]      = "versioncheck";
$pluginProperties["versioncheck"]["type"]           = "versioncheck";
$pluginProperties["versioncheck"]["php_include"][1] = "";
$pluginProperties["versioncheck"]["css_include"][1] = "";
$pluginProperties["versioncheck"]["js_code_pre"]    = "";
$pluginProperties["versioncheck"]["js_include"][1]  = "http://www.net2ftp.com/version.js";
$pluginProperties["versioncheck"]["js_code_post"]   = "";
$pluginProperties["versioncheck"]["browsers"][1]    = "IE";
$pluginProperties["versioncheck"]["browsers"][2]    = "Opera";
$pluginProperties["versioncheck"]["browsers"][3]    = "Mozilla";
$pluginProperties["versioncheck"]["browsers"][4]    = "Other";
$pluginProperties["versioncheck"]["filename_extensions"][1] = "";
$pluginProperties["versioncheck"]["body_onload"]    = "";


// -------------------------------------------------------------------------
// The HTML progress bar originates from the PHP Pear package called
// HTML_Progress written by Laurent Laville.
// http://pear.laurent-laville.org/HTML_Progress/examples/index.html
// http://pear.laurent-laville.org/HTML_Progress/examples/horizontal/string.php
// -------------------------------------------------------------------------

$pluginProperties["html_progress"]["use"]            = "yes";
$pluginProperties["html_progress"]["label"]          = "HTML progress bar";
$pluginProperties["html_progress"]["directory"]      = "html_progress";
$pluginProperties["html_progress"]["type"]           = "progressbar";
$pluginProperties["html_progress"]["php_include"][1] = "./plugins/html_progress/html_progress.inc.php";
$pluginProperties["html_progress"]["css_include"][1] = "";
$pluginProperties["html_progress"]["js_code_pre"]    = "";
$pluginProperties["html_progress"]["js_include"][1]  = "plugins/html_progress/html_progress.js";
$pluginProperties["html_progress"]["js_code_post"]   = "";
$pluginProperties["html_progress"]["browsers"][1]    = "IE";
$pluginProperties["html_progress"]["browsers"][2]    = "Opera";
$pluginProperties["html_progress"]["browsers"][3]    = "Mozilla";
$pluginProperties["html_progress"]["browsers"][4]    = "Other";
$pluginProperties["html_progress"]["filename_extensions"][1] = "";
$pluginProperties["html_progress"]["body_onload"]    = "";



// -------------------------------------------------------------------------
// The JS Calendar code is written by Mishoo (who also wrote the HTMLArea v3).
// http://dynarch.com/mishoo/calendar.epl
// -------------------------------------------------------------------------

// Language code (see /plugins/js-calendar-0.9.6/lang)
if     ($net2ftp_language == "cs") { $jscalendar_language = "cs-win"; }
elseif ($net2ftp_language == "de") { $jscalendar_language = "de"; }
elseif ($net2ftp_language == "es") { $jscalendar_language = "es"; }
elseif ($net2ftp_language == "fr") { $jscalendar_language = "fr"; }
elseif ($net2ftp_language == "it") { $jscalendar_language = "it"; }
elseif ($net2ftp_language == "nl") { $jscalendar_language = "nl"; }
elseif ($net2ftp_language == "pl") { $jscalendar_language = "pl"; }
elseif ($net2ftp_language == "ru") { $jscalendar_language = "ru"; }
elseif ($net2ftp_language == "tc") { $jscalendar_language = "en"; }
else                               { $jscalendar_language = "en"; }

$pluginProperties["jscalendar"]["use"]               = "yes";
$pluginProperties["jscalendar"]["label"]             = "JS Calendar";
$pluginProperties["jscalendar"]["directory"]         = "jscalendar";
$pluginProperties["jscalendar"]["type"]              = "calendar";
$pluginProperties["jscalendar"]["php_include"][1]    = "./plugins/jscalendar-0.9.6/calendar.php";
$pluginProperties["jscalendar"]["css_include"][1]    = "plugins/jscalendar-0.9.6/calendar-win2k-cold-1.css";
$pluginProperties["jscalendar"]["js_code_pre"]       = "";
$pluginProperties["jscalendar"]["js_include"][1]     = "plugins/jscalendar-0.9.6/calendar.js";
$pluginProperties["jscalendar"]["js_include"][2]     = "plugins/jscalendar-0.9.6/lang/calendar-" . $jscalendar_language . ".js";
$pluginProperties["jscalendar"]["js_include"][3]     = "plugins/jscalendar-0.9.6/calendar-setup.js";
$pluginProperties["jscalendar"]["js_code_post"]      = "";
$pluginProperties["jscalendar"]["browsers"][1]       = "IE";
$pluginProperties["jscalendar"]["browsers"][2]       = "Opera";
$pluginProperties["jscalendar"]["browsers"][3]       = "Mozilla";
$pluginProperties["jscalendar"]["browsers"][4]       = "Other";
$pluginProperties["jscalendar"]["filename_extensions"][1] = "";
$pluginProperties["jscalendar"]["body_onload"]       = "";


// -------------------------------------------------------------------------
// JUpload 0.79
// A Java applet to upload directories and files
// -------------------------------------------------------------------------

$pluginProperties["jupload079"]["use"]                      = "yes";
$pluginProperties["jupload079"]["label"]                    = "JUpload 0.79";
$pluginProperties["jupload079"]["directory"]                = "jupload-0.79";
$pluginProperties["jupload079"]["type"]                     = "applet";
$pluginProperties["jupload079"]["php_include"][1]           = "";
$pluginProperties["jupload079"]["css_include"][1]           = "";
$pluginProperties["jupload079"]["js_code_pre"]              = "";
$pluginProperties["jupload079"]["js_include"][1]            = "";
$pluginProperties["jupload079"]["js_code_post"]             = "";
$pluginProperties["jupload079"]["js_code_post"]             = "";
$pluginProperties["jupload079"]["body_onload"]              = "";
$pluginProperties["jupload079"]["browsers"][1]              = "IE";
$pluginProperties["jupload079"]["browsers"][2]              = "Opera";
$pluginProperties["jupload079"]["browsers"][3]              = "Mozilla";
//$pluginProperties["jupload079"]["browsers"][4]              = "Other";
$pluginProperties["jupload079"]["filename_extensions"][1]   = "";


// -------------------------------------------------------------------------
// GeSHi 1.0.5
// Syntax highlighter
// -------------------------------------------------------------------------

$pluginProperties["geshi"]["use"]                      = "yes";
$pluginProperties["geshi"]["label"]                    = "GeSHi 1.0.5";
$pluginProperties["geshi"]["directory"]                = "geshi";
$pluginProperties["geshi"]["type"]                     = "highlighter";
$pluginProperties["geshi"]["php_include"][1]           = "./plugins/geshi/geshi.php";
$pluginProperties["geshi"]["css_include"][1]           = "";
$pluginProperties["geshi"]["js_code_pre"]              = "";
$pluginProperties["geshi"]["js_include"][1]            = "";
$pluginProperties["geshi"]["js_code_post"]             = "";
$pluginProperties["geshi"]["js_code_post"]             = "";
$pluginProperties["geshi"]["body_onload"]              = "";
$pluginProperties["geshi"]["browsers"][1]              = "IE";
$pluginProperties["geshi"]["browsers"][2]              = "Opera";
$pluginProperties["geshi"]["browsers"][3]              = "Mozilla";
$pluginProperties["geshi"]["browsers"][4]              = "Other";
$pluginProperties["geshi"]["filename_extensions"][1]   = "";


// DO NOT CHANGE ANYTHING BELOW THIS LINE
if ($plugin == "ALL")                                                      { return $pluginProperties; }
elseif ($plugin != "ALL" && array_key_exists($plugin , $pluginProperties)) { return $pluginProperties[$plugin]; }
else                                                                       { return false; }

} // end function getPluginProperties

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************









// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function integratePlugin($dowhat) {

// --------------
// This function integrates a plugin in the application by
//   - including PHP files
//   - including Javascript files (client-side)
//   - run Javascript code
//   ...
// The plugin which has to be integrated is set by the global variable $activePlugins
// Which part of the integration (see above) has to be done is set by $dowhat
// --------------

// -------------------------------------------------------------------------
// Global variables and settings
// -------------------------------------------------------------------------
	global $activePlugins;

// -------------------------------------------------------------------------
// Initial checks and initialization
// -------------------------------------------------------------------------
	if ($activePlugins == "") { return ""; }
	$bodyOnLoad = "";

// -------------------------------------------------------------------------
// For all plugins...
// -------------------------------------------------------------------------
	for ($pluginnr=0; $pluginnr<count($activePlugins); $pluginnr++) {

// Get the plugin related data
		$pluginData = getPluginProperties($activePlugins[$pluginnr]);
		if ($pluginData == false)  { continue; }

// Check if the plugin should be used
		if ($pluginData["use"] != "yes") { continue; }

// -------------------------------------------------------------------------
// Include PHP files
// This is called from index.php
// -------------------------------------------------------------------------
		if ($dowhat == "includePhpFiles" && $pluginData["php_include"][1] != "") {
			for ($i=1; $i<=sizeof($pluginData["php_include"]); $i++) {
				require_once($pluginData["php_include"][$i]);
			} // end for
			continue;
		} // end if

// -------------------------------------------------------------------------
// Include CSS files
// This is called from html.inc.php, function HtmlBegin()
// -------------------------------------------------------------------------
		elseif ($dowhat == "includeCssFiles" && $pluginData["css_include"][1] != "") {
			for ($i=1; $i<=sizeof($pluginData["css_include"]); $i++) {
				echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"" . $pluginData["css_include"][$i] . "\">\n";
			} // end for
			continue;
		} // end elseif

// -------------------------------------------------------------------------
// Include Javascript files
// This is called from html.inc.php, function HtmlBegin()
// -------------------------------------------------------------------------
		elseif ($dowhat == "includeJavascriptFiles" && $pluginData["js_include"][1] != "") {
			for ($i=1; $i<=sizeof($pluginData["js_include"]); $i++) {
				echo "<script type=\"text/javascript\" src=\"" . $pluginData["js_include"][$i] . "\"></script>\n";
			} // end for
			continue;
		} // end elseif

// -------------------------------------------------------------------------
// Run Javascript code in the header
// This is called from html.inc.php, function HtmlBegin()
// -------------------------------------------------------------------------
		elseif ($dowhat == "runJavascriptCodeAtHeaderPre" && $pluginData["js_code_pre"] != "") {
			echo "<script type=\"text/javascript\">\n";
			echo $pluginData["js_code_pre"];
			echo "</script>\n";
			continue;
		} // end elseif
		elseif ($dowhat == "runJavascriptCodeAtHeaderPost" && $pluginData["js_code_post"] != "") {
			echo "<script type=\"text/javascript\">\n";
			echo $pluginData["js_code_post"];
			echo "</script>\n";
			continue;
		} // end elseif

// -------------------------------------------------------------------------
// Run Javascript code at body onload event
// This is called from html.inc.php, function HtmlBegin()
// -------------------------------------------------------------------------
		elseif ($dowhat == "runJavascriptCodeAtBodyOnload") {
			if ($pluginData["body_onload"] != "") { $bodyOnLoad .= $pluginData["body_onload"] . "; "; }
		} // end elseif

	} // end for

// -------------------------------------------------------------------------
// Return values
// -------------------------------------------------------------------------
	if ($dowhat == "runJavascriptCodeAtBodyOnload") {
		return $bodyOnLoad;
	} // end elseif

} // End function integratePlugin

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




?>