<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2004 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------



// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printProgressBar() {

// --------------
// This functions prints the HTML needed for the progress bar
// Demo: http://pear.laurent-laville.org/HTML_Progress/examples/horizontal/string.php
// --------------

// If the plugin is not active, do nothing
	if (isActivePlugin("html_progress") == false) { return true; }

	echo "<div id=\"p_561b57_progress\" class=\"p_561b57\">\n";
	echo "<table align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n";
	echo "<tr>\n";
	echo "	<td class=\"progressBar\">\n";
	echo "\n";
	echo "		<div class=\"progressBarBorder\">\n";
	echo "		<div id=\"p_561b57_progressCell0I\" class=\"cellI\" style=\"position:absolute;top:2px;left:2px;\">&nbsp;</div>\n";
	echo "		<div id=\"p_561b57_progressCell1I\" class=\"cellI\" style=\"position:absolute;top:2px;left:19px;\">&nbsp;</div>\n";
	echo "		<div id=\"p_561b57_progressCell2I\" class=\"cellI\" style=\"position:absolute;top:2px;left:36px;\">&nbsp;</div>\n";
	echo "		<div id=\"p_561b57_progressCell3I\" class=\"cellI\" style=\"position:absolute;top:2px;left:53px;\">&nbsp;</div>\n";
	echo "		<div id=\"p_561b57_progressCell4I\" class=\"cellI\" style=\"position:absolute;top:2px;left:70px;\">&nbsp;</div>\n";
	echo "		<div id=\"p_561b57_progressCell5I\" class=\"cellI\" style=\"position:absolute;top:2px;left:87px;\">&nbsp;</div>\n";
	echo "		<div id=\"p_561b57_progressCell6I\" class=\"cellI\" style=\"position:absolute;top:2px;left:104px;\">&nbsp;</div>\n";
	echo "		<div id=\"p_561b57_progressCell7I\" class=\"cellI\" style=\"position:absolute;top:2px;left:121px;\">&nbsp;</div>\n";
	echo "\n";
	echo "		<div id=\"p_561b57_progressCell8I\" class=\"cellI\" style=\"position:absolute;top:2px;left:138px;\">&nbsp;</div>\n";
	echo "		<div id=\"p_561b57_progressCell9I\" class=\"cellI\" style=\"position:absolute;top:2px;left:155px;\">&nbsp;</div>\n";
	echo "		<div id=\"p_561b57_progressCell0A\" class=\"cellA\" style=\"position:absolute;top:2px;left:2px;\">&nbsp;</div>\n";
	echo "		<div id=\"p_561b57_progressCell1A\" class=\"cellA\" style=\"position:absolute;top:2px;left:19px;\">&nbsp;</div>\n";
	echo "		<div id=\"p_561b57_progressCell2A\" class=\"cellA\" style=\"position:absolute;top:2px;left:36px;\">&nbsp;</div>\n";
	echo "		<div id=\"p_561b57_progressCell3A\" class=\"cellA\" style=\"position:absolute;top:2px;left:53px;\">&nbsp;</div>\n";
	echo "		<div id=\"p_561b57_progressCell4A\" class=\"cellA\" style=\"position:absolute;top:2px;left:70px;\">&nbsp;</div>\n";
	echo "		<div id=\"p_561b57_progressCell5A\" class=\"cellA\" style=\"position:absolute;top:2px;left:87px;\">&nbsp;</div>\n";
	echo "		<div id=\"p_561b57_progressCell6A\" class=\"cellA\" style=\"position:absolute;top:2px;left:104px;\">&nbsp;</div>\n";
	echo "\n";
	echo "		<div id=\"p_561b57_progressCell7A\" class=\"cellA\" style=\"position:absolute;top:2px;left:121px;\">&nbsp;</div>\n";
	echo "		<div id=\"p_561b57_progressCell8A\" class=\"cellA\" style=\"position:absolute;top:2px;left:138px;\">&nbsp;</div>\n";
	echo "		<div id=\"p_561b57_progressCell9A\" class=\"cellA\" style=\"position:absolute;top:2px;left:155px;\">&nbsp;</div>\n";
	echo "		</div>\n";
	echo "	</td>\n";
	echo "	<td class=\"installationProgress\" id=\"p_561b57_installationProgress\">\n";
	echo "		\n";
	echo "	</td>\n";
	echo "</tr>\n";
	echo "</table>\n";
	echo "</div>\n";

	echo "<script type=\"text/javascript\">self.setprogress(\"p_561b57_\",0,\"\",0); </script>\n";

} // end function printProgressBar

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function printProgressCircle() {

// --------------
// This functions prints the HTML needed for the progress circle
// Demo: http://pear.laurent-laville.org/HTML_Progress/examples/newshape/circleplain.php
// --------------

// If the plugin is not active, do nothing
	if (isActivePlugin("html_progress") == false) { return true; }

	echo "<div id=\"p_8e2a67_progress\" class=\"p_8e2a67\">\n";
	echo "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n";
	echo "<tr>\n";
	echo "	<td class=\"progressBar\">\n";
	echo "		<div class=\"progressBarBorder\">\n";
	echo "		<div id=\"p_8e2a67_progressCell0I\" class=\"cellI\" style=\"position:absolute;top:0;left:0;\">&nbsp;</div>\n";
	echo "		<div id=\"p_8e2a67_progressCell1I\" class=\"cellI\" style=\"position:absolute;top:0;left:0;\">&nbsp;</div>\n";
	echo "		<div id=\"p_8e2a67_progressCell2I\" class=\"cellI\" style=\"position:absolute;top:0;left:0;\">&nbsp;</div>\n";
	echo "		<div id=\"p_8e2a67_progressCell3I\" class=\"cellI\" style=\"position:absolute;top:0;left:0;\">&nbsp;</div>\n";
	echo "		<div id=\"p_8e2a67_progressCell4I\" class=\"cellI\" style=\"position:absolute;top:0;left:0;\">&nbsp;</div>\n";
	echo "		<div id=\"p_8e2a67_progressCell5I\" class=\"cellI\" style=\"position:absolute;top:0;left:0;\">&nbsp;</div>\n";
	echo "		<div id=\"p_8e2a67_progressCell6I\" class=\"cellI\" style=\"position:absolute;top:0;left:0;\">&nbsp;</div>\n";
	echo "		<div id=\"p_8e2a67_progressCell7I\" class=\"cellI\" style=\"position:absolute;top:0;left:0;\">&nbsp;</div>\n";
	echo "		<div id=\"p_8e2a67_progressCell8I\" class=\"cellI\" style=\"position:absolute;top:0;left:0;\">&nbsp;</div>\n";
	echo "		<div id=\"p_8e2a67_progressCell9I\" class=\"cellI\" style=\"position:absolute;top:0;left:0;\">&nbsp;</div>\n";
	echo "		<div id=\"p_8e2a67_progressCell0A\" class=\"cellA\" style=\"position:absolute;top:0;left:0;\"><img src=\"plugins/html_progress/c1.png\" border=\"0\" /></div>\n";
	echo "		<div id=\"p_8e2a67_progressCell1A\" class=\"cellA\" style=\"position:absolute;top:0;left:0;\"><img src=\"plugins/html_progress/c2.png\" border=\"0\" /></div>\n";
	echo "		<div id=\"p_8e2a67_progressCell2A\" class=\"cellA\" style=\"position:absolute;top:0;left:0;\"><img src=\"plugins/html_progress/c3.png\" border=\"0\" /></div>\n";
	echo "		<div id=\"p_8e2a67_progressCell3A\" class=\"cellA\" style=\"position:absolute;top:0;left:0;\"><img src=\"plugins/html_progress/c4.png\" border=\"0\" /></div>\n";
	echo "		<div id=\"p_8e2a67_progressCell4A\" class=\"cellA\" style=\"position:absolute;top:0;left:0;\"><img src=\"plugins/html_progress/c5.png\" border=\"0\" /></div>\n";
	echo "		<div id=\"p_8e2a67_progressCell5A\" class=\"cellA\" style=\"position:absolute;top:0;left:0;\"><img src=\"plugins/html_progress/c6.png\" border=\"0\" /></div>\n";
	echo "		<div id=\"p_8e2a67_progressCell6A\" class=\"cellA\" style=\"position:absolute;top:0;left:0;\"><img src=\"plugins/html_progress/c7.png\" border=\"0\" /></div>\n";
	echo "		<div id=\"p_8e2a67_progressCell7A\" class=\"cellA\" style=\"position:absolute;top:0;left:0;\"><img src=\"plugins/html_progress/c8.png\" border=\"0\" /></div>\n";
	echo "		<div id=\"p_8e2a67_progressCell8A\" class=\"cellA\" style=\"position:absolute;top:0;left:0;\"><img src=\"plugins/html_progress/c9.png\" border=\"0\" /></div>\n";
	echo "		<div id=\"p_8e2a67_progressCell9A\" class=\"cellA\" style=\"position:absolute;top:0;left:0;\"><img src=\"plugins/html_progress/c10.png\" border=\"0\" /></div>\n";
	echo "		</div>\n";
	echo "	</td>\n";
	echo "	<td class=\"installationProgress\" id=\"p_8e2a67_installationProgress\">\n";
	echo "		\n";
	echo "	</td>\n";
	echo "</tr>\n";
	echo "</table>\n";
	echo "</div>\n";

	echo "<script type=\"text/javascript\">self.setprogress(\"p_8e2a67_\",0,\"\",0); </script>\n";

} // end function printProgressCircle

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function setProgressBarStatus($current, $total, $string) {

// --------------
// This function prints the Javascript which will update the status in the top table
// See also the Javascript function setStatus_js defined in the PHP function printJavascriptFunctions.
// --------------

// If the plugin is not active, do nothing
	if (isActivePlugin("html_progress") == false) { return true; }

// Sometimes the progress bar does not need updating
	if ($current == 0 || $total == 0) { return true; }

// Convert $current (5) out of $total (15) to a number between 1 and 10 (5/15 = 33% ==> 3)
	$number = floor($current/$total*10);

	echo "<script type=\"text/javascript\"><!--\n";
	echo "	self.setprogress(\"p_561b57_\",$number,\"$string\",0);\n";
	echo "//--></script>\n";

	flush();

} // End function setProgressBarStatus

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function setProgressCircleStatus($current, $total, $string) {

// --------------
// This function prints the Javascript which will update the status in the top table
// See also the Javascript function setStatus_js defined in the PHP function printJavascriptFunctions.
// --------------

// If the plugin is not active, do nothing
	if (isActivePlugin("html_progress") == false) { return true; }

// Sometimes the progress bar does not need updating
	if ($current == 0 || $total == 0) { return true; }

// Convert $current (5) out of $total (15) to a number between 1 and 10 (5/15 = 33% ==> 3)
	$number = floor($current/$total*10);

	echo "<script type=\"text/javascript\"><!--\n";
	echo "	self.setprogress(\"p_8e2a67_\",$number,\"$string\",0);\n";
	echo "//--></script>\n";

	flush();

} // End function setProgressCircleStatus

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************





/* -------------------------------------------------------------------------------

   For documentation purposes, below is the original HTML file from
   http://pear.laurent-laville.org/HTML_Progress/examples/horizontal/string.php


<html>
<head>
<title>Horizontal String ProgressBar example</title>
<style type="text/css">
<!--
.p_561b57 .progressBar {
	background-color: #FFFFFF;
	width: 172px;
	height: 24px;
	position: relative;
	left: 0px;
	top: 0px;
}
.p_561b57 .progressBarBorder {
	background-color: #FFFFFF;
	width: 172px;
	height: 24px;
	position: relative;
	left: 0px;
	top: 0px;
	border-width: 0px;
	border-style: solid;
	border-color: #000000;
}
.p_561b57 .installationProgress {
	width: 350px;
	text-align: left;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #000000;
	background-color: #FFFFFF;
}
.p_561b57 .cellI {
	width: 15px;
	height: 20px;
	font-family: Courier, Verdana;
	font-size: 8px;
	float: left;
	background-color: #CCCCCC;
}
.p_561b57 .cellA {
	width: 15px;
	height: 20px;
	font-family: Courier, Verdana;
	font-size: 8px;
	float: left;
	background-color: #006600;
	visibility: hidden;
}

body {
	background-color: #FFFFFF;
	color: #000000;
	font-family: Verdana, Arial;
}

a:visited, a:active, a:link {
	color: navy;
}
// -->
</style>
<script type="text/javascript">
<!--
var isDom = document.getElementById?true:false;
var isIE  = document.all?true:false;
var isNS4 = document.layers?true:false;
var cellCount = 10;

function setprogress(pIdent, pValue, pString, pDeterminate)
{
        if (isDom) {
            prog = document.getElementById(pIdent+'installationProgress');
        } else if (isIE) {
            prog = document.all[pIdent+'installationProgress'];
        } else if (isNS4) {
            prog = document.layers[pIdent+'installationProgress'];
        }
        if (prog != null) {
            prog.innerHTML = pString;
        }
        if (pValue == pDeterminate) {
            for (i=0; i < cellCount; i++) {
                showCell(i, pIdent, "hidden");	
            }
        }
        if ((pDeterminate > 0) && (pValue > 0)) {
            i = (pValue-1) % cellCount;
            showCell(i, pIdent, "visible");	
        } else {
            for (i=pValue-1; i >=0; i--) {
                showCell(i, pIdent, "visible");	
            }
        }
}

function showCell(pCell, pIdent, pVisibility)
{
        if (isDom) {
            document.getElementById(pIdent+'progressCell'+pCell+'A').style.visibility = pVisibility;
        } else if (isIE) {
            document.all[pIdent+'progressCell'+pCell+'A'].style.visibility = pVisibility;
        } else if (isNS4) {
            document.layers[pIdent+'progressCell'+pCell+'A'].style.visibility = pVisibility;
        }
}

function hideProgress(pIdent)
{
        if (isDom) {
            document.getElementById(pIdent+'progress').style.visibility = 'hidden';
        } else if (isIE) {
            document.all[pIdent+'progress'].style.visibility = 'hidden';
        } else if (isNS4) {
            document.layers[pIdent+'progress'].style.visibility = 'hidden';
        }
        for (i=0; i < cellCount; i++) {
            showCell(i, pIdent, "hidden");	
        }
}
//-->
</script>
</head>
<body>
<h1>string.php</h1>

<div id="p_561b57_progress" class="p_561b57">
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
<tr>
	<td class=\"progressBar\">

		<div class="progressBarBorder">
		<div id=\"p_561b57_progressCell0I\" class=\"cellI\" style="position:absolute;top:2px;left:2px;">&nbsp;</div>
		<div id="p_561b57_progressCell1I" class=\"cellI\" style="position:absolute;top:2px;left:19px;">&nbsp;</div>
		<div id="p_561b57_progressCell2I" class=\"cellI\" style="position:absolute;top:2px;left:36px;">&nbsp;</div>
		<div id="p_561b57_progressCell3I" class=\"cellI\" style="position:absolute;top:2px;left:53px;">&nbsp;</div>
		<div id="p_561b57_progressCell4I" class=\"cellI\" style="position:absolute;top:2px;left:70px;">&nbsp;</div>
		<div id="p_561b57_progressCell5I" class=\"cellI\" style="position:absolute;top:2px;left:87px;">&nbsp;</div>
		<div id="p_561b57_progressCell6I" class=\"cellI\" style="position:absolute;top:2px;left:104px;">&nbsp;</div>
		<div id="p_561b57_progressCell7I" class=\"cellI\" style="position:absolute;top:2px;left:121px;">&nbsp;</div>

		<div id="p_561b57_progressCell8I" class=\"cellI\" style="position:absolute;top:2px;left:138px;">&nbsp;</div>
		<div id="p_561b57_progressCell9I" class=\"cellI\" style="position:absolute;top:2px;left:155px;">&nbsp;</div>
		<div id="p_561b57_progressCell0A" class=\"cellA\" style="position:absolute;top:2px;left:2px;">&nbsp;</div>
		<div id="p_561b57_progressCell1A" class=\"cellA\" style="position:absolute;top:2px;left:19px;">&nbsp;</div>
		<div id="p_561b57_progressCell2A" class=\"cellA\" style="position:absolute;top:2px;left:36px;">&nbsp;</div>
		<div id="p_561b57_progressCell3A" class=\"cellA\" style="position:absolute;top:2px;left:53px;">&nbsp;</div>
		<div id="p_561b57_progressCell4A" class=\"cellA\" style="position:absolute;top:2px;left:70px;">&nbsp;</div>
		<div id="p_561b57_progressCell5A" class=\"cellA\" style="position:absolute;top:2px;left:87px;">&nbsp;</div>
		<div id="p_561b57_progressCell6A" class=\"cellA\" style="position:absolute;top:2px;left:104px;">&nbsp;</div>

		<div id="p_561b57_progressCell7A" class=\"cellA\" style="position:absolute;top:2px;left:121px;">&nbsp;</div>
		<div id="p_561b57_progressCell8A" class=\"cellA\" style="position:absolute;top:2px;left:138px;">&nbsp;</div>
		<div id="p_561b57_progressCell9A" class=\"cellA\" style="position:absolute;top:2px;left:155px;">&nbsp;</div>
		</div>
	</td>
	<td class="installationProgress" id="p_561b57_installationProgress">
		
	</td>
</tr>
</table>
</div>

<script type="text/javascript">self.setprogress("p_561b57_",0,"",0); </script>
<script type="text/javascript">self.setprogress("p_561b57_",0,"&nbsp; installing package (0 %) ... : PEAR",0); </script>
<script type="text/javascript">self.setprogress("p_561b57_",1,"&nbsp; installing package (5 %) ... : PEAR",0); </script>
<script type="text/javascript">self.setprogress("p_561b57_",1,"&nbsp; installing package (10 %) ... : Archive_Tar",0); </script>
<script type="text/javascript">self.setprogress("p_561b57_",2,"&nbsp; installing package (15 %) ... : Archive_Tar",0); </script>
<script type="text/javascript">self.setprogress("p_561b57_",2,"&nbsp; installing package (20 %) ... : Config",0); </script>
<script type="text/javascript">self.setprogress("p_561b57_",3,"&nbsp; installing package (25 %) ... : Config",0); </script>
<script type="text/javascript">self.setprogress("p_561b57_",3,"&nbsp; installing package (30 %) ... : HTML_QuickForm",0); </script>

<script type="text/javascript">self.setprogress("p_561b57_",4,"&nbsp; installing package (35 %) ... : HTML_QuickForm",0); </script>
<script type="text/javascript">self.setprogress("p_561b57_",4,"&nbsp; installing package (40 %) ... : HTML_CSS",0); </script>
<script type="text/javascript">self.setprogress("p_561b57_",5,"&nbsp; installing package (45 %) ... : HTML_CSS",0); </script>
<script type="text/javascript">self.setprogress("p_561b57_",5,"&nbsp; installing package (50 %) ... : HTML_Page",0); </script>
<script type="text/javascript">self.setprogress("p_561b57_",6,"&nbsp; installing package (55 %) ... : HTML_Page",0); </script>
<script type="text/javascript">self.setprogress("p_561b57_",6,"&nbsp; installing package (60 %) ... : HTML_Template_Sigma",0); </script>
<script type="text/javascript">self.setprogress("p_561b57_",7,"&nbsp; installing package (65 %) ... : HTML_Template_Sigma",0); </script>
<script type="text/javascript">self.setprogress("p_561b57_",7,"&nbsp; installing package (70 %) ... : Log",0); </script>
<script type="text/javascript">self.setprogress("p_561b57_",8,"&nbsp; installing package (75 %) ... : Log",0); </script>

<script type="text/javascript">self.setprogress("p_561b57_",8,"&nbsp; installing package (80 %) ... : MDB",0); </script>
<script type="text/javascript">self.setprogress("p_561b57_",9,"&nbsp; installing package (85 %) ... : MDB",0); </script>
<script type="text/javascript">self.setprogress("p_561b57_",9,"&nbsp; installing package (90 %) ... : PHPUnit",0); </script>
<script type="text/javascript">self.setprogress("p_561b57_",10,"&nbsp; installing package (95 %) ... : PHPUnit",0); </script>
<script type="text/javascript">self.setprogress("p_561b57_",10,"",0); </script>
<p>&lt;&lt; <a href="../index.html">Back examples TOC</a></p>

</body>
</html>

------------------------------------------------------------------------------- */ 


/* -------------------------------------------------------------------------------

   For documentation purposes, below is the original HTML file from
   http://pear.laurent-laville.org/HTML_Progress/examples/newshape/circleplain.php

<html>
<head>
<title>Basic Circle ProgressBar example</title>
<style type="text/css">
<!--
.p_8e2a67 .progressBar {
	background-color: #FFFFFF;
	width: 50px;
	height: 50px;
	position: relative;
	left: 0px;
	top: 0px;
}
.p_8e2a67 .progressBarBorder {
	background-color: #FFFFFF;
	width: 50px;
	height: 50px;
	position: relative;
	left: 0px;
	top: 0px;
	border-width: 0px;
	border-style: solid;
	border-color: #000000;
}
.p_8e2a67 .installationProgress {
	width: 50px;
	text-align: right;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #000000;
	background-color: #eeeeee;
}
.p_8e2a67 .cellI {
	width: 50px;
	height: 50px;
	font-family: Courier, Verdana;
	font-size: 8px;
	background-image: url("../temp/c0.png");
	background-repeat: no-repeat;
}
.p_8e2a67 .cellA {
	width: 50px;
	height: 50px;
	font-family: Courier, Verdana;
	font-size: 8px;
	visibility: hidden;
}

body {
	background-color: #EEEEEE;
	color: #000000;
	font-family: Verdana, Arial;
}

a:visited, a:active, a:link {
	color: navy;
}
// -->
</style>
<script type="text/javascript">
<!--
var isDom = document.getElementById?true:false;
var isIE  = document.all?true:false;
var isNS4 = document.layers?true:false;
var cellCount = 10;

function setprogress(pIdent, pValue, pString, pDeterminate)
{
    if (isDom) {
        prog = document.getElementById(pIdent+'installationProgress');
    } else if (isIE) {
        prog = document.all[pIdent+'installationProgress'];
    } else if (isNS4) {
        prog = document.layers[pIdent+'installationProgress'];
    }
    if (prog != null) {
        prog.innerHTML = pString;
    }
    if (pValue == pDeterminate) {
        for (i=0; i < cellCount; i++) {
            showCell(i, pIdent, "hidden");	
        }
    }
    if ((pDeterminate > 0) && (pValue > 0)) {
        i = (pValue-1) % cellCount;
        showCell(i, pIdent, "visible");	
    } else {
        for (i=pValue-1; i >=0; i--) {
            showCell(i, pIdent, "visible");	
        }
    }
}

function setVisibility(pElement, pVisibility)
{
    if (isDom) {
        document.getElementById(pElement).style.visibility = pVisibility;
    } else if (isIE) {
        document.all[pElement].style.visibility = pVisibility;
    } else if (isNS4) {
        document.layers[pElement].style.visibility = pVisibility;
    }
}

function showCell(pCell, pIdent, pVisibility)
{
    setVisibility(pIdent+'progressCell'+pCell+'A', pVisibility);
}

function hideProgress(pIdent)
{
    setVisibility(pIdent+'progress', 'hidden');

    for (i=0; i < cellCount; i++) {
        showCell(i, pIdent, "hidden");	
    }
}
//-->
</script>
</head>
<body>
<h1>circleplain.php</h1>

<div id="p_8e2a67_progress" class="p_8e2a67">
<table border="0" cellspacing="0" cellpadding="0">
<tr>
	<td class="progressBar">
		<div class="progressBarBorder">
		<div id="p_8e2a67_progressCell0I" class="cellI" style="position:absolute;top:0;left:0;">&nbsp;</div>
		<div id="p_8e2a67_progressCell1I" class="cellI" style="position:absolute;top:0;left:0;">&nbsp;</div>
		<div id="p_8e2a67_progressCell2I" class="cellI" style="position:absolute;top:0;left:0;">&nbsp;</div>
		<div id="p_8e2a67_progressCell3I" class="cellI" style="position:absolute;top:0;left:0;">&nbsp;</div>
		<div id="p_8e2a67_progressCell4I" class="cellI" style="position:absolute;top:0;left:0;">&nbsp;</div>
		<div id="p_8e2a67_progressCell5I" class="cellI" style="position:absolute;top:0;left:0;">&nbsp;</div>
		<div id="p_8e2a67_progressCell6I" class="cellI" style="position:absolute;top:0;left:0;">&nbsp;</div>
		<div id="p_8e2a67_progressCell7I" class="cellI" style="position:absolute;top:0;left:0;">&nbsp;</div>
		<div id="p_8e2a67_progressCell8I" class="cellI" style="position:absolute;top:0;left:0;">&nbsp;</div>
		<div id="p_8e2a67_progressCell9I" class="cellI" style="position:absolute;top:0;left:0;">&nbsp;</div>
		<div id="p_8e2a67_progressCell0A" class="cellA" style="position:absolute;top:0;left:0;"><img src="../temp/c1.png" border="0" /></div>
		<div id="p_8e2a67_progressCell1A" class="cellA" style="position:absolute;top:0;left:0;"><img src="../temp/c2.png" border="0" /></div>
		<div id="p_8e2a67_progressCell2A" class="cellA" style="position:absolute;top:0;left:0;"><img src="../temp/c3.png" border="0" /></div>
		<div id="p_8e2a67_progressCell3A" class="cellA" style="position:absolute;top:0;left:0;"><img src="../temp/c4.png" border="0" /></div>
		<div id="p_8e2a67_progressCell4A" class="cellA" style="position:absolute;top:0;left:0;"><img src="../temp/c5.png" border="0" /></div>
		<div id="p_8e2a67_progressCell5A" class="cellA" style="position:absolute;top:0;left:0;"><img src="../temp/c6.png" border="0" /></div>
		<div id="p_8e2a67_progressCell6A" class="cellA" style="position:absolute;top:0;left:0;"><img src="../temp/c7.png" border="0" /></div>
		<div id="p_8e2a67_progressCell7A" class="cellA" style="position:absolute;top:0;left:0;"><img src="../temp/c8.png" border="0" /></div>
		<div id="p_8e2a67_progressCell8A" class="cellA" style="position:absolute;top:0;left:0;"><img src="../temp/c9.png" border="0" /></div>
		<div id="p_8e2a67_progressCell9A" class="cellA" style="position:absolute;top:0;left:0;"><img src="../temp/c10.png" border="0" /></div>
		</div>
	</td>
	<td class="installationProgress" id="p_8e2a67_installationProgress">
		0 %
	</td>
</tr>
</table>
</div>

<script type="text/javascript">self.setprogress("p_8e2a67_",0,"0 %",0); </script>
<script type="text/javascript">self.setprogress("p_8e2a67_",1,"10 %",0); </script>
<script type="text/javascript">self.setprogress("p_8e2a67_",2,"20 %",0); </script>
<script type="text/javascript">self.setprogress("p_8e2a67_",3,"30 %",0); </script>
<script type="text/javascript">self.setprogress("p_8e2a67_",4,"40 %",0); </script>
<script type="text/javascript">self.setprogress("p_8e2a67_",5,"50 %",0); </script>
<script type="text/javascript">self.setprogress("p_8e2a67_",6,"60 %",0); </script>
<script type="text/javascript">self.setprogress("p_8e2a67_",7,"70 %",0); </script>
<script type="text/javascript">self.setprogress("p_8e2a67_",8,"80 %",0); </script>
<script type="text/javascript">self.setprogress("p_8e2a67_",9,"90 %",0); </script>
<script type="text/javascript">self.setprogress("p_8e2a67_",10,"100 %",0); </script>
<p>&lt;&lt; <a href="../index.html">Back examples TOC</a></p>

</body>
</html>
   
------------------------------------------------------------------------------- */ 

?>