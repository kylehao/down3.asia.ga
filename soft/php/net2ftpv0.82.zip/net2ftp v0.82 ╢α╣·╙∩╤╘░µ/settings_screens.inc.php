<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//   -------------------------------------------------------------------------------
//  |                                                                               |
//  |  Enter your settings and preferences below.                                   |
//  |                                                                               |
//  |  The structure of each line is like this:                                     |
//  |     $settings['setting_name'] = "setting_value";                              |
//  |                                                                               |
//  |  BE CAREFUL WHEN EDITING THE FILE: ONLY EDIT THE setting_value, AND DO NOT    |
//  |  ERASE THE " OR THE ; CHARACTERS.                                             |
//   -------------------------------------------------------------------------------


// ----------------------------------------------------------------------------------
// Login screen fields
// Set which fields should be shown or hidden on the login screen
// ----------------------------------------------------------------------------------

// FTP server
// - Set it to "yes" (default setting) if you want to allow connections to ALL 
//   or a list of allowed FTP servers.
// - Set it to "no" ONLY IF YOU WANT TO RESTRICT CONNECTIONS TO ONE (1) SINGLE 
//   FTP SERVER. In that case, edit also $settings['net2ftp_allowed_ftpservers'][1] 
//   in settings_authorizations.inc.php.
$settings['fielduse_login_ftpserver'] = "yes";

// FTP server port
// If it is set to "no" and $settings['net2ftp_allowed_ftpserverport'] is set, 
// this port is used. If $settings['net2ftp_allowed_ftpserverport'] is not set,
// port 21 is used.
$settings['fielduse_login_ftpserverport'] = "yes";

// Username and password cannot be turned off on the login screen.
// NOTE: It is possible to log in without entering a username and password, by
// using the bookmark functionality.

// Initial directory
$settings['fielduse_login_directory'] = "yes";

// Anonymous checkbox
$settings['fielduse_login_anonymous'] = "yes";

// Passive mode checkbox
$settings['fielduse_login_passivemode'] = "yes";

// SSL checkbox
$settings['fielduse_login_sslconnect'] = "no";

// Language
// If it is set to "no", the default language will be used (see settings.inc.php)
$settings['fielduse_login_language'] = "yes";

// Skin
// If it is set to "no", skin number 1 will be used
$settings['fielduse_login_skin'] = "yes";

// FTP mode
// If it is set to "no", the FTP mode will be BINARY
$settings['fielduse_login_ftpmode'] = "yes";

// Clear Cookies link
$settings['fielduse_login_clearcookies'] = "yes";

// Admin link
$settings['fielduse_login_admin'] = "yes";


// ----------------------------------------------------------------------------------
// Functions on the Browse screen - TOP LEFT
// Indicate which functions are enabled or disabled
// ----------------------------------------------------------------------------------

// Create new directory
$settings['functionuse_newdirectory'] = "yes";

// Create new file
$settings['functionuse_newfile'] = "yes";

// Upload (upload, upload-and-unzip)
$settings['functionuse_uploadfile'] = "yes";

// Java upload
$settings['functionuse_javaupload'] = "yes";

// Create a website from pre-made HTML templates
$settings['functionuse_easyWebsite'] = "no";

// Bookmark a page
$settings['functionuse_bookmark'] = "yes";

// Advanced functions
$settings['functionuse_advanced'] = "yes";


// ----------------------------------------------------------------------------------
// Functions on the Browse screen - TOP RIGHT
// Indicate which functions are enabled or disabled
// ----------------------------------------------------------------------------------

// Copy, move and delete directories and files
$settings['functionuse_copy']   = "yes";
$settings['functionuse_move']   = "yes";
$settings['functionuse_delete'] = "yes";

// Rename
$settings['functionuse_rename'] = "yes";

// Chmod
$settings['functionuse_chmod'] = "yes";

// Zip-and-download
$settings['functionuse_zip_download'] = "yes";

// Zip-and-save, zip-and-email
$settings['functionuse_zip_save_email'] = "yes";

// Calculate size
$settings['functionuse_calculatesize'] = "yes";

// Find string
$settings['functionuse_findstring'] = "yes";


// ----------------------------------------------------------------------------------
// Functions on the Browse screen - ROW LEVEL
// Indicate which functions are enabled or disabled
// ----------------------------------------------------------------------------------

// Download file
$settings['functionuse_downloadfile'] = "yes";

// View file
$settings['functionuse_view'] = "yes";

// Edit file
$settings['functionuse_edit'] = "yes";

// Update file (beta function)
$settings['functionuse_updatefile'] = "no";

?>