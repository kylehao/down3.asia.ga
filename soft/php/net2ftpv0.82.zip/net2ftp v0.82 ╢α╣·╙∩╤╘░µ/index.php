<?php
//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2005 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//  | This program is distributed in the hope that it will be useful,               |
//  | but WITHOUT ANY WARRANTY; without even the implied warranty of                |
//  | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 |
//  | GNU General Public License for more details.                                  |
//  |                                                                               |
//  | You should have received a copy of the GNU General Public License             |
//  | along with this program; if not, write to the Free Software                   |
//  | Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA     |
//  |                                                                               |
//   -------------------------------------------------------------------------------


// -------------------------------------------------------------------------
// Erase all variables which are not $_GET, $_POST, $_COOKIE, $_SERVER, ...
// This is to make the script safer on environments which have register_globals = On.
// -------------------------------------------------------------------------
 if (ini_get(register_globals) == 1) {
	$defined_vars = get_defined_vars();
	while (list($var_name, $var_value) = each($defined_vars)) {
		if ($var_name != "_GET" && $var_name != "_POST" && $var_name != "_COOKIE" && $var_name != "_SERVER" && $var_name != "_FILES" && $var_name != "_SESSION" && $var_name != "_ENV" && $var_name != "HTTP_AUTHORIZATION") {
//			echo "Variable " . $var_name . " has value " . $var_value . "<br />\n";
			unset($$var_name);
		}
	} // end while
}


// -------------------------------------------------------------------------
// Basic settings
// -------------------------------------------------------------------------

// Run the script to the end, even if the user hits the stop button
ignore_user_abort();

// Execute function shutdown() if the script reaches the maximum execution time (usually 30 seconds)
register_shutdown_function("shutdown");

// Get settings files
require_once("settings.inc.php");
require_once("settings_authorizations.inc.php");
require_once("settings_screens.inc.php");

// The root directory cannot be determined from an include file,
// so this is the workaround
$application_rootdir = dirname(__FILE__);
$application_includesdir  = $application_rootdir . "/includes";
$application_languagesdir = $application_rootdir . "/languages";
$application_pluginsdir   = $application_rootdir . "/plugins";
$application_tempdir      = $application_rootdir . "/temp";
$application_templatesdir = $application_rootdir . "/html_templates";

// Set the error reporting level
if ($settings['error_reporting'] == "ALL")      { error_reporting(E_ALL); }
elseif ($settings['error_reporting'] == "NONE") { error_reporting(0); }
else                                            { error_reporting(E_ERROR | E_WARNING | E_PARSE); }

// Set the execution control variables
$execution_success = true;
$execution_errormessage = "";
$execution_debug_backtrace = "";
$execution_output = "no";

// Timer: start
$starttime = microtime();


// -------------------------------------------------------------------------
// Function libraries which are always needed
// Those not always needed are included below, depending on certain variables
// -------------------------------------------------------------------------
require_once($application_includesdir . "/net2ftp_loginform.inc.php");
require_once($application_includesdir . "/admin.inc.php");
require_once($application_includesdir . "/advanced.inc.php");
require_once($application_includesdir . "/authorizations.inc.php");
require_once($application_includesdir . "/bookmark.inc.php");
require_once($application_includesdir . "/browse.inc.php");
require_once($application_includesdir . "/consumption.inc.php");
require_once($application_includesdir . "/database.inc.php");
require_once($application_includesdir . "/easywebsite.inc.php");
require_once($application_includesdir . "/edit.inc.php");
require_once($application_includesdir . "/errorhandling.inc.php");
require_once($application_includesdir . "/filesystem.inc.php");
require_once($application_includesdir . "/html.inc.php");
require_once($application_includesdir . "/homepage.inc.php");
require_once($application_includesdir . "/languages.inc.php");
require_once($application_includesdir . "/manage.inc.php");
require_once($application_includesdir . "/skins.inc.php");
require_once($application_includesdir . "/view.inc.php");
require_once($application_includesdir . "/zip.lib.php");

// Define functions which are used, but which did not exist before PHP version 4.3.0
if (version_compare(phpversion(), "4.3.0", "<")) {
	require_once($application_includesdir . "/before430.inc.php");
} 

// -------------------------------------------------------------------------
// Register global variables (POST, GET, GLOBAL, ...)
// -------------------------------------------------------------------------
require_once($application_includesdir . "/registerglobals.inc.php");

// -------------------------------------------------------------------------
// Load the plugins
// -------------------------------------------------------------------------
require_once($application_pluginsdir . "/plugins.inc.php");
getActivePlugins();


// -------------------------------------------------------------------------
// Load the language file
// -------------------------------------------------------------------------
includeLanguageFile();


// -------------------------------------------------------------------------
// Function libraries which are NOT always needed
// -------------------------------------------------------------------------

// Zip functions
if ($state == "manage" && $state2 == "uploadfile") {
	require_once($application_includesdir . "/pclerror.lib.php");
	require_once($application_includesdir . "/pcltrace.lib.php");
	require_once($application_includesdir . "/pcltar.lib.php");
	require_once($application_includesdir . "/pclzip.lib.php");
}

// Plugins which need to include a PHP file
integratePlugin("includePhpFiles");


// -------------------------------------------------------------------------
// Check authorizations
// -------------------------------------------------------------------------
if ($settings["check_authorization"] == "yes" && $net2ftp_ftpserver != "") {
	$result = checkAuthorization($net2ftp_ftpserver, $net2ftp_ftpserverport, $directory, $net2ftp_username);
	if ($execution_success == false) { printErrorMessage("exit", "headerfooter"); }
}


// -------------------------------------------------------------------------
// Log access
// -------------------------------------------------------------------------
logAccess();


// -------------------------------------------------------------------------
// Get the consumption counter values from the database
// This retrieves the consumption of network and server resources for the 
// current IP address and FTP server from the database, and stores these 
// values in global variables. See /includes/consumption.inc.php for the details.
// -------------------------------------------------------------------------
getConsumption();
if ($execution_success == false) { printErrorMessage(); }


// -------------------------------------------------------------------------
// Send HTTP headers
// -------------------------------------------------------------------------
require_once($application_includesdir . "/httpheaders.inc.php");


// -------------------------------------------------------------------------
// Begin HTML output
// -------------------------------------------------------------------------
HtmlBegin($state, $state2, $screen, $directory, $entry);
$execution_output = "yes";


// ------------------------------------------------------------------------
// Main switch; functions are in include files "functions_somename.inc.php"
// -------------------------------------------------------------------------

switch ($state) {
	case "homepage":
		homepage($state2);
	break;
	case "browse":
		browse($state2, $directory, $FormAndFieldName, $sort, $sortorder);
	break;
	case "manage":
		manage($state2, $directory, $entry, $list, $newNames, $formresult, $screen, $targetDirectories, $copymovedelete, $text, $textareaType, $uploadedFilesArray, $uploadedArchivesArray, $use_folder_names, $command, $to, $message, $zipactions, $searchoptions, $comparison);
	break;
	case "easyWebsite":
		if ($settings['functionuse_easyWebsite'] == "yes") {
			easyWebsite($state2, $directory, $screen, $template, $standalone);
		}
		else {
			$errormessage = __("This function has been disabled by the Administrator of this website.");
			setErrorVars(false, $errormessage, debug_backtrace());
		}
	break;
	case "bookmark":
		if ($settings['functionuse_bookmark'] == "yes") {
			bookmark($directory, $url, $text);
		}
		else {
			$errormessage = __("This function has been disabled by the Administrator of this website.");
			setErrorVars(false, $errormessage, debug_backtrace());
		}
	break;
	case "advanced":
		if ($settings['functionuse_advanced'] == "yes") {
			advanced($state2, $directory, $entry, $formresult, $screen, $functionname);
		}
		else {
			$errormessage = __("This function has been disabled by the Administrator of this website.");
			setErrorVars(false, $errormessage, debug_backtrace());
		}
	break;
	case "logout":
		homepage_logout($state2);
	break;
	case "admin":
		admin($state2, $formresult, $dbusername2, $dbpassword2, $dbname2, $dbserver2, $sqlquerystring, $datefrom, $dateto);
	break;
	default:
		$resultArray['message'] = __("Unexpected state string. Exiting."); 
		setErrorVars(false, $errormessage, debug_backtrace());
	break;
}

// -------------------------------------------------------------------------
// Store the consumption counter values in the database
// Do this before printing the error message, or else no consumption is stored if an error occurs
// -------------------------------------------------------------------------
$endtime = microtime();
addConsumption(0, timer());
putConsumption();


// -------------------------------------------------------------------------
// If an error occured, print the error message
// printErrorMessage() is also called from registerglobals.inc.php and httpheaders.inc.php
// -------------------------------------------------------------------------
if ($execution_success == false) { printErrorMessage(); }


// -------------------------------------------------------------------------
// End HTML output
// -------------------------------------------------------------------------

HtmlEnd($state, $state2, $screen);


?>