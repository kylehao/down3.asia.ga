info.png was renamed from nuvola's original icon named help.png

