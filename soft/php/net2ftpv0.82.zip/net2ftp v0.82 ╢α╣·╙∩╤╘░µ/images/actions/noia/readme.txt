info.png      was renamed from noia's original icon named help.png
view_tree.png was renamed from noia's original icon named folder.png

button_cancel.png and button_ok.png come from the nuvola iconset

