ascend.png  was renamed from noia's original icon named 1uparrow.png
descend.png was renamed from noia's original icon named 1downarrow.png
colors.png  was renamed from noia's original icon named appearance.png
fonts.png   was renamed from noia's original icon named font.png
sound.png   was renamed from noia's original icon named kaboodle.png
java.png    was renamed from noia's original icon named java_src.png

