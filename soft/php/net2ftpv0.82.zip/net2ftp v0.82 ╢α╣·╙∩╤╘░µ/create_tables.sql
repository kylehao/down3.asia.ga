
#
# Table structure for table `net2ftp_logAccess`
#

DROP TABLE IF EXISTS net2ftp_logAccess;
CREATE TABLE net2ftp_logAccess (
  date date NOT NULL default '0000-00-00',
  time time NOT NULL default '00:00:00',
  remote_addr text NOT NULL,
  remote_port text NOT NULL,
  http_user_agent text NOT NULL,
  page text NOT NULL,
  ftpserver text NOT NULL,
  username text NOT NULL,
  state text NOT NULL,
  state2 text NOT NULL,
  directory text NOT NULL,
  file text NOT NULL,
  http_referer text NOT NULL,
  KEY index1 (date,time,ftpserver(100),username(50))
) TYPE=MyISAM;
# --------------------------------------------------------

#
# Table structure for table `net2ftp_logConsumptionFtpserver`
#

DROP TABLE IF EXISTS net2ftp_logConsumptionFtpserver;
CREATE TABLE net2ftp_logConsumptionFtpserver (
  date date NOT NULL default '0000-00-00',
  ftpserver varchar(255) NOT NULL default '0',
  dataTransfer int(10) unsigned default '0',
  executionTime mediumint(8) unsigned default '0',
  PRIMARY KEY  (date,ftpserver)
) TYPE=MyISAM;
# --------------------------------------------------------

#
# Table structure for table `net2ftp_logConsumptionIpaddress`
#

DROP TABLE IF EXISTS net2ftp_logConsumptionIpaddress;
CREATE TABLE net2ftp_logConsumptionIpaddress (
  date date NOT NULL default '0000-00-00',
  ipaddress varchar(15) NOT NULL default '0',
  dataTransfer int(10) unsigned default '0',
  executionTime mediumint(8) unsigned default '0',
  PRIMARY KEY  (date,ipaddress)
) TYPE=MyISAM;
# --------------------------------------------------------

#
# Table structure for table `net2ftp_logError`
#

DROP TABLE IF EXISTS net2ftp_logError;
CREATE TABLE net2ftp_logError (
  date date NOT NULL default '0000-00-00',
  time time NOT NULL default '00:00:00',
  ftpserver text NOT NULL,
  username text NOT NULL,
  message text NOT NULL,
  backtrace text NOT NULL,
  state text NOT NULL,
  state2 text NOT NULL,
  directory text NOT NULL,
  remote_addr text NOT NULL,
  remote_port text NOT NULL,
  http_user_agent text NOT NULL,
  KEY index1 (date,time,ftpserver(100),username(50))
) TYPE=MyISAM;
# --------------------------------------------------------

#
# Table structure for table `net2ftp_logLogin`
#

DROP TABLE IF EXISTS net2ftp_logLogin;
CREATE TABLE net2ftp_logLogin (
  date date NOT NULL default '0000-00-00',
  time time NOT NULL default '00:00:00',
  ftpserver text NOT NULL,
  username text NOT NULL,
  remote_addr text NOT NULL,
  remote_port text NOT NULL,
  http_user_agent text NOT NULL,
  KEY index1 (date,time,ftpserver(100),username(50))
) TYPE=MyISAM;

