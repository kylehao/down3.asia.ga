﻿<?php $config['name']='听松阁vip视频解析网';
$config['biaoti']='听松阁VIP视频解析站';
$config['keywords']='vip视频解析，听松阁vip视频解析，vip视频，vip视频解析站';
$config['miaoshu']='听松阁博主自己用的视频解析网站，自己的网站，自己用。';
$config['beijing']='images/bgimg.png';$config['tubiao']='images/favicon.ico';
$config['logo']='images/logo.png';
$config['link']='
<li><a href="./vip/" target="_blank" >全屏播放接口</a></li>';
$config['jiekou']='
<option value="http://api.baiyug.cn/vip/index.php?url=">推荐接口</option>
<option value="http://jiexi.92fz.cn/player/vip.php?url=">超清接口1</option>
<option value="http://jx.ejiafarm.com/dy.php?url=">超清接口2</option>

<option value="http://jx.vgoodapi.com/jx.php?url=">备用接口1</option>
<option value="http://jx.du2.cc/jx6.php?url=">备用接口2</option>
<option value="http://yun.mt2t.com/yun?url=">备用接口3</option>
<option value="http://api.ledboke.com/?url=">备用接口4</option>
<option value="http://jqaaa.com/jx.php?url=">备用接口5</option>
<option value="http://000o.cc/jx/ty.php?url=">备用接口6</option>
<option value="http://jx.52xftv.cn/?url=">备用接口7</option>
<option value="http://aikan-tv.com/?url=">备用接口8</option>
<option value="http://j.zz22x.com/jx/?url=">备用接口9</option>
<option value="http://jx.ejiafarm.com/yun.php?url=">备用接口10</option>
<option value="http://jqaaa.com/jx.php?url=">备用接口11</option>






';
$config['gonggao1']='听松阁解析站正式上线啦，本站是专为方便朋友而做的站，如果你有好的接口可以加群发送给我哦！';$config['tishilogg']='本站视频源于互联网视频网站，系互联网抓取所得，仅供学习交流。已支持以下网站视频播放(包含VIP电影)';
$config['footer']='Copyright © 2017-2018 <a href="http://www.free163.com" target="_blank"  >听松阁</a>  版权所有. 丨 <a href="http://vip.free163.com">VIP解析v1.0</a>'; ?>